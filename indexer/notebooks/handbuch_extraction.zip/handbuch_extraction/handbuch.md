<!-- PDF page 1 -->

Fabasoft

![img-0.jpeg](img-0.jpeg)

# Fabasoft eGov-Suite 2025

Benutzerhilfe

Gültig ab 19. Oktober 2025

<!-- PDF page 2 -->

Copyright © Fabasoft R&amp;D GmbH, A-4020 Linz, 2025.

Alle Rechte vorbehalten. Alle verwendeten Hard- und Softwarenamen sind Handelsnamen und/oder Marken der jeweiligen Hersteller.

Durch die Übermittlung und Präsentation dieser Unterlagen alleine werden keine Rechte an unserer Software, an unseren Dienstleistungen und Dienstleistungsresultaten oder sonstigen geschützten Rechten begründet.

Aus Gründen der einfacheren Lesbarkeit wird auf die geschlechtsspezifische Differenzierung, z. B. Benutzer/-innen, verzichtet. Entsprechende Begriffe gelten im Sinne der Gleichbehandlung grundsätzlich für beide Geschlechter.

Bitte beachten Sie, dass die in diesem Dokument enthaltenen Screenshots zu beschreibenden Zwecken dienen und von der tatsächlichen visuellen Darstellung im Produkt abweichen können.

Benutzerhilfe
2

<!-- PDF page 3 -->

Das Benutzerhandbuch für die Fabasoft eGov Suite Bayern wurde überarbeitet und ist nun neu strukturiert um Ihnen den Umgang damit zu erleichtern.

Es teilt sich in drei Teile: Teil I (Kapitel 1-3) und Teil II (Kapitel 4-7) sowie das Glossar.

Teil I führt Sie in die verschiedenen Prozesse, die Ihnen in der Fabasoft eGov Suite zur Verfügung stehen, ein. Hier finden Sie Hinweise zur Verwendung und Anwendung der Software (Wie verwende ich...? Was muss ich tun um...?).

Kapitel 1 befasst sich mit allgemeinen Hinweisen zur Bedingung, zum Beispiel dem Starten der Anwendung, einer kurzen Einführung in die Benutzeroberfläche oder den in der Fabasoft eGov Suite vorhandenen Tastenkombinationen.

Kapitel 2 enthält Informationen zu den Supportprozessen der Fabasoft eGov Suite, also grundlegenden Arbeitsschritten im Programm. Sie können hier beispielsweise nachlesen wie Sie ein neues Objekt erstellen, die Metadaten von Objekten bearbeiten, Dokumente über das Programm versenden können oder eine Suche im Programm starten.

Kapitel 3 bietet Ihnen einen Einblick in die Kernprozesse der Fabasoft eGov Suite. Entsprechend der üblichen Organisation eines Geschäftsgangs strukturiert, werden hier die Arbeitsschritte beschrieben, die Sie im Dienstalltag benötigen. So werden sie hier durch die notwendigen Schritte geführt, die sie ausführen müssen um eine Akte zu erstellen, eine Verfügung zu erstellen oder ein Schriftstück zu erfassen. Zu Beginn einiger Unterkapitel finden Sie einen Kasten mit Kurzbeschreibungen zu einer Auswahl an Kernprozessen.

Teil II bietet Ihnen eine Beschreibung der verschiedenen Elemente der Fabasoft eGov Suite. Hier finden Sie Informationen zu Zugriffsrechten (Kapitel 4) und Fachadministration (Kapitel 5), sowie Beschreibungen der Benutzerformulare (Kapitel 6) und der einzelnen Aktivitäten (Kapitel 7). Schließlich ein Glossar mit Erklärungen zu wichtigen Begriffen in der Fabasoft eGov Suite. In Teil II können Sie also die nötigen „Vokabeln“, Definitionen und Eigenschaften nachschlagen; Fragen wie „Was ist...?“, „Was bedeutet...?“, „Was macht...?“, „Wer kann...?“ werden hier beantwortet.

Benutzerhilfe
3

<!-- PDF page 4 -->

Benutzerhilfe

# Inhalt

1 Allgemeine Hinweise zur Bedienung 16
1.1 Starten des Fabasoft eGov-Suite Bayern Webbrowser-Clients 16
1.2 Beenden des Fabasoft eGov-Suite Bayern Webbrowser-Clients 17
1.3 Aufbau des Fabasoft eGov-Suite Bayern Webbrowser-Clients 19
1.3.1 Homescreen 19
1.3.2 Menüleiste 21
1.4 Arbeiten mit der Menüleiste 23
1.5 Arbeiten mit Schaltflächen 23
1.6 Barrierefreiheit 24
1.6.1 Hinweise zur Tastaturbedienung 24
1.6.2 Verstärkte Hervorhebung des Fokus bei Tastaturbedienung 24
1.6.3 Vergrößerung 24
1.6.4 Design im hohen Kontrast 25
1.6.5 Hinweise für den Gebrauch von Bildschirmleseprogrammen 25
1.6.6 Barrierefreiheit-Ausnahmen 26
1.7 Tastaturbedienung 28
1.7.1 Häufigste Tastenkombinationen 28
1.7.2 Globale Navigation 29
1.7.3 Kopfleiste 29
1.7.4 Menüs 30
1.7.5 Inhaltsbereich 31
1.7.6 Werkzeuge 39
1.7.7 Formulare 40
1.7.8 Prozessdarstellung 41
1.7.9 HTML-Editor 41
1.8 Arbeiten mit Listen 42
1.8.1 Inhaltsansicht 42
1.8.2 Detailansicht 43
1.8.3 Vorschauansicht 43
1.8.4 Einträge markieren 44
1.8.5 Datentabelle kopieren 44
1.8.6 Infobox 45
1.8.7 Spaltenbearbeitung in der Detailansicht 45
1.8.8 Listen im Eigenschaftseditor 46

4

<!-- PDF page 5 -->

Benutzerhilfe
5

# 2 Supportprozesse
47

## 2.1 Allgemeine Anwendungsfälle
47

### 2.1.1 Umgang mit Objekten
47

### 2.1.2 Hinweis: Die Dublettenprüfung kommt auch beim Erzeugen von Schlagwerten zum Einsatz. Für weitere Informationen zu Schlagwerten siehe Kapitel 2.6.8 „Synchronisierungs-Ausnahmen“
49

### 2.1.3 Hervorheben von Objekten
56

### 2.1.4 Versenden von Objekten
56

### 2.1.5 Kontextmenü
58

### 2.1.6 Spalteneinstellungen
58

### 2.1.7 Reihenfolge einer Objektliste verändern
63

### 2.1.8 Objektlisten
64

### 2.1.9 Umgang mit Aggregaten
69

## 2.2 Adressatenverwaltung
71

### 2.2.1 Globales Adressverzeichnis
71

### 2.2.2 Allgemeine Informationen zur Adressatenverwaltung
72

### 2.2.3 Rechtskonzept Kontaktraum
72

### 2.2.4 Einen Kontaktraum erzeugen
73

### 2.2.5 Ordner im Kontaktraum
73

### 2.2.6 Einen Adressaten erzeugen
74

### 2.2.7 Einen Verteiler erzeugen
74

### 2.2.8 Eine Organisation erzeugen
74

### 2.2.9 Einen Adressaten bearbeiten
74

### 2.2.10 Adressaten einem anderen Kontaktraum zuweisen
75

### 2.2.11 Schaltfläche Auswahl Adresstyp
75

## 2.3 Umgang mit Dokumenten
78

### 2.3.1 Ein Dokument erstellen
78

### 2.3.2 Die Schriftstücke eines Dokuments lesen oder bearbeiten
78

## 2.4 Öffnen des zugehörigen Objekts
79

## 2.5 IntelliHelp
80

## 2.6 Synchronisierungsfunktionalität „Folio Ordner“
81

### 2.6.1 Aktivierung der Synchronisierung
81

### 2.6.2 Synchronisierung erstmalig verwenden
82

### 2.6.3 Ordner und Dokumente für die Synchronisierung auswählen
83

### 2.6.4 Symbole für die Visualisierung des Status
84

### 2.6.5 Auflösen von Konflikten
85

### 2.6.6 Erweiterte Möglichkeiten
85

<!-- PDF page 6 -->

Benutzerhilfe

2.6.7 Mehrfache Mandanten oder Installationen 86
2.6.8 Synchronisierungs-Ausnahmen 87

2.7 Schlagwortkatalog 88
2.7.1 Ein Schlagwort erfassen 88
2.7.2 Vergeben von Schlagwerten 89
2.7.3 Ein Schlagwort suchen 89

2.8 Drucken 90
2.8.1 Ein Schriftstück ausdrucken 90
2.8.2 Seitenansicht 90
2.8.3 Einen Vorgang/eine Akte ausdrucken 90
2.8.4 Einen Aktenplan ausdrucken 93

2.9 Vorlagen und Textbausteine 93
2.9.1 Einen Dokumenttyp konfigurieren 94
2.9.2 Textbausteine und Dokumenteigenschaften 94
2.9.3 Ein Musterdokument erstellen 99
2.9.4 Objekt-Vorlagen 100

2.10 Versionierung 103
2.10.1 Eine Version manuell speichern 103
2.10.2 Eine Version anzeigen 104
2.10.3 Eine Version über die Zeitleiste anzeigen 105
2.10.4 Eine Version wiederherstellen 106
2.10.5 Ein Schriftstück mit einer Version vergleichen 107
2.10.6 Versionen löschen 107

2.11 Unterschreiben 108
2.12 Suche 108
2.12.1 Eine Suche starten 108
2.12.2 Objekte über Metadaten-Suche finden 110
2.12.3 Suche mit Platzhaltern 110
2.12.4 Eine Suche weiter einschränken 113
2.12.5 Kaskadierte Suche 114
2.12.6 Akten, Vorgänge und Dokumente über Volltextsuche finden 114
2.12.7 Akten, Vorgänge und Dokumente über phonetische Suche finden 116
2.12.8 Sammeln von Suchergebnissen 117
2.12.9 Übernehmen aller Suchergebnisse 118
2.12.10 Akten, Vorgänge und Dokumente im Online-Archiv finden 118
2.12.11 Eine Suche als Suchmuster speichern 119
2.12.12 Einen Suchordner einrichten und verwenden 119

6

<!-- PDF page 7 -->

Benutzerhilfe

2.12.13 Schnellsuche 120
2.12.14 Suche nach Objekten mittels Mindbreeze Suchfeld 122
2.12.15 Beispiele zur Mindbreeze Abfragesprache 124
2.12.16 Suchabfrage zusammenstellen 125

2.13 Auswertung über Berichte 127
2.13.1 Eine Auswertung eines Berichts durchführen 127

2.14 Stellvertretung 127
2.14.1 Standardwerte für Stellvertretungen definieren 127
2.14.2 Stellvertretungen auf Standardwerte zurücksetzen 130
2.14.3 Eine Stellvertretung erzeugen 131
2.14.4 Eine Stellvertretung ausüben 133
2.14.5 Eine Stellvertretung beenden 134

2.15 Verwendung von Teamrooms 135
2.15.1 Einen Teamroom erzeugen 135
2.15.2 Einladen zur Teilnahme an einem Teamroom 135
2.15.3 Einrichten von Berechtigungen in Teamrooms 136
2.15.4 In Teamrooms arbeiten 137
2.15.5 Ablegen von bestehenden Objekten in Teamrooms 137
2.15.6 Teamroom-Inhalte erfassen 138
2.15.7 Teamroom auflösen 138
2.15.8 Diskussionsforum 138
2.15.9 Verwaiste Objekte 138

2.16 Zugriffsrechte der einzelnen Stellen für Objekte am Schreibtisch 138
2.16.1 Stellen Sachbearbeitung, Leitung, Schriftgutverwaltung und Registratur 139
2.16.2 Stellen Poststelle, Vorlagenverwalter/in, Archivar/in, Sekretär 140
2.16.3 Stelle Fachadministration und OE-Administration 141

2.17 Darstellen von Formularen in eigenen Webbrowser Fenstern 143
2.18 Arbeiten mit kontextabhängigen Symbolen 144
2.19 Benutzerhilfe 145
2.19.1 Benutzerhilfe öffnen 145
2.19.2 In-Place Informationen 145

2.20 Office Integration 146
2.20.1 Microsoft Word Ribbons 148
2.20.2 Microsoft Outlook Ribbons 151

2.21 Viewer 152
2.21.1 Sidebar 153

<!-- PDF page 8 -->

Benutzerhilfe

2.21.2 Dokument durchsuchen 153
2.21.3 Blättern 154
2.21.4 Zoomen 154
2.21.5 Zum Drucken öffnen 154
2.21.6 Werkzeuge 154

2.22 Fachdaten 156
2.22.1 Fachdaten im Geschäftsobjekt verwenden 156
2.22.2 Einfügen von Fachdaten als DocProperties in Worddokumenten 157

2.23 Beilagen einfügen in Outlook 159

3 Kernprozesse 159
3.1 Erstellung und Pflege des Aktenplans 159
3.1.1 Einen Aktenplan anlegen 160
3.1.2 Einen Aktenplan pflegen 160
3.1.3 Einen Aktenplaneintrag hinzufügen 160
3.1.4 Einen Aktenplaneintrag bearbeiten 161
3.1.5 Eine Gültigkeit für einen Aktenplaneintrag festlegen 161

3.2 Behandlung von Akten 161
3.2.1 Eine Akte erzeugen 161
3.2.2 Die Metadaten einer Akte lesen bzw. bearbeiten 162
3.2.3 Bezüge eintragen 162
3.2.4 Eine Gültigkeit für eine Akte festlegen 165
3.2.5 Eine Akte löschen 165

3.3 Behandlung von Vorgängen 166
3.3.1 Einen Vorgang erzeugen 166
3.3.2 Einen Papiervorgang erzeugen 166
3.3.3 Einen Vorgang einer bestehenden Akte zuordnen 167
3.3.4 Einen Vorgang umschreiben 167
3.3.5 Einen Vorgang stornieren 167
3.3.6 Die Stornierung eines Vorgangs aufheben 167
3.3.7 Einen Vorgang duplizieren 168
3.3.8 Eine Unterschrift auf einen Vorgang anbringen 168
3.3.9 Laufweg von Vorgängen 169
3.3.10 Behandlung von Umlaufmappen 187

3.4 Behandlung von Erledigungen 195
3.4.1 Eine Erledigung erstellen 195
3.4.2 Geschäftszeichenbildung einer Erledigung 197
3.4.3 Einen Empfänger einer Erledigung definieren 197

8

<!-- PDF page 9 -->

Benutzerhilfe

3.4.4 Einen Dokumenttyp für eine Erledigung auswählen 203
3.4.5 Reinschriften 203
3.4.6 Den Inhalt einer Erledigung bearbeiten 205
3.4.7 Eine Erledigung kopieren oder duplizieren 205
3.4.8 Eine Erledigung löschen 206
3.4.9 Ablage 206
3.4.10 Behandlung von Registerblättern 207
3.4.11 Die Seitenansicht 211

3.5 Behandlung von Eingangsdokumenten 211

3.5.1 Ein Eingangsdokument erfassen 212
3.5.2 Eine E-Mail aus Microsoft Office Outlook in die Fabasoft eGov-Suite Bayern erfassen 212
3.5.3 Eine Sammelerfassung durchführen 214
3.5.4 Eine Einzelerfassung durchführen 215
3.5.5 Ein Eingangsdokument über den Kontextmenübefehl „Ändern zu Eingangsdokument“ erstellen 216
3.5.6 Revisionssicherheit für Eingangsdokumente 216
3.5.7 Ein Eingangsdokument prüfen bzw. sichten 217
3.5.8 Ein Eingangsdokument zu einem neuen Vorgang zuordnen 218
3.5.9 Eingangsdokument zu einem bestehenden Vorgang zuordnen 220

3.6 Behandlung von Schriftstücken 222

3.6.1 Ein Schriftstück zur Bearbeitung öffnen 222
3.6.2 Ein Schriftstück zum Lesen öffnen 222
3.6.3 Annotationen auf Schriftstücken 222
3.6.4 Schwärzen von Schriftstücken 235
3.6.5 Ein Schriftstück importieren/exportieren 239
3.6.6 Ein Schriftstück löschen oder stornieren 241
3.6.7 Ein Schriftstück direkt zu einem Vorgang zuordnen 241
3.6.8 Ein zugeordnetes Schriftstück einem Dokument als Kopie hinzufügen 242
3.6.9 Ein Schriftstück kopieren 243
3.6.10 Einen Postkorb auswählen 243
3.6.11 Ein Schriftstück aus dem Postkorb löschen 243

3.7 Status eines Geschäftsobjekts 244
3.8 XDOMEA 245

3.8.1 XDOMEA Paket importieren 245
3.8.2 XDOMEA Paket exportieren 245

3.9 Allgemeine Funktionen zu Dokumenten 246
3.9.1 Die Metadaten eines Dokuments lesen und bearbeiten 246

<!-- PDF page 10 -->

Benutzerhilfe
10

3.9.2 Ein Dokument stornieren 246
3.9.3 Die Stornierung eines Dokuments aufheben 247
3.9.4 Zulässige Schriftstück Objektklassen 247

3.10 Aussonderung und Auslagerung 247

3.10.1 Manuelle Aussonderung 248
3.10.2 Automatische Aussonderung 252

3.11 Management Center für Geschäftsobjekte 256

3.11.1 Funktionen der grafischen Darstellung 257
3.11.2 Dokumente 260
3.11.3 Aktivitäten 260
3.11.4 Aktueller Status der Dokumente 260
3.11.5 Fristen der Aktivitäten anzeigen 261
3.11.6 Offene Aktivitäten anzeigen 261
3.11.7 Berechtigte Benutzer anzeigen 262

3.12 Rechercheauftrag 262

3.12.1 Durchführung einer Recherche 263
3.12.2 Dokumentation der Suchen 266
3.12.3 Arbeiten mit Rechercheaufträgen 266
3.12.4 Vergabe von Rechten 267
3.12.5 Export 268

4 Zugriffsdefinitionen und Access Control Lists (ACLs) 268

4.1 Zugriffsdefinitionen 268

4.1.1 Zugriffsdefinition auswählen 268
4.1.2 Zugriffsdefinition entfernen 268
4.1.3 Zugriffsdefinitionen bei Vorlagen 269
4.1.4 Vordefinierte Zugriffsdefinitionen 269

4.2 ACLs 269

4.2.1 3-Welten-Philosophie 269
4.2.2 Zuordnung der Zugriffsrechte 270
4.2.3 Dynamische ACLs 270
4.2.4 Vorkonfigurierte ACLs 271
4.2.5 Vergabe von Zusatzberechtigungen 276
4.2.6 ACL für allgemein zugängliche Daten (Schreibtisch) 276
4.2.7 ACL für inaktive Objekte 276

5 Fachadministration 277

5.1 Definitionen 277
5.1.1 Aufbauorganisation 277

<!-- PDF page 11 -->

Benutzerhilfe

5.1.2 Benutzerverwaltung 279
5.1.3 Globaler Papierkorb 280
5.1.4 Feiertage und Zeitspannen 281
5.1.5 Workflow 282
5.1.6 Einen Bericht konfigurieren 283
5.1.7 Fachdaten am Aktenplaneintrag konfigurieren 284
5.1.8 Suchordner Administration 287
5.1.9 Verwalten von Transfer- und Aufbewahrungsfristen 289

5.2 Anleitungen zu Fachadminprozessen 290
5.2.1 Organisationseinheiten 290
5.2.2 Benutzer 291
5.2.3 Geschäftsgang 293

5.3 Softwarekomponenten und Komponentenobjekte 296
5.3.1 Eine lokale Softwarekomponente erzeugen 297
5.3.2 Komponentenobjekte erzeugen 297
5.3.3 Amts-/Dienstbezeichnungen verwalten 297
5.3.4 Synchronisierungsfunktionalität „Folio Ordner“ 297
5.3.5 Konfiguration Objektklassenzuordnung 297
5.3.6 Definieren einer Dateiendung für Annotationen 298

5.4 Aussonderung 298
5.4.1 Aktivierung der XDOMEA Aussonderung 298
5.4.2 Aktivieren der automatischen Aussonderung 299
5.4.3 AT-Job zum Löschen von archivierten Objekten 302
5.4.4 REST Urls für die automatische Aussonderung 303

5.5 Warteschlangen für die asynchrone Verarbeitung 305
5.5.1 Konfiguration der Warteschlangen 305
5.5.2 AT-Job zum Ausführen von Warteschlangen 306

5.6 Aktivieren des Fabasoft Viewers 307

5.7 Annotationen 308
5.7.1 Bulk-Job für Anzeige von annotiertem Inhalt und Originalinhalt 308
5.7.2 Konfiguration des Cachings für Annotationen 308
5.7.3 AT-Job für den Cleanup des Annotations-Caches 308
5.7.4 Konfiguration von Regeln für Schwärzung 309

5.8 Reorganisation 310
5.8.1 Erstellung einer Reorganisation 310
5.8.2 Durchführen einer Reorganisation 312
5.8.3 Konfiguration - Fachadministration 312

11

<!-- PDF page 12 -->

Benutzerhilfe

5.9 Neue Spalteneinstellungsdialoge freischalten 313
5.9.1 Aktivieren der Customizing App 313
5.9.2 Vorlagen und Voreinstellungen 313
5.9.3 Administrieren von Vorlagen und Voreinstellungen 315
5.9.4 Persönliche Voreinstellungen – Vorlagen und Voreinstellungen – Sammlung für Voreinstellungen 315
5.9.5 Zuordnung ändern 316

5.10 Konfigurieren der Anrede 317
5.10.1 Ausdruck zur Berechnung der Anrede 317
5.10.2 Kontext 318
5.10.3 Beispiel 319

6 Formulare 320
6.1 Allgemeine Formularseiten 320
6.1.1 Registerkarte „Aussonderung“ 320
6.1.2 Registerkarte „Laufweg“ 321
6.1.3 Registerkarte „Umschreibungen“ 321
6.1.4 Registerkarte „Bezüge“ 322
6.1.5 Registerkarte „Unterschriften“ 322
6.1.6 Registerkarte „Erstellung“ 323
6.1.7 Registerkarte „Sicherheit“ 324
6.1.8 Registerkarte „Fachdaten“ 325

6.2 Widget „Arbeitsvorrat“ 326
6.2.1 Registerkarte „Zu tun“ 326
6.2.2 Registerkarte „Zuletzt beendet“ 326
6.2.3 Registerkarte „Übernommene Aktivitäten“ 326
6.2.4 Registerkarte „Wiedervorlage“ 326

6.3 Aktenplan 327
6.4 Aktenplaneintrag 327
6.4.1 Registerkarte „Aktenplaneintrag“ 328
6.4.2 Registerkarte „Regeln“ 330
6.4.3 Registerkarte „FAI“ 330

6.5 Eingangsdokument 331
6.5.1 Registerkarte „Eingang“ 331
6.5.2 Registerkarte „Adressaten“ 332

6.6 Erledigung 333
6.6.1 Registerkarte „Erledigung“ 333
6.6.2 Registerkarte „Adressaten“ 335

12

<!-- PDF page 13 -->

Benutzerhilfe

6.6.3 Registerkarte „Anlagen“ 335
6.7 Umlaufmappe 336
6.7.1 Registerkarte „Umlaufmappe“ 336
6.7.2 Registerkarte „Unterschriften“ 337
6.8 Akte 338
6.8.1 Registerkarte „Akte“ 338
6.8.2 Registerkarte „Bezüge“ 339
6.9 Vorgang 339
6.9.1 Registerkarte „Vorgang“ 339
6.9.2 Registerkarte „Adressaten“ 342
6.9.3 Registerkarte „Bezüge“ 342
6.10 Verteilerlisten 343
6.11 Organisation 344
6.11.1 Registerkarte „Organisation“ 344
6.11.2 Registerkarte „Kontakt“ 345
6.11.3 Registerkarte „Erweitert“ 346
6.12 Person 347
6.12.1 Registerkarte „Person“ 347
6.12.2 Registerkarte „Kontakt“ 348
6.12.3 Registerkarte „Erweitert“ 349
6.13 Verteiler 350
6.14 Schlagwort 351
6.15 Dokumenttyp 352
6.15.1 Registerkarte „Dokumenttyp“ 352
6.15.2 Registerkarte „Regeln“ 353
6.15.3 Registerkarte „Versandoptionen“ 353
6.16 Benutzer 354
6.16.1 Registerkarte „Benutzer“ 354
6.16.2 Registerkarte „Umgebungen“ 356
6.17 Benutzerstellvertretung 357
6.18 Arbeitsumgebung (Administrative Sicht) 359
6.19 Organisationseinheit 361
6.20 Globaler Papierkorb 362
6.21 Feiertagstabelle 364
6.22 Feiertage 365

13

<!-- PDF page 14 -->

Benutzerhilfe

6.23 Zeitspanne 365
6.24 Amts-/Dienstbezeichnung 366
6.25 Softwarekomponente 367
6.26 Zugriffsdefinition 369

## 7 Aktivitäten 370

7.1 Die Aktivität Eingang 370
7.2 Die Aktivität Intern 370
7.3 Die Aktivität Ausgang 370
7.4 Die Aktivität Bearbeitung 371
7.5 Die Aktivität Starten 371
7.6 Die Aktivität Prüfen 371
7.7 Die Aktivität Überarbeiten 371
7.8 Die Aktivität Abschließen 371
7.9 Die Aktivität Aufgabe 372
7.10 Die Aktivität Versenden 372
7.11 Die Aktivität Medienübergang 372
7.12 Die Aktivität Reinschrift erstellen 372
7.13 Die Aktivität Weglegen 373
7.14 Die Aktivität Zum Akt 373
7.15 Die Aktivität Kenntnisnahme (Vorgang) 373
7.16 Die Aktivität Kenntnisnahme (hemmend) (Vorgang) 373
7.17 Die Aktivität Kenntnisnahme (Umlaufmappe) 373
7.18 Die Aktivität Kenntnisnahme (hemmend) (Umlaufmappe) 374
7.19 Die Aktivität Kenntnisnahme (Dokumente) 374
7.20 Die Aktivität Kenntnisnahme (hemmend) (Dokumente) 374
7.21 Die Aktivität Billigung 374
7.22 Die Aktivität Mitzeichnung 374
7.23 Die Aktivität Schlusszeichnung 375
7.24 Die Aktivität Abgabe 375
7.25 Die Aktivität Interner Eingang 375

## 8 Glossar 376

A 376
B 381

14

<!-- PDF page 15 -->

Benutzerhilfe
15

C 382
D 382
E 384
F 384
G 385
K 385
L 386
M 386
O 387
P 388
R 388
S 389
T 392
U 393
V 394
W 397
X 398
Z 398

<!-- PDF page 16 -->

Benutzerhilfe
16

# 1 Allgemeine Hinweise zur Bedienung

Beachten Sie die folgenden Punkte im Umgang mit dem Fabasoft eGov-Suite Bayern Webbrowser-Client:

- Beenden Sie immer zuerst alle offenen Transaktionen bevor Sie ein Fabasoft Webbrowser-Fenster schließen. Benutzen Sie dazu die Schaltflächen „Abbrechen“ bzw. „Weiter“.

**Abbrechen**
**Weiter**

Hinweis: Wenn Sie ein Fabasoft eGov-Suite Bayern Webbrowser-Fenster schließen, obwohl die Transaktion offen ist, wird ein Dialogfenster eingeblendet. Wenn Sie die offene Transaktion schließen möchten, bevor das Fenster geschlossen wird, klicken Sie auf die Schaltfläche „Abbrechen“. Wenn Sie das nicht tun und auf die Schaltfläche „OK“ klicken, gehen alle nicht gespeicherten Änderungen verloren.

- Die in der Fabasoft eGov-Suite Bayern Webbrowser-Umgebung zur Verfügung stehende Funktionalität ist in vielen Fällen konfigurierbar. Daher müssen nicht alle in den folgenden Kapiteln beschriebenen Themen in Ihrem System vorhanden sein.

# 1.1 Starten des Fabasoft eGov-Suite Bayern Webbrowser-Clients

Der Fabasoft eGov-Suite Bayern Webbrowser-Client bietet Ihnen eine intuitive, einfach zu erlernende und individuell anpassbare Benutzeroberfläche, die eine effiziente Bearbeitung und Verwaltung Ihrer täglichen Aufgaben ermöglicht.

Der Fabasoft eGov-Suite Bayern Webbrowser-Client wird wie eine beliebige Webseite in Ihrem am Computer installierten Webbrowser (Microsoft Edge, Mozilla Firefox, etc.) geöffnet.

- Starten Sie den Webbrowser durch einen Klick bzw. Doppelklick auf das Webbrowser-Symbol. Je nach Konfiguration des Betriebssystems befindet sich das Symbol (oder Icon)

![img-0.jpeg](img-0.jpeg)

- in der Schnellstartleiste
- direkt am Desktop
- Und/oder unter „Start“ &gt; „Windows Zubehör“

<!-- PDF page 17 -->

![img-1.jpeg](img-1.jpeg)

- Geben Sie in der Adresszeile die Adresse der entsprechenden Fabasoft eGov-Suite Bayern an. Falls Sie die Adresse nicht wissen, kontaktieren Sie bitte Ihren IT-Servicedesk.
Hinweis: Für einen schnellen Aufruf empfiehlt es sich, die Adresse zur Fabasoft eGov-Suite Bayern entweder als Startseite im Webbrowser festzulegen oder die Adresse zu den

![img-2.jpeg](img-2.jpeg)

Favoriten hinzuzufügen.

- Abhängig von der Konfiguration des Systems werden Sie aufgefordert Ihren Benutzernamen und Ihr Passwort einzugeben.

## 1.2 Beenden des Fabasoft eGov-Suite Bayern Webbrowser-Clients

Der Fabasoft eGov-Suite Bayern Webbrowser-Client wird beendet, indem alle Webbrowser-Fenster geschlossen werden, in denen der Fabasoft eGov-Suite Bayern WebbrowserClient geöffnet ist. Es muss keine spezielle Logout-Prozedur durchgeführt werden, jedoch sollten nicht

Benutzerhilfe

<!-- PDF page 18 -->

beendete Dateneingaben abgeschlossen werden. Ein Webbrowser-Fenster kann folgendermaßen geschlossen werden:

- Durch Klicken auf die Schaltfläche „Schließen“ des Webbrowsers

![img-3.jpeg](img-3.jpeg)

- Über die Tastenkombination Alt + F4
- Über den Befehl „Beenden“ aus dem Menü „Datei“ im Browser.

Nachdem Sie auf „Schließen“ geklickt haben, öffnet sich ein Dialogfenster, das folgendermaßen aussieht:

![img-4.jpeg](img-4.jpeg)

- Durch einen Klick auf „Seite verlassen“ schließt sich das Browserfenster.
- Durch einen Klick auf „Auf dieser Seite bleiben“ schließt sich das Dialogfenster und das Browserfenster bleibt geöffnet.

Hinweis: Je nach Browser bzw. Betriebssystem kann dieser Dialog in seinem Aussehen variieren, der Text „Fabasoft eGov-Suite Bayern wird beendet“ ist allerdings überall derselbe.

Benutzerhilfe
18

<!-- PDF page 19 -->

Benutzerhilfe
19

# 1.3 Aufbau des Fabasoft eGov-Suite Bayern Webbrowser-Clients

## 1.3.1 Homescreen

Nach der Anmeldung in Ihrer Fabasoft eGov-Suite Bayern befinden Sie sich am Homescreen:

![img-5.jpeg](img-5.jpeg)

## Fabasoft Logo oder Kundenlogo

Hier wird das Logo des Fabasoft Softwareproduktes oder ein Kundenlogo angezeigt.

## Widgets

Durch einen Klick auf eines der Widgets am Homescreen wechselt man standardmäßig in die Listenansicht des jeweiligen Objekts. (Bspw. Schreibtisch, Arbeitsvorrat oder die Favoriten)

<!-- PDF page 20 -->

Die Reihenfolge sowie die Größe der Widgets können entweder per Drag-and-drop oder per Kontextmenü geändert werden:

![img-6.jpeg](img-6.jpeg)

Auch weitere Objekte (wie zum Beispiel: Ordner oder Hyperlinks) können mit Drag-and-drop zu den bestehenden Widgets hinzugefügt werden. Dazu muss das gewünschte Objekt markiert werden und per Drag-and-drop in die Baumansicht gezogen werden.

Ein Widget kann über den Kontextmenübefehl „Entfernen“ entfernt werden.

Achtung: Für diverse Widgets ist ein Entfernen nicht vorgesehen, die Kontextmenüaktion „Entfernen“ steht bei diesen dementsprechend nicht zur Verfügung.

Ein Widget kann über die Einstellungen mittels „Starten Mit:“ als Startscreen festgelegt werden. Dieses wird beim Wiedereinstieg sofort angezeigt.

## Einen Hyperlink zu den Widgets hinzufügen

Um einen Hyperlink zum Homescreen hinzuzufügen, gehen Sie folgendermaßen vor:

1. Ziehen Sie den Link (sprich das kleine Symbol der Webseite, meistens links von der Adresse) auf den Schreibtisch in der Fabasoft eGov-Suite und klicken Sie im angezeigten Dialog auf „Ja“
2. Ziehen Sie nun den auf dem Schreibtisch erstellten Link auf den Homescreen (Auf „Home“ in der Baumansicht)

Um Widgets vom Homescreen zu entfernen existiert rechts oben der Button „Ansicht“:

![img-7.jpeg](img-7.jpeg)

Benutzerhilfe
20

<!-- PDF page 21 -->

Benutzereinstellungen

Regina Kainz (SG A1)

Durch einen Klick auf den Benutzernamen und anschließend unter „Meine Rollen“ können Sie die gewünschte Rolle auswählen um in diese zu wechseln.

Rolle wechseln

Rolle

Wählen Sie Ihre gewünschte Rolle aus

unsortiert

Details anzeigen (2)

[tbl-0.md](tbl-0.md)

Navigationsleiste

Zur einfachen Navigation innerhalb von tief verzweigten Teilbäumen stehen Navigationspfade zur Verfügung. Hierbei handelt es sich um Navigationselemente, die den Pfad zum aktuellen Dokument anzeigen.

Home · Schreibtisch

Durch Auswahl von einzelnen Elementen des Navigationspfads kann in der Hierarchie wieder zurück (nach oben) gewechselt werden.

1.3.2 Menüleiste

Für das Bearbeiten von Listen stehen die Menüleiste und die Symbolleiste zur Verfügung-
Hinweis: Die horizontale Menüleiste wird nur dann angezeigt, wenn in den Einstellungen die Option „Menüleiste anzeigen“ aktiviert ist.

Objekt Zwischenablage Ansicht Extras Einstellungen Versionen Archiv

Darüber hinaus wird rechts in derselben Menüleiste ein Suchfeld eingeblendet (Sofern Mindbreeze installiert)

Welche Menüs und Symbole zur Verfügung stehen, hängt von der Konfiguration, der aktuellen Objektliste und Ihren Einstellungen ab.

Wichtige Funktionen des Menüs werden als Schaltflächen angezeigt, um einen schnellen und effizienten Zugriff zu gewähren.

Benutzerhilfe

<!-- PDF page 22 -->

Hinweis: Die hier beschriebenen Schaltflächen stehen nicht in jedem Kontext zur Verfügung. Es sind nicht alle im System vorhandenen Schaltflächen beschrieben.

Beispiel: Die Schaltflächen „Postkorb auswählen“, „Postkorb aufräumen“ und „Verschieben“ stehen lediglich in dem Widget „Posteingang“ zur Verfügung.

Hinweis: Schaltflächen, deren Funktionen im aktuellen Kontext nicht verfügbar sind, werden grau angezeigt.

Beispiel: Ist kein Objekt selektiert wird die Schaltfläche „Kopieren“ grau angezeigt.

[tbl-0.md](tbl-0.md)

Benutzerhilfe
22

<!-- PDF page 23 -->

[tbl-1.md](tbl-1.md)

## 1.4 Arbeiten mit der Menüleiste

Die Menüleiste gliedert sich in einzelne, logisch strukturierte Menüs, welche entsprechende Befehle enthalten. Klicken Sie auf das gewünschte Menü, um die zugehörigen Befehle anzuzeigen.

![img-0.jpeg](img-0.jpeg)

Ein Klick auf einen Befehl führt diesen auf die markierten Objekte der Liste aus.

**Hinweis:** Befehle können weiter gegliedert sein. Dies wird durch ein Pfeilsymbol verdeutlicht. Bewegen Sie die Maus über diesen Eintrag oder klicken Sie darauf, um die darunterliegenden Menübefehle sichtbar zu machen.

**Hinweis:** Die verfügbaren Menüs und Befehle können je nach Kontext und selektierten Objekten variieren.

## 1.5 Arbeiten mit Schaltflächen

Standardmäßig stehen folgende Schaltflächen in einem Dialog zur Verfügung:

- **Abbrechen**
Alle vorgenommenen und nicht gespeicherten Änderungen werden verworfen und die Bearbeitung beendet.

- **Bearbeiten**
Je nach Art des Dialogs und Ihrer persönlichen Einstellungen wird ein Eigenschaftsfenster nur lesend angezeigt. Wechselt von der lesenden Ansicht in die Bearbeitungsansicht.

**Hinweis:** Diese Schaltfläche wird nur angezeigt, wenn die Metadaten eines Objekts lesend geöffnet sind.

Benutzerhilfe

<!-- PDF page 24 -->

Benutzerhilfe
24

- **Übernehmen**
Die vorgenommenen Änderungen werden gespeichert, jedoch wird die Bearbeitungsansicht nicht verlassen.
**Hinweis:** Diese Schaltfläche wird nur angezeigt, wenn die Metadaten eines Objekts bearbeitend geöffnet sind.

- **Weiter**
Die vorgenommenen Änderungen werden gespeichert und die Bearbeitungsansicht wird verlassen.

## 1.6 Barrierefreiheit

### 1.6.1 Hinweise zur Tastaturbedienung

#### 1.6.2
Die Fabasoft eGov-Suite bietet den vollen Zugang für Anwender, die statt mit der Maus mit der Tastatur arbeiten. Standard-Tastenkombinationen wie zum Beispiel `Strg + C`, die Sie vom Betriebssystem her gewohnt sind, können Sie auch in der Fabasoft eGov-Suite verwenden. Die unterstützten Tastenkombinationen finden Sie im Kapitel 1.6.2 Verstärkte Hervorhebung des Fokus bei Tastaturbedienung

Beim Arbeiten mit der Tastatur wird der Fokus verstärkt hervorgehoben (z. B. gelber Rand). Die verstärkte Hervorhebung wird automatisch bei Betätigung der `Tabulatortaste` oder `Umschalttaste + Tabulatortaste` aktiviert. Bei der ersten Mausverwendung wird die verstärkte Hervorhebung wieder deaktiviert.

### 1.6.3 Vergrößerung

Sie können Texte und Grafiken mit der Webbrowserfunktionalität beliebig vergrößern. Dabei passt sich das Layout des Webclients optimal an die eingestellte Größe an.

[tbl-2.md](tbl-2.md)

### 1.6.4 Design im hohen Kontrast

Die Fabasoft eGov-Suite unterstützt auch das Design im hohen Kontrast.

<!-- PDF page 25 -->

Hinweis: Falls sie den hohen Kontrast aktiviert haben, nachdem Sie die Fabasoft eGov-Suite bereits geöffnet haben, müssen Sie die Seite erneut laden, um die Änderungen im Produkt zu aktivieren.

## 1.6.5 Hinweise für den Gebrauch von Bildschirmleseprogrammen

Die Fabasoft eGov-Suite unterstützt den WAI-ARIA-Standard (Accessible Rich Internet Applications). WAI-ARIA wird aber nicht von allen Bildschirmleseprogrammen vollständig unterstützt.

Folgende Bildschirmleseprogramme sind für die Nutzung mit der Fabasoft eGov-Suite empfohlen:

- NVDA (NonVisual Desktop Access) mit Mozilla Firefox oder Google Chrome
- JAWS mit Microsoft Edge, Google Chrome oder Mozilla Firefox

Benutzer, die Bildschirmleseprogramme nutzen, sollten folgende Einstellungen treffen:

1. Öffnen Sie das Kontomenü (Ihr Benutzername) und wählen Sie „Grundeinstellungen" aus.
2. Wechseln Sie auf die Registerkarte „Bedienungshilfen".
3. Aktivieren Sie die Option Alle Felder in die Tabreihenfolge aufnehmen. Dadurch werden auch Read-only-Felder in die Tabulatorreihenfolge aufgenommen.

Hinweis: Bei Verwendung von Apple Safari müssen Sie im Webbrowser zusätzlich folgende Option aktivieren: „Safari" &gt; „Einstellungen" &gt; „Erweitert" &gt; Über Tabulator jedes Objekt auf einer Webseite hervorheben.

4. Aktivieren Sie die Option Tabellarischen Modus für Vorschreibungen verwenden, da der im Workflow standardmäßig angezeigte grafische Prozesseditor nicht für die Bedienung mit der Tastatur geeignet ist.
5. Aktivieren Sie die Option Textalternative für farblich hervorgehobene Felder anzeigen.
6. Aktivieren Sie die Option Fremdsprachige Ausdrücke für Sprachausgabe aufbereiten. Damit können festlegen, dass wohlbekannte englischsprachige Begriffe speziell ausgezeichnet werden, um eine korrekte Aussprache zu gewährleisten.
7. Speichern Sie die Änderungen über die Schaltfläche „Speichern".

## Hinweis:

- Der Webclient passt sich automatisch der Größe des Webbrowserfensters an. Das heißt, dass einige Bereiche temporär ausgeblendet werden, falls der Platz nicht ausreicht. Bei Verwendung von Bildschirmleseprogrammen sollte das Webbrowserfenster maximiert sein (Windows-Taste + Aufwärts), damit sich immer alle Elemente in der Tabulatorreihenfolge befinden.
- Sollte Ihr Bildschirmleseprogramm einen Lesemodus im Webbrowser anbieten, in dem Sie z. B. Tasten zur Schnellnavigation auf den Webseiten verwenden können, kann es notwendig sein, diesen Modus aus- und wieder einzuschalten. Ob das Bildschirmleseprogramm Ihren manuellen Eingriff benötigt, merken Sie daran, ob die Tastenkombinationen der Fabasoft eGov-Suite funktionieren.
- Wenn die Braille-Ausgabe Ihres Bildschirmleseprogramms zwischen einer flachen und einer strukturierten Darstellung unterscheidet, müssen Sie die strukturierte Darstellung einstellen.

Benutzerhilfe
25

<!-- PDF page 26 -->

Benutzerhilfe

# Nützliche JAWS-Einstellungen

Die folgenden JAWS-Einstellungen erlauben ein optimales Arbeiten mit der Fabasoft eGov-Suite.

Führen Sie in JAWS folgende Schritte durch:

1. Öffnen Sie die Fabasoft eGov-Suite im Webbrowser Ihrer Wahl.
2. Öffnen Sie die JAWS-Schnelleinstellungen mit JAWS-Taste + V. Alle notwendigen Einstellungen befinden sich in der letzten Kategorie „Personalisierte Web-Einstellungen“. Diese Einstellungen gelten somit nur für die Fabasoft eGov-Suite.
3. Deaktivieren Sie die Einstellung „Dokument automatisch lesen“.
4. Wählen Sie für die Einstellung „Dokumentpräsentation“ den Wert „Einfaches Layout“ aus.
5. Sollten Sie andere Web-Einstellungen von JAWS allgemein geändert haben, könnte es notwendig sein, diese hier wieder auf die Voreinstellungen zurückzusetzen.

## 1.6.6 Barrierefreiheit-Ausnahmen

Folgende Funktionalität ist nur eingeschränkt bzw. nicht barrierefrei nutzbar:

- BPMN-Editor
- Dokumentenansicht
- Inhalt von Widgets
- Teamroom-Neuigkeiten
- Anpassen von Bildern
- Menüs in Listenzellen
- Manuelles Sortieren von Listen

### 1.6.6.1 BPMN-Editor

Der BPMN-Editor dient zur grafischen Modellierung von Geschäftsprozessen, die direkt ausgeführt werden können. Der BPMN-Editor wird angezeigt, wenn Sie ein BPMN-Prozessdiagramm, BPMN-Choreographiediagramm bzw. BPMN-Konversationsdiagramm öffnen.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (die grafische Modellierung ist nur mittels Maus möglich).

### 1.6.6.2 Dokumentenansicht

Die Dokumentenansicht dient zur integrierten PDF-Vorschau von Dokumenten. Die Dokumentenansicht wird im Inhaltsbereich angezeigt, wenn Sie in ein Dokument navigieren.

Bildschirmleseprogramme werden nicht unterstützt (Dokumentstruktur und Navigation sind nicht barrierefrei).

Alternativ können Dokumente im entsprechenden Drittprodukt geöffnet werden (wenn zulässig).

26

<!-- PDF page 27 -->

Benutzerhilfe

## 1.6.6.3 Inhalt von Widgets

Widgets zeigen Vorschaulisten bzw. Grafiken und dienen in Dashboards als Zugangspunkt zu den entsprechenden Bereichen. Widgets werden in der Inhaltsansicht zum Beispiel direkt auf „Home“ angezeigt.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (der Zugriff auf Vorschaulisten ist nicht möglich bzw. gibt es keine Textalternativen für Grafiken).

Alternativ kann in das Widget navigiert werden, um zur vollständigen, barrierefreien Information zu gelangen.

## 1.6.6.4 Teamroom-Neuigkeiten

Die Teamroom-Neuigkeiten dienen zur Anzeige von Änderungen im Teamroom. Die Neuigkeiten werden auf Registerkarten mit unterschiedlichen Filterkriterien dargestellt. Die Neuigkeiten werden angezeigt, wenn Sie den Befehl „Neuigkeiten anzeigen“ ausführen.

Bildschirmleseprogramme werden auf den Registerkarten „Neuigkeiten“ und „Timeline“ nicht unterstützt.

Alternativ können die Registerkarten „Chronik“, „Nach Objekten“, „Nach Kategorie“ und „Nach Benutzer“ verwendet werden.

## 1.6.6.5 Anpassen von Bildern

Bilder können skaliert und zugeschnitten werden. Die integrierte Bildbearbeitung ist zum Beispiel beim Festlegen von Logos oder Benutzerbildern möglich.

Bildschirmleseprogramme werden nicht unterstützt (beim Skalieren über den Slider ist die Bildgröße nicht ermittelbar).

## 1.6.6.6 Menüs in Listenzellen

Menüs in Listenzellen dienen zum direkten ausführen von Befehlen bezogen auf die Zeile. Menüs in Listen werden im Arbeitsvorrat zum Ausführen von Arbeitsschritten von Aktivitäten verwendet.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (das Menü ist nicht erreichbar).

Alternativ können Sie in eine Aktivität navigieren und die entsprechende Arbeitsschritt-Aktion ausführen oder das Kontextmenü verwenden.

## 1.6.6.7 Manuelles Sortieren von Listen

Einträge in Listen können manuell angeordnet werden. Die Positionierung ist mittels Drag-and-drop möglich.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (die manuelle Sortierung ist nur mittels Maus möglich).

27

<!-- PDF page 28 -->

Benutzer, die ausschließlich die Tastatur benutzen, sollten folgende Einstellungen treffen:

1. Öffnen Sie das Kontomenü (Ihr Benutzername) und wählen Sie „Einstellungen“ aus.
2. Wechseln Sie auf die Registerkarte „Workflow“.
3. Aktivieren Sie die Option Erweiterten Modus für Vorschreibungen standardmäßig verwenden da der im Workflow standardmäßig angezeigte grafische Prozesseditor nicht für die Bedienung mit der Tastatur geeignet ist.
4. Wechseln Sie auf die Registerkarte „Barrierefreiheit“.
5. Falls Sie Farben nicht oder schlecht erkennen, aktivieren Sie die Option Textalternative für farblich hervorgehobene Felder anzeigen.
6. Falls Sie Hintergrundbilder als störend empfinden, deaktivieren Sie die Option Hintergrundbilder in Dashboards und Home anzeigen.
7. Falls Sie einen verstärkten Kontrast benötigen, aktivieren Sie die Option Kontrast verstärken.
8. Speichern Sie die Änderungen über die Schaltfläche „Speichern“.

## 1.6.7 Verstärkte Hervorhebung des Fokus bei Tastaturbedienung

Beim Arbeiten mit der Tastatur wird der Fokus verstärkt hervorgehoben (z. B. gelber Rand). Die verstärkte Hervorhebung wird automatisch bei Betätigung der Tabulatortaste oder Umschalttaste + Tabulatortaste aktiviert. Bei der ersten Mausverwendung wird die verstärkte Hervorhebung wieder deaktiviert.

## 1.6.8 Vergrößerung

Sie können Texte und Grafiken mit der Webbrowserfunktionalität beliebig vergrößern. Dabei passt sich das Layout des Webclients optimal an die eingestellte Größe an.

[tbl-3.md](tbl-3.md)

## 1.6.9 Design im hohen Kontrast

Die Fabasoft eGov-Suite unterstützt auch das Design im hohen Kontrast.

**Hinweis:** Falls sie den hohen Kontrast aktiviert haben, nachdem Sie die Fabasoft eGov-Suite bereits geöffnet haben, müssen Sie die Seite erneut laden, um die Änderungen im Produkt zu aktivieren.

Benutzerhilfe
28

<!-- PDF page 29 -->

Benutzerhilfe

# 1.6.10 Hinweise für den Gebrauch von Bildschirmleseprogrammen

Die Fabasoft eGov-Suite unterstützt den WAI-ARIA-Standard (Accessible Rich Internet Applications). WAI-ARIA wird aber nicht von allen Bildschirmleseprogrammen vollständig unterstützt.

Folgende Bildschirmleseprogramme sind für die Nutzung mit der Fabasoft eGov-Suite empfohlen:

- NVDA (NonVisual Desktop Access) mit Mozilla Firefox oder Google Chrome
- JAWS mit Microsoft Edge, Google Chrome oder Mozilla Firefox

Benutzer, die Bildschirmleseprogramme nutzen, sollten folgende Einstellungen treffen:

6. Öffnen Sie das Kontomenü (Ihr Benutzername) und wählen Sie „Grundeinstellungen“ aus.
7. Wechseln Sie auf die Registerkarte „Bedienungshilfen“.
8. Aktivieren Sie die Option *Alle Felder in die Tabreihenfolge aufnehmen*. Dadurch werden auch Read-only-Felder in die Tabulatorreihenfolge aufgenommen.

**Hinweis:** Bei Verwendung von Apple Safari müssen Sie im Webbrowser zusätzlich folgende Option aktivieren: „Safari“ &gt; „Einstellungen“ &gt; „Erweitert“ &gt; Über Tabulator jedes Objekt auf einer Webseite hervorheben.

9. Aktivieren Sie die Option *Tabellarischen Modus für Vorschreibungen verwenden*, da der im Workflow standardmäßig angezeigte grafische Prozesseditor nicht für die Bedienung mit der Tastatur geeignet ist.
10. Aktivieren Sie die Option *Textalternative für farblich hervorgehobene Felder anzeigen*.
11. Aktivieren Sie die Option *Fremdsprachige Ausdrücke für Sprachausgabe aufbereiten*. Damit können festlegen, dass wohlbekannte englischsprachige Begriffe speziell ausgezeichnet werden, um eine korrekte Aussprache zu gewährleisten.
12. Speichern Sie die Änderungen über die Schaltfläche „Speichern“.

**Hinweis:**

- Der Webclient passt sich automatisch der Größe des Webbrowserfensters an. Das heißt, dass einige Bereiche temporär ausgeblendet werden, falls der Platz nicht ausreicht. Bei Verwendung von Bildschirmleseprogrammen sollte das Webbrowserfenster maximiert sein (Windows-Taste + Aufwärts), damit sich immer alle Elemente in der Tabulatorreihenfolge befinden.
- Sollte Ihr Bildschirmleseprogramm einen Lesemodus im Webbrowser anbieten, in dem Sie z. B. Tasten zur Schnellnavigation auf den Webseiten verwenden können, kann es notwendig sein, diesen Modus aus- und wieder einzuschalten. Ob das Bildschirmleseprogramm Ihren manuellen Eingriff benötigt, merken Sie daran, ob die Tastenkombinationen der Fabasoft eGov-Suite funktionieren.
- Wenn die Braille-Ausgabe Ihres Bildschirmleseprogramms zwischen einer flachen und einer strukturierten Darstellung unterscheidet, müssen Sie die strukturierte Darstellung einstellen.

# Nützliche JAWS-Einstellungen

Die folgenden JAWS-Einstellungen erlauben ein optimales Arbeiten mit der Fabasoft eGov-Suite.

29

<!-- PDF page 30 -->

Führen Sie in JAWS folgende Schritte durch:

13. Öffnen Sie die Fabasoft eGov-Suite im Webbrowser Ihrer Wahl.
14. Öffnen Sie die JAWS-Schnelleinstellungen mit JAWS-Taste + V. Alle notwendigen Einstellungen befinden sich in der letzten Kategorie „Personalisierte Web-Einstellungen“. Diese Einstellungen gelten somit nur für die Fabasoft eGov-Suite.
15. Deaktivieren Sie die Einstellung „Dokument automatisch lesen“.
16. Wählen Sie für die Einstellung „Dokumentpräsentation“ den Wert „Einfaches Layout“ aus.
17. Sollten Sie andere Web-Einstellungen von JAWS allgemein geändert haben, könnte es notwendig sein, diese hier wieder auf die Voreinstellungen zurückzusetzen.

## 1.6.11 Barrierefreiheit-Ausnahmen

Folgende Funktionalität ist nur eingeschränkt bzw. nicht barrierefrei nutzbar:

- BPMN-Editor
- Dokumentenansicht
- Inhalt von Widgets
- Teamroom-Neuigkeiten
- Anpassen von Bildern
- Menüs in Listenzellen
- Manuelles Sortieren von Listen

### 1.6.11.1 BPMN-Editor

Der BPMN-Editor dient zur grafischen Modellierung von Geschäftsprozessen, die direkt ausgeführt werden können. Der BPMN-Editor wird angezeigt, wenn Sie ein BPMN-Prozessdiagramm, BPMN-Choreographiediagramm bzw. BPMN-Konversationsdiagramm öffnen.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (die grafische Modellierung ist nur mittels Maus möglich).

### 1.6.11.2 Dokumentenansicht

Die Dokumentenansicht dient zur integrierten PDF-Vorschau von Dokumenten. Die Dokumentenansicht wird im Inhaltsbereich angezeigt, wenn Sie in ein Dokument navigieren.

Bildschirmleseprogramme werden nicht unterstützt (Dokumentstruktur und Navigation sind nicht barrierefrei).

Alternativ können Dokumente im entsprechenden Drittprodukt geöffnet werden (wenn zulässig).

Benutzerhilfe
30

<!-- PDF page 31 -->

Benutzerhilfe

# 1.6.11.3 Inhalt von Widgets

Widgets zeigen Vorschaulisten bzw. Grafiken und dienen in Dashboards als Zugangspunkt zu den entsprechenden Bereichen. Widgets werden in der Inhaltsansicht zum Beispiel direkt auf „Home“ angezeigt.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (der Zugriff auf Vorschaulisten ist nicht möglich bzw. gibt es keine Textalternativen für Grafiken).

Alternativ kann in das Widget navigiert werden, um zur vollständigen, barrierefreien Information zu gelangen.

# 1.6.11.4 Teamroom-Neuigkeiten

Die Teamroom-Neuigkeiten dienen zur Anzeige von Änderungen im Teamroom. Die Neuigkeiten werden auf Registerkarten mit unterschiedlichen Filterkriterien dargestellt. Die Neuigkeiten werden angezeigt, wenn Sie den Befehl „Neuigkeiten anzeigen“ ausführen.

Bildschirmleseprogramme werden auf den Registerkarten „Neuigkeiten“ und „Timeline“ nicht unterstützt.

Alternativ können die Registerkarten „Chronik“, „Nach Objekten“, „Nach Kategorie“ und „Nach Benutzer“ verwendet werden.

# 1.6.11.5 Anpassen von Bildern

Bilder können skaliert und zugeschnitten werden. Die integrierte Bildbearbeitung ist zum Beispiel beim Festlegen von Logos oder Benutzerbildern möglich.

Bildschirmleseprogramme werden nicht unterstützt (beim Skalieren über den Slider ist die Bildgröße nicht ermittelbar).

# 1.6.11.6 Menüs in Listenzellen

Menüs in Listenzellen dienen zum direkten ausführen von Befehlen bezogen auf die Zeile. Menüs in Listen werden im Arbeitsvorrat zum Ausführen von Arbeitsschritten von Aktivitäten verwendet.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (das Menü ist nicht erreichbar).

Alternativ können Sie in eine Aktivität navigieren und die entsprechende Arbeitsschritt-Aktion ausführen oder das Kontextmenü verwenden.

# 1.6.11.7 Manuelles Sortieren von Listen

Einträge in Listen können manuell angeordnet werden. Die Positionierung ist mittels Drag-and-drop möglich.

Tastaturbedienung und Bildschirmleseprogramme werden nicht unterstützt (die manuelle Sortierung ist nur mittels Maus möglich).

31

<!-- PDF page 32 -->

Benutzerhilfe
32

# 1.7 Tastaturbedienung

Neben der Bedienung der Benutzeroberfläche mit der Maus wird auch die Bedienung mit der Tastatur unterstützt. In den folgenden Kapiteln sind die verfügbaren Tastenkombinationen gruppiert nach Anwendungsbereichen angeführt.

Hinweis: Auf Apple macOS wird die Cmd-Taste gleich wie die Strg-Taste unter Microsoft Windows behandelt.

# 1.7.1 Häufigste Tastenkombinationen

[tbl-4.md](tbl-4.md)

# 1.7.2 Globale Navigation

Alle Steuerelemente befinden sich in der Tabulator-Reihenfolge. Das bedeutet, dass Sie sich von einem Steuerelement zum anderen vorwärts und rückwärts bewegen können.

[tbl-5.md](tbl-5.md)

<!-- PDF page 33 -->

Benutzerhilfe
33

[tbl-6.md](tbl-6.md)

Innerhalb einzelner komplexer Steuerelemente, wie z.B. Menüs oder Strukturansichten können die Pfeiltasten eingesetzt werden, um in Untermenüs oder Baumverzweigungen zu navigieren.

## 1.7.3 Kopfleiste

In der Kopfleiste stehen Ihnen die folgenden Tastenkombinationen zur Verfügung.

[tbl-7.md](tbl-7.md)

## 1.7.4 Menüs

Folgende Menüs stehen Ihnen zur Verfügung:

<!-- PDF page 34 -->

- Menüleiste der Objektliste
Die Menüleiste kann über die Grundeinstellungen aktiviert werden und befindet sich über dem Inhaltsbereich.

- Werkzeuge
Kann zum Anzeigen und Ausblenden von Werkzeugen verwendet werden.

- Aktionen
Bietet die wichtigsten Aktionen zur angezeigten Liste bzw. zum angezeigten Objekt.

- Kontomenü
Das Kontomenü mit Ihrem Namen befindet sich in der Kopfleiste und ermöglicht grundsätzliche Einstellungen zu treffen.

- Sortieren
Das Sortieren-Menü kann über die Anzeige der Anzahl und Sortierung der Einträge im Inhaltsbereich geöffnet werden. Die Anzeige zur Sortierung erreichen Sie durch Drücken von Alt + F9, wenn sich der Fokus in der Objektliste befindet.

- Spaltenmenü
Kann über die Spalten im Inhaltsbereich geöffnet werden.

- Kontextmenü
Bietet Befehle für ausgewählte Objekte. Wird mit der Kontextmenü-Taste oder mit Umschalttaste + F10 geöffnet.

[tbl-8.md](tbl-8.md)

Benutzerhilfe
34

<!-- PDF page 35 -->

Benutzerhilfe
35

[tbl-9.md](tbl-9.md)

## 1.7.5 Inhaltsbereich

Das wichtigste Steuerelement im Inhaltsbereich ist die Objektliste. Zu ihr gehören die Titelleiste und die Menüleiste, die direkt darüber positioniert sind.

Objektlisten bieten im Allgemeinen folgende unterschiedliche Ansichten:

- Details
- Miniaturen
- Karten
- Inhalt
- Vorschau

Einzelne Objekte werden in der sogenannten Dokumentenansicht angezeigt.

## 1.7.5.1 Tastenkombinationen für alle Ansichten

Im Allgemeinen können Sie die Darstellung von Objektlisten individuell anpassen. Die Ansicht kann entweder über den Menübefehl oder Kontextmenübefehl „Ansicht ändern“ geändert werden. Der Kontextmenübefehl ist nur verfügbar, wenn kein Objekt ausgewählt ist.

### Auswählen, Kopieren und Einfügen

[tbl-10.md](tbl-10.md)

<!-- PDF page 36 -->

Benutzerhilfe
36

[tbl-11.md](tbl-11.md)

## Aktionen

[tbl-12.md](tbl-12.md)

<!-- PDF page 37 -->

Benutzerhilfe
37

Alt + F10
Navigiert zum Menü der Objektliste.

## 1.7.5.2 Tastenkombinationen für die Kartenansicht

Die Kartenansicht wird zum Beispiel standardmäßig in der persönlichen Ablage verwendet.

[tbl-13.md](tbl-13.md)

## 1.7.5.3 Tastenkombinationen für die Inhaltsansicht

[tbl-14.md](tbl-14.md)

<!-- PDF page 38 -->

Benutzerhilfe
38

Pos1 | Navigiert zum ersten Objekt.
---|---
Umschalttaste + Abwärts | Erweitert die Auswahl auf das nächste Objekt.
Umschalttaste + Aufwärts | Erweitert die Auswahl auf das vorherige Objekt.
Umschalttaste + Ende | Erweitert die Auswahl bis zum letzten Objekt.
Umschalttaste + Pos1 | Erweitert die Auswahl bis zum ersten Objekt.
Alt + F9 | Navigiert zur Schaltfläche „Sortieren“.
Alt + F10 | Navigiert in die Menüleiste der Objektliste, falls diese eingeblendet ist.

1.7.5.4 Tastenkombinationen für die Detailansicht

[tbl-15.md](tbl-15.md)

<!-- PDF page 39 -->

Benutzerhilfe
39

[tbl-16.md](tbl-16.md)

Über den Spaltenkopf sind die Spaltenfilter erreichbar. Der Werte-Filter von Datumswerten wird durch eine Baumstruktur abgebildet. Es besitzt immer nur ein Baumelement einen *tabindex*. Mit den Pfeiltasten, Pos 1 und Ende kann zwischen den Baumelementen navigiert werden. Ob ein Element aufgeklappt ist, ist für Screenreader über das Attribut `aria-expanded` ersichtlich. Wenn untergeordnete Baumelemente nur teilweise ausgewählt wurden (zum Beispiel in einem Monat nur ein Tag von mehreren), dann besitzen die übergeordneten Baumelemente den Zustand "Teilweise ausgewählt". Dieser wird bei Verwendung von Screenreadern mit dem Attribut `aria-checked="mixed"` verdeutlicht. Bei der Auswahl eines teilweise ausgewählten Elements werden alle untergeordneten Elemente ausgewählt.

## 1.7.5.5 Tastenkombinationen für die Tabellenbearbeitung

In der Detailansicht kann über die Schaltfläche „Tabellenbearbeitung“ (Alt + F2) im Spaltenkopf die alternativ zur Verfügung stehende Tabellenbearbeitung aktiviert werden. Dadurch funktioniert die Bedienung ähnlich einem Tabellenkalkulationsprogramm.

[tbl-17.md](tbl-17.md)

<!-- PDF page 40 -->

[tbl-18.md](tbl-18.md)

Benutzerhilfe
40

<!-- PDF page 41 -->

[tbl-19.md](tbl-19.md)

Benutzerhilfe
41

<!-- PDF page 42 -->

[tbl-0.md](tbl-0.md)

## 1.7.5.6 Tastenkombinationen für die Dokumentansicht

Wenn Sie in ein Dokument navigieren, wird im Inhaltsbereich eine Vorschau des Dokuments angezeigt.

[tbl-1.md](tbl-1.md)

## 1.7.6 Werkzeuge

Werkzeuge werden im linken Bereich dargestellt und können direkt mit den Tastenkombinationen geöffnet werden. Dabei wird immer auch der Fokus in das Werkzeug bewegt. Sie finden diese Befehle im Kapitel 1.7.2 „Globale Navigation“.

## 1.7.6.1 Navigation (Baumansicht)

Die Baumansicht ermöglicht das Navigieren in Ordnerhierarchien.

[tbl-2.md](tbl-2.md)

Benutzerhilfe

<!-- PDF page 43 -->

Benutzerhilfe
43

[tbl-3.md](tbl-3.md)

## 1.7.6.2 Team und Facetten

Das Werkzeug „Berechtigungen“ zum Verwalten von Teammitgliedern ist im Sinne der Tastaturbedienung der Baumnavigation sehr ähnlich. Der einzige Unterschied dabei ist, dass hier die Hauptknoten immer offen bleiben. Um die Navigation zu beschleunigen, navigieren Sie mit den Pfeiltasten Aufwärts und Abwärts auf der obersten Ebene nicht zum nächsten oder vorherigen sichtbaren Eintrag, sondern direkt zwischen den Knoten auf oberster Ebene. Die tieferen Ebenen verhalten sich identisch mit der Navigation im Baum.

## 1.7.7 Formulare

Fabasoft Folio verwendet Formulare zur Darstellung von Eigenschaften und Einstellungen.

Hinweis: Screenreader-Benutzer sollten in den Grundeinstellungen die Option Alle Felder in die Tabreihenfolge aufnehmen aktivieren. Dadurch werden auch Read-only-Felder in die Tabulatorreihenfolge aufgenommen.

[tbl-4.md](tbl-4.md)

<!-- PDF page 44 -->

Benutzerhilfe
44

[tbl-5.md](tbl-5.md)

**Hinweis:** In Aggregatslisten gelten im Allgemeinen die gleichen Tastenkombinationen wie für die Detailansicht von Listen. Unterschiedlich ist jedoch, dass mit F2 in Aggregatslisten die gesamte Liste zwischen Editier- und Navigationsmodus umgeschaltet wird und nicht nur die jeweilige Zelle.

## 1.7.8 Prozessdarstellung

Die Prozessdarstellung, wie sie zum Beispiel auf der Registerkarte „Prozesse“ zu finden ist, wurde als eine offene, waagrechte Baumansicht implementiert. Der Unterschied zu einer Standard-Baumansicht ist jedoch, dass sich die Knoten nicht zuklappen lassen und die Hauptreihenfolge der Einträge nicht von oben nach unten, sondern von links nach rechts erfolgt.

[tbl-6.md](tbl-6.md)

<!-- PDF page 45 -->

Benutzerhilfe
45

[tbl-7.md](tbl-7.md)

## 1.7.9 HTML-Editor

Der HTML-Editor unterstützt zum Formatieren von Texten ähnliche Tastenkombinationen im Textbereich wie Microsoft Word.

Die wichtigsten Tastenkombinationen finden Sie in der folgenden Liste:

[tbl-8.md](tbl-8.md)

<!-- PDF page 46 -->

[tbl-9.md](tbl-9.md)

## 1.8 Arbeiten mit Listen

### 1.8.1 Inhaltsansicht

In der Inhaltsansicht werden Ihnen die wichtigsten Daten zu einem Objekt angezeigt.

![img-0.jpeg](img-0.jpeg)

### 1.8.2 Detailansicht

Die Detailansicht wird standardmäßig angezeigt. In dieser Liste können Sie sich weitere Informationen zu den entsprechenden Objekten über die Spalten einblenden.

Benutzerhilfe

<!-- PDF page 47 -->

![img-1.jpeg](img-1.jpeg)

## 1.8.3 Vorschauansicht

In der Vorschauansicht werden Ihnen die wichtigsten Metadaten zum Objekt und die Vorschau angezeigt. Bei Dokumenten werden die ersten Seiten angezeigt.

![img-2.jpeg](img-2.jpeg)

## 1.8.4 Einträge markieren

Sie können mehrere Objekte einer Liste markieren, um diese gleichzeitig zu bearbeiten.

### Mehrere Einträge auswählen

Um mehrere Einträge einer Liste zu markieren, klicken Sie bei gedrückter Strg-Taste auf die gewünschten Objekte oder markieren Sie die Objekte über das Auswahl-Kästchen.

- In der Inhaltsansicht wird das Kästchen erst angezeigt, wenn Sie die Maus über den rechten Bereich der Zeile bewegen bzw. in der Vorschauansicht erst, wenn Sie die Maus über den linken Bereich der Zeile bewegen.
- In der Detailansicht wird das Kästchen links neben der ersten Spalte dargestellt.
- In der Kartenansicht werden die Kästchen zum Markieren unter den Karten eingeblendet.

Benutzerhilfe

<!-- PDF page 48 -->

Benutzerhilfe
48

# Einen Bereich auswählen

Um einen Bereich der Liste auszuwählen, klicken Sie auf das erste Objekt und drücken Sie die Umschalttaste. Halten Sie die Umschalttaste gedrückt und klicken Sie auf den letzten gewünschten Eintrag. Dadurch werden alle Objekte zwischen den beiden Einträgen markiert.

## Alle markieren

Wählen Sie das Kästchen im Spaltenkopf aus um alle Einträge zu markieren (nur Detailansicht).

### 1.8.5 Datentabelle kopieren

Wenn Sie die Menüleiste einblenden, können Sie über den Menübefehl „Zwischenablage“ &gt; „Datentabelle“ &gt; „Kopieren“ die Liste in die Zwischenablage kopieren und z. B. in Microsoft Excel einfügen. Falls Zeilen markiert sind, werden nur diese in die Zwischenablage übernommen. Die Reihenfolge, in der die Zeilen markiert wurden, wird dabei berücksichtigt.

Hinweis: Wenn Sie „Kopieren (Erweitert)“ ausführen, werden zusätzlich zu den sichtbaren Spalten auch Einträge von eingeblendeten Objektlisten und alle Werte von Aggregaten und Aggregatslisten als verschachtelte Tabelle kopiert.

### 1.8.6 Infobox

Die Infobox wird nach ca. einer Sekunde eingeblendet, wenn sich Ihr Mauszeiger über dem Auswahlkästchen bzw. Symbol eines selektierten Objekts befindet und nicht bewegt wird. So erhalten Sie die wichtigsten Informationen, ohne das Objekt öffnen zu müssen.

Hinweis: In den „Einstellungen“ können Sie die Infobox über die Option „Hinweise zu Objekten anzeigen“ deaktivieren.

### 1.8.7 Spaltenbearbeitung in der Detailansicht

Wenn Sie eine Zelle markieren und die F2-Taste drücken, können Sie den Inhalt der Zelle direkt bearbeiten.

Für die effiziente Bearbeitung mehrerer Objekte gleichzeitig, stehen in der Detailansicht Möglichkeiten ähnlich einem Tabellenkalkulationsprogramm zur Verfügung.

Bearbeitungsmöglichkeiten:

- Kopieren (Strg + C)
- Ausschneiden (Strg + X)
- Einfügen (Strg + V)
- Löschen (Entf-Taste)

Es können mehrere auch nicht zusammenhängende Zellen innerhalb einer Spalte gleichzeitig kopiert und eingefügt werden. Ist die Anzahl der markierten Zellen beim Einfügen größer als die Anzahl der markierten Zellen beim Kopieren, wird wieder mit dem ersten Wert begonnen. Werden beim Einfügen weniger Zellen markiert, werden nur Werte in den markierten Zellen geändert.

Hinweis: Unter Linux werden keine leeren Objektzeiger kopiert.

<!-- PDF page 49 -->

Die Werte können auch von der Fabasoft Cloud kopiert und zum Beispiel in Microsoft Excel eingefügt werden. Das Einfügen von Werten aus Drittanwendungen in die Fabasoft Cloud ist nur bedingt möglich (abhängig vom Zwischenablageformat der Drittanwendung).

## 1.8.7.1 Tabellenbearbeitung

Über die Schaltfläche „Tabellenbearbeitung“ (Alt + F2) im Spaltenkopf die alternativ zur Verfügung stehende Tabellenbearbeitung aktiviert werden. Dadurch funktioniert die Bedienung ähnlich einem Tabellenkalkulationsprogramm:

- Die Zellen werden mit Rahmenlinien dargestellt.
- Die Hover-Hervorhebung wird pro Zelle angezeigt.
- Zellen die nicht bearbeitet werden können, werden mit grauem Hintergrund dargestellt.
- Die Bearbeitung einer Zelle wird mit F2, einem Doppelklick (schnell und langsam) bzw. durch Tippen von Buchstaben/Zahlen aktiviert.
- Ein Klick auf den Objektnamen öffnet das Objekt nicht.

## 1.8.8 Listen im Eigenschaftseditor

Um die Komplexität des Eigenschaftseditors zu reduzieren und die Übersicht zu verbessern, steht für Objekt- und Aggregatslisten eine vereinfachte Darstellung zur Verfügung. Über die Schaltfläche „Details anzeigen“ gelangen Sie zu einer seitenfüllenden, für die Bearbeitung optimierten Gesamtansicht der Liste.

### Vereinfachte Liste

Die reduzierten Bearbeitungsmöglichkeiten in der vereinfachten Liste ermöglichen einen verbesserten Überblick.

- Es wird keine Menüleiste angezeigt.
- Die Anzahl der angezeigten Einträge ist abhängig vom Kontext beschränkt. Im Allgemeinen werden maximal 15 Einträge angezeigt. Über die Schaltfläche „Weitere Einträge“ gelangen Sie zur Gesamtansicht.
- Sortierungen und Gruppierungen können in der vereinfachten Liste nicht vorgenommen werden. Diese werden von den Einstellungen in der Gesamtansicht übernommen.
- Es werden nur so viele Spalten angezeigt wie Platz zur Verfügung steht. Somit können horizontale Scrollbalken vermieden werden.
- Vorschaubilder werden in der Detailansicht nicht angezeigt.
- Aktionen auf den Einträgen können über das Kontextmenü durchgeführt werden.
- Aktionen, die die Liste betreffen, können über Schaltflächen oberhalb der Liste angeboten werden.
- Direktes Bearbeiten mit F2 ist abhängig von der Liste möglich.
- Sind mehr Einträge vorhanden als auf einer Seite dargestellt werden können, werden die Spaltenüberschriften fixiert.

### Gesamte Liste

Benutzerhilfe
49

<!-- PDF page 50 -->

Die gesamte Liste dient insbesondere für die Bearbeitung und ist über die Schaltfläche „Details anzeigen“ der vereinfachen Liste erreichbar. Wenn die Liste das einzige Feld auf einer Registerkarte ist, kann auch direkt die gesamte Liste angezeigt werden.

- In der Gesamtansicht wird die Fensterbreite optimal ausgenutzt.
- Die gesamte Liste bietet wie gewohnt die vollständige Listenfunktionalität.
- Sind mehr Einträge vorhanden als auf einer Seite dargestellt werden können, werden die Spaltenüberschriften fixiert.

## 2 Supportprozesse

### 2.1 Allgemeine Anwendungsfälle

#### 2.1.1 Umgang mit Objekten

##### 2.1.1.1 Ein Objekt neu erstellen

Um ein Objekt neu zu erstellen, gehen Sie folgendermaßen vor:

1. Klicken Sie im Menü „Objekt“ auf „Neu“ oder klicken Sie auf die Schaltfläche „Neu“.
2. Wählen Sie im angezeigten Dialog den gewünschten Objekttyp aus und klicken Sie auf „Weiter“.
**Hinweis:** Je nach Objekttyp können Sie sofort nach der Auswahl des Objekttyps z.B. einen Namen vergeben.
3. Geben Sie mindestens die verpflichtenden Metadaten des neuen Objekts ein und klicken Sie auf „Weiter“.
**Hinweis:** Verpflichtende Metadaten sind durch einen roten Stern neben der Feldbezeichnung gekennzeichnet. Außerdem wird die Feldbezeichnung bei solchen Feldern fett dargestellt.

##### 2.1.1.1.1 Dublettenprüfung

Sollten Sie es wünschen, eine Person oder eine Organisation zu erzeugen, wird im Zuge des Erzeugens dieser Objekte auf bereits existierende Objekte geprüft.

Nach Auswahl des Objekttyps „Person“ können Sie den Vor- und Nachname der zu erzeugenden Person angeben. Durch einen Klick auf die Schaltfläche „Weiter“ wird eine Suche nach dem eingegebenen Vor- und Nachnamen durchgeführt.

**Person**

Benutzerhilfe
50

<!-- PDF page 51 -->

Denutzerhilfe
51

Dublettenprüfung der Objektklasse "Person"
Rolle ☐ X

Personensuche (Dublette)
Vorname ☐
Nachname ☐

Organisation

Dublettenprüfung der Objektklasse "Organisation"
Rolle ☐ X

Organisationssuche (Dublette)
Name (vollständig) ☐
Kurzname ☐

Existierende Objekte

Für den Fall, dass die Suche bereits existierende Objekte gefunden, wird folgendes Formular angezeigt:

<!-- PDF page 52 -->

Existierende Objekte für Ihre Eingabe für die Objektklasse Organis... Rohe
Ein Eintrag unsortiert
Details anzeigen (1)

# Dubletten

[tbl-10.md](tbl-10.md)

Hier werden die gefundenen Objekte in einer Liste angezeigt über die Sie, bei Bedarf, die Möglichkeit haben, die Metadaten der gefundenen Personen zu überprüfen. Zusätzlich stehen Ihnen folgende Schaltflächen zur Verfügung:

- „Abbrechen“: bricht das Erzeugen der Person/Organisation ab.
- „Erzeugen“: Erzeugt eine neue Person, leitet Sie auf das Formular mit allen weiteren Metadaten für Personen. Der zuvor eingegebene Vor- bzw. Nachname werden übernommen.
- „Übernehmen“: Das Erzeugen der Person wird beendet und der selektierte Benutzer wird übernommen.

## 2.1.2 Hinweis: Die Dublettenprüfung kommt auch beim Erzeugen von Schlagworten zum Einsatz. Für weitere Informationen zu Schlagworten siehe Kapitel 2.6.8 „Synchronisierungs-Ausnahmen“

## Ausgenommene Dateien

Damit zum Beispiel temporäre Dateien von Drittprodukten nicht hochgeladen werden, gibt es folgende Synchronisierungs-Ausnahmen:

- Versteckte Dateien.
- Dateien, die mit -WRD, -WRL, ps bzw. ppt beginnen, gefolgt von mindestens einer Dezimal- bzw. Hexadezimalziffer (Großbuchstaben) und gefolgt von .tmp (Klein- und/oder Großbuchstaben).
- Dateien, die mit - beginnen, gefolgt von einer beliebigen Zeichenkette, gefolgt von .id1k.
- Dateien, die mit mindestens einer Dezimal- bzw. Hexadezimalziffer (Großbuchstaben) beginnen, gefolgt von .tmp (Klein- und/oder Großbuchstaben).
- Dateien, die ausschließlich aus Ziffern (Dezimal- bzw. Hexadezimalziffern in Großbuchstaben) bestehen. Jedoch sind davon Dateien ausgenommen, die mit „00“ beginnen, gefolgt von beliebig vielen Dezimalziffern.
- Dateien, die mit aa beginnen, gefolgt von einem Kleinbuchstaben, gefolgt von fünf Ziffern und optional gefolgt von einer Zeichenfolge, die ebenfalls der zuvor angeführten Regel entspricht.

Benutzerhilfe

<!-- PDF page 53 -->

- Dateien, die mit Icon beginnen gefolgt von einem „carriage return“ (nur Apple macOS).

## Datei-Zusatzinformationen

Datei-Zusatzinformationen wie zum Beispiel Datei-Tags, wie sie unter Apple macOS zur Verfügung gestellt werden, werden nicht synchronisiert und gehen verloren.

## Nicht erlaubte Objektklassen

In der Webservice-Konfiguration können in der Eigenschaft „Objektklassen die in Web-Ordnern nicht angezeigt werden“ jene Objektklassen hinterlegt werden, welche nicht synchronisiert werden sollen.

Schlagwortkatalog.

Benutzerhilfe
53

<!-- PDF page 54 -->

Benutzerhilfe
54

## 2.1.2.1 Ein Objekt löschen

Um ein Objekt zu löschen, gehen Sie folgendermaßen vor:

1. Markieren Sie durch einfaches Anklicken das Objekt, das Sie löschen möchten.
2. Klicken Sie im Menü „Objekt“ auf „Löschen“ und bestätigen Sie die angezeigte Abfrage mit „Ja“.

**Hinweis:** Die angezeigte Abfrage variiert, je nach Verfügbarkeit eines globalen Papierkorbs.

**Achtung:** Ist kein globaler Papierkorb definiert, wird durch Ausführen des Befehls „Löschen“ das gewählte Objekt unwiderruflich vernichtet.

**Hinweis:** Existiert in der Fabasoft eGov-Suite Bayern Domäne ein globaler Papierkorb, so wird das Objekt nicht sofort vernichtet, sondern für einen bestimmten Zeitraum im globalen Papierkorb abgelegt, bevor es endgültig gelöscht wird. Von diesem Papierkorb aus kann es durch Benutzer in der Rolle „Domänenadministrator“ oder „Support“ wiederhergestellt werden. Wird ein Dokument gelöscht, so werden die darin enthaltenen Schriftstücke zusammen mit dem Dokument in den globalen Papierkorb verschoben.

**Hinweis:** Führen Sie den Befehl „Ausschneiden“ aus, um ein Objekt nicht endgültig zu löschen, sondern lediglich den Verweis auf dieses Objekt zu entfernen. Sie können das Objekt danach über die Suche wieder ausfindig machen.

## 2.1.2.2 Die Metadaten eines Objekts lesen

Um die Metadaten eines Objekts zu lesen, gehen Sie wie folgt vor:

1. Markieren Sie durch einfaches Anklicken das gewünschte Objekt.
2. Klicken Sie im Menü „Objekt“ auf den Befehl „Eigenschaften“.

**Hinweis:** In den Benutzereinstellungen (Klick auf Ihren Namen -&gt; „Einstellungen“) befindet sich unter der Registerkarte „Bedienung“ die Option „Eigenschaften bevorzugt lesen“. Ist diese Option aktiviert, öffnen sich die Eigenschaften eines Objekts immer lesend.

## 2.1.2.3 Die Metadaten eines Objekts bearbeiten

Um die Metadaten eines Objekts zu bearbeiten, gehen Sie wie folgt vor:

1. Markieren Sie durch einfaches Anklicken das gewünschte Objekt.
2. Klicken Sie im Menü „Objekt“ auf „Eigenschaften“
3. Sofern die Eigenschaften lesend geöffnet wurden, klicken Sie auf die Schaltfläche „Bearbeiten“.

**Hinweis:** In den Benutzereinstellungen (Klick auf Ihren Namen -&gt; „Einstellungen“) befindet sich unter der Registerkarte „Bedienung“ die Option „Eigenschaften bevorzugt lesen“. Ist diese Option aktiviert, öffnen sich die Eigenschaften eines Objekts immer lesend.

## 2.1.2.4 Metadaten von zwei Objekten gleichen Typs vergleichen

Die Metadaten zweier Objekte können auch verglichen werden, solange Sie vom selben Objekttyp sind. Jene Metadaten, die sich innerhalb dieser beiden Objekte unterscheiden, werden in einer Übersicht dargestellt.

<!-- PDF page 55 -->

Um die Metadaten zweier Objekte gleichen Typs zu vergleichen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die beiden Objekte und markieren Sie sie durch einfaches Anklicken. Halten Sie dafür beim die Strg-Taste gedrückt und Klicken Sie die Objekte an, die Sie vergleichen möchten.
2. Klicken Sie im Menü „Objekt“ auf den Menübefehl „Unterschiede der Eigenschaften anzeigen“.
3. Klicken Sie nach der Betrachtung der Unterschiede auf die Schaltfläche „Weiter“.

**Hinweis:** Der Menübefehl „Unterschiede der Eigenschaften anzeigen“ ist ausschließlich für Administratoren verfügbar.

## 2.1.2.5 Metadaten eines Objekts in einer Liste bearbeiten

Sie haben die Möglichkeit, die wichtigsten Metadaten eines Objekts (z.B. den Namen eines Microsoft Word-Objekts) in einer Liste zu bearbeiten, ohne die Metadaten des Objekts öffnen zu müssen.

Wenn Sie die Metadaten eines Objekts in einer Liste ändern möchten, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt dessen Metadaten geändert werden sollen (z.B. über die Suchfunktion).
2. Legen Sie das Objekt z.B. am „Schreibtisch“ ab.
3. Falls nicht angezeigt, blenden Sie die Eigenschaft, welche geändert werden soll, als Spalte ein.
4. Markieren Sie die Zelle mittels eines Klicks.
5. Klicken Sie ein weiteres Mal auf die Zelle oder drücken Sie auf Ihrer Tastatur auf die Taste F2.

**Hinweis:** Nicht alle Metadaten eines Objekts können auf diese Weise geändert werden.

6. Beenden Sie die Bearbeitung durch Klick auf eine beliebige Stelle im Fabasoft eGov-Suite Bayern Webbrowser Client.

**Hinweis:** Alternativ können Sie die Bearbeitung auch durch Druck auf die Eingabetaste beenden.

**Beispiel:** Der Name eines Microsoft Word-Objekts wird auf die beschriebene Weise geändert.

**Beispiel:** Die Eigenschaft Serienbrief eines Microsoft Word-Objekts wird geändert, indem die Eigenschaft als Spalte eingeblendet wird und anschließend, wie in der Anleitung beschrieben, geändert wird.

**Beispiel:** Am „Schreibtisch“ wurde neben einem Microsoft Word-Objekt ein Vorgang abgelegt. Es wurde vom Microsoft Word-Objekt die Eigenschaft Serienbrief eingeblendet. Da ein Vorgang diese Eigenschaft nicht zur Verfügung hat, wird eine Fehlermeldung ausgegeben, wenn beim Vorgang versucht wird diese Eigenschaft über die oben angegebene Anleitung zu ändern.

## 2.1.2.6 Ein Objekt in einem neuen Fenster öffnen

Für einige Objekte, z.B. Akten, Vorgänge, Dokumente, Ordner oder Teamrooms, steht die Funktion „In neuem Fenster öffnen“ zur Verfügung. Diese Funktionalität entspricht dem

Benutzerhilfe
55

<!-- PDF page 56 -->

Navigieren in ein Objekt über den Baum, bietet jedoch den Vorteil, dass ein neues Fenster Ihres Internet Browsers geöffnet wird und Sie zusätzlich in dem ursprünglichen Fenster arbeiten können.

Um ein Objekt in einem neuen Fenster zu öffnen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt, das Sie in einem neuen Fenster öffnen möchten.
2. Öffnen Sie das Kontextmenü des Objekts und wählen Sie den Befehl „In neuem Fenster öffnen“ aus.

## 2.1.2.7 Ein Objekt kopieren und einfügen

Um ein Objekt zu kopieren und anschließend einzufügen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das gewünschte Objekt und markieren Sie es durch einfaches Anklicken.
2. Betätigen Sie die Tastenkombination `Strg + C`, um das Objekt in die Zwischenablage zu kopieren.

**Hinweis:** Alternativ steht Ihnen der Kontextmenübefehl „Kopieren“ oder der gleichnamige Menübefehl im Menü „Zwischenablage“ zur Verfügung.

3. Wechseln Sie an den gewünschten Ort in der Fabasoft eGov-Suite Bayern, an dem Sie das Objekt einfügen möchten (z.B. Ordner oder Akte) und betätigen Sie dort die Tastenkombination `Strg + V`.

**Hinweis:** Alternativ steht Ihnen das Symbol Verknüpfung einfügen und der gleichnamigen Menübefehl im Menü „Zwischenablage“ zur Verfügung.

**Hinweis:** Es existiert neben der Möglichkeit zum Einfügen auch noch die Option, ein Duplikat einzufügen. Hierfür müssen Sie den Menübefehl „Duplikat einfügen“ bzw. das Symbol Duplikat einfügen anklicken, wenn ein Objekt zuvor in die Zwischenablage kopiert wurde.

## 2.1.2.8 Ein Objekt importieren

Um ein Objekt zu importieren, gehen Sie folgendermaßen vor:

1. Markieren Sie durch einfaches Anklicken die Datei, welche Sie importieren möchten, im lokalen Dateisystem auf Ihrem Computer.
2. Betätigen Sie die Tastenkombination `Strg + C`, um das ausgewählte Schriftstück in die Zwischenablage zu kopieren.
3. Wechseln Sie zur Fabasoft eGov-Suite Bayern und betätigen Sie dort die Tastenkombination `Strg + V`, um das sich in der Zwischenablage befindliche Objekt dorthin zu kopieren.
4. Betätigen Sie die erscheinende Abfrage mit „Ja“.

**Hinweis:** Alternativ zur oben beschriebenen Methode gibt es noch die Möglichkeit, die Datei/die Dateien per Drag &amp; Drop der Objektliste der Fabasoft eGov-Suite Bayern abzulegen.

**Hinweis:** Alternativ steht Ihnen das Symbol Hochladen bzw. der gleichnamige Menübefehl im Menü „Extras“ zur Verfügung.

Es werden mindestens folgende Metadaten beim Importvorgang automatisch befüllt:

- Der Name der Datei wird als Name des Schriftstücks übernommen.
- Der Inhalt der Datei wird in den Hauptinhalt des Schriftstücks übernommen.

Benutzerhilfe

<!-- PDF page 57 -->

Hinweis: Sollte es bereits ein Objekt mit dem Namen der importierten Datei in der Objektliste, in der die Datei importiert wird, geben, haben Sie die Möglichkeit, die Datei zu importieren und das bestehende Objekt zu behalten, das bestehende Objekt zu ersetzen, oder den Import dieser Datei zu überspringen.

## 2.1.2.8.1 Unterstützte Dateiformate

Folgende konkrete Dateiformate können in die Fabasoft eGov-Suite Bayern importiert bzw. aus der Fabasoft eGov-Suite Bayern exportiert werden:

[tbl-11.md](tbl-11.md)

Benutzerhilfe
57

<!-- PDF page 58 -->

Dateien, die eines der oben aufgeführten Dateiformate aufweisen, können mit dem Menübefehl „Herunterladen“ aus der Menügruppe „Extras“ ins Dateisystem exportiert werden.

**Hinweis:** Im Allgemeinen erfolgt die Identifikation einer Datei neben der Identifikation über die Dateiendung unter anderem über das auf Ihrem Computer definierte Standardprogramm zum Öffnen von Dateien mit dieser Dateiendung. Dies gilt vor allem für das Öffnen eines Inhalts aus der Fabasoft eGov-Suite Bayern.

Sollte der Dateityp keiner konkreten Objektklasse zugeordnet werden können, wird für die importierte Datei ein Objekt der Klasse „Inhalt (unbekannter Typ)“ erzeugt.

**Hinweis:** Nur bestimmte Schriftstück-Objektklassen (z.B. Microsoft Word-Objekt) können direkt erzeugt werden. Z.B. PDF-Objekte oder E-Mails zu erzeugen ist nicht möglich, da sie einen fixen Inhalt haben.

## 2.1.2.8.2 Ein Objekt über die Office Button Funktion „Ablegen“ importieren

Eine weitere komfortable Möglichkeit ein Microsoft Office-Objekt (z.B. ein Microsoft Word-Objekt) zu importierten, bietet der Office Button „Ablegen“.

Um ein Schriftstück auf diese Weise zu importieren gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück in Ihrem lokalen Dateisystem (z.B. Windows-Explorer) und öffnen Sie dieses.
2. Öffnen Sie den Ribbon „Fabasoft eGov-Suite“ und wählen Sie die Schaltfläche „Ablegen“ aus.

[tbl-12.md](tbl-12.md)

3. Geben Sie die Daten zum Log-in in der Fabasoft eGov-Suite Bayern ein, sollten Sie dazu aufgefordert werden.
4. Nach Betätigen der Schaltfläche und dem Bestätigen des Hochladens, kann über eine Baumdarstellung des Schreibtischs ausgewählt werden, an welcher Stelle das Objekt abgelegt werden soll:

Benutzerhilfe
58

<!-- PDF page 59 -->

Speichern unter
System Administrator (Administration)

# Office-Dokument importieren

Name
Dokument1

Speichern unter
Schreibtisch
Mein Ordner

Speicherort
Schreibtisch

Hinweis: Auch der Schreibtisch selbst kann ausgewählt werden.

5. Bestätigen Sie den Import des Schriftstücks durch Klick auf die Schaltfläche „Ja“.

# Ergebnis:

- Das Schriftstück wurde in die Fabasoft eGov-Suite Bayern importiert und an der ausgewählten Stelle abgelegt.
- Das Dokument wird aus der eGov-Suite Bayern geöffnet.
- Das Schriftstück steht weiterhin in Ihrem lokalen Dateisystem zur Verfügung.

# 2.1.2.9 Ein Objekt exportieren

Um ein Objekt zu exportieren, gehen Sie folgendermaßen vor:

1. Markieren Sie durch einfaches Anklicken das Objekt, das Sie exportieren möchten.
2. Betätigen Sie die Tastenkombination Strg + C, um das ausgewählte Objekt in die Zwischenablage zu kopieren.
3. Wechseln Sie zum gewünschten Pfad im lokalen Dateisystem und betätigen Sie dort die Tastenkombination Strg + V, um das sich in der Zwischenablage befindliche Objekt an diese Stelle zu exportieren.

Hinweis: Zusätzlich steht Ihnen die Schaltfläche „Herunterladen“ zur Verfügung.

Hinweis: Sie haben außerdem die Möglichkeit, den Menüeintrag „Herunterladen“ im Menü „Extras“ zum Exportieren eines Objekts zu verwenden.

# 2.1.2.10 Eine Unterschrift auf einem Objekt anbringen

Um eine Unterschrift auf einem Objekt anzubringen, gehen Sie folgendermaßen vor:

Benutzerhilfe

<!-- PDF page 60 -->

1. Lokalisieren Sie das Objekt, das unterschrieben werden soll.
2. Öffnen Sie das Kontextmenü des Objekts.
3. Wählen Sie unter „Unterschriften“ die gewünschte Unterschrift aus.

Hinweis: Die verfügbaren Unterschriften variieren je nach Kontext und dem Status des markierten Objekts sowie der Rolle des Benutzers.

Hinweis: Viele Unterschriften stehen beim Ausführen von Arbeitsschritten von Aktivitäten zur Verfügung.

Beim Anbringen einer Unterschrift wird dies auf der Registerkarte „Unterschriften“ des Objekts, das unterschrieben wurde, dokumentiert. Weiters wird in der Regel eine neue Version des Objekts erstellt. Viele Unterschriften ändern den Status bzw. Bearbeitungsstatus eines Objekts und beeinflussen die Bearbeitbarkeit des Objekts nach dem Anbringen der Unterschrift.

## 2.1.3 Hervorheben von Objekten

Sie haben die Möglichkeit, Objekte farblich hervorzuheben, um diese z.B. in Listen leichter finden zu können. Um ein Objekt hervorzuheben, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das hervorzuhebende Objekt und legen Sie es am Schreibtisch ab.
2. Markieren Sie durch einfaches Anklicken das Objekt, öffnen Sie das Kontextmenü, wählen Sie „Hervorhebungsfarbe“ und anschließend die gewünschte Farbe aus.

Hinweis: Die Hervorhebungsfarbe „Normal“ entfernt gesetzte Hervorhebungsfarben.

Ergebnis: Das Objekt wird für alle Benutzer und allen Listen in der ausgewählten Hervorhebungsfarbe dargestellt.

Hinweis: Die „Hervorhebungsfarbe“ kann auch als Spalte eingeblendet werden.

## 2.1.4 Versenden von Objekten

Um das Arbeiten mit anderen Personen bzw. Benutzern der Fabasoft eGov-Suite Bayern zu erleichtern, ist es möglich, Objekte zu versenden. Es ist möglich

- Links auf Objekte,
- Inhalte von Schriftstücken oder
- PDF-Inhalte bzw. PDF-Übersichten

zu versenden.

## 2.1.4.1 Versenden eines Links, einer Kopie oder einer PDF

Durch das Versenden eines Objekts als Link, als Kopie oder als PDF kann ein Objekt dem Empfänger schnell zur Verfügung gestellt werden, ohne, dass dieser es selbst suchen muss.

Um ein Objekt zu versenden gehen Sie wie folgt vor:

1. Lokalisieren Sie das zu versendende Objekt.
2. Öffnen Sie das Kontextmenü und wählen Sie den Eintrag „Versenden“ aus.

Benutzerhilfe
60

<!-- PDF page 61 -->

3. Wählen Sie im Untermenü von „Versenden“ die gewünschte Versandmethode (Link, Kopie oder PDF)
4. Der Dialog zum Erstellen einer Neuen E-Mail in Ihrem E-Mail-Programm (z.B. Microsoft Outlook) öffnet sich. In der neuen E-Mail wurde der Link, die Kopie oder das PDF automatisch eingefügt.
5. Versenden Sie, wie gewohnt, die E-Mail.

## 2.1.4.2 Direktes Einfügen von Anlagen als Anhang in eine E-Mail

Das direkte Einfügen von Anlagen funktioniert nun nicht mehr mit gedrückter Alt-Taste und Drag &amp; Drop, sondern über den Einfügen Dialog von Microsoft Outlook. Dies wurde geändert, da die Alt-Taste je nach Browser und Browser-Version anders belegt ist. Durch diese Änderung erreicht man eine Browser-Unabhängigkeit und diese Funktionalität ist nun bei allen unterstützten Browsern durchführbar und nicht nur mehr im Microsoft Edge.

Um ein Schriftstück als Anlage zu einer E-Mail hinzuzufügen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück, das als Anlage zu einer E-Mail hinzugefügt werden soll und kopieren Sie es z.B. über die Tastenkombination Strg + C in die Zwischenablage.
2. Wechseln Sie zu der E-Mail, bei der Sie das Schriftstück als Anlage hinzufügen wollen.
3. Wählen Sie im Menü „Einfügen“ den Befehl „Inhalte einfügen“ aus.

![img-3.jpeg](img-3.jpeg)

4. Wählen Sie Option „Files“ aus und klicken Sie anschließend auf die Schaltfläche „OK“.

**Ergebnis:** Das Schriftstück wurde als Anlage zu der E-Mail hinzugefügt.

![img-4.jpeg](img-4.jpeg)

Benutzerhilfe

<!-- PDF page 62 -->

Benutzerhilfe
62

# 2.1.5 Kontextmenü

Die Fabasoft eGov-Suite Bayern bietet, ähnlich einem Dateimanager, im leeren Bereich einer Objektliste (bzw. im leeren Bereich des Listenkopfs) ein Kontextmenü an, in dem häufig verwendete Befehle zur Verfügung stellt.

Hinweis: Das Kontextmenü kann je nach aktuellem Kontext bzw. Objekt, für das das Kontextmenü aufgerufen wurde, variieren.

Hinweis: Nicht verfügbare Befehle werden im Kontextmenü ausgegraut dargestellt bzw. ausgeblendet.

[tbl-0.md](tbl-0.md)

Diese Liste enthält keine Einträge.

[tbl-1.md](tbl-1.md)
[tbl-2.md](tbl-2.md)

# 2.1.6 Spalteneinstellungen

## 2.1.6.1 Spalteneinstellungen über die Kopfzeile anpassen

Mithilfe der Spalteneinstellungen können Spalten einer Objektliste Ihren jeweiligen Anforderungen angepasst werden.

Um eine Spalte hinzuzufügen, gehen Sie folgendermaßen vor:

1. Markieren Sie durch einfaches Anklicken das Objekt in der Objektliste, dessen Metadaten Sie einblenden möchten.
2. Klicken Sie auf die Schaltfläche „Spalte hinzufügen“ (Plus-Symbol) und wählen Sie aus der entsprechenden Kategorie die Eigenschaft aus, die angezeigt werden soll.

Hinweis: Welche Eigenschaften als Spalten zur Auswahl stehen hängt vom Typ des Objekts ab, das in der Objektliste markiert ist.

<!-- PDF page 63 -->

Objekt Zwischenablage Ansicht Extras

![img-0.jpeg](img-0.jpeg)

Hinweis: Weiters steht eine Schaltfläche zum Hinzufügen bzw. Entfernen von Spalten zur Verfügung. Siehe hierzu Kapitel 2.1.6.2 „Spalteneinstellungen über die Schaltfläche „Spalteneinstellungen ändern“ anpassen“.

## Schaltflächen zum Bearbeiten der Spalten

Hinweis: Um das Kontextmenü einer Spalte zu Öffnen führen Sie entweder einen Linksklick auf das Pfeilsymbol im Spaltenheader durch oder führen einen Rechtsklick irgendwo im Spaltenheader durch.

- Um eine Spalte nach rechts oder links zu verschieben öffnen Sie das Kontextmenü der Spalte und wählen „Verschieben nach“ und die gewünschte Richtung.

![img-1.jpeg](img-1.jpeg)

Hinweis: Alternativ können Sie die Spalten auch per Drag &amp; Drop (Klicken und ziehen) verschieben.

- Um eine Spalte zu löschen öffnen Sie das Kontextmenü der Spalte und klicken auf die Schaltfläche „Spalte entfernen“.
- Um eine Spalte hinzuzufügen öffnen Sie das Kontextmenü einer bestehenden Spalte und klicken auf die Schaltfläche „Spalte hinzufügen“.
- Bei Objektzeigereigenschaften können über den Kontextmenübefehl „Nächste Stufe“ Eigenschaften des referenzierten Objekts angezeigt werden.

Benutzerhilfe

<!-- PDF page 64 -->

- Bei zusammengesetzten Eigenschaften können über den Kontextmenübefehl „Details“ Eigenschaften der zusammengesetzten Eigenschaft angezeigt werden.

## 2.1.6.2 Spalteneinstellungen über die Schaltfläche „Spalteneinstellungen ändern“ anpassen

Alternativ zum Anpassen der Spalteneinstellungen über die Kopfzeile, kann der „Spalteneinstellungen ändern“-Dialog verwendet werden.

Um die Spalteneinstellungen zu ändern, gehen Sie folgendermaßen vor:

1. Markieren Sie durch einfaches Anklicken das Objekt in der Objektliste, dessen Eigenschaften Sie einblenden möchten.
2. Öffnen Sie das Menü „Ansicht“ in der Menüleiste, wählen Sie „Spalteneinstellungen“ und anschließend „Ändern“.
3. Wählen Sie die gewünschten Eigenschaften aus.
- Geben Sie im Filterfeld den gewünschten Eigenschaftsnamen ein, um die Auswahl zu filtern. Um Eigenschaften von referenzierten Objekten anzuzeigen, klicken Sie auf die Schaltfläche „Nächste Stufe“ (max. 3 Stufen). Die Schaltfläche ist nur sichtbar, wenn das Filterfeld befüllt ist.
- Wählen Sie eine Registerkarte aus, um nur Eigenschaften dieser Registerkarte anzuzeigen.
- Wählen Sie eine oder mehrere Spalten aus, die Sie hinzufügen möchten und klicken Sie auf die Schaltfläche „Hinzufügen“.
- Wählen Sie eine oder mehrere Spalten aus, die Sie entfernen möchten und klicken Sie auf die Schaltfläche „Entfernen“.
- Die angezeigten Spalten können per Drag &amp; Drop sortiert werden.
4. Klicken Sie auf die Schaltfläche „Weiter“, um die Änderungen zu übernehmen.

## 2.1.6.3 Speichern und Laden von Spalteneinstellungen

Spalteneinstellungen einer Objektliste können durch Speichern und Laden für andere Objekte verwendet werden bzw. anderen Benutzern zur Verfügung gestellt werden.

Um die aktuellen Spalteneinstellungen zu speichern, gehen Sie folgendermaßen vor:

1. Klicken Sie auf die Schaltfläche „Ansicht“ und führen Sie unter „Spalteneinstellungen“ den Befehl „Speichern“ aus.
2. Klicken Sie auf die gewünschte Art der Speicherung.

Um eine gespeicherte Spalteneinstellung zu laden, gehen Sie folgendermaßen vor:

1. Klicken Sie auf die Schaltfläche „Ansicht“ und führen Sie unter „Spalteneinstellungen“ den Befehl „Laden“ aus.

Benutzerhilfe
64

<!-- PDF page 65 -->

![img-2.jpeg](img-2.jpeg)

2. Wählen Sie die gewünschte, gespeicherte Einstellung aus.
Hinweis: Sie haben auch die Möglichkeit, eine gespeicherte Vorlage (z.B. „Erweitert“) zu laden.

Zum Speichern von Ansichtseinstellungen stehen die folgenden Optionen zur Verfügung:

![img-3.jpeg](img-3.jpeg)

Benutzerhilfe

<!-- PDF page 66 -->

"Standardansicht für „Objektname“ für alle Benutzer festlegen"
- Speichert die aktuelle Ansicht für dieses Objekt für alle Benutzer

„Neue Ansichtseinstellung erzeugen“:
- „Speichern unter“: Legt fest, an welchem Speicherort die neue Ansichtseinstellung gespeichert wird.
- „Name“: Der Name unter welchem die neue Ansichtseinstellung gefunden werden kann.
- „Als Standard für Objekte dieses Typs festlegen“: Ist der Haken hier gesetzt, wird diese Ansichtseinstellung als der Standardwert für Ansichtseinstellungen dieses Objekttyps verwendet.

„Bestehende Ansichtseinstellung überschreiben“:
- „Bestehende Ansichtseinstellung“: Legt fest, welche bereits gespeicherte Ansichtseinstellung mit den aktuellen Spalten überschrieben wird.
- „Als Standard für Objekte dieses Typs festlegen“: Ist der Haken hier gesetzt, wird diese Ansichtseinstellung als der Standardwert für Ansichtseinstellungen dieses Objekttyps verwendet.

Hinweis: Die Verfügbarkeit dieser Optionen kann, abhängig von Ihrer Rolle und ob es gespeicherte Spalteneinstellungen gibt, variieren.

## 2.1.6.4 Freigeben von Spalteneinstellungen

Beim Speichern von Spalteneinstellungen in „Sammlungen für Vorlagen“ müssen diese zur Verwendung freigegeben werden. Die Abfrage, ob die Spalteneinstellung freigegeben werden soll oder nicht kommt direkt nach dem Speichern in einer „Sammlung für Vorlagen“. Wenn das Objekt nicht freigegeben wird, so kann es nicht verwendet werden. Spalteneinstellungen können auch zu einem späteren Zeitpunkt freigegeben werden.

Das Menü „Zur Verwendung freigeben“ befindet sich im Kontextmenü von Spalteneinstellungen.

Hinweis: Wenn eine Spalteneinstellung nicht freigegeben wurde, werden die Spalten für die gespeicherte Ansicht auf die Spalte „Name“ reduziert, bis die Spalteneinstellung freigegeben wurde.

## 2.1.6.5 Erneutes Freigeben von Spalteneinstellungen

Wenn Spalteneinstellungen, welche sich in einer „Sammlung für Vorlagen“ befinden, verändert werden, dann müssen diese erneut freigegeben werden, damit die Änderungen wirksam werden.

Das Menü „Erneut freigeben“ befindet sich im Kontextmenü von Spalteneinstellungen.

## 2.1.6.6 Freigabe zurückziehen

Falls eine Freigabe zum Beispiel irrtümlich vergeben wurde, so kann diese mit dem Menü „Freigabe deaktivieren“ wieder zurückgezogen werden. Dieses Menü ist ebenfalls im Kontextmenü von Spalteneinstellungen zu finden.

Benutzerhilfe
66

<!-- PDF page 67 -->

Benutzerhilfe
67

# 2.1.6.7 Spalteneinstellungen kopieren

## Spalteneinstellungen in andere Objektlisten kopieren

Um Spalteneinstellungen einer Objektliste für andere Objektlisten zu übernehmen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in die Objektliste, deren Spalteneinstellungen kopiert werden sollen.
2. Klicken Sie auf die Schaltfläche „Ansicht“ und führen Sie unter „Spalteneinstellungen“ den Befehl „Kopieren“ aus.
3. Wechseln Sie zu der Objektliste, die die gleichen Spalteneinstellungen erhalten soll.
4. Klicken Sie auf das Menü „Ansicht“ und führen Sie unter „Spalteneinstellungen“ den Befehl „Einfügen“ aus.

**Ergebnis:** Die Objektliste erhält nun die gleichen Spalteneinstellungen wie die ursprüngliche Objektliste.

## 2.1.7 Reihenfolge einer Objektliste verändern

Die Reihenfolge der Einträge in einer Objektliste können Sie über Drag &amp; Drop frei anpassen (zusätzlich zu den Möglichkeiten der Sortierung im Kapitel 2.1.8 „Objektlisten“ und der Möglichkeit der Gruppierung im Kapitel 2.1.8.2 „Gruppierung in Objektlisten“).

Um die Reihenfolge einer Objektliste zu verändern, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Objektliste, in der Sie die Reihenfolge verändern wollen.
2. Selektieren Sie die gewünschten Einträge.
3. Ziehen Sie bei gedrückter linker Maustaste die markierten Elemente an die gewünschte Position.

**Hinweis:** In Aggregatslisten wird dies durch einen Klick auf die Zeilennummerierung erreicht.

4. Lassen Sie die Maustaste an der gewünschten Stelle los, um das Objekt dorthin zu verschieben. Das Objekt wird erst beim Loslassen der Maustaste verschoben.

**Hinweis:** Das Objekt kann entweder an eine andere Stelle in der Liste verschoben werden oder in ein anderes Objekt integriert werden.

**Hinweis:** Das Ziel für die Verschiebeoperation wird grafisch visualisiert.

**Beispiel:** Im folgenden Beispiel wird das Dokument „Excel Document“ zwischen „My first Folder“ und „Word Document“ abgelegt.

[tbl-3.md](tbl-3.md)

**Hinweis:** Die Reihenfolge der Objekte ist nur änderbar, wenn die Objekte der Objektliste nicht gruppiert und nicht sortiert sind.

<!-- PDF page 68 -->

Benutzerhilfe
68

# 2.1.8 Objektlisten

## 2.1.8.1 Sortierung in Objektlisten

Die Sortierung von Objektlisten kann auf mehrere Arten erfolgen:

- Mithilfe des Sortieren-Symbols.
- Mithilfe des Spaltenmenüs der jeweiligen Spalte.
- Mithilfe des Kontextmenüs der jeweiligen Spalte.

Um eine Objektliste nach einer Spalte zu sortieren, klicken Sie in der Objektliste auf den Spaltenheader einer Spalte. Beim ersten Klick wird die Objektliste nach der jeweiligen Spalte aufsteigend sortiert. Ein Pfeilsymbol entsprechend der Sortierung wird im Spaltenheader hinzugefügt:

↑ Name

Wenn Sie einen zweiten Klick auf die Schaltfläche ausführen, wird die Objektliste absteigend nach der betroffenen Spalte sortiert. Das Pfeilsymbol ändert sich wieder entsprechend:

↓ Name

**Hinweis:** Die Sortierung kann ebenfalls über das Kontextmenü des Spaltenheaders aktiviert werden.

Dazu öffnen Sie mit einem Rechtsklick das Kontextmenü des Spaltenheaders, wählen „Sortieren“ und anschließend die gewünschte Sortierung „Aufsteigend“ bzw. „Absteigend“.

**Hinweis:** Um die Sortierung wieder zu entfernen, öffnen Sie mit einem Rechtsklick das Kontextmenü des Spaltenheaders, wählen „Sortieren“ und anschließend „Keine Sortierung“.

![img-4.jpeg](img-4.jpeg)

Die Sortierung von Objekten in einer Objektliste kann einfach an unterschiedliche Anforderungen angepasst werden. Sie können die Objekte einer Spalte nach bestimmten Kriterien auf- bzw. absteigend anordnen sowie nach mehreren Aspekten gleichzeitig sortieren.

<!-- PDF page 69 -->

Existiert keine explizite Sortierung, werden die Objekte nach dem Zeitpunkt des Einfügens in die Objektliste sortiert angezeigt.

## 2.1.8.1.1 Sortierung nach mehreren Kriterien

Sie haben die Möglichkeit, die Sortierung der Objektliste nach mehreren Kriterien vorzunehmen.

Um nach einer zusätzlichen Spalte zu sortieren muss zwingend das Kontextmenü der zusätzlich zu sortierenden Spalte geöffnet und hier der Eintrag „Sortieren“ gewählt werden.

Ein einfacher Klick auf den Spaltenheader einer zweiten Spalte löscht die Sortierung der ersten Spalte und aktiviert die Sortierung der zuletzt gewählten Spalte.

Im folgenden Beispiel werden die Einträge zuerst nach dem Kriterium „Name“ aufsteigend sortiert. Wenn für einen Namen mehrere Einträge existieren, werden diese Einträge aufsteigend nach der Spalte „Letzte Änderung am/um“ sortiert.

![img-5.jpeg](img-5.jpeg)

Hinweis: Rechts oben ist die Priorität der sortierten Spalten ersichtlich. Zusätzlich kann durch einen Klick auf diese Info ein Menü geöffnet werden, über welches die Sortierung geändert werden kann.

## 2.1.8.2 Gruppierung in Objektlisten

Standardmäßig werden alle Objekte nach dem Zeitpunkt des Einfügens in die Objektliste dargestellt. Es kann aber auch eine auf- oder absteigende Gruppierung der Einträge nach einem Kriterium oder nach mehreren Kriterien vorgenommen werden. Eine Liste mit gleichen Einträgen kann somit übersichtlich gestaltet werden.

Hinweis: Eine Gruppierung in leeren Objektlisten ist nicht möglich.

Hinweis: Um Gruppierungen durchzuführen, ist es ratsam, alle Sortierungen aufzuheben.

Um Einträge einer Objektliste nach dem Inhalt einer Spalte zu gruppieren, gehen Sie folgendermaßen vor:

Benutzerhilfe

<!-- PDF page 70 -->

1. Führen Sie den Kontextmenübefehl „Gruppieren nach“ → „Wert“ in der Spaltenbezeichnung aus.

Alle gleich lautenden Einträge einer Spalte werden zu einer Gruppe zusammengefasst.

![img-6.jpeg](img-6.jpeg)

2. Durch einen Klick auf ein das Dreieck-Symbol am Beginn einer Zeile kann die jeweilige Gruppierung expandiert werden:

![img-7.jpeg](img-7.jpeg)

Hinweis: Eine Gruppierung kann in einer Spalte, die Zeichenketten enthält, auch nach den Anfangsbuchstaben der Einträge erfolgen (Befehl „Gruppieren nach Anfangsbuchstaben“).

Hinweis: Eine Gruppierung kann in einer Spalte, die Datumsangaben enthält, auch nach Jahr, Monat, Tag oder Stunde erfolgen.

Benutzerhilfe

<!-- PDF page 71 -->

Benutzerhilfe

# 2.1.8.3 Berechnungen in Objektlisten

Für Zahlen- und Währungswerte, die in einer Spalte dargestellt werden, kann die Anzahl der Einträge, die einen gültigen Wert beinhalten, die Summe und der Durchschnitt berechnet werden. Dafür steht im Kontextmenü des Spaltenkopfs bei der entsprechenden Spalte der Befehl „Berechnen" zur Verfügung. Das Ergebnis wird am Seitenende angezeigt.

![img-8.jpeg](img-8.jpeg)

![img-9.jpeg](img-9.jpeg)

[tbl-4.md](tbl-4.md)

Wird die Liste gruppiert, werden die Berechnungen pro Gruppe durchgeführt und am Ende der Gruppeneinträge angezeigt. Bei gefilterten Objektlisten werden nur die angezeigten Einträge für die Berechnung herangezogen.

Wird ein Wert zum Beispiel mit der F2-Taste verändert, findet eine Neuberechnung erst nach dem Aktualisieren der Liste statt. Die Werte der alten Berechnung werden ausgegraut dargestellt.

# 2.1.8.4 Filtern von Objektlisten

Sie haben die Möglichkeit, eine Objektliste nach bestimmten Werten der angezeigten Spalten zu filtern. Durch das Filtern werden alle Einträge, die dem eingegebenen Wert entsprechen angezeigt. Um das Filtern zu aktivieren, gehen Sie folgendermaßen vor:

1. Öffnen Sie das Kontextmenü der Spalte und wählen Sie den Befehl „Filtern".
2. Tippen Sie den gesuchten Wert in das angezeigte Feld

71

<!-- PDF page 72 -->

![img-10.jpeg](img-10.jpeg)

Das Feld zur Eingabe der zu filternden Werte kann durch einen Klick auf die Schaltfläche „Schließen" innerhalb des Feldes wieder ausgeblendet werden.

![img-11.jpeg](img-11.jpeg)

Dadurch wird die Filterung der Objektliste aufgehoben und wieder die vollständige Liste angezeigt.

## 2.1.8.5 Datentabelle

Die angezeigten Spalten einer Objektliste können als Tabelle in die Zwischenablage kopiert werden. Somit kann eine textuelle Repräsentation der Liste zum Beispiel in Microsoft Office Excel eingefügt werden.

Um eine Datentabelle in die Zwischenablage zu kopieren, gehen Sie folgendermaßen vor:

1. Öffnen Sie die gewünschte Objektliste in der Detailansicht.
2. Öffnen Sie das Menü „Zwischenablage", klicken Sie auf den Befehl „Datentabelle" und dort auf „Kopieren (Standard)" bzw. „Kopieren (Erweitert)". Wenn Sie „Kopieren (Erweitert)" wählen, werden zusätzlich zu den sichtbaren Spalten auch Einträge von eingeblendeten Objektlisten und alle Werte von Aggregaten und Aggregatslisten als verschachtelte Tabelle kopiert.

Benutzerhilfe

<!-- PDF page 73 -->

Benutzerhilfe
73

# 2.1.9 Umgang mit Aggregaten

Aggregate sind Felder, die jeweils wiederum mehrere Felder enthalten.
Beispielsweise die Eigenschaft „Datei“ eines Word-Dokuments:

![img-12.jpeg](img-12.jpeg)

Aggregatslisten sind Listen von Aggregaten, wobei jede Zeile ihrerseits aus einem Aggregat besteht.
Beispielsweise die Liste der Adressaten einer Erledigung:

![img-13.jpeg](img-13.jpeg)

<!-- PDF page 74 -->

Benutzerhilfe

## 2.1.9.1 Neue Zeile in einer Aggregatsliste erzeugen

Um eine neue Zeile in einer Aggregatsliste zu erzeugen, gehen Sie folgendermaßen vor:

1. Klicken Sie in dem Aggregat auf die Schaltfläche „Eintrag hinzufügen“.
2. Befüllen Sie den Eintrag wie in Kapitel 2.1.9.2 „Eine Zeile bearbeiten“ beschrieben.

## 2.1.9.2 Eine Zeile bearbeiten

Eine Zeile kann auf drei verschiedene Arten bearbeitet werden:

- Über Freitextfelder
- Über Drop-down-Listen
- Über die Detailansicht

**Bearbeiten über Freitextfelder:**

Freitextfelder in Aggregaten können mit beliebigen Texten befüllt werden.

**Hinweis:** Bei Adressatenaggregaten werden Daten aus Freitextfeldern nicht im Adressverzeichnis gespeichert.

**Bearbeiten über Drop-down-Listen:**

In Drop-down-Listen kann einer der angezeigten Einträge ausgewählt werden.

**Hinweis:** Wenn der gewünschte Eintrag in der Drop-down-Liste nicht angezeigt wird, können Sie eine Suche durchführen (siehe Kapitel 2.12 „Suche“).

**Hinweis:** Wird in einem Adressatenaggregat ein Adressatenobjekt (z.B. eine Person oder eine Organisation) aus einer Drop-down-Liste ausgewählt, werden die zugehörigen Freitextfelder automatisch befüllt. Eine manuelle Änderung der Freitextfelder wirkt sich weder auf das ausgewählte Adressatenobjekt noch auf das Adressverzeichnis aus.

**Bearbeiten über die Detailansicht**

Mithilfe der Detailansicht können Sie die Daten in einem erweiterten Formular befüllen. Weitere Informationen finden Sie im Kapitel 2.1.9.3 „Einen Eintrag in der Detailansicht anzeigen“.

## 2.1.9.3 Einen Eintrag in der Detailansicht anzeigen

Ein Eintrag kann zur besseren Übersicht und genaueren Definition in einem erweiterten Formular angezeigt werden. In dieser Ansicht werden sämtliche verfügbaren Metadaten der selektierten Zeile dargestellt. Um einen Eintrag in der Detailansicht zu öffnen, öffnen Sie das

74

<!-- PDF page 75 -->

Kontextmenü der jeweiligen Zeile und wählen bearbeiten:

![img-14.jpeg](img-14.jpeg)

Hinweis: Das Kontextmenü können Sie entweder per Rechtsklick auf die Zeile oder per Linksklick auf den Pfeil ganz links öffnen.

## 2.1.9.4 Zeilen kopieren oder einfügen

Um eine Zeile zu kopieren und später in einem Aggregat wieder einzufügen, gehen Sie folgendermaßen vor:

1. Selektieren Sie in der Aggregatsliste eine oder mehrere gewünschte Zeilen. Jede markierte Zeile wird gelb markiert.
2. Führen Sie einen Rechtsklick auf eine der ausgewählten Zeilen durch und wählen „Kopieren“:
3. Wechseln Sie zu jenem Aggregat, in dem Sie die Zeilen einfügen möchten, führen einen Rechtsklick innerhalb des Aggregats durch und wählen „Einfügen“. Dadurch werden die in der Zwischenablage liegenden Zeilen in das ausgewählte Aggregat eingefügt und als neue Zeile(n) hinzugefügt.

Eine Zeile in einem Aggregat löschen:

Um eine Zeile in einem Aggregat zu löschen, gehen Sie folgendermaßen vor:

1. Selektieren Sie die gewünschten Zeilen.
2. Führen Sie einen Rechtsklick auf eine der ausgewählten Zeilen durch und wählen „Löschen“:

## 2.2 Adressatenverwaltung

### 2.2.1 Globales Adressverzeichnis

Als Adressverzeichnis werden alle in der Fabasoft eGov-Suite Bayern gespeicherten Adressatenobjekte bezeichnet, z.B. Personen und Organisationen. Diese Adressatenobjekte stehen in entsprechenden Feldern zur Verfügung, z.B. in der Drop-down-Liste Absender des Adressatenaggregats.

Benutzerhilfe

<!-- PDF page 76 -->

Hinweis: In Freitextfeldern eines Adressatenaggregats (Absender bzw. Empfänger) enthaltene Daten werden nicht im Adressverzeichnis gespeichert (siehe Kapitel 2.1.9.2 „Eine Zeile bearbeiten").

Hinweis: Einträge in Freitextfeldern eines Absenders bzw. Empfängers werden überschrieben, wenn nachträglich ein Absender oder Empfänger aus dem Adressverzeichnis eingetragen wird und für das Freitextfeld ein Wert im Adressverzeichnis existiert.

Hinweis: Die Suche von Adressatenobjekten kann, wie in Kapitel 2.12 „Suche“ und Kapitel 2.1.9.2 „Eine Zeile bearbeiten“ beschrieben, durchgeführt werden.

## 2.2.2 Allgemeine Informationen zur Adressatenverwaltung

Um Adressaten (Person, Organisation und Verteiler) besser verwalten und strukturieren zu können wurde die Adressatenverwaltung implementiert. Die Adressatenverwaltung ist ein Widget am Home Screen, welches Kontakträume beinhaltet.

![img-15.jpeg](img-15.jpeg)

Die Kontakträume eines Benutzers werden dabei dynamisch berechnet. In der Kontaktraum-Liste der Adressatenverwaltung werden alle lese- und änderungsberechtigten Kontakträume angezeigt. Kontakträume eines Benutzers können an folgenden Stellen definiert sein:

- Arbeitsumgebung - Registerkarte E-Government
- Domäne (inkl. übergeordneten Domäne)
- Gruppe des aktuellen Benutzers (inkl. übergeordneten Gruppen)

## 2.2.3 Rechtskonzept Kontaktraum

Kontakträume verwenden das gleiche Rechtekonzept wie auch die bereits bekannten Teamrooms. Innerhalb eines Kontaktraums steht in der Aufgabenfläche das Menü „Berechtigungen“ zur Verfügung:

Benutzerhilfe

<!-- PDF page 77 -->

![img-16.jpeg](img-16.jpeg)

Teams und Gruppen können hier als Berechtigte Mitglieder (Alle Rechte, Änderungs- und Lese-Berechtigt) eingetragen werden. Der Eigentümer des Kontaktraums wird automatisch unter „Alle Rechte“ hinzugefügt. Über die Sicherheitseinstellungen kann der Zugriffsschutz des Kontaktraums festgelegt werden:

## Kontaktraum

Zugriffsschutz *
Standard: Nur das festgelegte Team darf auf den Kontaktraum und seine Inhalte zugreifen

Anhand des Zugriffsschutz wird den Adressaten des Kontaktraums bzw. dem Kontaktraum selbst eine entsprechende ACL vergeben.

## 2.2.4 Einen Kontaktraum erzeugen

Kontakträume können ausschließlich im Widget „Adressatenverwaltung“ erzeugt werden. Adressaten können wiederum ausschließlich innerhalb eines Kontaktraums erzeugt werden. Um einen Kontaktraum zu erzeugen gehen Sie wie folgt vor:

1. Wechseln Sie in die Adressatenverwaltung durch einen Klick auf das gleichnamige Widget am Homescreen.
2. Klick Sie auf die Schaltfläche „Neu“
3. Definieren Sie einen Namen für den Kontaktraum und bestätigten den Dialog mit „Weiter“.

## 2.2.5 Ordner im Kontaktraum

Zur Sub-Strukturierung von Adressaten in Kontakträumen können Ordner verwendet werden. Auch Ordner in Ordner sind möglich, dabei erfolgt eine Rekursions-Überprüfung.

Um einen Ordner zu erzeugen gehen Sie wie folgt vor:

1. Wechseln Sie in die Adressatenverwaltung durch einen Klick auf das gleichnamige Widget am Homescreen.

Benutzerhilfe

<!-- PDF page 78 -->

2. Klick Sie auf die Schaltfläche „Neu"
3. Definieren Sie einen Namen für den Order und bestätigten den Dialog mit „Weiter".

## 2.2.6 Einen Adressaten erzeugen

Adressaten können in der Fabasoft eGov-Suite Bayern über die Adressatenverwaltung erzeugt werden.

Um einen Adressaten zu erzeugen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in die Adressatenverwaltung durch einen Klick auf das gleichnamige Widget am Homescreen.
2. Öffnen Sie den jeweiligen Kontaktraum. (Sie können über „Neu" einen neuen Kontaktraum erstellen, sollte noch keiner existieren)
3. Wählen Sie die Schaltfläche „Neu".
4. Wählen Sie den Eintrag „Verteiler", „Organisation" bzw. „Person" aus, abhängig vom Typ des zu erfassenden Adressaten und klicken Sie auf die Schaltfläche „Weiter".
5. Abhängig vom ausgewählten Adressaten, werden Sie dazu aufgefordert einen Namen zu vergeben. Betätigen Sie nach erfolgter Eingabe die Schaltfläche „Weiter". (siehe auch Kapitel 2.1.1.1.1 „Dublettenprüfung")
6. Erfassen Sie die Adressateninformation. Die Metadaten eines Adressaten enthalten alle adressatenspezifischen Informationen, wie Name, Geburtsdatum, Adresse, Telefonnummer usw. (siehe hierzu auch Kapitel 6.11 „Organisation" und 6.12 „Person").
7. Klicken Sie auf die Schaltfläche „Weiter", um die vorgenommenen Änderungen zu speichern.

## 2.2.7 Einen Verteiler erzeugen

Ein Verteiler kann, wie in Kapitel 2.2.6 Einen Adressaten erzeugen" beschrieben innerhalb eines Kontaktraums des Adressatenverwaltung erstellt werden. Dabei muss als Objekttyp „Verteiler" ausgewählt werden. Beim Erzeugen eines Verteilers kann eine Liste von Adressaten, sowie deren Kategorie und Versandart definiert werden, welche dann z.B. als Empfänger einer Erledigung definiert werden können. Siehe hierzu auch die Kapitel 3.4.3 „Einen Empfänger einer Erledigung definieren" und 6.13 „Verteiler".

## 2.2.8 Eine Organisation erzeugen

Eine Organisation kann, wie in Kapitel 2.2.6 „Einen Adressaten erzeugen" beschrieben innerhalb eines Kontaktraums des Adressatenverwaltung erstellt werden. Dabei muss als Objekttyp „Organisation" ausgewählt werden. Siehe hierzu auch die Kapitel 3.4.3 Einen Empfänger einer Erledigung definieren und 6.11 „Organisation".

## 2.2.9 Einen Adressaten bearbeiten

Die Fabasoft eGov-Suite Bayern unterstützt das Bearbeiten eines Adressaten innerhalb eines Kontaktordners. Die Kontaktordner eines Benutzers befinden sich im Widget „Adressatenverwaltung":

Benutzerhilfe

<!-- PDF page 79 -->

Um einen Adressaten zu bearbeiten, gehen Sie folgendermaßen vor:

1. Wechseln Sie in den entsprechenden Kontaktordner.
2. Lokalisieren Sie den Adressaten, den Sie bearbeiten möchten.
3. Führen Sie den Kontextmenübefehl „Eigenschaften bearbeiten“ auf das betroffene Objekt aus. Die Metadaten des Objekts werden im Bearbeitungsmodus geöffnet. Für weitere Informationen zu den Metadaten eines Adressaten siehe auch Kapitel 6.12 „Person“.
4. Editieren Sie die Adressateninformationen. Die Metadaten eines Adressaten enthalten alle adressatenspezifischen Informationen wie Name, Geburtsdatum, Adresse, Telefonnummer usw.
5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

## 2.2.10 Adressaten einem anderen Kontaktraum zuweisen

Ein Adressat bzw. ein Ordner (inklusive der darin befindlichen Hierarchie) kann mittels Drag&amp;Drop bzw. Kopieren/Einfügen einem anderen Kontaktraum zugewiesen werden. Voraussetzung dafür ist, dass der Benutzer ausreichend Rechte besitzt (D.h. man ist Eigentümer vom betroffenen Objekt oder man hat auf den Kontaktraum Alle Rechte). Aus Sicherheitsgründen erscheint beim Zuordnen ein entsprechender Dialog:

[tbl-5.md](tbl-5.md)

Die nachfolgenden Objekte sind bereits einem Kontaktraum zugeordnet. Möchten Sie trotzdem dem ausgewählten Kontaktraum die Objekte zuweisen?

[tbl-6.md](tbl-6.md)

Hinweis: Ein Adressat kann nur genau einem Kontaktraum zugewiesen werden.

## 2.2.11 Schaltfläche Auswahl Adresstyp

Am Adressatenaggregat (z.B. Absender, Empfänger) befindet sich die Schaltfläche „Auswahl Adresstyp“, mit der es möglich ist, die Adressinformationen der einzelnen Adressaten anzupassen.

Benutzerhilfe

<!-- PDF page 80 -->

Benutzerhilfe

# Adressaten

[tbl-7.md](tbl-7.md)

Eintrag hinzufügen

Die Schaltfläche ist selektionsabhängig, d.h. die Adressatenzeilen die markiert sind, erscheinen nach betätigen im „Auswahl Adresstyp“ Dialog. Falls nichts markiert ist, werden alle Adressatenzeilen übernommen. Dargestellt wird immer nur ein Adressat.

Der „Auswahl Adresstyp“ Dialog besteht aus den folgenden Feldern:

- Adressenvorschau: Die aktuell eingestellten Adressinformationen. Bei Änderungen wird die Vorschau automatisch angepasst.
- Versandart: Die zu verwendende Versandart. Das Feld kann manuell oder automatisch – über die nachfolgenden Felder – geändert werden.
- Adresse: Sämtliche Adressen, die beim Adressaten hinterlegt wurden, stehen hier zur Auswahl. Über die „Übernehmen“ Schaltfläche kann man eine Adresse auswählen. Die Versandart ändert sich dabei auf „Papier“.
- E-Mail-Adressen: Sämtliche E-Mail-Adressen/Fax-Adressen, die beim Adressaten hinterlegt wurden, stehen hier zur Auswahl. Über die „Übernehmen“ Schaltfläche kann man eine E-Mail-Adresse/Fax-Adresse auswählen. Die Versandart ändert sich bei Auswahl einer E-Mail-Adresse auf „E-Mail“ und bei Auswahl einer Fax-Adresse auf „Fax“.
- Telefonnummern: Sämtliche Telefonnummern, die beim Adressaten hinterlegt wurden, stehen hier zur Auswahl. Über die „Übernehmen“ Schaltfläche kann man eine Telefonnummer auswählen. Auf die Versandart hat das Feld keinen Einfluss.

80

<!-- PDF page 81 -->

Auswahl von Adressen für "Musterfrau Maxime"
81

Adressenvorschau

Adressat
Musterfrau Maxime

Adresse
Wunderstraße 7, 0000, 0000 Wunderort

E-Mail

Telefon

Fax

Versandart *
Papier

Adresse
Details anzeigen (0)
Diese Liste enthält keine Einträge.

E-Mail-Adressen
Details anzeigen (0)
Diese Liste enthält keine Einträge.

Telefonnummern
Details anzeigen (0)
Diese Liste enthält keine Einträge.

Über die Schaltflächen „Nächste/r Adressat/in“ und „Voriger Adressat“ kann man zwischen den einzelnen Adressaten hin und her wechseln. Sie sind nur sichtbar, wenn mehrere Adressatenzeilen ausgewählt wurden. Mit der Schaltfläche „Weiter“ kann der Dialog wieder geschlossen werden.

Benutzerhilfe

<!-- PDF page 82 -->

Hinweis: Da es keine „Abbrechen“ Schaltfläche gibt, werden alle Änderungen sofort übernommen.

## 2.3 Umgang mit Dokumenten

### 2.3.1 Ein Dokument erstellen

Ein Dokument kann, wie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ beschrieben, erzeugt werden, indem beim Erzeugen der Objekttyp „Eingangsdokument“ oder „Erledigung“ ausgewählt wird. Die genauen Metadatenformulare finden Sie im Kapitel 6.5 „Eingangsdokument“ bzw. 6.6 „Erledigung“.

Hinweis: Das Erzeugen von Dokumenten steht nur in der Objektliste eines Vorgangs zur Verfügung.

### 2.3.2 Die Schriftstücke eines Dokuments lesen oder bearbeiten

Öffnet man ein Dokument befindet man sich in der Vorschauansicht.

![img-0.jpeg](img-0.jpeg)

Schriftstücke eines Dokuments können durch einen Klick auf „Bearbeiten“ bzw. „Lesen“ in der Symbolleiste in der zugehörigen Drittanwendung geöffnet werden (z.B. in Microsoft Office Word). Sind mehrere Schriftstücke innerhalb eines Dokuments vorhanden erscheint ein Auswahldialog, in welchem man das zu öffnende Schriftstück auswählen kann. Alternativ dazu kann über das Menü „Zur Listenansicht wechseln“ in die Listenansicht gewechselt werden und hier direkt ein Schriftstück geöffnet werden.

Benutzerhilfe

<!-- PDF page 83 -->

![img-1.jpeg](img-1.jpeg)

Wird ein Dokument über das Kontextmenü in einem neuen Fenster geöffnet, wird dieses ebenfalls in der Listenansicht geöffnet. In dieser Liste lassen sich (je nach Berechtigung und Benutzerrolle) neue Schriftstücke erzeugen (siehe Kapitel 2.1.1.1 „Ein Objekt neu erstellen“), die Metadaten der Schriftstücke bearbeiten (siehe Kapitel 2.1.2.3 „Die Metadaten eines Objekts bearbeiten“) oder auch Schriftstücke löschen (siehe Kapitel 2.1.2.1 „Ein Objekt löschen“).

## Ein Dokument einem Vorgang zuordnen:

Um ein Dokument einem Vorgang zuzuordnen, gehen Sie folgendermaßen vor:

1. Bearbeiten Sie die Eigenschaften des Dokuments durch einen Klick auf „Eigenschaften bearbeiten“ im Kontextmenü des Dokuments.
2. Wählen Sie im Feld Vorgang den gewünschten Vorgang aus oder suchen Sie danach (siehe Kapitel 2.12 „Suche“).
3. Klicken Sie auf „Weiter“, um die Änderungen zu speichern.

**Hinweis:** Weitere Informationen zu den Formularen finden Sie in den Kapiteln 6.5 „Eingangsdokument“ und 6.6 „Erledigung“.

**Hinweis:** Zusätzlich haben Sie die Möglichkeit, ein Dokument über Copy &amp; Paste oder Drag &amp; Drop einem Vorgang zuzuordnen. Siehe hierzu auch Kapitel 2.1.2.7 „Ein Objekt kopieren und einfügen“.

## 2.4 Öffnen des zugehörigen Objekts

Über das Kontextmenü von zugehörigen Geschäftsobjekten haben Sie die Möglichkeit, das zugehörige Objekt in einem neuen Fenster zu öffnen. Im Falle eines Vorgangs wird die Akte des Vorgangs angeboten.

Um das zugehörige Objekt eines Geschäftsstücks zu öffnen gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Geschäftsobjekt, dessen zugehöriges Objekt in einem neuen Fenster geöffnet werden soll.

Benutzerhilfe

<!-- PDF page 84 -->

2. Öffnen Sie das Kontextmenü des Geschäftsobjekts und klicken Sie auf den Befehl „[zugehöriges Objekt] öffnen".

![img-2.jpeg](img-2.jpeg)

Hinweis: Die exakte Bezeichnung des Befehls variiert, je nach zugehörigem Objekt, da sowohl die Objektklasse, als auch der Name des zugehörigen Objekts angezeigt werden.

Ergebnis: Das zugehörige Objekt wird in einem neuen Fenster geöffnet.

## 2.5 IntelliHelp

Die IntelliHelp bietet die Möglichkeit, wichtige Eigenschaften eines Objekts zu betrachten, ohne dieses lesend oder bearbeitend öffnen zu müssen.

![img-3.jpeg](img-3.jpeg)

Benutzerhilfe

<!-- PDF page 85 -->

Handelt es sich bei dem Objekt, dessen IntelliHelp angezeigt wird, um ein Geschäftsobjekt, wird zusätzlich zu den wichtigsten Metadaten die Hierarchie des Geschäftsobjekts angezeigt:

Zum Anzeigen der IntelliHelp gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt, für das die IntelliHelp aufgerufen werden soll
2. Markieren Sie durch einfaches Anklicken das Objekt und stellen Sie den Mauszeiger direkt auf das Symbol des Objekts.

Hinweis: Eine Bewegung der Maus unterbricht das Anzeigen der IntelliHelp bzw. blendet diese wieder aus.

Hinweis: Die IntelliHelp wird nur dann angezeigt, wenn in den Benutzereinstellungen die Option „Hinweise zu Objekten anzeigen“ aktiviert wurde.

## 2.6 Synchronisierungsfunktionalität „Folio Ordner“

Hinweis: Der Folio Ordner ist Teil des Fabasoft Folio Clients und steht nur unter Microsoft Windows zur Verfügung.

Der Folio Ordner ermöglicht das Synchronisieren von Ordnerstrukturen Ihres Fabasoft eGov-Suite Bayern Webclients mit dem Dateisystem. Sie können entweder Ihr gesamtes „Home“ oder einen dedizierten Ordner synchronisieren.

## 2.6.1 Aktivierung der Synchronisierung

Die Synchronisierung kann in der Arbeitsumgebung auf der Registerkarte „Bedienung“ im Feld „Synchronisierungsart“ aktiviert werden. Folgende Optionen stehen zur Verfügung:

1. Keine Synchronisierung
2. Synchronisierter Schreibtisch oder synchronisierter Ordner
3. Synchronisierter Ordner

### Keine Synchronisierung

Es findet keine Synchronisierung statt.

### Synchronisierter Schreibtisch oder synchronisierter Ordner

Es wird entweder der Home Bereich oder ein dedizierter Ordner synchronisiert. Ob ein dedizierter Ordner verwendet werden soll kann in dem Kontomenü (Ihr Benutzername) -&gt; „Synchronisierung“ eingestellt werden. Wenn der synchronisierte Ordner nicht aktiviert ist, dann wird der Home Bereich synchronisiert.

### Synchronisierter Ordner

Es wird ein dedizierter Ordner synchronisiert.

Hinweis: Die Synchronisierung kann auch über die Organisationseinheit des Benutzers aktiviert werden (Registerkarte „Arbeitsumgebung (Erweitert)“ bzw. „Einstellungen“, Feld Synchronisierungsart: „Keine Synchronisierung“, „Synchronisierter Ordner“, „Synchronisierter Schreibtisch oder synchronisierter Ordner“).

Hinweis: Die Synchronisierung kann in der Arbeitsumgebung des Benutzers nur dann aktiviert werden, wenn in allen Organisationseinheiten, welche beim Benutzer in der Eigenschaft

Benutzerhilfe
85

<!-- PDF page 86 -->

"Mitglied von" eingetragen sind, eine Synchronisierungsart definiert ist. Ist "Keine Synchronisierung" in einer der Organisationseinheiten eingetragen, kann der Benutzer dies nicht übersteuern.

## 2.6.2 Synchronisierung erstmalig verwenden

Abhängig von den Systemeinstellungen können Sie entscheiden, ob Sie Ihr gesamtes „Home“ oder nur einen dedizierten Ordner mit dem Dateisystem synchronisieren möchten.

Um den dedizierten synchronisierten Ordner zu aktivieren, gehen Sie folgendermaßen vor:

1. Klicken Sie auf das Kontomenü (Ihr Benutzername) und dann auf „Synchronisierung“.
2. Klicken Sie auf die Schaltfläche „Synchronisierten Ordner aktivieren“.
**Hinweis:** Die Schaltfläche ist nur sichtbar, wenn die Systemeinstellungen dies für Sie erlauben.
3. Klicken Sie auf die Schaltfläche „Aktivieren“. Alle bisher synchronisierten Daten werden von Ihren Endgeräten entfernt.
4. Klicken Sie auf „Schließen“.

Der dedizierte synchronisierte Ordner wird automatisch auf „Home“ abgelegt.

**Hinweis:** Die Deaktivierung des dedizierten synchronisierten Ordners funktioniert analog (Schaltfläche „Synchronisierten Ordner deaktivieren“).

## Synchronisierung starten

```html
[tbl-0.md](tbl-0.md)
```

Führen Sie in der Taskleiste auf dem Benachrichtigungssymbol den Kontextmenübefehll „Folio Ordner öffnen“ aus.

- Wenn Sie „Home“ synchronisieren, wird die oberste Ebene ins Dateisystem synchronisiert. Wenn Sie in einen Ordner navigieren, wird der Inhalt dieses Ordners (auf erster Ebene) synchronisiert. Sie können aber auch gesamte Ordnerhierarchien synchronisieren (siehe nächstes Kapitel).

**Hinweis:** Beim erstmaligen Öffnen wird das Synchronisieren nach Eingabe von Benutzername und Passwort automatisch gestartet.

- Wenn Sie einen dedizierten synchronisierten Ordner verwenden, wird die gesamte Ordnerhierarchie standardmäßig ins Dateisystem synchronisiert.
- Die erfolgreiche Synchronisierung wird durch ein grünes Häkchen visualisiert.

Sie können nun die Dateien und Ordner sowohl im Fabasoft eGov-Suite Bayern Webclient als auch im Dateisystem bearbeiten.

**Ergebnis:** Die aktuelle Ordnerstruktur des Fabasoft eGov-Suite Bayern Webclients wird im Dateisystem nachgebildet.

Benutzerhilfe
86

<!-- PDF page 87 -->

Benutzerhilfe

# Fabasoft eGov-Suite Bayern Webclient:

![img-4.jpeg](img-4.jpeg)

# Im Dateisystem:

![img-5.jpeg](img-5.jpeg)

Hinweis: Die Reihenfolge der Objekte und deren Repräsentationen im Dateisystem kann, je nach Konfiguration der Sortierung in Ihrem Dateisystem bzw. in der Fabasoft eGov-Suite Bayern variieren.

Hinweis: Nicht alle Objektklassen der Fabasoft eGov-Suite Bayern können synchronisiert werden. Dies betrifft z.B. Verteilerlisten.

## 2.6.3 Ordner und Dokumente für die Synchronisierung auswählen

Im Dateisystem können Sie folgendermaßen Ordner und Dokumente für die Synchronisierung auswählen:

- Wenn Sie „Home“ synchronisieren, wird beim Navigieren durch die Ordnerstruktur automatisch der Inhalt des aktuellen Ordners synchronisiert und synchron gehalten. Hinweis: Wenn Sie einen dedizierten synchronisierten Ordner verwenden, wird die gesamte Ordnerhierarchie standardmäßig ins Dateisystem synchronisiert.

87

<!-- PDF page 88 -->

- Um komfortabel eine gesamte Ordnerhierarchie zu synchronisieren und synchron zu halten, steht Ihnen bei Ordnern der Kontextmenübefehll „Folio Ordner“ &gt; „Ordner aktuell halten“ zur Verfügung.

[tbl-1.md](tbl-1.md)

- Synchronisierte Ordner können über den Kontextmenübefehll „Folio Ordner“ &gt; „Lokale Dateien entfernen“ wieder von der Synchronisierung ausgenommen werden. Dabei werden die lokalen Dateien der gesamten Ordnerhierarchie entfernt. Dies hat keine Auswirkung auf die entsprechenden Objekte in Fabasoft Folio.

## Hinweis:

- Die Synchronisierung erfolgt automatisch im Hintergrund, sie kann aber über den Optionen-Dialog des Benachrichtigungssymbols deaktiviert werden (Registerkarte „Allgemein“ &gt; „Folio Ordner“ &gt; Feld Offline).
- Wenn Sie die Synchronisierung nicht mehr benötigen, können Sie im Optionen-Dialog des Benachrichtigungssymbols über die Schaltfläche „Ordner löschen“, den Folio Ordner vom Dateisystem entfernen.

## 2.6.4 Symbole für die Visualisierung des Status

Folgende Symbole zeigen im Explorer den Synchronisierungsstatus an:

- Nicht synchronisiert
- Elemente, die sich nur am Server befinden, werden ausgegraut dargestellt. Subelemente werden nicht dargestellt.

Benutzerhilfe

<!-- PDF page 89 -->

Benutzerhilfe
89

- Synchronisiert
Synchronisierte Elemente werden durch ein grünes Häkchen gekennzeichnet.
Hinweis: Am Server kann sich eine bereits neuere Version des Elements befinden.

- Modifiziert
Das Element wurde lokal verändert bzw. es wird gerade ein Synchronisierungsvorgang durchgeführt.

- Konflikt/Fehler
Die Möglichkeiten den Konflikt aufzulösen sind in Kapitel 2.6.5 „Auflösen von Konflikten“ beschrieben. Falls ein Fehler beim Synchronisieren aufgetreten ist, stehen im Kontextmenü unter „Fehler beheben“ entsprechende Befehle zur Verfügung.
Beispiel: Elemente wurden nach dem letzten Synchronisierungsvorgang lokal und am Server bearbeitet oder wird derzeit über den Fabasoft eGov-Suite Bayern Webclient bearbeitet und ist daher gesperrt.

## 2.6.5 Auflösen von Konflikten

Wenn Elemente nach dem letzten Synchronisierungsvorgang lokal und am Server bearbeitet wurden, entsteht beim nächsten Synchronisieren ein Konflikt. Die betroffenen Elemente werden nicht synchronisiert und mit einem Symbol wird auf den Konflikt hingewiesen.

Im Kontextmenü des betroffenen Elements stehen folgende Möglichkeiten zur Verfügung, um den Konflikt auszulösen:

- Element am Server ansehen: Um entscheiden zu können, wie der Konflikt aufgelöst werden soll, kann die aktuelle Version des Elements am Server im Fabasoft eGov-Suite Bayern Webclient angesehen werden.
- Lokale Änderungen verwerfen: Die lokalen Änderungen werden verworfen und das Element wird vom Server heruntergeladen.
- Änderungen am Server verwerfen: Die Änderungen am Server werden verworfen und das lokale Element wird auf den Server hochgeladen.

## 2.6.6 Erweiterte Möglichkeiten

Im Kontextmenü von synchronisierten Elementen stehen unter „Folio Ordner“ folgende Befehle zur Verfügung:

![img-6.jpeg](img-6.jpeg)

- „Im Folio Webclient anzeigen“: Der Fabasoft eGov-Suite Bayern Webclient wird geöffnet.
- „Eigenschaften im Folio Webclient anzeigen“: Die Eigenschaften des jeweiligen Elements werden im Fabasoft eGov-Suite Bayern Webclient geöffnet.
- „Link kopieren“: Kopiert das Objekt in die Zwischenablage und kann z.B. in einer E-Mail als Verweis auf das Objekt eingefügt werden.

<!-- PDF page 90 -->

Benutzerhilfe

# 2.6.7 Mehrfache Mandanten oder Installationen

Der Fabasoft Folio Client unterstützt auch die Synchronisation mit mehreren Mandanten der Fabasoft eGov-Suite Bayern oder mit mehreren installierten Systemen der Fabasoft eGov-Suite Bayern. Welche Systeme/Mandanten bereits synchronisiert werden können wird im

[tbl-2.md](tbl-2.md)

Kontextmenü des Fabasoft Folio Clients angezeigt:

In diesem Beispiel haben Sie die Möglichkeit, zwischen drei Mandanten zu synchronisieren (Bayern, Mandant A und Mandant B). Der aktive Mandant ist mit einem Haken markiert. Betätigen Sie nun den Befehl „Synchronisieren“, werden die Einstellungen für den Mandant Bayern herangezogen und die entsprechenden Daten synchronisiert.

Hinweis: Arbeiten Sie mit mehreren Installationen der Fabasoft eGov-Suite Bayern, bei denen die Mandanten gleich benannt sind, so wird immer der zuletzt verwendete Mandant für die Synchronisation herangezogen. Der Name des Mandanten ist der Schlüssel für die Darstellung im Kontextmenü.

Das System aktualisiert die Liste der Mandanten immer dann, wenn Sie in die Fabasoft eGov-Suite Bayern einsteigen oder den Browser mit „F5“ aktualisieren. Folgende Regeln werden für die angezeigten Einträge herangezogen:

1. Der Mandant, der zuletzt im Fabasoft eGov-Suite Bayern Webbrowser Client aktualisiert wurde, wird immer angezeigt, egal ob dieser bereits synchronisiert wurde oder nicht.

90

<!-- PDF page 91 -->

2. Die Mandanten, die bereits einmal synchronisiert wurden, werden so lange angezeigt, so lange auch ein Ordner im konfigurierten Pfad existiert. Diese Konfiguration kann über den

![img-7.jpeg](img-7.jpeg)
Befehl „Optionen“ des Fabasoft Folio Plug-Ins geöffnet werden:

3. Kann das System nur exakt einen Mandanten aus den Regeln zuvor ermitteln, wird nichts

![img-8.jpeg](img-8.jpeg)

angezeigt, da der Anwender keine Auswahl treffen kann:

Wird ein Mandant nun synchronisiert erzeugt der Fabasoft Folio Client im Benutzer-Ordner des Windows Profils einen neuen Ordner mit dem Namen des Mandanten. Ab diesem Zeitpunkt ist dieser Mandant so lange im Kontextmenü des Fabasoft Folio Clients verfügbar, bis der lokale Ordner manuell gelöscht wurde.

## 2.6.8 Synchronisierungs-Ausnahmen

### Ausgenommene Dateien

Damit zum Beispiel temporäre Dateien von Drittprodukten nicht hochgeladen werden, gibt es folgende Synchronisierungs-Ausnahmen:

- Versteckte Dateien.
- Dateien, die mit -WRD, -WRL, ps bzw. ppt beginnen, gefolgt von mindestens einer Dezimal- bzw. Hexadezimalziffer (Großbuchstaben) und gefolgt von .tmp (Klein- und/oder Großbuchstaben).
- Dateien, die mit - beginnen, gefolgt von einer beliebigen Zeichenkette, gefolgt von .id1k.
- Dateien, die mit mindestens einer Dezimal- bzw. Hexadezimalziffer (Großbuchstaben) beginnen, gefolgt von .tmp (Klein- und/oder Großbuchstaben).

Benutzerhilfe

<!-- PDF page 92 -->

- Dateien, die ausschließlich aus Ziffern (Dezimal- bzw. Hexadezimalziffern in Großbuchstaben) bestehen. Jedoch sind davon Dateien ausgenommen, die mit „00“ beginnen, gefolgt von beliebig vielen Dezimalziffern.
- Dateien, die mit aa beginnen, gefolgt von einem Kleinbuchstaben, gefolgt von fünf Ziffern und optional gefolgt von einer Zeichenfolge, die ebenfalls der zuvor angeführten Regel entspricht.
- Dateien, die mit Icon beginnen gefolgt von einem „carriage return“ (nur Apple macOS).

## Datei-Zusatzinformationen

Datei-Zusatzinformationen wie zum Beispiel Datei-Tags, wie sie unter Apple macOS zur Verfügung gestellt werden, werden nicht synchronisiert und gehen verloren.

## Nicht erlaubte Objektklassen

In der Webservice-Konfiguration können in der Eigenschaft „Objektklassen die in Web-Ordnern nicht angezeigt werden“ jene Objektklassen hinterlegt werden, welche nicht synchronisiert werden sollen.

## 2.7 Schlagwortkatalog

### 2.7.1 Ein Schlagwort erfassen

Neue Schlagworte können von allen Benutzen erfasst werden.

Um ein Schlagwort am Schreibtisch zu erfassen, gehen Sie folgendermaßen vor:

1. Wechseln Sie zu Ihrem „Schreibtisch“.
2. Klicken Sie auf die Schaltfläche „Neu“.
3. Wählen Sie den Eintrag „Schlagwort“ aus und klicken Sie auf die Schaltfläche „Weiter“.
4. Erfassen Sie die Metadaten des Schlagworts. Metadaten enthalten Informationen, die das Schlagwort beschreiben.

**Hinweis:** Beim Erzeugen eines Schlagworts erfolgt, analog zu Personen und Organisationen, eine Dublettenprüfung. Siehe hierzu auch Kapitel 2.1.1.1.1 „Dublettenprüfung“.

5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

Wenn Sie ein Schlagwort direkt im Geschäftsstück erzeugen wollen gehen Sie wie folgt vor:

1. Lokalisieren Sie das Feld **Schlagworte z.B.** in den bearbeitend geöffneten Matedaten eines Vorgangs.
2. Geben Sie den Titel des gewünschten Schlagworts ein
3. Wählen Sie die Option „Wird das gewünschte Schlagwort noch immer nicht angezeigt? Klicken Sie hier, um das eingegebene Schlagwort zu erzeugen“:

```
Schlagworte
Schlagwort
```

☐ Wird das gewünschte Schlagwort nicht angezeigt? Klicken Sie hier, um nach weiteren Schlagworten zu suchen ...

⚠️ Wird das gewünschte Schlagwort noch immer nicht angezeigt? Klicken Sie hier, um das eingegebene Schlagwort zu erzeugen ...

Benutzerhilfe

<!-- PDF page 93 -->

Benutzerhilfe

## 2.7.2 Vergeben von Schlagworten

Akten, Vorgänge, Dokumente und andere Objekte können mit Schlagworten versehen werden, indem die entsprechenden Schlagworte im jeweiligen Objekt im Feld Schlagworte eingetragen werden.

Um Schlagworte zu vergeben, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt und öffnen Sie die Metadaten bearbeitend.
**Hinweis:** Falls Sie keine Rechte besitzen um die Metadaten zu bearbeiten, wird ein Hinweis angezeigt, dass Sie die Metadaten nur im Lesemodus einsehen können.

2. Abhängig vom Typ des Objekts befindet sich das Feld Schlagworte auf unterschiedlichen Registerkarten. Lokalisieren Sie das Feld Schlagworte. Um nach einem bestehenden Schlagwort zu suchen, verfahren Sie, wie im Kapitel 2.7.3 „Ein Schlagwort suchen“.
**Hinweis:** Sie können ein Schlagwort am „Schreibtisch“ suchen und anschließend in dem gewünschten Objekt mittels der Kontextmenüfunktion „Verknüpfung einfügen“ eintragen.

3. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

## 2.7.3 Ein Schlagwort suchen

Sie haben die Möglichkeit, nach einem Schlagwort am Schreibtisch oder direkt in dem Objekt, welches beschlagwortet werden soll, zu suchen.

**Schreibtisch:**

Um nach einem Schlagwort am Schreibtisch zu suchen, gehen Sie bitte, wie im Kapitel 2.12 „Suche“ beschrieben vor.

**Zu beschlagwortende Objekt:**

Um ein Schlagwort direkt im zu beschlagwortenden Objekt zu suchen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das zu beschlagwortende Objekt und öffnen Sie es bearbeitend.
2. Lokalisieren Sie das Feld Schlagworte.
3. Tippen Sie den Namen des Schlagworts, nach dem Sie suchen möchten direkt im Feld Schlagworte.
4. Durch Drücken der Eingabetaste auf der Tastatur wird die Suche gestartet.
5. Wählen Sie in der Auswahl das gewünschte Schlagwort.

```
Schlagworte
auto
Auto
Automat
Automobil
```

**Hinweis:** Sie haben die Möglichkeit nach weiteren Schlagworten zu suchen. Tippen Sie einfach nach dem Eintrag/den Einträgen der bereits vergebenen Schlagworte den Namen des zu suchenden Schlagworts und verfahren Sie wie beschrieben.

93

<!-- PDF page 94 -->

## 2.8 Drucken

### 2.8.1 Ein Schriftstück ausdrucken

Um ein Schriftstück auszudrucken, gehen Sie folgendermaßen vor:

1. Öffnen Sie das Schriftstück mit der zugeordneten Drittapplikation (siehe Kapitel 3.6.2 „Ein Schriftstück zum Lesen öffnen“).
2. Drucken Sie das Schriftstück mithilfe der zugeordneten Drittapplikation aus.
3. Schließen Sie die zugeordnete Drittapplikation.

### 2.8.2 Seitenansicht

Um ein Objekt über die Seitenansicht auszudrucken, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das entsprechende Objekt und selektieren Sie es in einer Objektliste.
2. Klicken Sie in der Menüleiste auf das Menü „Objekt“ und anschließend auf „Seitenansicht“.
3. Nutzen Sie die Druckfunktionalität des Adobe Acrobat Readers, um das angezeigte PDF-Dokument auszudrucken.

**Hinweis:** Zusätzliche Informationen finden Sie im Kapitel 3.4.11 „Die Seitenansicht“

### 2.8.3 Einen Vorgang/eine Akte ausdrucken

Das Menü „PDF exportieren“ ist auf Vorgängen und Akten zu finden und bietet die Möglichkeit die Bestandteile der PDF-Übersicht individuell zu gestalteten.

Im Dialog „Auswahl des Exports“ muss der Export festgelegt werden. Es gibt zwei Optionen, diese verhalten sich wie folgt:

- „Standard Export“: Sortierung erfolgt anhand der Reihenfolge in den Objektlisten.
- „Export für Gericht“: Sortierung erfolgt anhand des Erzeugen Datums der Objekte und es werden keine Registerblätter exportiert.

Um einen Export auszuwählen gehen Sie wie folgt vor:

1. Selektieren Sie einen der beiden Exports.
2. Klicken Sie auf Weiter.

Benutzerhilfe

<!-- PDF page 95 -->

Auswahl des Exports

Rolle

X

Bitte wählen Sie den gewünschten Export aus:

Name

Standard Export

Export für Gerichte

Abbrechen

Weiter

Hinweis: Es muss genau ein Export ausgewählt werden, ansonsten erscheint eine Fehlermeldung.

In der „Objekte auswählen" Ansicht werden die untergeordneten Objekte des Vorgangs bzw. der Akte in einer Hierarchie dargestellt. Hier können die, für den PDF Export wichtigen Objekte, einfach über Checkboxen ausgewählt werden. Standardmäßig sind alle Objekte ausgewählt.

Objekte auswählen

Note

X

Selektieren Sie bitte jene Objekte im Baum, die als PDF exportiert werden sollen. Die zusätzlichen Informationen, welche die PDF-Übersichten neben den Metadaten enthalten sollen, lassen sich pro Objekt über den Knoten "PDF-Elemente" einstellen.

![img-9.jpeg](img-9.jpeg)

Abbrechen

Weiter

In der anschließenden „Einstellungen" Ansicht kann definiert werden, wie viele Geschäftsobjekte in einer PDF-Übersicht angezeigt werden sollen.

Benutzerhilfe

<!-- PDF page 96 -->

Einstellungen
Note

X

![img-10.jpeg](img-10.jpeg)

Abbrechen
Weiter

Zur Erstellung einer individuellen PDF-Übersicht eines Vorgangs bzw. einer Akte über „PDF exportieren“, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das entsprechende Objekt und klicken Sie auf den Kontextmenüeintrag „PDF exportieren“
2. Wählen Sie im „Objekte auswählen“ Dialog jene Objekte, welche in der PDF-Übersicht vorkommen sollen und klicken Sie auf Weiter
3. Wählen Sie, ob die Objekte in Pakete aufgeteilt werden sollen und die Anzahl der Geschäftsobjekte pro Paket und klicken Sie auf Weiter

**Ergebnis:**

Von den ausgewählten Objekten wird die PDF-Übersicht generiert und am Ende zum Download angeboten.

Wenn Schwärzungen vorhanden sind, stehen diese auch im Baum zur Auswahl. Pro Ebene wird ein Knoten angezeigt:

Benutzerhilfe
96

<!-- PDF page 97 -->

Objekte auswählen
Rote

Selektieren Sie bitte jene Objekte im Baum, die als PDF exportiert werden sollen. Die zusätzlichen Informationen, welche die PDF-Übersichten neben den Metadaten enthalten sollen, lassen sich pro Objekt über den Knoten "PDF-Elemente" einstellen.

![img-11.jpeg](img-11.jpeg)

Abbrechen
Weiter

## 2.8.4 Einen Aktenplan ausdrucken

Um einen Aktenplan auszudrucken, kann ein Bericht generiert werden und dieser gesamt oder teilweise über die Druckfunktionalität des Webbrowsers ausgedruckt werden.

**Hinweis:** Sortierungen können in der Berichtsvorlage konfiguriert werden.

Um einen Aktenplan auszudrucken, gehen Sie folgendermaßen vor:

1. Zuerst muss ein Bericht mit einer entsprechenden Berichtvorlage generiert werden. Nähere Informationen zum Erzeugen und Generieren von Berichten finden Sie im Kapitel 2.13.1 „Eine Auswertung eines Berichts durchführen".
2. Ein generierter Bericht kann über den Kontextmenüeintrag „Öffnen" eingesehen und über die Druckfunktionalität des Webbrowsers ausgedruckt werden.

## 2.9 Vorlagen und Textbausteine

Um die tägliche Arbeit zu erleichtern, stehen in der Fabasoft eGov-Suite Bayern Dokumentvorlagen und Textbausteine zur Verfügung.

**Hinweis:** Nur Benutzer mit der Stelle „Vorlagenverwalter/in" sowie Administratoren sind zum Erzeugen und Bearbeiten von Dokumenttypen, Dokumentvorlagen, Textbausteinen und Textbaustein-Kategorien berechtigt.

**Hinweis:** Im Rahmen der Weiterentwicklung der Fabasoft eGov-Suite Bayern wurden „Erledigungsvorlagen für Einzelabfertigung" und „Erledigungsvorlagen für Serienabfertigung" mit dem Objekttyp „Microsoft Word-Objekt" zusammengefasst. Sollten Sie eine Erledigungsvorlage für Serienabfertigung suchen, führen Sie bitte eine Suche, wie im Kapitel 2.12 „Suche" beschrieben, nach dem Objekttyp „Microsoft Word-Objekt" durch und setzen Sie das Feld Serienbrief auf „Ja".

Benutzerhilfe

<!-- PDF page 98 -->

Benutzerhilfe

# 2.9.1 Einen Dokumenttyp konfigurieren

Ein neuer Dokumenttyp kann durch Erzeugen eines Objekts der Objektklasse „Dokumenttyp“ bzw. „Dokumenttyp Komponentenobjekt“ konfiguriert werden.

Hinweis: Ein neues Objekt der Objektklasse „Dokumenttyp Komponentenobjekt“ kann nur in einem Verwaltungswerkzeug von einem Domänenadministrator erzeugt werden.

Um einen Dokumenttyp zu erstellen, gehen Sie folgendermaßen vor:

1. Betätigen Sie in der Symbolleiste das Symbol Neu.
2. Wählen Sie in der Auswahl den Eintrag „Dokumenttyp“ aus und klicken Sie auf die Schaltfläche „Weiter“.
3. Setzen Sie die gewünschten Metadaten des Dokumenttyps. Nähere Informationen zu den Metadaten eines Dokumenttyps finden Sie in dem Kapitel 6.15 „Dokumenttyp“.
4. Klicken Sie auf die Schaltfläche „Weiter“, um den Dokumenttyp zu speichern.

# 2.9.2 Textbausteine und Dokumenteigenschaften

## 2.9.2.1 Textbaustein-Kategorien erzeugen und hierarchisch strukturieren

Hinweis: Zum Erzeugen und Bearbeiten von Textbaustein-Kategorien müssen Sie über entsprechende Berechtigungen verfügen.

Um eine Textbaustein-Kategorie zu erzeugen und hierarchisch zu strukturieren, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Klicken Sie auf die Schaltfläche „Neu“.
3. Wählen Sie den Eintrag „Textbaustein-Kategorie“ aus und klicken Sie auf die Schaltfläche „Weiter“.
4. Geben Sie im Feld Name einen Namen für die Textbaustein-Kategorie ein und klicken Sie auf die Schaltfläche „Weiter“.
5. Die Metadaten einer Textbaustein-Kategorie enthalten Informationen, die die Textbaustein-Kategorie beschreiben. Um die Metadaten einer Textbaustein-Kategorie eingeben und bearbeiten zu können, öffnen Sie die Metadaten der Textbaustein-Kategorie im Bearbeitungsmodus.
6. Öffnen Sie das Kontextmenü des Objekts und führen Sie den Befehl „Eigenschaften bearbeiten“ aus.
7. Textbaustein-Kategorien, die dieser Textbaustein-Kategorie übergeordnet sind, werden im Feld Übergeordnete Kategorie eingetragen. Untergeordnete Textbaustein-Kategorien werden im Feld Subkategorien hinterlegt. Im Feld Zugeordnete Textbausteine können Textbausteine angegeben werden, die dieser Textbaustein-Kategorie zugeordnet sind.
8. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

98

<!-- PDF page 99 -->

Benutzerhilfe

## 2.9.2.2 Textbausteine erzeugen und Textbaustein-Kategorien zuordnen

Vordefinierte Texte können mithilfe von Textbausteinen erfasst werden. Textbausteine können bei Dokumenttypen hinterlegt werden.

**Hinweis:** Damit ein Textbaustein für Benutzer verfügbar ist, muss dieser einer Textbaustein-Kategorie zugeordnet werden.

Um Textbausteine zu erzeugen und Textbaustein-Kategorien zuzuordnen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch".
2. Klicken Sie auf die Schaltfläche „Neu".
3. Wählen Sie den Eintrag „Statischer Textbaustein (Word)" aus und klicken Sie auf die Schaltfläche „Weiter".
4. Geben Sie im Feld **Name** einen Namen für den Textbaustein ein und klicken Sie auf die Schaltfläche „Weiter".
5. Die Metadaten „Statischer Textbaustein (Word)" enthalten Informationen, die den Textbaustein beschreiben. Führen Sie den Kontextmenübefehl „Eigenschaften bearbeiten" aus, um die Bearbeitungsansicht zu öffnen.
6. Klicken Sie auf die Schaltfläche „Weiter", um die vorgenommenen Änderungen zu speichern.
7. Um den erzeugten Textbaustein einer Kategorie zuzuordnen, öffnen Sie die Eigenschaften der gewünschten Kategorie.
8. Unter **Zugeordnete Textbausteine** können sie einen kopierten Textbaustein über „Original einfügen" oder über die Suche hinzufügen.
9. Klicken Sie auf die Schaltfläche „Weiter", um die vorgenommenen Änderungen zu speichern.

## 2.9.2.3 Einen statischen Textbaustein (Word) erzeugen und bearbeiten

Das Einfügen von Textbausteinen in Microsoft Office Word erfolgt über die zur Verfügung gestellten Schaltflächen "Unformatiert", "Formatiert" und "Verknüpft". Siehe hierzu auch Kapitel 2.9.2.5 „Einen Textbaustein einfügen".

**Hinweis:** Nur Benutzer mit entsprechenden Berechtigungen können Textbausteine erstellen bzw. bearbeiten.

Um einen statischen Textbaustein (Word) anzulegen, gehen Sie bitte folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch".
2. Klicken Sie auf die Schaltfläche „Neu".
3. Wählen Sie „Statischer Textbaustein (Word)" aus, vergeben Sie einen Namen und klicken Sie auf die Schaltfläche „Weiter".
4. Öffnen Sie den Textbaustein indem Sie auf diesen Klicken.
5. Wählen Sie „Bearbeiten" um den Textbaustein im Bearbeitungsmodus in Microsoft Office Word zu öffnen.

99

<!-- PDF page 100 -->

6. Geben Sie den Text ein und formatieren Sie ihn mit den Formatierungsmöglichkeiten von Microsoft Office Word.

Hinweis: Es können auch andere Textbausteine und sogar virtuelle Eigenschaften in den Textbaustein über die Schaltflächen eingefügt werden.

7. Speichern Sie die Änderungen und schließen Sie Microsoft Office Word. Der Textbaustein ist nun mit Inhalt gefüllt und kann verwendet werden.

Hinweis: Verwenden Sie nicht die Word-Funktion „Speichern unter“, da sonst die Verknüpfung zur Fabasoft eGov-Suite Bayern verloren geht und der Inhalt nicht im Textbaustein gespeichert wird.

## 2.9.2.4 Einen Textbaustein erzeugen und bearbeiten

Metadaten und Inhalt von Textbausteinen des Typs „Textbaustein“ (In früheren Versionen der Fabasoft eGov-Suite „Erweiterter Textbaustein (Web)“) können direkt in der Fabasoft eGov-Suite Bayern bearbeitet werden. Der Inhalt des Textbausteins kann mithilfe des in der Fabasoft eGov-Suite Bayern integrierten HTML-Editors erfasst und geändert werden.

Um einen Textbaustein zu erzeugen und zu bearbeiten, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Erzeugen Sie über „Objekt“ und anschließend „Neu“ einen neuen Textbaustein oder lokalisieren Sie den Textbaustein, den Sie bearbeiten möchten.
3. Zum Bearbeiten der Metadaten eines Textbaustein-Objekts öffnen Sie das Kontextmenü des Objekts und führen Sie den Befehl „Eigenschaften bearbeiten“ aus. Die Metadaten des Objekts werden im Bearbeitungsmodus geöffnet.

Hinweis: Falls Sie keine Rechte besitzen, um die Metadaten zu bearbeiten, wird ein Hinweis angezeigt, dass Sie die Metadaten nur im Lesemodus einsehen können.

4. Erfassen Sie die Metadaten des erweiterten Textbausteins.

Geben Sie im Feld Inhalt auf der Registerkarte „Inhalt“ den Text an, den dieser Textbaustein zur Verfügung stellen soll. Sie können die Möglichkeiten der Formatierung nutzen, die der integrierte Editor bietet.

5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

## 2.9.2.5 Einen Textbaustein einfügen

Zum Einfügen von Textbausteinen in Microsoft Word stehen am Ribbon „Fabasoft eGov-Suite“ folgende Schaltflächen zur Verfügung:

Benutzerhilfe
100

<!-- PDF page 101 -->

![img-12.jpeg](img-12.jpeg)

Hinweis: Das Schriftstück muss aus der Fabasoft eGov Suite Bayern bearbeitend geöffnet werden.

Beim Einfügen eines Textbausteins kann festgelegt werden, ob der Text unformatiert, formatiert oder aktualisierbar eingefügt wird.

Um einen Textbaustein einzufügen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das entsprechende Schriftstück.
2. Öffnen Sie den Inhalt des Schriftstücks mittels des Kontextmenübefehls „Öffnen".
Hinweis: Falls Sie keine Rechte besitzen, um den Inhalt zu bearbeiten, wird ein Hinweis angezeigt, dass Sie den Inhalt nur im Lesemodus einsehen können.
3. Klicken Sie auf die entsprechende Schaltfläche zum Einfügen von Textbausteinen, um einen vordefinierten Text auszuwählen und einzufügen. (Siehe Screenshot oben)
4. Klicken Sie auf die Bezeichnung eines Textbausteins, um den Text an der aktuellen Cursor-Position in den Inhalt des Schriftstücks einzufügen.
Hinweis: Eingefügte Texte können, sofern Sie nicht aus der Gruppe der aktualisierbaren Textbausteine stammen, im aktuellen Dokument angepasst werden. Dies hat keine Auswirkungen auf den Inhalt der Textbausteine selbst.

Zum Einfügen von Textbausteinen stehen folgende Möglichkeiten zur Verfügung:

- **Unformatiert**
Unformatierten Text einfügen: Der Text des Textbausteins wird eingefügt. Die Formatierung wird nicht berücksichtigt.

- **Formatiert**
Formatierten Text einfügen: Der Text des Textbausteins wird eingefügt. Die Formatierung wird berücksichtigt.

- **Verknüpft**
Formatierten Text einfügen (aktualisierbar): Der Text des Textbausteins wird formatiert eingefügt und ist aktualisierbar. Das bedeutet, dass sich Änderungen im Textbaustein auch auf den Text, der im Microsoft Word-Objekt eingefügt wurde, auswirken. Die Aktualisierung erfolgt beispielsweise, wenn das Schriftstück erneut geöffnet wird.

## 2.9.2.6 Dokumenteigenschaften

Um Dokumenteigenschaften über einen Auswahldialog einzufügen, gehen Sie folgendermaßen vor:

Benutzerhilfe

<!-- PDF page 102 -->

1. Klicken Sie auf die Schaltfläche „Einfügen“ und wählen „Eigenschaft“ am Ribbon „Fabasoft eGov-Suite“.

![img-0.jpeg](img-0.jpeg)

Der Dialog „Text einfügen“ wird geöffnet:

![img-1.jpeg](img-1.jpeg)

2. Wählen Sie einen Eintrag aus der Liste der virtuellen Eigenschaften aus. Die gewünschte Dokumenteigenschaft wird automatisch eingefügt. Die Dokumenteigenschaften des Microsoft Word-Objekts werden vom System automatisch mit den entsprechenden Werten befüllt.

Hinweis: Felder in Microsoft Word können mit der F9-Taste aktualisiert werden.

Hinweis: Grundsätzlich sollten nur die Dokumenteigenschaften der Komponenten CFGBAYERN@15.1400 („Bayern Vorkonfiguration“) verwendet werden.

Benutzerhilfe

<!-- PDF page 103 -->

Benutzerhilfe

# 2.9.3 Ein Musterdokument erstellen

Hinweis: Je nach Konfiguration des Microsoft Word-Objekts, durch Setzen des Feldes Serienbrief wahlweise auf „Ja" oder „Nein", erhalten die Empfänger einen personalisierten Inhalt (Serienbrief „Ja") oder jeder Empfänger eine idente Kopie des Inhalts (Serienbrief „Nein").

Um ein Musterdokument zu erzeugen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf den „Schreibtisch"
2. Lokalisieren Sie den Dokumenttyp, dessen Musterdokumente Sie bearbeiten möchten.
Hinweis: Wenn sich der Dokumenttyp noch nicht auf Ihrem Schreibtisch befindet, ermitteln Sie diesen über eine Suche. Geben Sie als gesuchten Typ des Objekts „Dokumenttyp" an. Übernehmen Sie den Dokumenttyp aus dem Suchergebnis auf Ihren Schreibtisch.
3. Führen Sie den Kontextmenübefehl „Eigenschaften bearbeiten" aus. Die Metadaten des Objekts werden im Bearbeitungsmodus geöffnet.
Hinweis: Falls Sie keine Rechte besitzen, um die Metadaten zu bearbeiten, wird ein Hinweis angezeigt, dass Sie die Metadaten nur im Lesemodus einsehen können.
4. Wechseln Sie auf die Registerkarte „Dokumenttyp" und lokalisieren Sie das Feld Musterdokumente. In diesem Feld können Dokumentvorlagen hinterlegt werden.
5. Klicken Sie auf die Schaltfläche „Neu".
6. Wählen Sie den Typ des Objekts aus, das erzeugt werden soll. Folgende Einträge stehen zur Verfügung:
- Microsoft Word-Objekt
- Microsoft Excel-Arbeitsblatt
- OpenDocument Tabellendokument
- OpenDocument Text
7. Geben Sie im Feld Name einen Namen für das Objekt ein und klicken Sie auf die Schaltfläche „Weiter".
8. Wenn Sie eine Vorlage zur Serienabfertigung erstellen möchten, öffnen Sie die Metadaten des Microsoft Word-Objekts und setzen Sie das Feld Serienbrief auf „Ja".
9. Mit einem Klick auf den Namen der Vorlage oder durch das Ausführen des Kontextmenübefehls „Öffnen" öffnen Sie die gewünschte Vorlage, die Sie bearbeiten möchten im zugehörigen Drittprodukt.
Nun können Sie die Vorlage frei gestalten / ändern.
10. Um Änderungen zu speichern, muss die Speicherfunktionalität des Drittprodukts genutzt werden. Dies bewirkt, dass die Änderungen auch in der Fabasoft eGov-Suite Bayern verfügbar werden.
Um die Bearbeitung zu beenden, schließen Sie das Drittprodukt.

# 2.9.3.1 Dokumenteigenschaft „Empfänger" und „Empfänger blockorientiert"

In Word-Dokumentvorlagen können Dokumenteigenschaften als Felder hinterlegt werden. Beim Öffnen einer Erledigung, die auf dieser Vorlage basiert, werden die Felder mit den aktuellen Werten aus dem System befüllt.

103

<!-- PDF page 104 -->

Die Dokumenteigenschaften „Empfänger“ (Recipients) und „Kopie-Empfänger“ (CopyRecipients) zeigen als Ergebnis jeden (Kopie-)Empfänger in einer eigenen Zeile.

Sollen die Empfänger in jeweils einem Adressblock dargestellt werden, so können folgende Dokumenteigenschaften verwendet werden:

Die Dokumenteigenschaften „Empfänger-blockorientiert“ (RecipientsBlocked) und „Kopie-Empfänger-blockorientiert“ (CopyRecipientsBlocked) zeigen als Ergebnis jeden (Kopie-) Empfänger in einem eigenen, mehrzeiligen Block.

![img-2.jpeg](img-2.jpeg)

## 2.9.4 Objekt-Vorlagen

### 2.9.4.1 Eine Vorlagensammlung erzeugen

Um eine Vorlagensammlung zu erzeugen, gehen Sie folgendermaßen vor:

1. Klicken Sie auf Ihren Benutzernamen rechts oben
2. Öffnen Sie das Menü „Einstellungen“ und wechseln Sie auf die Registerkarte „Bedienung“.
3. Lokalisieren Sie das Feld Vorlagensammlungen. In diesem Feld können Sie neue Objekte des Typs Vorlagensammlung erzeugen. Sie können Vorlagensammlungen bearbeiten und Vorlagen in diesen Vorlagensammlungen hinterlegen.

**Hinweis:** Um Vorlagensammlungen für Benutzer zur Verfügung zu stellen, muss dies von Benutzern mit entsprechender Berechtigung konfiguriert werden.

4. Klicken Sie auf die Schaltfläche „Eintrag erzeugen“ und anschließend auf „Neu“.
5. Erfassen Sie die Metadaten der Vorlagensammlung. Die Objekte, die über diese Vorlagensammlung als Vorlagen verfügbar gemacht werden sollen, werden auf der Registerkarte „Vorlagensammlung“ im Feld Vorlage hinterlegt. Zur Verfügung stehende Vorlagenkategorien können im Feld Kategorien eingetragen werden. Ein bestehendes Objekt können Sie auf folgende Arten in das Feld Objektliste übernehmen:

Benutzerhilfe

<!-- PDF page 105 -->

o Führen Sie im Suchen und Hinzufügen-Feld eine Schnellsuche durch.
o Führen Sie über die Kontextmenüaktion „Suche“ eine Suche durch.

6. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.
7. Objekte, die in Vorlagensammlungen als Vorlagen hinterlegt sind, werden beim Erzeugen von neuen Objekten im Feld Vorlagen zur Auswahl angeboten. Wenn Sie auf einen Eintrag im Feld Vorlagen klicken, wird eine Kopie dieser Vorlage erzeugt und in der aktuellen Objektliste abgelegt. Standardmäßig wird vor dem Namen des neu erzeugten Objekts „Kopie der Vorlage“ angefügt.

## 2.9.4.2 Eine Vorlagensammlung kategorisieren

Um Vorlagensammlungen zu kategorisieren, müssen Vorlagenkategorien erzeugt und den Vorlagensammlungen zugeordnet werden. Dies dient dazu, Benutzern Vorlagen übersichtlich gegliedert anzubieten. Vorlagenkategorien werden in den Metadaten einer Vorlagensammlung im Feld Kategorien angegeben.

Wurden Vorlagensammlungen durch Zuordnung von Vorlagenkategorien kategorisiert, werden beim Erzeugen neuer Objekte die verfügbaren Vorlagenkategorien im Feld Vorlagen-Kategorien angeboten. Klicken Sie auf die Bezeichnung einer Vorlagenkategorie erhalten, Sie eine Übersicht über die Vorlagen, die dieser Kategorie zugeordnet wurden. Klicken Sie auf die Bezeichnung einer Vorlage um ein Objekt zu erzeugen, welches auf der gewählten Vorlage basiert. Es wird eine Kopie dieser Vorlage erzeugt und in der aktuellen Objektliste abgelegt.

Um eine Vorlagensammlung zu kategorisieren, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Öffnen Sie das Menü „Einstellungen“ und wechseln Sie auf die Registerkarte „Bedienung“.
3. Lokalisieren Sie das Feld Vorlagensammlung. In diesem Feld können Sie neue Objekte des Typs Vorlagensammlung erzeugen. Sie können Vorlagensammlungen bearbeiten und Vorlagen in diesen Vorlagensammlungen hinterlegen.

**Hinweis:** Um Vorlagensammlungen für Organisationseinheiten oder Fabasoft eGov-Suite Bayern Domänen zur Verfügung zu stellen, muss dies von Benutzern mit der Stelle „Domänenadministrator“ entsprechend konfiguriert werden.

4. Führen Sie den Kontextmenübefehl „Eigenschaften bearbeiten“ aus. Die Metadaten des Objekts werden im Bearbeitungsmodus geöffnet.

**Hinweis:** Falls Sie keine Rechte besitzen, um die Metadaten zu bearbeiten, wird ein Hinweis angezeigt, dass Sie die Metadaten nur im Lesemodus einsehen können.

5. Vorlagenkategorien werden Vorlagensammlungen auf der Registerkarte „Vorlagensammlung“ im Feld Kategorien zugeordnet. Eine bestehende Vorlagenkategorie können Sie durch eine Schnellsuche im Hinzufügen-Feld in die Objektliste übernehmen.
6. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

Benutzerhilfe
105

<!-- PDF page 106 -->

Benutzerhilfe

## 2.9.4.3 Eine Vorlage erzeugen

Als Vorlagen sind jene Objekte verfügbar, die in Vorlagensammlungen im Feld Objektliste abgelegt werden. Vorlagen können folgendermaßen abgelegt werden:

- Neue Objekte erzeugen: Erzeugen Sie ein neues Objekt. Öffnen Sie das Menü „Objekt“ im Feld Objektliste und führen Sie den Befehl „Neu“ aus.
- Bestehende Objekte übernehmen: Es kann eine Suche durchgeführt werden.
- Dateien aus dem lokalen Dateisystem übernehmen: Eine Datei aus dem lokalen Dateisystem kann z.B. mithilfe von Drag &amp; Drop auf die Objektliste oder durch Importieren in die Vorlagensammlung übernommen werden. Siehe hierzu auch Kapitel 2.1.2.8 „Ein Objekt importieren“.

Um eine Vorlage zu erzeugen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Öffnen Sie das Menü „Einstellungen“ und wechseln Sie auf die Registerkarte „Bedienung“.
3. Lokalisieren Sie das Feld Vorlagensammlung. In diesem Feld können Sie neue Objekte des Typs Vorlagensammlung erzeugen. Sie können Vorlagensammlungen bearbeiten und Vorlagen in diesen Vorlagensammlungen hinterlegen.

**Hinweis:** Um Vorlagensammlungen für Organisationseinheiten oder Fabasoft eGov-Suite Bayern Domänen zur Verfügung zu stellen, muss dies von Benutzern mit der Stelle „Domänenadministrator“ entsprechend konfiguriert werden. Für die Konfiguration der Benutzer kann dies auch durch den „Fachadministrator“ geschehen. Benutzern mit der Stelle „OE-Administrator“ können diese Konfigurierung nur durchführen, solange die Organisationseinheit der zu bearbeitenden Organisationseinheit der Organisationseinheit des Benutzers untergeordnet ist.

4. Führen Sie den Kontextmenübefehl „Eigenschaften bearbeiten“ aus. Die Metadaten der Vorlagensammlung werden im Bearbeitungsmodus geöffnet.

**Hinweis:** Falls Sie keine Rechte besitzen, um die Metadaten zu bearbeiten, wird ein Hinweis angezeigt, dass Sie die Metadaten nur im Lesemodus einsehen können.

5. Klicken Sie auf die Schaltfläche „Neu“ in der Symbolleiste des Feldes Vorlagen, um ein neues Objekt zu erzeugen, das als Vorlage verfügbar sein soll. Wählen Sie den Typ des Objekts aus, das erzeugt werden soll. Bearbeiten Sie die Metadaten und den Inhalt des Objekts.

**Hinweis:** Sobald ein Objekt im Feld Objektliste hinterlegt ist, ist es als Vorlage verfügbar.

6. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

Das von Ihnen erzeugte Objekt kann nun beim Erzeugen von neuen Objekten als Vorlage verwendet werden.

## 2.9.4.4 Ein auf einer Vorlage basierendes Objekt erzeugen

Objekte, die auf einer Vorlage basieren, können über die Schaltfläche „Neu“ bzw. über den Befehl „Neu“ aus dem Menü „Objekt“ erzeugt werden.

Beim Erzeugen eines neuen Objekts werden die verfügbaren Vorlagenkategorien im Feld Vorlagen-Kategorien angeboten. Klicken Sie auf die Bezeichnung der Vorlagenkategorie, die die Vorlagen enthält, die Sie benötigen. Klicken Sie anschließend auf die Bezeichnung der Vorlage,

Benutzerhilfe

<!-- PDF page 107 -->

um ein Objekt zu erzeugen, das auf dieser Vorlage basiert. Es wird eine Kopie dieser Vorlage erzeugt und in der aktuellen Objektliste, beispielsweise auf Ihrem Schreibtisch abgelegt.

Beispiel: Es wurde eine Vorlagensammlung erstellt und die Kategorie „Meine Vorlagenkategorie" vergeben. Die Vorlagensammlung enthält eine Vorlage für ein Word-Dokument.

![img-3.jpeg](img-3.jpeg)

## 2.10 Versionierung

### 2.10.1 Eine Version manuell speichern

Um eine Version zu erzeugen gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt, von dem eine Version erzeugt werden soll.
2. Markieren Sie das Objekt.
3. Klicken Sie auf den „Zeitreise“-Button und anschließend auf „Aktuelle Version sichern“.

Benutzerhilfe

<!-- PDF page 108 -->

Benutzerhilfe
108

[tbl-0.md](tbl-0.md)

4. Geben Sie eine Beschreibung der zu sichernden Version ein und klicken Sie auf die Schaltfläche „Weiter“.

**Hinweis:** Diese Beschreibung kann später nicht mehr geändert werden.

## 2.10.2 Eine Version anzeigen

Ein bereits gesicherter Stand eines Objekts kann, auch wenn bereits eine neuere Version existiert, noch immer gelesen werden. Sämtliche Metadaten und Primärinhalte werden mit den zum Zeitpunkt der Versionierung vorhandenen Werten angezeigt.

Über den Befehl „Zurück zur aktuellen Version“ im Menü „Versionen“ kann die Version wieder auf den aktuellen Stand zurückgesetzt werden.

Um eine Version anzuzeigen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt, von dem eine Version gelesen werden soll
2. Markieren Sie das Objekt
3. Klicken Sie auf den „Zeitreise“-Button und anschließend auf „Zeitreise starten“.
4. Klicken Sie auf das Datum einer Version, um das aktuelle Objekt auf den ausgewählten Stand zurückzusetzen.
5. Öffnen Sie das Objekt nun lesend wie im Kapitel 3.6.2 „Ein Schriftstück zum Lesen öffnen“.

<!-- PDF page 109 -->

Hinweis: Es wird ein zusätzliches Symbol  $\mathbb{O}$  beim Objekt angezeigt, wenn sie eine Version lesen, um schnell erkennen zu können, ob es sich um die aktuelle Version handelt.

## 2.10.3 Eine Version über die Zeitleiste anzeigen

Die Versionen eines Objekts können auch über die Zeitleiste eingesehen werden. Die Zeitleiste befindet sich nach dem Öffnen des Menüs Zeitreise im unteren Bereich. Sie besteht aus folgenden Elementen:

![img-4.jpeg](img-4.jpeg)

Zeitachse: Der Verlauf der Zeit dargestellt als horizontale Line. Die nachfolgenden Elemente sind darauf angeordnet.

Positionslinie: Rote vertikale Linie am Zeitstrahl. Die Linie zeigt an, auf welcher Position man sich auf der Zeitachse befindet. Beim Positionieren ist die Vorschau der Linie grau hinterlegt. Beim Ausführen des Menüs Zeitreise befindet sich die Linie auf dem Element Jetzt. Je nach Zeitbestand des Objekts ist die Zeitachse zunächst z.B. in Monats-, Tages- bzw. Stundenbereiche unterteilt. Bei der Positionierung der Linie per Klick auf einen Monats- bzw. Tagesbereich, werden maximal drei Tage bzw. drei Stunden dieses Bereichs in der Zeitleiste geöffnet. Die geöffneten Bereiche sind weiß hinterlegt, die anderen auswählbaren Bereiche sind grau untermalt. Bei der Positionierung spielt es eine Rolle, wo genau die Positionslinie gesetzt wurde. D.h. wenn z.B. im Monatsbereich die Mitte ausgewählt wurde, dann erscheinen die mittleren Monatstage. Eine Auswahl einer Version kann im Stundenbereich durchgeführt werden. Hier entspricht die Position der Linie dem ausgewählten Zeitpunkt bzw. eines ausgewählten Versionspunkts. Im Stundenbereich kann man eine Stunde vor- bzw. zurücknavigieren. Hierbei positioniert man die Linie in den linken (Navigation um eine Stunde zurück) bzw. rechten Stundenbereich (Navigation um eine Stunde nach vor).

Erzeugt: Der Zeitpunkt der Erstellung. Durch einen Klick auf das Element wird die Zeitreise gestartet und die Positionslinie wird auf das Element gesetzt.

Jetzt: Der aktuelle Zeitpunkt und Ausgangspunkt der Zeitreise. Gestartet ist die Zeitreise auf dieser Position nicht. Wenn man sich aktuell in der Zeitreise befindet, kann durch Klick auf das Element die Zeitreise wieder beendet werden.

Versionspunkt: Eine Version wird als Punkt auf der Zeitachse dargestellt.

Um eine Version über die Zeitleiste anzuzeigen, gehen Sie folgendermaßen vor:

1. Navigieren Sie in das Objekt, von dem eine Version gelesen werden soll.
2. Klicken Sie auf den „Zeitreise“-Button. Die Zeitleiste erscheint im unteren Bereich.
3. Versionsauswahl über Monatsbereich: Klicken Sie auf den gewünschten Monat in welchem sich der Versionspunkt befindet. Der Tagesbereich des Monats öffnet sich. Klicken Sie erneut auf den Versionspunkt. Der Stundenbereich des Monats öffnet sich. Klicken Sie auf den Versionspunkt.

Versionsauswahl über Tagesbereich: Klicken Sie auf den gewünschten Tagesbereich. Positionieren Sie dabei die Positionslinie auf den Versionspunkt. Der Stundenbereich des Versionspunkt wird geöffnet. Klicken Sie auf den Versionspunkt.

Versionsauswahl über Stundenbereich: Klicken Sie auf den Versionspunkt in der Zeitleiste.

Benutzerhilfe
109

<!-- PDF page 110 -->

Hinweis: Wenn man den Mauszeiger auf einen Versionspunkt positioniert, werden in der erscheinenden IntelliHelp Informationen zur Version angezeigt.

## 2.10.4 Eine Version wiederherstellen

Die Fabasoft eGov-Suite Bayern unterstützt das Wiederherstellen eines Objekts aus einer früheren Version. Die Version wird wiederhergestellt und kann direkt bearbeitet werden. Um den aktuellen Inhalt (Metadaten und Schriftstücke) zu sichern, kann vor dem Wiederherstellen einer Version eine Version gespeichert werden.

Um eine Version eines Objekts wiederherzustellen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt, von dem eine Version gelesen werden soll
2. Markieren Sie das Objekt
3. Klicken Sie auf den „Zeitreise“-Button und anschließend auf „Zeitreise starten“.
4. Wählen Sie aus der angezeigten Liste der Versionen die Version aus, die Sie wiederherstellen möchten.
5. Führen Sie den Befehl „Wiederherstellen“ aus.

Hinweis: Durch das Ausführen des Befehls „Version wiederherstellen“ wird das Original überschrieben. Sichern Sie eine Version, bevor Sie eine alte Version wiederherstellen, um Datenverlust zu vermeiden.

![img-5.jpeg](img-5.jpeg)

Benutzerhilfe
110

<!-- PDF page 111 -->

Benutzerhilfe
111

# 2.10.5 Ein Schriftstück mit einer Version vergleichen

Hinweis: Diese Funktion existiert ausschließlich für Microsoft Word-Objekte.

Die Fabasoft eGov-Suite Bayern bietet die Möglichkeit, Inhalte von Schriftstücken verschiedener Versionen zu vergleichen. Es kann beispielsweise der aktuelle Inhalt eines Schriftstücks mit einer früheren Version desselben Schriftstücks verglichen werden. Die Unterschiede werden über die Versionsvergleichsfunktionalität von Microsoft Office Word angezeigt.

Um den Inhalt eines Schriftstücks mit einer Version zu vergleichen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Geschäftsobjekt, von dem Versionen verglichen werden sollen.
2. Markieren Sie das Geschäftsobjekt.
3. Starten Sie eine Zeitreise und wählen Sie die Version aus, die Sie vergleichen wollen.
4. Drücken Sie auf „Vergleichen“ dann, kann die ausgewählte Version mit einer weiteren verglichen werden.

Hinweis: Wenn Sie eine gesicherte mit der aktuellen Version vergleichen wollen, wählen Sie nur eine Version aus.

5. Klicken Sie auf die Schaltfläche „Inhalte vergleichen“, wenn Sie dann die Inhalte der beiden Versionen miteinander vergleichen wollen.

[tbl-1.md](tbl-1.md)

# Erstellung

[tbl-2.md](tbl-2.md)
[tbl-3.md](tbl-3.md)

# 2.10.6 Versionen löschen

Hinweis: Für das Löschen von Versionen muss der jeweilige Benutzer entsprechend berechtigt sein.

Mittels Version löschen ist es möglich einzelne Versionen zu löschen. Mit Versionen aufräumen können Versionen auf zwei Arten gelöscht werden:

1. Definieren der Maximalen Anzahl der aufbewahrten Versionen
2. Vergabe der Tage, nach denen ältere Versionen automatisch gelöscht werden

Hinweis: Hierbei handelt es sich um ein einmaliges Löschen von Versionen.

<!-- PDF page 112 -->

Benutzerhilfe
112

# 2.11 Unterschreiben

In der Fabasoft eGov-Suite Bayern haben Sie die Möglichkeit, Unterschriften auf Objekten anzubringen. Unterschriften können über verschiedene Möglichkeiten angebracht werden:

- Über das Kontextmenü
- Implizit über das Ausführen eines Arbeitsschritts im Arbeitsvorrat

Anbringen einer Unterschrift über das Kontextmenü

Um eine Unterschrift über das Kontextmenü anzubringen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt, auf das Sie die Unterschrift anbringen wollen.
2. Rufen Sie das Kontextmenü des Objekts auf.
3. Wählen Sie die gewünschte Unterschrift im Kontextmenü unter „Unterschriften“ aus.

Anbringen einer Unterschrift über einen Arbeitsschritt:

Falls über das Ausführen eines Arbeitsschritts eine Unterschrift auf ein Objekt angebracht wird, haben Sie die Möglichkeit, eine Zeichnungsbezogene Bemerkung einzugeben. Die Unterschrift wird mit dem Klick auf die Schaltfläche „Zeichnen“ auf das Objekt angebracht.

# 2.12 Suche

## 2.12.1 Eine Suche starten

Eine mithilfe von Suchkriterien eingeschränkte Suche kann auf eine der folgenden Arten gestartet werden:

- Mithilfe der Schaltfläche „Suchen“

Ordner
Mein Ordner

+ Neu
☐ Suchen
↑ Hochladen
☐ Kopieren
☐ Link
☐ Eigenschaften
☐ Zeitreise

<!-- PDF page 113 -->

- Über den Befehl „Suchen“ im Kontextmenü.

![img-6.jpeg](img-6.jpeg)

- Über „Suchen und hinzufügen“ in diversen Objektlisten

![img-7.jpeg](img-7.jpeg)

- Über das Mindbreeze Suchfeld:

![img-8.jpeg](img-8.jpeg)

Hinweis: Die Mindbreeze Suche unterscheidet sich von der standardmäßig verwendeten Metadatensuche. Detaillierte Informationen zur Mindbreeze Suche finden Sie im Kapitel 2.12.14 „Suche nach Objekten mittels Mindbreeze Suchfeld“.

Benutzerhilfe

<!-- PDF page 114 -->

2.12.2 Objekte über Metadaten-Suche finden

Akten, Vorgänge, Dokumente usw. können nach ihren Metadaten gesucht werden.

Um über die Metadaten-Suche zu finden, gehen Sie folgendermaßen vor:

1. Öffnen Sie die Suche über die gleichnamige Schaltfläche oder über das Kontextmenü (Siehe Kapitel 2.12.1 „Eine Suche starten“)

2. Wählen Sie Objektklasse aus, nach welcher gesucht werden soll und klicken Sie auf die Schaltfläche „Weiter“.

**Hinweis:** Objektklassen, von denen Objekte bereits in der aktuellen Liste vorhanden sind und eine definierte Liste von Objektklassen, werden in der Liste Vorschlag vor der Durchführung einer neuen Suche gezeigt. Klicken Sie auf die Bezeichnung des Eintrags, um einen Typ auszuwählen. Dieser Schritt entfällt, wenn im jeweiligen Kontext nur nach einer einzigen Objektklasse gesucht werden kann.

3. Geben Sie die Informationen, die Ihnen über das zu suchende Objekt bekannt sind, in den entsprechenden Feldern ein. Nähere Informationen zur Eingabe der Suchkriterien finden Sie im Kapitel 2.12.3 „Suche mit Platzhaltern“.

4. Klicken Sie auf die Schaltfläche „Suche starten“.

Das Suchergebnis wird als Trefferliste angezeigt. Es können sowohl der Inhalt als auch die Metadaten der gefundenen Objekte eingesehen werden. Markieren Sie die Treffer, die Sie für die weitere Arbeit übernehmen möchten.

5. Klicken Sie auf die Schaltfläche „Weiter“, um die markierten Treffer aus der Suchergebnisliste zu übernehmen. Die gewählten Treffer werden in der Liste eingefügt, aus der Sie die Suche gestartet haben.

2.12.3 Suche mit Platzhaltern

Im Suchdialog werden die Kriterien festgelegt, anhand derer die Ergebnisobjekte gesucht werden. Nur Objekte, die diesen Kriterien entsprechen, werden in die Trefferliste übernommen. Alle angegebenen Suchkriterien werden mit dem logischen Operator „UND“ verknüpft, d.h. es müssen alle angegebenen Kriterien erfüllt werden, damit ein Objekt in die Trefferliste übernommen wird.

Die einzelnen Felder im Suchdialog (wie Name, Anmerkungen usw.) stellen die einzelnen Metadaten (Eigenschaften) des gesuchten Objekts dar. In den Feldern werden die gewünschten Werte eingegeben. Exakte Suchkriterien liefern ein genaueres Ergebnis (also weniger Treffer) als Allgemeine.

Suchkriterien können:

- über Einträge in Auswahllisten verfeinert oder
- über Wildcards eingeschränkt werden.

**Optionen im Menü:**

Optionen im Menü ermöglichen die Formulierung von Suchabfragen, ohne die dahinterstehende Abfragesprache beherrschen zu müssen. Je nach Typ des Feldes, in dem ein Suchkriterium eingegeben werden kann, können verschiedene Einträge über ein zugehöriges Symbol ausgewählt werden. Klicken Sie dazu auf das Symbol.

Benutzerhilfe

<!-- PDF page 115 -->

![img-9.jpeg](img-9.jpeg)

Alle Einträge im Überblick:

- „gleich“
Durch diesen Eintrag werden alle Objekte gesucht, die exakt dem eingegeben Wert entsprechen.

- „ungleich“
Durch diesen Eintrag werden alle Objekte gesucht, für die der Wert in dieser Eigenschaft ungleich dem im zugehörigen Eingabefeld definierten Wert ist.

- „Beliebiger Wert“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, deren Wert in dieser Eigenschaft nicht leer ist.

- „Kein Wert“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, deren zugehörige Eigenschaft keinen Wert enthält. Wenn dieser Eintrag ausgewählt ist, ist keine Eingabe im Eingabefeld mehr notwendig, dieses wird daher nicht mehr bearbeitbar dargestellt.

- „Beginnt mit“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft mit der definierten Zeichenfolge beginnt.

Benutzerhilfe
115

<!-- PDF page 116 -->

Benutzerhilfe
116

„Beginnt nicht mit“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft nicht mit der definierten Zeichenfolge beginnt.

... A
„Endet mit“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft mit der definierten Zeichenfolge endet.

... A
„Endet nicht mit“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft nicht mit der definierten Zeichenfolge endet.

... A ... „Enthält“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft an beliebiger Stelle die im Eingabefeld definierte Zeichenfolge enthält.

... A ... „Enthält nicht“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft an keiner Stelle die in dem zugehörigen Eingabefeld definierte Zeichenfolge enthält.

... A ■ „Volltext-Abfrage“
Dieser Eintrag bewirkt, dass eine Volltextsuche in Zeichenketteneigenschaften in der Datenbank durchgeführt wird (entsprechende Systemkonfiguration vorausgesetzt).

... ))
„Klingt wie“
Dieser Eintrag bewirkt, dass eine phonetische Suche durchgeführt wird. Es werden alle Objekte in die Ergebnisliste übernommen, bei denen der Wert dieser Eigenschaft „ähnlich klingt“ (datenbankabhängig), wie die im zugehörigen Eingabefeld festgelegte Zeichenkette.

... ))
„Klingt nicht wie“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft nicht „ähnlich klingt“, wie die im zugehörigen Eingabefeld festgelegte Zeichenkette.

[ ... „Ab“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, welche in der Eigenschaft ein Datum ab dem angegebenen Datum eingetragen haben.

... ] „Bis“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, welche in der Eigenschaft ein Datum bis zu dem angegebenen Datum eingetragen haben.

[ ... ] „Zwischen“
Dieser Eintrag bewirkt, dass alle Objekte in die Ergebnisliste aufgenommen werden, bei denen der Wert dieser Eigenschaft zwischen den beiden Daten in den zugehörigen Eingabefeldern festgelegten Werten liegt.

<!-- PDF page 117 -->

Wildcards dienen als Platzhalter für beliebige Zeichen oder Zeichenfolgen nach selbst definierten Kriterien. Dadurch können Sie die Suche erweitern und bessere Suchergebnisse zu einer bestimmten Bedeutung erzielen.

Folgende Wildcards können verwendet werden:

- „*“ oder „%“
Der Stern („*“) steht für eine beliebige Zeichenfolge. Optional zum Zeichen „*“ kann auch das Prozentzeichen „%“ verwendet werden.
Beispiel: Eine Suche nach „*berg“ liefert Ergebnisse, die eine beliebige Zeichenfolge gefolgt von der Zeichenfolge „berg“ am Ende der Zeichenkette enthalten – „Eisberg“, „Zauberberg“, „Erzberg“. Eine Suche nach „Berg*“ liefert Ergebnisse, die „Berg“ gefolgt von einer beliebigen Zeichenfolge enthalten – „Berger“, „Bergsteiger“, „Berghotel“. Eine Suche nach „Ber*er“ liefert Ergebnisse, die „Ber“ gefolgt von einer beliebigen Zeichenfolge sowie gefolgt von „er“ enthalten – „Berger“, „Bergsteiger“, „Berliner“.

- „?“ oder „_“
Das Fragezeichen „?“ steht für exakt ein Zeichen. Optional zum Zeichen „?“ kann auch das Zeichen Unterstrich „_“ verwendet werden.
Beispiel: Eine Suche nach „_atterbauer“ liefert Ergebnisse, die exakt ein (beliebiges) Zeichen gefolgt von der Zeichenkette „_atterbauer“ enthalten – „Katterbauer“, „Patterbauer“, „Natterbauer“.

- „~“
Die Tilde „~“ (erreichbar über die Tastenkombination AltGr + +) steht für eine phonetische Suche. Es werden alle Objekte gefunden, bei denen die Aussprache der im Suchkriterium angegebenen Zeichenkette ähnlich ist. Eine Tilde muss genau am Beginn des Suchkriteriums eingegeben werden.
Beispiel: Eine Suche nach „~Maier“ liefert ähnlich klingende Ergebnisse wie „Maier“ und „Meier“.

Die meisten Optionen, die über Wildcards abgedeckt werden, können auch über Optionen aus dem Menü definiert werden. Für die Wildcards „?“ bzw. „_“ sowie „[ ]“ stehen jedoch keine entsprechenden Optionen in den Drop-down-Listen zur Verfügung.

Gegenüberstellung: Optionen aus dem Menü vs. Wildcards

- „Beginnt mit“ „Vertrag“ entspricht „Vertrag*“
- „Endet mit“ „Vertrag“ entspricht „*Vertrag“
- „Enthält“ „Vertrag“ entspricht „*Vertrag*“
- „Klingt wie“ „Vertrag“ entspricht „~Vertrag“
- „Volltext-Abfrage“ „Vertrag“ entspricht „%%Vertrag“

## 2.12.4 Eine Suche weiter einschränken

Durchgeführte Suchen können durch die Eingabe weiterer Suchparameter zusätzlich eingeschränkt werden. Dabei werden die Suchparameter der ursprünglichen Suche nicht verworfen.

Um erneut zur Eingabe der Suchkriterien zu gelangen, klicken Sie in der Suchergebnisliste auf die Schaltfläche „Suche ändern“.

Benutzerhilfe
117

<!-- PDF page 118 -->

Hinweis: Nähere Informationen zur Durchführung einer Suche finden Sie im Kapitel 2.12.2 „Objekte über Metadaten-Suche finden“.

Um eine Suche weiter einzuschränken, gehen Sie folgendermaßen vor:

1. Klicken Sie in der Suchergebnisliste auf die Schaltfläche „Suche ändern“. Die Suchkriterien der ursprünglichen Suche werden nicht verworfen, sondern erneut angeboten. Dadurch können die bereits definierten Suchkriterien verändert oder genauer spezifiziert werden.
2. Geben Sie bei Bedarf weitere Suchkriterien ein.

## 2.12.5 Kaskadierte Suche

Mittels kaskadierter Suche kann eine Suche in einer Suche durchgeführt werden. Dadurch kann zum Beispiel beim Suchen nach Geschäftsobjekten, im Suchformular nach hinterlegten Schlagwörtern gesucht werden.

Um eine kaskadierte Suche durchzuführen, gehen Sie folgendermaßen vor:

1. Klicken Sie innerhalb eines Suchformulars auf das Suchen-Symbol am Ende einer Objektzeigereigenschaft (rechts im betroffenen Eintrag) z.B. Schlagworte im Suchformular für Vorgang.
2. Geben Sie die Informationen, die Ihnen über das zu suchende Objekt bekannt sind, in den entsprechenden Feldern ein. Nähere Informationen zur Eingabe der Suchkriterien finden Sie im Kapitel 2.12.3 „Suche mit Platzhaltern“.
3. Klicken Sie auf die Schaltfläche „Suche starten“.

Das Suchergebnis wird als Trefferliste angezeigt. Es können sowohl der Inhalt als auch die Metadaten der Objekte eingesehen werden. Markieren Sie die Treffer, die Sie für die weitere Arbeit übernehmen möchten.

1. Klicken Sie auf die Schaltfläche „Weiter“, um die markierten Treffer aus der Suchergebnisliste zu übernehmen.
2. Setzen Sie die ursprüngliche Suche fort, indem Sie bei Bedarf weitere Metadaten als Suchkriterien befüllen und anschließend die Suche mit „Weiter“ starten.

## 2.12.6 Akten, Vorgänge und Dokumente über Volltextsuche finden

### 2.12.6.1 Volltextsuche in Metadaten

Die Fabasoft eGov-Suite Bayern unterstützt die Volltextsuche in Metadaten des Typs Zeichenkette.

Hinweis: Um die Volltextsuche nutzen zu können, muss diese vom Systemadministrator für die betreffenden Felder konfiguriert worden sein.

Um Akten, Vorgänge und Dokumente über die Volltextsuche zu finden, gehen Sie folgendermaßen vor:

1. Öffnen Sie die Suche über die gleichnamige Schaltfläche oder über das Kontextmenü (Siehe Kapitel 2.12.1 „Eine Suche starten“)

Benutzerhilfe
118

<!-- PDF page 119 -->

2. Wählen Sie den Eintrag aus, der dem Typ des gesuchten Objekts entspricht und klicken Sie auf die Schaltfläche „Weiter“.
Hinweis: Typen, von denen Objekte bereits in der aktuellen Liste vorhanden sind und eine definierte Liste von Objektklassen, werden in der Liste Vorschlag angezeigt. Klicken Sie auf die Bezeichnung des Eintrags, um einen Typ auszuwählen. Dieser Schritt entfällt, wenn im jeweiligen Kontext nur nach einem bestimmten Typ gesucht werden kann.

3. Wählen Sie aus der Auswahlliste vor einem Feld des Typs Zeichenkette, z.B. Name, den Eintrag „Volltext-Abfrage“ aus (siehe Kapitel 2.12.3 „Suche mit Platzhaltern“).
4. Geben Sie im betroffenen Feld den Text ein, nach dem Sie suchen möchten.
5. Klicken Sie auf die Schaltfläche „Suche starten“.
6. Das Suchergebnis wird als Trefferliste angezeigt. Es können sowohl der Inhalt als auch die Metadaten der Objekte eingesehen werden. Markieren Sie die Treffer, die Sie für die weitere Arbeit übernehmen möchten.
7. Klicken Sie auf die Schaltfläche „Weiter“, um die markierten Treffer aus der Suchergebnisliste zu übernehmen. Die gewählten Treffer werden in die Liste eingefügt, aus der Sie die Suche gestartet haben.

## 2.12.6.2 Volltextsuche in Primärinhalten

Die Fabasoft eGov-Suite Bayern unterstützt die Volltextsuche in Primärinhalten z.B. von Microsoft Word-Dokumenten.

Für folgende Typen ist eine Volltextsuche in Primärinhalten möglich:

- Microsoft Word-Dokument
- Microsoft Excel-Arbeitsmappe
- Microsoft PowerPoint-Präsentation
- Notiz-Objekt
- PDF-Objekt
- HTML-Objekt

Hinweis: Die Liste der Objektklassen, deren Primärinhalt über die Volltextsuche durchsucht werden kann, kann durch die Domänenadministratoren individuell angepasst werden.

Um Dokumente über die Volltextsuche zu finden, gehen Sie folgendermaßen vor:

1. Öffnen Sie die Suche über die gleichnamige Schaltfläche oder über das Kontextmenü (Siehe Kapitel 2.12.1 „Eine Suche starten“)
2. Wählen Sie den Eintrag aus, der dem Typ des gesuchten Objekts entspricht und klicken Sie auf die Schaltfläche „Weiter“.
Hinweis: Typen, von denen Objekte bereits in der aktuellen Liste vorhanden sind und eine definierte Liste von Objektklassen, werden in der Liste Vorschlag angezeigt. Klicken Sie auf die Bezeichnung des Eintrags, um einen Typ auszuwählen. Dieser Schritt entfällt, wenn im jeweiligen Kontext nur nach einem bestimmten Typ gesucht werden kann.
3. Wählen Sie aus der Auswahlliste vor einem Feld des Typs Zeichenkette, z.B. Inhalt, den Eintrag „Volltext-Abfrage“ aus (siehe Kapitel 2.12.3 „Suche mit Platzhaltern“).

Benutzerhilfe
119

<!-- PDF page 120 -->

![img-10.jpeg](img-10.jpeg)

4. Geben Sie im betroffenen Feld den Text ein, nach dem Sie suchen möchten.
5. Klicken Sie auf die Schaltfläche „Suche starten".
6. Das Suchergebnis wird als Trefferliste angezeigt. Es können sowohl der Inhalt als auch die Metadaten der Objekte eingesehen werden. Markieren Sie die Treffer, die Sie für die weitere Arbeit übernehmen möchten.
7. Klicken Sie auf die Schaltfläche „Weiter“, um die markierten Treffer aus der Suchergebnisliste zu übernehmen. Die gewählten Treffer werden in die Liste eingefügt, aus der Sie die Suche gestartet haben.

## 2.12.7 Akten, Vorgänge und Dokumente über phonetische Suche finden

Die Fabasoft eGov-Suite Bayern unterstützt die phonetische Suche in Metadaten des Typs Zeichenkette. Eine phonetische Suche führt eine Suche nach dem Annäherungsprinzip aus. Um eine phonetische Suche durchzuführen, stehen in der Auswahlliste vor Feldern des Typs Zeichenkette die Einträge „klingt wie“ oder „klingt nicht wie“ zur Verfügung. Nähere Informationen zur Eingabe der Suchkriterien finden Sie im Kapitel 2.12.3 „Suche mit Platzhaltern“.

Benutzerhilfe

<!-- PDF page 121 -->

Hinweis: Alternativ zur Auswahl des Eintrags „klingt wie“ aus der Auswahlliste kann dem Suchbegriff das Zeichen „~“ (Tilde) vorangestellt werden.

Bei einer phonetischen Suche werden Objekte gefunden, bei denen die Aussprache der im Suchkriterium angegebenen Zeichenkette ähnlich ist.

Beispiel: Eine Suche nach „~Maier“ liefert ähnlich klingende Ergebnisse wie „Maier“ und „Meier“.

Um Akten, Vorgänge und Dokumente über eine phonetische Suche zu finden, gehen Sie folgendermaßen vor:

1. Öffnen Sie die Suche über die gleichnamige Schaltfläche oder über das Kontextmenü (Siehe Kapitel 2.12.1 „Eine Suche starten“)
2. Wählen Sie den Eintrag aus, der dem Typ des gesuchten Objekts entspricht und klicken Sie auf die Schaltfläche „Weiter“.
Hinweis: Typen, von denen Objekte bereits in der aktuellen Liste vorhanden sind und eine definierte Liste von Objektklassen, werden in der Liste Vorschlag angezeigt. Klicken Sie auf die Bezeichnung des Eintrags, um einen Typ auszuwählen. Dieser Schritt entfällt, wenn im jeweiligen Kontext nur nach einem bestimmten Typ gesucht werden kann.
3. Wählen Sie in der Auswahlliste den Eintrag „klingt wie“ aus. Geben Sie im zugehörigen Eingabefeld die gesuchte Zeichenfolge ein. Es wird eine phonetische Suche durchgeführt. In die Ergebnisliste werden alle Objekte übernommen, bei denen der Wert dieser Eigenschaft „ähnlich klingt“ wie die im Eingabefeld festgelegte Zeichenkette.
4. Klicken Sie auf die Schaltfläche „Suche starten“.
5. Suchergebnisse können bereits in der Trefferliste geöffnet werden. Es können sowohl der Inhalt als auch die Metadaten der Objekte angezeigt werden.
6. Markieren Sie die Treffer, die Sie für die weitere Arbeit übernehmen möchten und klicken Sie auf die Schaltfläche „Weiter“, um die markierten Treffer aus der Suchergebnisliste zu übernehmen. Die gewählten Treffer werden in die Liste eingefügt, aus der Sie die Suche gestartet haben.

## 2.12.8 Sammeln von Suchergebnissen

Sie haben die Möglichkeit, Ergebnisse von mehreren Suchen zu sammeln und auf einmal in die jeweilige Objektliste zu übernehmen. Sie können hierbei Suchen nach Objekten der gleichen und unterschiedlichen Objektklassen nach Bedarf kombinieren. Um eine Treffersammlung in eine Objektliste zu übernehmen gehen Sie folgendermaßen vor:

1. Öffnen Sie die Suche über die gleichnamige Schaltfläche oder über das Kontextmenü (Siehe Kapitel 2.12.1 „Eine Suche starten“)
2. Wählen Sie den Eintrag aus, der dem Typ des von Ihnen gesuchten Objekts entspricht und klicken Sie auf die Schaltfläche „Weiter“.
Hinweis: Objektklassen, von denen Objekte bereits in der aktuellen Liste vorhanden sind, und eine definierte Liste von Objektklassen, werden in der Liste Vorschlag vor der Durchführung einer neuen Suche gezeigt. Klicken Sie auf die Bezeichnung des Eintrags, um einen Typ auszuwählen. Dieser Schritt entfällt, wenn im jeweiligen Kontext nur nach einer einzigen Objektklasse gesucht werden kann.

Benutzerhilfe
121

<!-- PDF page 122 -->

3. Geben Sie die Informationen, die Ihnen über das zu suchende Objekt bekannt sind, in den entsprechenden Feldern ein. Nähere Informationen zur Eingabe der Suchkriterien finden Sie im Kapitel 2.12.3 „Suche mit Platzhaltern".
4. Klicken Sie auf die Schaltfläche „Suche starten".
5. Markieren Sie im Suchergebnis die Objekte, die Sie Sammeln möchten und klicken Sie auf die Schaltfläche „Sammeln".
6. Klicken Sie auf die Schaltfläche „Suche ändern" oder „Neue Suche", um nach weiteren Objekten zu suchen.
**Hinweis:** Durch Klick auf die Schaltfläche „Neue Suche“ gelangen Sie wieder in den Dialog zur Auswahl des Typs des gesuchten Objekts. Für weitere Informationen zur Schaltfläche „Suche ändern“ siehe Kapitel 2.12.4 „Eine Suche weiter einschränken".
7. Wiederhohlen Sie die Suchen und das Übernehmen der Objekte in die Treffersammlung, bis Sie alle gewünschten Objekte gefunden haben.
8. Legen Sie die Treffersammlung nach der letzten Suche durch Klick auf die Schaltfläche „Weiter“ in der Objektliste ab.

## 2.12.9 Übernehmen aller Suchergebnisse

Zur schnellen Übernahme aller Suchergebnisse in eine Objektliste, ohne diese markieren zu müssen, steht Ihnen die Schaltfläche „Alle nehmen“ im Suchergebnis zur Verfügung. Zur Übernahme aller Ergebnisse einer Suche, gehen Sie folgendermaßen vor:

1. Öffnen Sie die Suche über die gleichnamige Schaltfläche oder über das Kontextmenü (Siehe Kapitel 2.12.1 „Eine Suche starten“)
2. Wählen Sie den Eintrag aus, der dem Typ des von Ihnen gesuchten Objekts entspricht und klicken Sie auf die Schaltfläche „Weiter“.
**Hinweis:** Objektklassen, von denen Objekte bereits in der aktuellen Liste vorhanden sind und eine definierte Liste von Objektklassen, werden in der Liste Vorschlag vor der Durchführung einer neuen Suche gezeigt. Klicken Sie auf die Bezeichnung des Eintrags, um einen Typ auszuwählen. Dieser Schritt entfällt, wenn im jeweiligen Kontext nur nach einer einzigen Objektklasse gesucht werden kann.
3. Geben Sie die Informationen, die Ihnen über das zu suchende Objekt bekannt sind, in den entsprechenden Feldern ein. Nähere Informationen zur Eingabe der Suchkriterien finden Sie im Kapitel 2.12.3 „Suche mit Platzhaltern".
4. Klicken Sie auf die Schaltfläche „Suche starten".
5. Klicken Sie auf die Schaltfläche „Alle nehmen“.

## 2.12.10 Akten, Vorgänge und Dokumente im Online-Archiv finden

Werden Akten, Vorgänge bzw. Dokumente nur mehr selten verwendet, können sie in ein Online-Archiv ausgelagert werden. Dort können sie über eine Suche gefunden und gelesen werden.

Bei der Durchführung einer Suche oder Recherche und bei Auswertungen ist konfigurierbar, ob das elektronische Archiv berücksichtigt wird oder nicht. Es kann auch explizit nur das elektronische Archiv berücksichtigt werden.

Benutzerhilfe

<!-- PDF page 123 -->

Benutzerhilfe
123

## 2.12.11 Eine Suche als Suchmuster speichern

Die Suchkriterien einer Suche können als Suchmuster gespeichert werden, um die Suche zu einem späteren Zeitpunkt erneut ausführen zu können.

**Hinweis:** Gespeicherte Suchmuster können beim Ausführen einer Suche beim Auswahldialog für den gewünschten Objekttyp am Beginn einer Suche ausgewählt werden. Diese werden in der Liste Suchmuster angezeigt. Durch einen Klick auf die Bezeichnung des Suchmusters wird das Suchmuster ausgewählt. Die durch das Suchmuster gespeicherten Suchkriterien werden vorausgefüllt und im darauf erscheinenden Suchdialog zur Verfügung gestellt.

Um eine Suche als Suchmuster zu speichern, gehen Sie folgendermaßen vor:

1. Öffnen Sie die Suche über die gleichnamige Schaltfläche oder über das Kontextmenü (Siehe Kapitel 2.12.1 „Eine Suche starten“)
2. Wählen Sie den Eintrag aus, der dem Typ des gesuchten Objekts entspricht und klicken Sie auf die Schaltfläche „Weiter“.
**Hinweis:** Typen, von denen Objekte bereits in der aktuellen Liste vorhanden sind, und eine definierte Liste von Objektklassen, werden in der Liste Vorschlag angezeigt. Klicken Sie auf die Bezeichnung des Eintrags, um einen Typ auszuwählen. Dieser Schritt entfällt, wenn im jeweiligen Kontext nur nach einem bestimmten Typ gesucht werden kann.
3. Geben Sie die Informationen, die Ihnen über das zu suchende Objekt bekannt sind, in den entsprechenden Feldern ein. Nähere Informationen zur Eingabe der Suchkriterien finden Sie im Kapitel 2.12.3 „Suche mit Platzhaltern“.
4. Klicken Sie auf die Schaltfläche „Als Suchmuster speichern“, um die festgelegten Suchkriterien als Suchmuster zu speichern.
5. Geben Sie im Feld **Name** einen Namen für das Suchmuster ein und klicken Sie auf die Schaltfläche „Weiter“.
**Hinweis:** Wenn eine Suche gestartet wird, wird das Suchmuster unter dem Namen im oben beschriebenen Feld Suchmuster zur Auswahl angeboten.
6. Klicken Sie auf die Schaltfläche „Suche starten“.
7. Das Ergebnis des Suchmusters wird als Suchergebnis angezeigt. Es können sowohl der Inhalt als auch die Metadaten der Objekte eingesehen werden. Markieren Sie die Treffer, die Sie für die weitere Arbeit übernehmen möchten.
8. Klicken Sie auf die Schaltfläche „Weiter“, um die markierten Treffer aus der Suchergebnisliste zu übernehmen. Die von Ihnen gewählten Treffer werden in der Liste eingefügt, aus der Sie die Suche gestartet haben.

## 2.12.12 Einen Suchordner einrichten und verwenden

Suchordner sind Ordner, die mit dem Suchergebnis einer als Suchmuster definierten Suche dynamisch befüllt werden. Suchordner können von allen Benutzern auf dem jeweiligen Schreibtisch erzeugt werden. Um den Suchordner zu befüllen bzw. zu aktualisieren, muss die Schaltfläche „Aktualisieren“ betätigt werden:

<!-- PDF page 124 -->

![img-0.jpeg](img-0.jpeg)

Um einen Suchordner zu erzeugen, gehen Sie folgendermaßen vor:

1. Erstellen Sie auf Ihrem „Schreibtisch“ ein Objekt vom Typ „Suchordner“, wie in der Anleitung in Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ beschrieben.
2. Bearbeiten Sie die Metadaten dieses Objekts (Anleitung siehe Kapitel 2.1.2.3 „Die Metadaten eines Objekts bearbeiten“).
3. Wählen Sie aus der Eigenschaft Suchmuster ein bereits vorhandenes Suchmuster aus. Folgende Möglichkeiten stehen dazu zur Verfügung:
- Führen Sie in der Drop-down-Liste Suchmuster eine Schnellsuche aus. (siehe Kapitel 2.12.13 „Schnellsuche“)
- Klicken Sie auf die Schaltfläche „Suchen“, um eine Suche auszuführen. Nähere Informationen zur Durchführung einer Suche finden Sie im Kapitel 2.12 „Suche“.
4. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

## 2.12.13 Schnellsuche

In Objektzeigereigenschaften kann direkt (also nicht über den Suchdialog) eine Schnellsuche durchgeführt werden. Die Schaltfläche „Suchen“ neben einer Drop-down-Liste zeigt an, dass

Benutzerhilfe

<!-- PDF page 125 -->

hier eine Schnellsuche durchgeführt werden kann.

# Sicherheit

![img-1.jpeg](img-1.jpeg)

In Objektlisten steht für die Schnellsuche das Suchen und Hinzufügen-Feld zur Verfügung.

![img-2.jpeg](img-2.jpeg)

Die Eigenschaften der Elemente der Trefferliste bei der Schnellsuche können direkt über das Kontextmenü aufgerufen werden.

Um eine Schnellsuche in Objektzeigereigenschaften durchzuführen, gehen Sie folgendermaßen vor:

1. Klicken Sie auf das jeweilige Element, in dem Sie die Suche durchführen wollen.
2. Drücken Sie die Einfg-Taste – das Feld ändert daraufhin die Farbe und der Cursor für die Bearbeitung von Text wird in dem Feld angezeigt.
3. Benutzen Sie entweder die Volltextsuche oder Platzhalter (siehe Kapitel 2.12.3 „Suche mit Platzhaltern“) und drücken Sie auf die Eingabetaste.
4. Wenn mehrere Einträge gefunden werden, wird eine Liste mit den gefundenen Treffern angezeigt, aus der Sie einen auswählen können.

Um eine Schnellsuche in einer Objektliste durchzuführen, gehen Sie folgendermaßen vor:

1. Klicken Sie auf das Suchen und Hinzufügen-Feld in der Objektliste.
2. Geben Sie den gewünschten Suchbegriff ein und drücken Sie die Eingabetaste.
3. Wählen Sie im angezeigten Suchergebnis den gewünschten Eintrag aus.

**Ergebnis:** Das gefundene Objekt wird in der Objektliste abgelegt.

**Hinweis:** Das Suchen und Hinzufügen-Feld bietet die Möglichkeit, eine Suche in der Datenbank, analog der Suche über die Schaltfläche „Suchen“, oder eine Volltextsuche mittels Mindbreeze durchzuführen. Die aktuelle Suchoption wird mittels eines Symbols angezeigt. Zum Wechseln zwischen den Suchoptionen klicken Sie auf das Symbol.

Benutzerhilfe
125

<!-- PDF page 126 -->

Benutzerhilfe
126

# 2.12.14 Suche nach Objekten mittels Mindbreeze Suchfeld

Bei der Suche über das Mindbreeze Suchfeld öffnet sich im Anschluss eine eigene Ansicht, in welcher die Trefferliste Ihrer Suche sowie diverse Eigenschaften zur weiteren Einschränkung der Trefferliste angezeigt werden.

Um eine Suche über das Mindbreeze Suchfeld durchzuführen gehen Sie folgendermaßen vor:

1. Geben Sie im Mindbreeze Suchfeld einen Suchbegriff ein:

![img-3.jpeg](img-3.jpeg)

2. Klicken Sie auf das Lupen-Symbol rechts neben dem Suchbegriff oder drücken Sie die Eingabetaste um die Suche zu starten.

**Hinweis:** Zusätzlich zur Eingabe eines Suchbegriffs besteht auch die Möglichkeit, einen alten Suchbegriff auszuwählen. Dazu reicht ein Klick in das Suchfeld und es öffnet sich automatisch ein DropDown, in welchem die zuletzt gesuchten Begriffe zu Auswahl stehen.

**Hinweis:** Bei der Suche im Mindbreeze Suchfeld kann auch direkt auf die eigene Organisation eingeschränkt werden. Dazu muss der Suchbegriff unter „in meiner Organisation ausgewählt werden. (Siehe Screenshot oben)

3. Es öffnet sich die Trefferliste und Sie können weitere Einschränkungen vornehmen. Standardmäßig werden folgende 3 Einschränkungen immer angezeigt (Siehe Screenshot nächste Seite):

- **Wo:**
Hier können Sie den Suchkontext definieren, sprich ob Sie beispielsweise im gesamten System (überall), innerhalb eines Organisationseinheits auch nur innerhalb eines Akts, Vorgangs oder Dokuments durchgeführt wird.

**Hinweis:** Die Möglichkeit zur Einschränkung auf Akten, Vorgänge oder Dokumente ist nur dann vorhanden, wenn die Suche aus der Objektliste einer dieser Klasse gestartet wurde.

- **Objektklasse:**
Über diese Einschränkung können Sie die Trefferliste nach Objektklassen filtern.

<!-- PDF page 127 -->

- Datum:
Über diese Einschränkung können Sie die Trefferliste nach Datum filtern.

Hinweis: Welche Sucheinschränkungen angezeigt werden kann durch die Systemadministration angepasst werden.

Home + Domain Administration + Objektliste + Domänenobjekte + Domänen + Suchergebnis + 0003 A10 01.1.1/5/6 +

Suchergebnis

Suche verfeinern

Suche zurücksetzen

Wo

☐ In Dokument "0003 A10 01.1.1/5/6"
☐ In Vorgang "0003 A10 01.1.1/5 (eGov-Suite10638)"
☐ In Akte "0003 A10 01.1.1"
☐ In meiner Organisationseinheit
☑ Überall

Objektklasse

☑ Alle
☐ Sachgebiet (879)
☐ Person (288)
☐ Postkorb (154)
☐ Organisation (138)
☐ Microsoft Word-Objekt (136)
☐ Organisationseinheit (136)
☐ Eingangs dokument (114)
☐ Vorgang (109)
☐ Akte (79)
☐ Umlaufmappe (48)
☐ Erledigung (40)
☐ Aktenplan (23)
☐ Arbeitsvorrat (23)
☐ Internes Stück (23)
☐ Suchergebnis (23)

Suche

Datum

☐ Alle
☑ 2019 (2565)
☑ November (2565)
☐ 2016 (12)
☐ 2012 (1)
☐ 2011 (2)

[tbl-0.md](tbl-0.md)

Um Suchtreffer aus der Trefferliste zu übernehmen müssen diese kopiert und an der gewünschten Stelle (in der gewünschten Objektliste) eingefügt werden. Weitere Informationen zum Kopieren und Einfügen von Objekten finden Sie im Kapitel 2.1.2.7 „Ein Objekt kopieren und einfügen“.

Benutzerhilfe

<!-- PDF page 128 -->

# 2.12.15 Beispiele zur Mindbreeze Abfragesprache

In der folgenden Tabelle finden Sie einige Beispiele, wie Suchen in der Mindbreeze Abfragesprache formuliert werden können:

[tbl-1.md](tbl-1.md)

Benutzerhilfe

<!-- PDF page 129 -->

Benutzerhilfe
129

# 2.12.16 Suchabfrage zusammenstellen

Das Menü „Suchabfrage zusammenstellen“ ist im Suchergebnis von Mindbreeze zu finden und unterstützt beim Zusammenstellen und Absetzen einer Mindbreeze Suche.

![img-4.jpeg](img-4.jpeg)

# Suchabfrage

Beinhaltet die aktuelle Suchabfrage. Über die Optionen "Verknüpfung" und "Vordefinierte Suchabfrage" kann die Suchabfrage automatisch angepasst werden. Mittels der Schaltfläche "Suchen" kann die Suchabfrage abgesetzt werden.

# Gespeicherte Suchabfrage

Beinhaltet die Suchabfrage, welche vor dem Zusammenstellen der Suchabfrage hinterlegt wurde. Sie können den Wert mittels der Schaltfläche "Zurücksetzen" wiederherstellen.

# Verknüpfung

Über diese Option kann die Suchabfrage AND-, OR- oder NEAR-verknüpft werden. Beim Klick auf "Keine Verknüpfung", wird die bestehende Verknüpfung wieder entfernt. Hinweis: Die Auswahl einer vordefinierten Suchabfrage überschreibt die getätigte Verknüpfung.

- Keine Verknüpfung: Es wird nach allen Begriffen gesucht, es müssen aber nicht alle Begriffe vorkommen
- Alle Begriffe: Es müssen alle Begriffe vorkommen
- Einer der Begriffe: Einer der Begriffe muss vorkommen
- Alle Begriffe kommen gemeinsam vor: Die Begriffe müssen sich in der Nähe voneinander befinden

Beispiele und Erklärungen für die Mindbreeze Abfragesprache können im Kapitel „2.12.15 Beispiele zur Mindbreeze Abfragesprache“ gefunden werden.

<!-- PDF page 130 -->

# Vordefinierte Suchabfragen

Beinhaltet vordefinierte Suchabfragen, welche auf den Wert im Feld "Suchabfrage" angewendet werden.

**Geschäftszeichen**: Ergänzt die externen Referenzen „gz“ und „fremd“ und sucht in den Eigenschaften

- „Geschäftszeichen (COOELAK@1.1001:filereference)“ von „Akten“, „Vorgängen“, „Eingangsdokumenten“, „Erledigungen“, und „Internen Dokumenten“.
- „Fremdes Geschäftszeichen (COOELAK@1.1001:foreignnr)“ von „Eingangsdokumenten“. Die übergeordneten „Vorgänge“, welche den gefundenen Eingangsdokumenten zugeordnet sind, werden auch zurückgeliefert.

## Adressaten:

Ergänzt die externe Referenz „adr“ und sucht in den Eigenschaften

- „Adressen (COOELAK@1.1001:addressees)“ von „Eingangsdokumenten“, „Erledigungen“, „Internen Dokumenten“. Die übergeordneten „Vorgänge“, welche den gefundenen Dokumenten zugeordnet sind, werden auch zurückgeliefert.
- „Adresse (FSCFOLIO@1.1001:address)“ von „Personen“ und „Organisationen“

Benutzerhilfe
130

<!-- PDF page 131 -->

Benutzerhilfe
131

# 2.13 Auswertung über Berichte

## 2.13.1 Eine Auswertung eines Berichts durchführen

Um eine Auswertung durchzuführen, wird ein Berichtsobjekt angelegt, wenn für diese Auswertung noch kein solches Objekt vorhanden ist. In diesem Bericht werden die nötigen Einstellungen definiert.

Die Fabasoft eGov Suite Bayern definiert bestimmte Berichte, über die Auswertungen durchgeführt werden können. Auswertungen können mit einer Bezeichnung versehen und in Vorgängen als Inhalt abgelegt werden.

**Hinweis:** Werden mehrere Auswertungen mit gleichem Namen erzeugt, so können diese beispielsweise anhand ihrer Objektadresse, Ersteller, Erstellungsdatum usw. unterschieden werden.

Um eine Auswertung eines Berichts durchzuführen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch".
2. Wenn für die gewünschte Auswertung noch kein Berichtsobjekt vorhanden ist, so erzeugen Sie ein Objekt des Typs **Bericht**. Öffnen Sie dazu das Menü „Objekt" und führen Sie den Befehl „Neu" aus. Wählen Sie den Eintrag „Bericht" aus und klicken Sie auf die Schaltfläche „Weiter".
3. Wählen Sie die gewünschte Berichtsvorlage aus. Klicken Sie dazu auf die Bezeichnung der Berichtsvorlage.
4. Öffnen Sie das Kontextmenü des Berichts und führen Sie den Befehl „Bericht generieren" aus. Das Generieren eines Berichts „befüllt" den Bericht mit dem gewünschten Inhalt.
**Hinweis:** Der Bericht selbst wird dabei noch nicht angezeigt.

Doppelklicken Sie auf die Bezeichnung des Berichts, um den Inhalt anzuzeigen.

**Beispiel:** Um ein Posteingangsbuch anzuzeigen, führen Sie die oben angeführten Schritte aus und wählen Sie in Schritt 3 die Berichtsvorlage „Posteingangsbuch" aus.

## 2.14 Stellvertretung

Ein Benutzer kann in seiner Abwesenheit von anderen Benutzern in seinen Rollen vertreten werden. Dabei kann ein Benutzer generell (nur in seiner Rolle) oder persönlich (auch von ihm persönlich zugeordnete Aktivitäten) vertreten werden. Arbeitet der Stellvertreter in der Rolle des Stellvertreten, so erhält er automatisch die gleichen Rechte, um die Aufgaben erledigen zu können.

Benutzer können im Rahmen ihrer Rechte für eine Aktivität festlegen, ob diese durch Stellvertreter bzw. persönliche Stellvertreter durchgeführt werden darf. Stellvertretungen sind für jene Aktivitäten möglich, bei denen eine Stellvertretung nicht explizit ausgeschlossen wurde.

## 2.14.1 Standardwerte für Stellvertretungen definieren

Um Standardwerte für Stellvertretungen festzulegen, gehen Sie folgendermaßen vor:

1. Klicken Sie rechts oben auf den Benutzernamen.

<!-- PDF page 132 -->

2. Öffnen Sie das Menü „Stellvertreter“ und klicken auf das Feld „Standardwerte für Stellvertretungen festlegen“ aus.

Stellvertreter festlegen

Legen Sie Ihre Stellvertreter fest

Details anzeigen (1)

Nachfolgend werden für Ihre Rollen die aktuellen Stellvertretungen angezeigt. Die festgelegten Standardwerte werden bei neuen Rollen, neuen Stellvertretungen und beim Zurücksetzen der Stellvertretungen verwendet.

Standardwerte für Stellvertretungen festlegen

Auf Standardwerte zurücksetzen

☐ 1

☐ 1

Leiter/in

Gba-0001 (Grund- und Bauamt-0001)

3. Im folgenden Dialog können Sie folgende Standardwerte definieren:

- Stellvertreter:
Die in dieser Liste definierten Benutzer werden beim Erzeugen einer neuen Stellvertretung (siehe Punkt 2.14.3 „Eine Stellvertretung erzeugen“) als Stellvertreter initialisiert.

- Start:
Definiert den Beginn der Stellvertretung. Wird dieses Feld leer gelassen, ist die Stellvertretung ab sofort aktiv.

- Ende:
Definiert das Ende der Stellvertretung. Wird dieses Feld leer gelassen, gibt es keine zeitliche Befristung.

- Persönliche Stellvertretung:
Legt fest, ob zusätzlich zur rollenbezogenen Stellvertretung auch Aktivitäten in Stellvertretung bearbeitet werden können, die direkt an den Benutzer gerichtet sind.

- Bemerkung:
Legt eine Bemerkung zur Stellvertretung fest. Diese wird dem Stellvertreter bei der Auswahl der Stellvertreterrolle angezeigt.

- Für Stellvertreter nicht gestattet:
Definiert Zugriffsrechte (z. B. "Objekt löschen"), die der Stellvertreter nicht ausüben darf.

Benutzerhilfe
132

<!-- PDF page 133 -->

Benutzerhilfe
133

# Legen Sie die Standardwerte für Stellvertretungen fest

Die hier festgelegten Standardwerte werden bei neuen Rollen, neuen Stellvertretungen und beim Zurücksetzen der Stellvertretungen verwendet. Im nachfolgenden Dialog können diese Werte auch auf bestehende Stellvertretungen übernommen werden.

[tbl-2.md](tbl-2.md)
[tbl-3.md](tbl-3.md)
[tbl-4.md](tbl-4.md)
[tbl-5.md](tbl-5.md)
[tbl-6.md](tbl-6.md)

4. Bestätigen Sie Ihre Änderungen mit „Festlegen".
5. Im sich nun öffnenden Dialog können Sie festlegen, für welche bestehenden Stellvertretungen welche neuen Standardwerte übernommen werden sollen. Standardmäßig sind in der Liste der „Zu ändernde Eigenschaften" alle Eigenschaften ausgewählt, die im vorherigen Formular bearbeitet wurden. In der Eigenschaft „Betroffene Stellvertretungen" sind standardmäßig alle Stellvertretungen ausgewählt.

<!-- PDF page 134 -->

Stellvertreter festlegen

🚶‍♂️ 🔍 ✗

# Übernehmen Sie die Standardwerte für bestehende Stellvertretungen

Wählen Sie die Eigenschaften aus, die Sie für die ausgewählten Stellvertretungen übernehmen möchten.

## Zu ändernde Eigenschaften

☑ Stellvertreter
☑ Start
☑ Ende
☐ Persönliche Stellvertretung
☐ Bemerkung
☐ Für Stellvertreter nicht gestattet

## Betroffene Stellvertretungen

Details anzeigen (1)

☑ ↑ Stelle Gruppe Stellvertreter Start Ende

☐ 1 Leiter/in Gba-0001 (Grund- und Bau...)

6. Bestätigen Sie Ihre Änderungen wieder mit „Festlegen“.

## Ergebnis:

- Es sind neue Standardwerte für Stellvertretungen definiert. Die entsprechenden Eigenschaften werden beim Erzeugen einer Stellvertretung automatisch initialisiert.
- Die neuen Eigenschaftswerte wurden gemäß Auswahl auf bestehende Stellvertretungen übertragen.

## 2.14.2 Stellvertretungen auf Standardwerte zurücksetzen

Über die Schaltfläche „Auf Standardwerte zurücksetzen“ können die Stellvertretungen auf deren Standardwerte zurückgesetzt werden. Dabei wird für jede Rolle, die dem Benutzer zugewiesen ist, eine Stellvertretung angelegt und diese mit den Standardwerten (wie in Punkt 2.14.1 „Standardwerte für Stellvertretungen definieren“ definiert) befüllt.

**Hinweis:** Alle manuell erzeugten Stellvertretungen werden dabei gelöscht.

Um Stellvertretungen auf die Standardwerte zurückzusetzen gehen Sie bitte wie folgt vor:

1. Klicken Sie rechts oben auf den Benutzernamen.
2. Öffnen Sie das Menü „Stellvertreter“ und klicken auf das Feld „Auf Standardwerte zurücksetzen“ aus.

Benutzerhilfe

<!-- PDF page 135 -->

Stellvertreter festlegen
🚫 ⚠️ ⚡

# Legen Sie Ihre Stellvertreter fest

Details anzeigen (1)

Nachfolgend werden für Ihre Rollen die aktuellen Stellvertretungen angezeigt. Die festgelegten Standardwerte werden bei neuen Rollen, neuen Stellvertretungen und beim Zurücksetzen der Stellvertretungen verwendet.

[tbl-7.md](tbl-7.md)

## 2.14.3 Eine Stellvertretung erzeugen

Eine Stellvertretung ist durch berechtigte Benutzer und/oder durch den zu Vertretenden selbst definierbar. Eine Stellvertretung kann wahlweise für Zeiträume (von/bis) und/oder unbegrenzt festgelegt werden.

Um eine neue Stellvertretung festzulegen, gehen Sie folgendermaßen vor:

1. Klicken Sie rechts oben auf den Benutzernamen.
2. Öffnen Sie das Menü „Stellvertreter“.
3. Klicken Sie auf die Schaltfläche „Eintrag hinzufügen“ in der Liste der Stellvertretungen.

# Legen Sie Ihre Stellvertreter fest

Details anzeigen (1)

Nachfolgend werden für Ihre Rollen die aktuellen Stellvertretungen angezeigt. Die festgelegten Standardwerte werden bei neuen Rollen, neuen Stellvertretungen und beim Zurücksetzen der Stellvertretungen verwendet.

[tbl-8.md](tbl-8.md)

Benutzerhilfe

<!-- PDF page 136 -->

4. Im sich nun öffnenden Formular können Sie die Eigenschaften der Stellvertretung definieren.

```markdown
Rollen mit Stellvertreter

Rollen mit Stellvertreter

Stelle *
*   Ø
Gruppe *
*   Ø

Stellvertreter
Details anzeigen (1)
☐ Name
☒ Adler-0001, Adam
Eintrag hinzufügen   Suchen und hinzufügen

Start
09.11.2020

Ende
09.11.2021

☑ Persönliche Stellvertretung

Bemerkung

Für Stellvertreter nicht gestattet
Details anzeigen (0)
Diese Liste enthält keine Einträge.
Eintrag hinzufügen   Suchen und hinzufügen

Symbol
*

Folgende Eigenschaften stehen zur Verfügung:

- Stelle
In der Eigenschaft Stelle wird jene Stelle definiert, in welcher der Benutzer vertreten werden möchte.

- Gruppe
In der Eigenschaft Gruppe wird jene Gruppe definiert, in welcher der Benutzer vertreten werden möchte.

- Stellvertreter:
Die in dieser Liste definierten Benutzer werden standardmäßig (beim Erzeugen einer

Benutzerhilfe
136

<!-- PDF page 137 -->

neuen Stellvertretung (siehe Punkt 2.14.3 „Eine Stellvertretung erzeugen“) als Stellvertreter definiert.

- **Start:**
Definiert den Beginn der Stellvertretung. Wird dieses Feld leer gelassen, ist die Stellvertretung ab sofort aktiv.

- **Ende:**
Definiert das Ende der Stellvertretung. Wird dieses Feld leer gelassen, gibt es keine zeitliche Befristung.

- **Persönliche Stellvertretung:**
Legt fest, ob zusätzlich zur rollenbezogenen Stellvertretung auch Aktivitäten in Stellvertretung bearbeitet werden können, die direkt an den Benutzer gerichtet sind.

- **Bemerkung:**
Legt eine Bemerkung zur Stellvertretung fest. Diese wird dem Stellvertreter bei der Auswahl der Stellvertreterrolle angezeigt.

- **Für Stellvertreter nicht gestattet:**
Definiert Zugriffsrechte (z. B. "Objekt löschen"), die der Stellvertreter nicht ausüben darf.

- **Symbol:**
Hier kann ein Symbol hinterlegt werden, welches bei der Rollenauswahl angezeigt wird.

5. Bestätigen Sie Ihre Eingaben mit „Weiter“.

**Ergebnis:**

- Der Stellvertreter hat nun die Möglichkeit, in der Rolle und somit im Rechtekontext des Stellvertretenen im angegebenen Zeitraum zu arbeiten.
- Aktivitäten, die an die vertretene Rolle vorgeschrieben wurden, werden auf der Registerkarte „Zu tun“ angezeigt und können dort wie gewohnt bearbeitet werden.

**Hinweis:** Werden Aktionen stellvertretend für einen anderen Benutzer ausgeführt, wird es in der jeweiligen Aktivität vermerkt.

**Hinweis:** Die vorhandenen Schaltflächen „Vorheriger Eintrag“ (&lt;) und „Nächster Eintrag“ (&gt;) können innerhalb des Rollenaggregats die Navigation zwischen den einzelnen Einträgen erleichtern.

Abtreichen

Weiter

## 2.14.4 Eine Stellvertretung ausüben

Um eine Stellvertretung auszuüben, führen Sie die folgenden Schritte aus:

1. Klicken Sie auf Ihren Benutzernamen
2. Öffnen Sie das Menü „Meine Rollen“
3. Sollte jemand Sie für eine Stellvertretung eingeteilt haben, können Sie hier nun die Rolle des Stellvertretenen auswählen.

Benutzerhilfe

<!-- PDF page 138 -->

Hinweis: Eine fremde Rolle erkennen Sie daran, dass vor der auswählbaren Rolle ein „Stv.“ (Stellvertretung) steht

4. Klicken Sie auf die gewünschte Rolle, um sie auszuüben.

**Ergebnis:**

- Alle Aktivitäten, die die ausgeübte Rolle betreffen, werden in Ihrem Arbeitsvorrat auf der Registerkarte „Zu tun“ eingetragen
- Nach der übernommenen Aktivität wird in den Leitweg eine neue Aktivität mit dem Vertreter als Benutzer eingefügt, wobei der vertretene Benutzer ebenfalls angeführt wird.

Im Rahmen der Ausübung der Stellvertretung werden zwei Fälle unterschieden:

- Rollen-Vertretung
Vertreter erhalten Vorschreibungen an die Rolle, die sie vertreten, in ihrem Arbeitsvorrat auf der Registerkarte „Zu tun“.

- Persönliche Vertretung
Vertreter erhalten alle persönlich an die vertretene Person vorgeschriebenen Aktivitäten auf der Registerkarte „Vertretungen/Zu tun“ bzw. „Vertretungen/Frist“ ihres Arbeitsvorrats.

Um bei einer persönlichen Vertretung zusätzlich die Aktivitäten bearbeiten zu können, die an den Vertretenen persönlich vorgeschrieben wurden, gehen Sie folgendermaßen vor:

1. Wechseln Sie in dem Widget „Arbeitsvorrat“ und auf die Registerkarte „Vertretungen/Zu tun“, falls Sie sich auf einer anderen Registerkarte befinden.
2. Lokalisieren Sie die Aktivität, die Sie für den vertretenen Benutzer bearbeiten wollen. Hinweis: Es stehen auch Aktivitäten zur Verfügung, die der vertretene Benutzer bereits begonnen hat.
3. Öffnen Sie das Kontextmenü der Aktivität durch einen Klick mit der rechten Maustaste und führen Sie den Befehl „Übernehmen“ aus.
4. Geben Sie eine Bemerkung ein, falls Sie zu dieser Aktivität im Laufweg eine Bemerkung anzeigen wollen, und klicken Sie auf die Schaltfläche „Weiter“.
5. Wechseln Sie auf die Registerkarte „Zu tun“, um die Bearbeitung der Aktivität zu beginnen.

**Ergebnis:**

- Die Aktivität wird auf der Registerkarte „Zu tun“ in dem Widget „Arbeitsvorrat“ verschoben und kann dort bearbeitet werden.
- Nach der übernommenen Aktivität wird in den Leitweg eine neue Aktivität mit dem Vertreter als Benutzer eingefügt, wobei der vertretene Benutzer ebenfalls angeführt wird.

## 2.14.5 Eine Stellvertretung beenden

### Durch den Stellvertreter

Der Stellvertreter kann die Stellvertretung dadurch beenden, dass er aus der Rolle des Stellvertreters in eine seiner eigenen Rollen wechselt. (siehe Kapitel 2.14.4 Eine Stellvertretung ausüben)

Benutzerhilfe
138

<!-- PDF page 139 -->

Benutzerhilfe
139

# Durch den Vertretenen

Ist eine Stellvertretung aktiv und hat sich der vertretene Benutzer anmeldet, wird ein Dialog angezeigt, in dem ausgewählt werden kann, ob die Stellvertretung beendet werden soll.

Weiteres können die Metadaten der Stellvertretung bearbeitet werden, um die Stellvertretung zu beenden. (z.B. über das Ende-Datum der Stellvertretung oder durch Entfernen des Stellvertreters).

Um die Stellvertretung zu beenden, gehen Sie folgendermaßen vor:

1. Öffnen Sie das Menü „Einstellungen" und führen Sie den Befehl „Stellvertreter" aus.
2. Lokalisieren Sie im Feld Stellvertreter den Benutzer, der Sie nun nicht mehr vertreten soll.
3. Wählen Sie den Benutzer, den Sie aus seiner Rolle entfernen möchten, aus und klicken Sie auf die Schaltfläche „Eintrag entfernen".
4. Klicken Sie auf die Schaltfläche „Weiter", um die Änderungen zu speichern.

## Ergebnis:

- Die Stellvertretung ist beendet.

# 2.15 Verwendung von Teamrooms

## 2.15.1 Einen Teamroom erzeugen

Um einen Teamroom zu erzeugen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren Schreibtisch.
2. Klicken Sie auf die Schaltfläche Neu.
3. Wählen Sie aus der Auswahlliste „Teamroom" und klicken Sie auf die Schaltfläche „Weiter".
4. Vergeben Sie einen aussagekräftigen Namen und bestätigen Sie diesen mit der Schaltfläche „Weiter" oder drücken Sie die Eingabetaste. Der Teamroom ist nun angelegt und befindet sich auf Ihrem Schreibtisch.

## 2.15.2 Einladen zur Teilnahme an einem Teamroom

An einem Teamroom können mehrere Gruppen und Benutzer mitarbeiten. Die gewünschten Beteiligten bekommen Bearbeitungsrechte auf alle Schriftstücke im Teamroom. Sollen die Schriftstücke auch im Teamroom strukturiert werden, müssen Ordner erstellt werden.

Um weitere Benutzer und Gruppen einzuladen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den gewünschten Teamroom.
2. Öffnen Sie das Kontextmenü des Teamrooms und führen Sie den Befehl „Zum Erfassen weiterleiten" aus.
3. Wählen Sie nun den gewünschten Teilnehmer aus dem Schnellsuchfeld aus. Es können hier sowohl Benutzer als auch Gruppen beteiligt werden.
4. Es öffnet sich nun ein E-Mail mit Ihren lokal installierten E-Mail Client (z.B. Microsoft Office Outlook). Sind bei den Teilnehmern E-Mail Adressen definiert, werden diese direkt in das E-

<!-- PDF page 140 -->

Mail als Empfänger übernommen. Inhalt des E-Mails ist ein Link auf den Arbeitsbereich. Hinweis: Der E-Mail Text kann noch geändert werden.

## 2.15.3 Einrichten von Berechtigungen in Teamrooms

Um anderen Benutzern Zugriff auf die Objekte eines Teamrooms zu ermöglichen gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Teamroom auf der linken Seite in der Baumdarstellung oder auf dem Schreibtisch um ihn zu öffnen.

2. Klicken Sie nun auf das Symbol `BA` Berechtigungen, danach sollte folgende Schaltfläche erscheinen:

```
Berechtigungen
test
Sicherheitseinstellungen
E-Mail-Einladungen versenden
```

```
Alle Rechte
+ Kainz, Regina
Eigentümer
```

```
Änderungsberechtigt
+ Leseberechtigt
```

3. Durch einen Klick auf „+“ in der jeweiligen Kategorie erscheint ein Suchfeld:

```
Änderungsberechtigt
Benutzer oder Gruppe
+```

4. Es stehen folgende Optionen zur Verfügung:

- „Leseberechtigt“: Der Benutzer hat lesenden Zugriff auf den Teamroom und dessen Objekte.
- „Änderungsberechtigt“: Der Benutzer können die Objekte des Teamrooms bearbeiten.
- „Alle Rechte“: Der Benutzer hat dieselben Berechtigungen, die der Benutzer, der als „Eigentümer/in“ eingetragen ist.

Benutzerhilfe
140

<!-- PDF page 141 -->

Zusätzlich stehen folgende Optionen im Kontextmenü zur Verfügung:

- „Entfernen“: Entfernt die Benutzerin bzw. den Benutzer aus dem Team. Dies bewirkt, dass diese Benutzerin bzw. dieser Benutzer keine Rechte auf den Teamroom oder dessen Objekte hat.
- „Im neuen Fenster öffnen“ öffnet den Eintrag in einem neuen Fenster
- „Kopieren“ kopiert den Eintrag, dieser kann dann in einen anderen Berechtigungsbereich eingefügt werden.
- „Eigenschaften“: Die Metadaten des Benutzerobjekts können eingesehen werden.
- Hinweis: Die angezeigten Metadaten können je nach Berechtigung variieren.

## 2.15.4 In Teamrooms arbeiten

### 2.15.4.1 Erzeugen von Schriftstücken in Teamrooms

Über "Neu" können in einem Teamroom Schriftstücke (Inhaltsobjekte), Ordner und weitere Teamrooms erzeugt werden. Über zusätzliche Teamrooms können vom übergeordneten Teamroom abweichende Berechtigungen auf die enthaltenen Objekte erteilt werden. Ordner dienen der Strukturierung und somit der Übersichtlichkeit in Teamrooms.

Wird ein Schriftstück, oder ein Ordner in einem Teamroom erzeugt, wird der zugehörige Teamroom in der Eigenschaft "Teamroom" eingetragen und das entsprechende Objekt somit dem Teamrooms zugeordnet.

## 2.15.5 Ablegen von bestehenden Objekten in Teamrooms

### 2.15.5.1 Schriftgut in Teamroom ablegen

Schriftgut aus dem Aktenplan (Akten, Vorgänge, Umlaufmappen und Dokumente) können als Verknüpfung in Teamrooms abgelegt werden. Für den Zugriff auf Schriftgut im Teamroom werden die Berechtigungen im Aktenplan herangezogen. Die über den Teamroom definierten Berechtigungen haben in diesem Fall keine Auswirkungen auf den Zugriff.

### 2.15.5.2 Schriftstücke vom Schreibtisch in Teamroom ablegen

Schriftstücke die am Schreibtisch eines Benutzers erzeugt wurden, können über Drag &amp; Drop, oder Ausschneiden/Kopieren &amp; Einfügen in Teamrooms als Verknüpfung abgelegt werden. Eine Zuordnung des Schriftstücks zum Teamroom erfolgt dabei nicht.

Soll das Schriftstück dem Teamrooms zugeordnet werden, ist es erforderlich, dass das gewünschte Schriftstück im Teamroom über "Duplikat einfügen" im Teamroom erzeugt und abgelegt wird.

### 2.15.5.3 Schriftstücke zwischen Teamrooms verschieben

Wird ein Schriftstück von einem Teamroom über Drag &amp; Drop, oder Ausschneiden/Kopieren &amp; Einfügen verschoben, ändert sich die Zuordnung zum ursprünglichen Teamroom nicht. Das verschobene Schriftstück wird als Verknüpfung im Teamroom angezeigt.

Benutzerhilfe
141

<!-- PDF page 142 -->

Benutzerhilfe
142

# 2.15.5.4 Löschen von Schriftstücken in Teamrooms

Wenn Schriftstücke in einem Teamroom gelöscht werden, werden sie im globalen Papierkorb des Mandanten abgelegt und verlieren die Zuordnung zum Teamroom.

# 2.15.6 Teamroom-Inhalte erfassen

Wenn die Zusammenarbeit über einen Teamroom abgeschlossen ist und die Arbeitsergebnisse finalisiert wurden, können die Arbeitsergebnisse im Aktenplan erfasst werden. Dazu kann das zu erfassende Schriftstück kopiert und in einem Vorgang, oder in einem Dokument über "Duplikat einfügen" abgelegt werden.

Alternativ dazu kann über den Kontextmenüeintrag "Zum Erfassen weiterleiten" der Link zum Teamroom per E-Mail an bspw. die Zentralregistratur übermittelt werden.

Wenn alle erforderlichen Schriftstücke erfasst wurden, kann der Teamroom aufgelöst werden.

# 2.15.7 Teamroom auflösen

Über den Kontextmenüeintrag "Teamroom auflösen" kann der Teamroom aufgelöst werden, wodurch der Teamroom rückstandslos gelöscht wird. Im Abfragedialog wird darauf hingewiesen, dass im aufzulösenden Teamroom enthaltene Teamrooms dadurch nicht aufgelöst werden.

# 2.15.8 Diskussionsforum

Über das Diskussionsforum können Kommentare für alle auf den Teamroom berechtigten Benutzer sichtbar angebracht werden.

# 2.15.9 Verwaiste Objekte

Wird ein Schriftstück aus einem Teamroom ausgeschnitten, oder über Drag &amp; Drop an eine Stelle außerhalb des zugeordneten Teamrooms verschoben, können diese Objekte über die Funktion "Verwaiste Objekte" angezeigt werden.

# 2.16 Zugriffsrechte der einzelnen Stellen für Objekte am Schreibtisch

Benutzer können abhängig von ihrer Stelle unterschiedliche Objekte auf dem Schreibtisch erzeugen. Eine Beschreibung der vordefinierten Stellen finden Sie im Glossar. Folgende Objekte erhalten dabei standardmäßig die „ACL für persönliche Objekte (Schreibtisch)“, um den Zugriff entsprechend einzuschränken (Akten, Vorgänge erhalten die entsprechend definierten Vorgangsrelevanten ACLs):

**Hinweis:** Die folgenden Objektklassen können seit Version 2019 der Fabasoft eGov-Suite nicht mehr am Schreibtisch erstellt werden.

- Akte
- Vorgang
- Eingangsdokument
- Internes Dokument
- Erledigung

<!-- PDF page 143 -->

- Umlaufmappe

Weitere Informationen zum Erstellen dieser Objektklassen finden Sie unter 3.1.1 „Einen Aktenplan anlegen“, 3.2.1 „Eine Akte erzeugen“, 3.3.1 „Einen Vorgang erzeugen“, 3.3.10.1 „Eine Umlaufmappe erzeugen“ 3.4.1 „Eine Erledigung erstellen“.

**Hinweis:** Auch wenn das Erzeugen vieler Objektklassen am Schreibtisch nicht möglich ist, können diese trotzdem am Schreibtisch abgelegt werden. (Bspw. durch Kopieren aus einer anderen Objektliste und Einfügen am Schreibtisch)

## 2.16.1 Stellen Sachbearbeitung, Leitung, Schriftgutverwaltung und Registratur

[tbl-0.md](tbl-0.md)

Benutzerhilfe
143

<!-- PDF page 144 -->

[tbl-1.md](tbl-1.md)

2.16.2 Stellen Poststelle, Vorlagenverwalter/in, Archivar/in, Sekretär

[tbl-2.md](tbl-2.md)

Benutzerhilfe

<!-- PDF page 145 -->

[tbl-3.md](tbl-3.md)

## 2.16.3 Stelle Fachadministration und OE-Administration

[tbl-4.md](tbl-4.md)

Benutzerhilfe

<!-- PDF page 146 -->

Benutzerhilfe
146

[tbl-5.md](tbl-5.md)

<!-- PDF page 147 -->

[tbl-6.md](tbl-6.md)

## 2.17 Darstellen von Formularen in eigenen Webbrowser Fenstern

Standardmäßig werden Formulare (bspw. die Metadaten eines Objekts) in einem eigenen Overlay (Eingabefenster „über“ der Benutzeroberfläche) angezeigt und die aktuelle Objektliste, in welcher man sich befindet, im Hintergrund ausgegraut dargestellt. In der Fabasoft eGov-Suite Bayern haben Sie die Möglichkeit, die Metadaten als eigenes Webbrowser Fenster darzustellen. Dies können Sie über zwei Methoden erreichen:

Verwenden der „Herauslösen“ Schaltfläche ☐:

Zum Anzeigen des aktuellen Formulars als eigenes Webbrowser Fenster gehen Sie folgendermaßen vor:

1. Klicken Sie auf die „Herauslösen“ Schaltfläche ☐ rechts oben im angezeigten Overlay
Hinweis: Diese Schaltfläche steht nicht in allen Situationen zur Verfügung.

![img-0.jpeg](img-0.jpeg)

Betätigen und gedrückt halten der Umschalttaste bei der Auswahl des Kontextmenübefehls „Eigenschaften lesen“ bzw. „Eigenschaften bearbeiten“:

Zum sofortigen Anzeigen der Metadaten eines Objekts in einem eigenen Webbrowser Fenster gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Objekt, dessen Metadaten eingesehen oder bearbeitet werden sollen.
2. Öffnen Sie das Kontextmenü des Objekts und betätigen Sie die Umschalttaste Ihrer Tastatur und halten Sie die Taste gedrückt.
3. Wählen Sie den Kontextmenübefehler „Eigenschaften lesen“ oder „Eigenschaften bearbeiten“.

Ergebnis: Die Metadaten des Objekts werden in einem eigenen Webbrowser Fenster geöffnet.

Benutzerhilfe

<!-- PDF page 148 -->

# 2.18 Arbeiten mit kontextabhängigen Symbolen

In der Fabasoft eGov-Suite Bayern kommt es häufig vor, dass Symbole von Objektklassen bzw. Aktionen mit bestimmten (meist) überlappenden Zeichen dargestellt werden, z.B. werden bei Geschäftsobjekten durch diese Zeichen bestimmte Zustände repräsentiert. Das hat den Vorteil, dass die Benutzer damit ohne die Eigenschaften öffnen zu müssen bzw. sich die entsprechenden Spalten einblenden zu lassen, anhand des Objektsymbols auf den Zustand des Geschäftsobjekts schließen können. In der nachfolgenden Tabelle werden die wichtigsten kontextabhängigen Zeichen erklärt.

[tbl-7.md](tbl-7.md)

Benutzerhilfe

<!-- PDF page 149 -->

Benutzerhilfe
149

[tbl-8.md](tbl-8.md)

## 2.19 Benutzerhilfe

Für die Teilsysteme, Komponenten und Module steht ein einheitliches Hilfesystem zur Verfügung.

## 2.19.1 Benutzerhilfe öffnen

Um die Benutzerhilfe aufzurufen, befolgen Sie folgende Schritte:

1. Klicken Sie rechts oben auf Ihren Benutzernamen
2. Wählen Sie die Option „Hilfe“ im geöffneten DropDown

**Hinweis:** Alternativ dazu kann die Benutzerhilfe auch durch das Drücken der F1 Taste aufgerufen werden.

**Ergebnis:** Es öffnet sich die Benutzerhilfe als PDF.

## 2.19.2 In-Place Informationen

In der neuen Benutzeroberfläche existiert zu jedem Feld eine eigenständige Information:

![img-1.jpeg](img-1.jpeg)

Durch einen Klick auf das Infosymbol erscheint eine Erklärung zum jeweiligen Feld:

<!-- PDF page 150 -->

![img-2.jpeg](img-2.jpeg)

Durch einen Klick auf „Benutzerhilfe“ wird das Benutzerhandbuch geöffnet. (Siehe auch Kapitel 2.19.1 „Benutzerhilfe“)

## 2.20 Office Integration

Unter Microsoft Word und Microsoft Outlook stehen im „Fabasoft eGov-Suite“ Ribbon nützliche eGov-Suite spezifische Anwendungen zur Verfügung:

![img-3.jpeg](img-3.jpeg)

Sollte der „Fabasoft eGov-Suite“ Ribbon nicht zur Verfügung stehen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in einer Microsoft Word Instance auf die Registerkarte „Datei“

![img-4.jpeg](img-4.jpeg)

2. Klicken Sie auf „Optionen“

Benutzerhilfe
150

<!-- PDF page 151 -->

Benutzerhilfe
151

![img-5.jpeg](img-5.jpeg)

# 3. Klicken Sie auf „Add-Ins“ und Klicken Sie auf „Los...“

![img-6.jpeg](img-6.jpeg)

# 4. Setzen Sie das Flag bei „Fabasoft Folio 2019 Word Extension“ auf „Ja“

![img-7.jpeg](img-7.jpeg)

<!-- PDF page 152 -->

Benutzerhilfe
152

# 2.20.1 Microsoft Word Ribbons

Je nachdem ob ein Microsoft Word Objekt aus der Fabasoft eGov-Suite oder aus Windows geöffnet wurde, stehen unterschiedliche Anwendungen zur Verfügung. Ein großer Vorteil ist, dass während dem Ausführen der Anwendungen das geöffnete Dokument nicht geschlossen werden muss.

Ribbons eines aus der eGov-Suite geöffneten Schriftstücks (noch nicht erfasst):

![img-8.jpeg](img-8.jpeg)

Ribbons eines aus der eGov-Suite geöffneten Schriftstücks (bereits erfasst):

![img-9.jpeg](img-9.jpeg)

Ribbons eines lokal geöffneten Schriftstücks:

![img-10.jpeg](img-10.jpeg)

# 2.20.1.1 Aus eGov-Suite öffnen

„Aus eGov-Suite öffnen“ bietet die Möglichkeit Microsoft Word Objekte aus der Fabasoft eGov-Suite zu öffnen. Nach einem Klick auf den Button wird in einem neuen Fenster der Schreibtisch des Benutzers geöffnet. In diesem kann zu dem gewünschten Microsoft Word Objekt navigiert und durch einen Klick auf das Objekt geöffnet werden. Anschließen wird eine neue Word Instance mit dem gewählten Microsoft Word Objekt geöffnet.

# 2.20.1.2 Ablegen

Nach einem Klick auf „Ablegen“ wird in einem neuen Fenster der Schreibtisch des Benutzers geöffnet. Der Name des neuen Microsoft Word Objekts wird vorbefüllt und kann vor dem Speichern geändert werden. Nach einem Klick auf „Speichern“ wird das Objekt in die Fabasoft eGov-Suite geladen.

Hinweis: Dieser Button steht nur zur Verfügung, wenn das Microsoft Word Objekt nicht aus der Fabasoft eGov-Suite geöffnet wurde. Die Anwendung befindet sich auch im „Datei“ Menü.

<!-- PDF page 153 -->

Benutzerhilfe
153

# 2.20.1.3 Erfassen

Mit der Anwendung kann die lokale Datei als Dokument in der eGov-Suite erfasst werden.

**Hinweis:** Dieser Button steht nur zur Verfügung, wenn das Microsoft Word Objekt nicht aus der Fabasoft eGov-Suite geöffnet wurde. Die Anwendung befindet sich auch im „Datei“ Menü.

# 2.20.1.4 Version erzeugen

Um eine aktuelle Version des Microsoft Word Objekts zu speichern steht der „Version erzeugen“ Button zur Verfügung. Vor dem Erzeugen einer neuen Version muss eine Beschreibung eingegeben werden.

# 2.20.1.5 Version lesen

Bereits erzeugte Versionen können in einem neuen Fenster geöffnet werden. Beim Klick auf eine bestimmte Version wird eine neue Microsoft Word Instance geöffnet. Diese zeigt den Inhalt des Microsoft Word Objekts zum Zeitpunkt der Versionierung an.

**Hinweis:** Dieser Button steht nur zur Verfügung, wenn bereits eine Version des Objekts gespeichert wurde.

# 2.20.1.6 Eigenschaften

Der „Eigenschaften“ Button bietet die Möglichkeit die Eigenschaften der übergeordneten Objekte zu öffnen. Nach einem Klick auf den „Eigenschaften“ Button werden in einem Dropdown Feld diese Objekte anzeigt.

![img-11.jpeg](img-11.jpeg)

Ein Klick auf einen Eintrag öffnet die Eigenschaften des Objekts in einem neuen Fenster.

**Hinweis:** Dieser Button steht nur zur Verfügung, wenn das Microsoft Word Objekt in einem Dokument liegt.

# 2.20.1.7 Öffnen

Der „Öffnen“ Button bietet die Möglichkeit das Explore-Formular übergeordneter Objekte zu öffnen. Nach einem Klick auf den „Eigenschaften“ Button werden in einem Dropdown Feld diese Objekte anzeigt.

<!-- PDF page 154 -->

![img-12.jpeg](img-12.jpeg)

Ein Klick auf einen Eintrag öffnet das Explore-Formular des Objekts in einem neuen Fenster.

Hinweis: Dieser Button steht nur zur Verfügung, wenn das Microsoft Word Objekt in einem Dokument liegt.

## 2.20.1.8 Unterschriften Vorgang

Der „Unterschriften Vorgang“ Button bietet in einem Dropdown Feld verschiedene Unterschriften an. Nach einem Klick auf eine Unterschrift, wird diese direkt auf dem Vorgang angebracht.

Hinweis: Dieser Button steht nur zur Verfügung, wenn das Microsoft Word Objekt in einem Vorgang liegt.

## 2.20.1.9 Unterschriften Dokument

Der „Unterschriften Dokument“ Button bietet in einem Dropdown Feld verschiedene Unterschriften an. Nach einem Klick auf eine Unterschrift, wird diese direkt auf dem Dokument angebracht.

Hinweis: Dieser Button steht nur zur Verfügung, wenn das Microsoft Word Objekt in einem Dokument liegt.

## 2.20.1.10 Verfügen

Nach einem Klick auf den „Verfügen“ Button werden zuerst in einem Dropdown Feld die übergeordneten Objekte angezeigt, welche Verfügt werden können.

![img-13.jpeg](img-13.jpeg)

Nach einem Klick auf das zu verfügende Objekt, wird der Verfügen-Dialog in einem neuen Fenster geöffnet. Nähere Informationen zu Verfügungen finden Sie im Kapitel 3.3.9.3 „Verfügungen“.

Benutzerhilfe

<!-- PDF page 155 -->

Hinweis: Dieser Button steht nur zur Verfügung, wenn das Microsoft Word Objekt in einem Dokument liegt.

## 2.20.1.11 Aktenplan öffnen

Der eingehängte Aktenplan des Benutzers wird in einem neuen Fenster geöffnet.

## 2.20.1.12 Umbenennen

Nach einem Klick auf „Umbenennen“ wird der Umbenennen Dialog in einem neuen Fenster geöffnet. Nach der Eingabe eines neuen Namens, wird das Objekt dahingehend umbenannt.

Hinweis: Das Name der aktuell geöffneten Microsoft Word Instance wird nicht aktualisiert.

## 2.20.1.13 Aktualisieren

Dieser Button sorgt für eine Aktualisierung der DocProperties, der Felder und der Schaltflächen des Fabasoft eGov-Suite Ribbons.

## 2.20.1.14 DocProperties einfügen

Mittels der Anwendung können DocProperties im Schriftstück eingefügt werden.

## 2.20.1.15 Text

Mittels der Anwendung können Textbausteine im Schriftstück eingefügt werden.

Hinweis: Es können auch mehrere Textbausteine gleichzeitig eingefügt werden.

## 2.20.1.16 Feld einfügen

Vordefinierte Felder können über die Anwendung im Schriftstück eingefügt werden.

Hinweis: Bei einigen vordefinierten Feldern werden Änderungen automatisch in die eGov-Suite übernommen.

## 2.20.2 Microsoft Outlook Ribbons

Die Buttons im „Fabasoft eGov-Suite Ribbon“ öffnen einen neuen Bereich, in welchen Microsoft E-Mails direkt importiert werden können. Wie bei einem Import von Microsoft E-Mails in die Fabasoft eGov-Suite, stehen auch in diesem Bereich folgende Optionen zur Verfügung:

- E-Mail Import: Aufteilung der E-Mail in Text und Anhang
- Auswahl der zu erstellenden Objektklasse: Eingangsdokument oder Erledigung

![img-14.jpeg](img-14.jpeg)

Benutzerhilfe
155

<!-- PDF page 156 -->

Durch einen Klick auf eines der angezeigten Buttons wird der „Fabasoft eGov-Suite“ Bereich geöffnet:

![img-15.jpeg](img-15.jpeg)

## Aktenplan

Der eingehängte Aktenplan des Benutzers wird im Fabasoft eGov-Suite Bereich geöffnet.

## Postkorb

Der Postkorb des Benutzers wird im Fabasoft eGov-Suite Bereich geöffnet.

## Zuletzt verwendet

Öffnet die „Häufig verwendet“ Liste des Benutzers.

## Schreibtisch

Öffnet den Schreibtisch des aktuellen Benutzers.

## 2.21 Viewer

Durch den Fabasoft eGov-Suite Viewer werden zum Öffnen von PDF Objekten keine externen Plugins (z.B.: Adobe Reader Plugin im Microsoft Edge) oder Browser Funktionalitäten des jeweiligen Browsers benötigt.

Durch das Aktivieren des Viewer wird dieser zum Beispiel in der dreigeteilten Sicht im Arbeitsvorrat oder in der zweigeteilten Sicht beim Erfassen von Schriftstücken verwendet und präsentiert sich folgendermaßen:

Benutzerhilfe
156

<!-- PDF page 157 -->

Benutzerhilfe
157

![img-16.jpeg](img-16.jpeg)

Das Aktivieren des Fabasoft Viewers wird im Kapitel 5.6 „Aktivieren des Fabasoft Viewers“ behandelt.

## 2.21.1 Sidebar

Über die Sidebar kann sowohl eine Vorschauansicht, als auch eine Strukturansicht angezeigt werden.

![img-17.jpeg](img-17.jpeg)

## 2.21.2 Dokument durchsuchen

Nach einem Klick auf „Dokument durchsuchen“ kann das Dokument nach Begriffen durchsucht werden. Mit den Pfeilen kann zu den einzelnen Suchtreffern navigiert werden.

<!-- PDF page 158 -->

![img-18.jpeg](img-18.jpeg)

## 2.21.3 Blättern

Mit den Buttons „Eine Seite zurück“ und „Eine Seite vor“ kann auf die vorige bzw. nachfolgende Seite geblättert werden.

![img-19.jpeg](img-19.jpeg)

## 2.21.4 Zoomen

Mit den Buttons „Verkleinern“ bzw. „Vergößern“ ändert sich der Zoomfaktor. Dieser kann auch in der Dropdown-Liste ausgewählt werden. Als Standard ist der Automatische Zoom eingestellt.

![img-20.jpeg](img-20.jpeg)

## 2.21.5 Zum Drucken öffnen

Öffnet die PDF-Übersicht zum Drucken in einem neuen Fenster.

![img-21.jpeg](img-21.jpeg)

**Hinweis:** Durch einen Klick auf das Icon „Zum Drucken Öffnen“ wird die PDF-Übersicht in einem eigenständigen Browser Fenster geöffnet. Hier steht unter anderem auch die Funktion „Herunterladen“ zur Verfügung.

## 2.21.6 Werkzeuge

Ein Klick auf den Werkzeuge-Button bietet in einer DropDown-Liste zusätzlich folgende Werkzeuge an.

Benutzerhilfe

<!-- PDF page 159 -->

![img-22.jpeg](img-22.jpeg)

# Erste Seite anzeigen

Sprint zur ersten Seite

# Letzte Seite anzeigen

Sprint zur letzten Seite

# Im Uhrzeigersinn drehen

Dreht alle PDF-Seiten im Uhrzeigersinn

# Gegen Uhrzeigersinn drehen

Dreht alle PDF-Seiten gegen den Uhrzeigersinn

# Hand-Werkzeug aktivieren

Mit dem Hand-Werkzeug kann in der PDF-Übersicht mit gedrückter linker Maustaste navigiert werden.

# Dokumenteigenschaften

Zeigt die Eigenschaften der aktuellen PDF-Übersicht:

[tbl-9.md](tbl-9.md)

Benutzerhilfe

<!-- PDF page 160 -->

Benutzerhilfe
160

# 2.22 Fachdaten

Hinweis: Bei den Geschäftsobjekten ist die Registerkarte „Fachdaten" nur eingeblendet, wenn Fachdaten am übergeordneten Aktenplaneintrag konfiguriert wurden.

In den nachfolgenden beiden Kapiteln wird die Verwendung von Fachdaten anhand eines Beispiels erklärt. Die vorhandenen Eigenschaften von Geschäftsobjekten werden mit der booleschen Eigenschaft Vertraulich erweitert. Zusätzlich soll die Eigenschaft auf der Objektklasse Erledigung vorinitialisiert sein.

## 2.22.1 Fachdaten im Geschäftsobjekt verwenden

Um Fachdaten z.B. bei einem Eingangsdokument zu verwenden, gehen Sie folgendermaßen vor:

1. Wechseln Sie zu Ihrem „Schreibtisch".
2. Lokalisieren Sie das Dokument, bei dem Sie die Fachdaten verwenden wollen und öffnen Sie mit einem Rechtsklick das Kontextmenü. Klicken Sie auf das Feld „Eigenschaften bearbeiten".
3. Wechseln Sie auf die Registerkarte „Fachdaten" und fügen Sie über „Eintrag hinzufügen" eine neue Zeile im Feld „Fachdaten" hinzu.

![img-23.jpeg](img-23.jpeg)

4. Wählen Sie im Drop-Down Menü ein vordefiniertes Fachdatum aus.

<!-- PDF page 161 -->

Benutzerhilfe
161

# Fachdaten

![img-24.jpeg](img-24.jpeg)

5. Durch Markieren eines Fachdatums oder mehrerer Fachdaten und einem anschließenden Klick auf „Fachdaten bearbeiten“ haben Sie die Möglichkeit, diese zu bearbeiten. Bestätigen Sie mit einem Klick auf „Beenden“.

# Fachdaten

![img-25.jpeg](img-25.jpeg)

Hinweis: Werden mehrere Fachdaten bearbeitet, werden zusätzlich zur „Beenden“ Schaltfläche eine „nächstes Fachdatum“ sowie eine „Voriges Fachdatum“ Schaltfläche angezeigt.

Hinweis: Bei neu erstellten Dokumenten kann der Wert vom Fachadministrator initialisiert sein, d.h. dass in dem Feld „Wert“ schon etwas eingetragen ist. Dies können Sie dennoch abändern.

6. Bestätigen Sie Ihre Eingaben mit einem Klick auf „Weiter“.

Ergebnis: Das Fachdatum wurde am Dokument angebracht.

## 2.22.2 Einfügen von Fachdaten als DocProperties in Worddokumenten

1. Folgen Sie der Anleitung im Kapitel 2.22.1 „Fachdaten im Geschäftsobjekt verwenden“ um ein Fachdatum am Dokument anzuwenden.
2. Öffnen Sie das Worddokument des Vorgangs, in dem Sie die DocProperty einfügen wollen.
3. Wechseln Sie auf den Ribbon „Fabasoft eGov Suite“ und klicken Sie auf die Schaltfläche „Text einfügen“. Im DropDown wählen Sie „Eigenschaft“.

<!-- PDF page 162 -->

![img-0.jpeg](img-0.jpeg)

4. Gruppieren Sie die Spalte „Softwarekomponente“ per Rechtsklick auf die Spalte und dann Klick auf „Gruppieren nach“ und wählen Sie „Wert“ aus.
5. Um ein vom Fachadministrator erstelltes Fachdatum zu verwenden erweitern Sie nun die Gruppe „Built-In Settings“ mit einem Klick auf Softwarekomponente „Built-in Settings“.

![img-1.jpeg](img-1.jpeg)

6. Klicken Sie auf das Fachdatum, das als DocProperty eingefügt werden soll.

Ergebnis: Der Wert des Fachdatums erscheint ausformuliert im Worddokument.

![img-2.jpeg](img-2.jpeg)

Benutzerhilfe

<!-- PDF page 163 -->

Benutzerhilfe
163

# 2.23 Beilagen einfügen in Outlook

Im Microsoft Outlook steht am Ribbon „Nachricht“ die Funktion „Beilagen einfügen“ zur Verfügung. Mit dieser ist es möglich Schriftstücke aus der eGov-Suite direkt als Beilage in eine neue E-Mail einzufügen.

Um Beilagen aus der eGov-Suite in eine neue E-Mail einzufügen, gehen Sie wie folgt vor:

1. Wechseln Sie in das Programm „Microsoft Outlook“.
2. Erstellen Sie eine neue E-Mail.
3. Wechseln Sie in die eGov-Suite und kopieren Sie das gewünschte Schriftstück, welches als Beilage verwendet werden soll.
4. Wechseln Sie zurück zu der neuen E-Mail und führen Sie die Anwendung „Beilagen einfügen“ aus.

![img-3.jpeg](img-3.jpeg)

Ergebnis: Das Schriftstück wurde als Beilage in die neue E-Mail eingefügt.

Hinweis: Um die Anwendung verwenden zu können müssen Sie das Add-In „Fabasoft Folio 2025 Outlook Extension“ aktivieren.

# 3 Kernprozesse

Unter Kernprozessen werden jene Tätigkeiten und Aktionen verstanden, die direkt mit der Behandlung von Akten, Vorgängen, Umlaufmappen, Dokumenten und Schriftstücken in Beziehung stehen.

# 3.1 Erstellung und Pflege des Aktenplans

## Überblick Aktenplan

- Kann nur durch Administratoren erzeugt werden
- Besteht aus einer Hierarchie von Aktenplaneinheiten, die den Geschäftsbereich einer Dienststelle hierarchisch strukturieren.
- Eindeutige Kennung durch Aktenplankennzeichen
- Bearbeitung/Erstellung von Aktenplänen erfolgt am Schreibtisch

<!-- PDF page 164 -->

- Aktenplaneinträge können im jeweiligen Aktenplan oder am Schreibtisch erzeugt und bearbeitet werden.

## 3.1.1 Einen Aktenplan anlegen

**Hinweis:** Ein neues Objekt des Typs Aktenplan kann nur durch Administratoren erzeugt werden. Um einem Benutzer einen Aktenplan zur Verfügung zu stellen, muss dieser in der Arbeitsumgebung des Benutzers im Feld Aktenplan hinterlegt werden. Dadurch ist der Aktenplan z.B. im Widget „Aktenplan“ verfügbar.

Um einen Aktenplan anzulegen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren Schreibtisch.
2. Klicken Sie auf die Schaltfläche „Neu“.
3. Wählen Sie den Eintrag Aktenplan aus und klicken Sie auf die Schaltfläche „Weiter“.
4. Die Metadaten eines Aktenplans enthalten Informationen, die den Aktenplan beschreiben. Siehe hierzu Kapitel 6.3 „Aktenplan“.
5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern und die Erstellung abzuschließen.

## 3.1.2 Einen Aktenplan pflegen

Ein Aktenplan wird zur Organisation von Akten verwendet und besteht aus einer Hierarchie von Aktenplaneinträgen.

Es können auch mehrere Aktenpläne parallel geführt werden.

Für die Aktenplanpflege und das Einsehen eines Aktenplans steht für Administratoren das Widget „Aktenplan“ zur Verfügung.

**Hinweis:** Zusätzlich haben Sie die Möglichkeit, auf Ihrem „Schreibtisch“ nach einem Aktenplan zu suchen und abzulegen.

## 3.1.3 Einen Aktenplaneintrag hinzufügen

Um einen Aktenplaneintrag hinzuzufügen, gehen Sie folgendermaßen vor:

1. Navigieren Sie in das Widget „Aktenplan“.
2. Wählen Sie einen Aktenplaneintrag aus, dem Sie einen neuen Aktenplaneintrag zuordnen möchten.

**Hinweis:** Wählen Sie den Aktenplan selbst aus, um auf oberster Ebene einen Aktenplaneintrag zu erzeugen.

3. Klicken Sie auf die Schaltfläche „Neu“.
4. Erfassen Sie die Metadaten des Aktenplaneintrags. Nähere Informationen zu den Metadaten eines Aktenplaneintrags finden Sie in der Beschreibung der Benutzerformulare im Kapitel 6.4 „Aktenplaneintrag“.
5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern und die Erstellung abzuschließen.

Benutzerhilfe
164

<!-- PDF page 165 -->

Benutzerhilfe
165

# 3.1.4 Einen Aktenplaneintrag bearbeiten

Die Metadaten von bestehenden Aktenplaneinträgen können von Benutzern im Rahmen ihrer Zugriffsrechte bearbeitet werden. (Registrator/in und Schriftgutverwalter/in sowie Administratoren)

Um einen Aktenplaneintrag zu bearbeiten, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Aktenplaneintrag über den Schreibtisch oder über den Aktenplan.
2. Führen Sie den Kontextmenübefehl „Eigenschaften bearbeiten“ aus. Die Metadaten des Objekts werden im Bearbeitungsmodus geöffnet.
3. Erfassen Sie die Metadaten des Aktenplaneintrags. Nähere Informationen zu den Metadaten eines Aktenplaneintrags finden Sie in der Beschreibung der Benutzerformulare im Kapitel 6.4 „Aktenplaneintrag“.
4. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

# 3.1.5 Eine Gültigkeit für einen Aktenplaneintrag festlegen

Auf der Registerkarte „Erstellung“ im Eigenschaftseditor eines Aktenplaneintrages kann die Gültigkeit festgelegt werden. Ein Aktenplaneintrag kann über die Definition der Gültigkeit durch Eingabe eines Datums Gültig von und Gültig bis zeitlich beschränkt werden. Ist der Gültigkeitszeitraum definiert, so ist es nur im Gültigkeitszeitraum möglich, dem betroffenen Aktenplaneintrag neue Aktenplaneinträge oder Akten zuzuordnen.

# 3.2 Behandlung von Akten

[tbl-0.md](tbl-0.md)

# 3.2.1 Eine Akte erzeugen

Eine Akte kann, wie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ beschrieben, erzeugt werden, indem beim Erzeugen der Objekttyp „Akte“ ausgewählt wird.

<!-- PDF page 166 -->

Hinweis: Akten können ausschließlich innerhalb von Aktenplaneinträgen erzeugt werden. Eine Erstellung direkt am Schreibtisch ist nicht möglich!

Hinweis: Akten können nur von Benutzern erstellt und bearbeitet werden, die mindestens eine der folgenden Benutzerrollen einnehmen:

- Registrator
- Support
- Fachadministrator
- Schriftgutverwalter
- OE-Administrator

## 3.2.2 Die Metadaten einer Akte lesen bzw. bearbeiten

Die Metadaten einer Akte können, wie in den Kapiteln 2.1.2.2 „Die Metadaten eines Objekts lesen“ bzw. 2.1.2.3 „Die Metadaten eines Objekts bearbeiten“ beschrieben, im Rahmen der derzeitigen Benutzerrechte gelesen oder bearbeitet werden.

## 3.2.3 Bezüge eintragen

Die Fabasoft eGov-Suite Bayern unterstützt das Erfassen von Querverweisen von Akten oder Vorgängen zu anderen Akten oder Vorgängen, die zu dieser Akte oder diesem Vorgang in Beziehung stehen. Diese Querverweise werden auf der Registerkarte „Bezüge“ angegeben. Folgende Metadaten sind für das Erfassen von Querverweisen verfügbar:

- Bezüge zu vorhergehenden Vorgängen/Akten
- Bezüge zu nachfolgenden Vorgängen/Akten
- Elektronische Bezüge
- Bezüge

Für genauere Informationen zu diesen Metadaten siehe Kapitel 6.8.2 „Registerkarte „Bezüge“.

Hinweis: Eine Akte/ein Vorgang kann Beziehungen und Rückverweise zu ein oder mehreren Akten oder Vorgängen haben.

Hinweis: Die Erfassung der Querverweise kann entweder direkt bei der Zuordnung oder nachträglich in den Metadaten der Akte oder des Vorgangs erfolgen.

Hinweis: Wenn bei einem Akt/Vorgang Bezüge eingetragen sind, können diese in der Baumansicht am „Schreibtisch“ eingesehen werden, ohne die Metadaten der Akte/des Vorgangs zu öffnen.

## 3.2.3.1 Bezüge zu vorhergehenden Vorgängen/Akten erfassen

Um einen Bezug zu vorhergehenden Vorgängen/Akten zu erfassen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang bzw. die Akte, für den/die Sie einen Querverweis erfassen wollen.
2. Klicken Sie auf den Kontextmenüeintrag „Eigenschaften bearbeiten“ des Vorgangs/der Akte.

Benutzerhilfe
166

<!-- PDF page 167 -->

3. Wechseln Sie auf die Registerkarte „Bezüge“.

4. Fügen Sie im Feld Bezüge zu vorhergehenden Vorgängen/Akten die Akte oder den Vorgang ein, auf den verwiesen werden soll. Folgende Möglichkeiten stehen dazu zur Verfügung:
- Führen Sie eine Suche durch (Nähere Informationen dazu finden Sie im Kapitel 2.12 „Suche“).
- Fügen Sie einen Eintrag aus der Zwischenablage ein. Öffnen Sie dazu das Menü „Eintrag hinzufügen“ und führen Sie den Befehl „Verknüpfung einfügen“ aus.

**Hinweis:** Alternativ dazu können Sie mittels Rechtsklick innerhalb der jeweiligen Bezugs-Eigenschaft das Kontextmenü öffnen und hier „Verknüpfung einfügen“ bzw. „Suche“ auswählen.

**Ergebnis:**
- Die Akte/der Vorgang ist als vorhergehend eingetragen.
- Die aktuelle Akte/der aktuelle Vorgang wird in der vorhergehenden Akte bzw. dem vorhergehenden Vorgang im Feld Bezüge zu nachfolgenden Vorgängen/Akten eingetragen.

**Hinweis:** Wenn es keine gegenseitige Referenz geben soll, gehen Sie wie im Kapitel 3.2.3.3 „Einen elektronischen Bezug erfassen“ beschrieben vor.

Für weitere Informationen bezüglich den in dieser Registerkarte befindlichen Feldern finden Sie im Kapitel 6.8.2 „Registerkarte „Bezüge“.

## 3.2.3.2 Bezüge zu nachfolgenden Vorgängen/Akten erfassen

Um einen Bezug zu nachfolgenden Vorgängen/Akten zu erfassen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang/die Akte, für die Sie einen Querverweis erfassen möchten.
2. Öffnen Sie das Kontextmenü des Vorgangs/der Akte und führen Sie den Befehl „Eigenschaften bearbeiten“ aus.
3. Wechseln Sie auf die Registerkarte „Bezüge“.
4. Fügen Sie im Feld Bezüge zu nachfolgenden Vorgängen/Akten den Vorgang/die Akte ein, auf die verwiesen werden soll. Folgende Möglichkeiten stehen dazu zur Verfügung:
- Führen Sie eine Suche durch (Nähere Informationen dazu finden Sie im Kapitel 2.12 „Suche“).
- Fügen Sie einen Eintrag aus der Zwischenablage ein. Öffnen Sie dazu das Menü „Eintrag hinzufügen“ und führen Sie den Befehl „Verknüpfung einfügen“ aus.

**Hinweis:** Alternativ dazu können Sie mittels Rechtsklick innerhalb der jeweiligen Bezugs-Eigenschaft das Kontextmenü öffnen und hier „Verknüpfung einfügen“ bzw. „Suche“ auswählen.

5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

**Ergebnis:**
- Die Akte/der Vorgang ist als nachfolgend eingetragen.
- Die aktuelle Akte/der aktuelle Vorgang wird in der nachfolgenden Akte bzw. dem nachfolgenden Vorgang im Feld Bezüge zu vorhergehenden Vorgängen/Akten eingetragen.

Benutzerhilfe
167

<!-- PDF page 168 -->

Hinweis: Wenn es keine gegenseitige Referenzierung geben soll gehen Sie, wie im Kapitel 3.2.3.3 „Einen elektronischen Bezug erfassen“ beschrieben, vor.

Weitere Informationen bezüglich den in dieser Registerkarte befindlichen Feldern finden Sie im Kapitel 6.9.2 „Registerkarte „Adressaten“.

## 3.2.3.3 Einen elektronischen Bezug erfassen

Um in einem Vorgang oder in einer Akte auf einen anderen Vorgang oder eine andere Akte zu verweisen, ist dieser Vorgang oder diese Akte als elektronischer Bezug im Feld Elektronische Bezüge zu erfassen. Im Unterschied zu Einträgen im Feld Bezüge zu vorhergehenden Vorgängen/Akten oder im Feld Bezüge zu nachfolgenden Vorgängen/Akten wird dabei in dem angegebenen Vorgang oder in der angegebenen Akte kein Verweis auf den aktuellen Vorgang oder die aktuelle Akte eingefügt – es erfolgt kein Rückwärtsverweis.

Um einen elektronischen Bezug zu erfassen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang bzw. die Akte, für den/die Sie einen Querverweis erfassen möchten.
2. Öffnen Sie das Kontextmenü des Vorgangs bzw. der Akte und führen Sie den Befehl „Eigenschaften bearbeiten“ aus.
3. Wechseln Sie auf die Registerkarte „Bezüge“.
4. Fügen Sie im Feld Elektronische Bezüge die Akte oder den Vorgang ein, auf die/den verwiesen werden soll. Folgende Möglichkeiten stehen dazu zur Verfügung:
- Führen Sie eine Suche durch (Nähere Informationen dazu finden Sie im Kapitel 2.12 „Suche“).
- Fügen Sie einen Eintrag aus der Zwischenablage ein. Öffnen Sie dazu das Menü „Eintrag hinzufügen“ und führen Sie den Befehl „Verknüpfung einfügen“ aus.

Hinweis: Alternativ dazu können Sie mittels Rechtsklick innerhalb der jeweiligen Bezugs-Eigenschaft das Kontextmenü öffnen und hier „Verknüpfung einfügen“ bzw. „Suche“ auswählen.

5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

Ergebnis: Die Akte/der Vorgang ist als Bezug eingetragen.

Hinweis: Der aktuelle Akt/Vorgang wird im Gegensatz zu vorhergehenden und nachfolgenden Akten bzw. Vorgängen als Bezug eingetragen.

Für weitere Informationen bezüglich den in dieser Registerkarte befindlichen Feldern finden Sie im Kapitel 6.8.2 „Registerkarte „Bezüge“.

## 3.2.3.4 Einen sonstigen Bezug erfassen

In dem Feld Bezüge kann beliebiger Text bezüglich Materialien erfasst werden, die zu der Akte/dem Vorgang gehören und nicht in elektronischer Form verfügbar sind, z.B. Papierunterlagen oder CDs.

Um einen sonstigen Bezug zu erfassen, gehen Sie folgendermaßen vor:

Benutzerhilfe
168

<!-- PDF page 169 -->

1. Lokalisieren Sie den Vorgang bzw. die Akte, für den/die Sie einen Querverweis erfassen möchten und markieren Sie diese/diesen durch einfaches Anklicken.
2. Klicken Sie auf den Kontextmenüeintrag „Eigenschaften bearbeiten“.
3. Wechseln Sie auf die Registerkarte „Bezüge“.
4. Fügen Sie im Feld Bezüge einen Text ein, der auf die Akte oder den Vorgang verweist, die/der nicht in elektronischer Form zur Verfügung steht.
5. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

Für weitere Informationen bezüglich den in dieser Registerkarte befindlichen Feldern finden Sie im Kapitel 6.8.2 „Registerkarte „Bezüge““.

## 3.2.4 Eine Gültigkeit für eine Akte festlegen

Eine Akte kann über die Definition der Gültigkeit durch Eingabe eines Datums in den Feldern Gültig ab und Gültig bis zeitlich beschränkt werden. Ist der Gültigkeitszeitraum definiert, so ist es nur im Gültigkeitszeitraum möglich der betroffenen Akte Vorgänge zuzuordnen.

## 3.2.5 Eine Akte löschen

Soll eine Akte aus der Fabasoft eGov-Suite Bayern gelöscht werden, ist das nur möglich, wenn sich in der Akte keine Vorgänge mehr befinden. Eine Akte kann wie im Kapitel 2.1.2.1 „Ein Objekt löschen“ beschrieben gelöscht werden.

**Hinweis:** Eine Akte kann nur gelöscht werden, wenn sich keine Vorgänge in der Akte befinden.

Benutzerhilfe
169

<!-- PDF page 170 -->

Benutzerhilfe
170

# 3.3 Behandlung von Vorgängen

## Überblick Vorgänge

- Können innerhalb einer Akte erzeugt werden.
- Mögliche Arten: Elektronischer Vorgang/Akte, Papiervorgang/-akte, Hybridvorgang/-akte
- Zuordnung zu bestehender Akte während des Erzeugens über Drop-Down-Liste „Akte"
- Laufweg über „Arbeitsvorrat" festlegen/bearbeiten: Rechtsklick auf Aktivität → „Laufweg öffnen" klicken → „Bearbeiten" (r.o.) klicken → Änderungen vornehmen → „Weiter" klicken
- Alternativ: Bearbeitung über Metadaten: Rechtsklick auf Aktivität im „Arbeitsvorrat" → „Eigenschaften bearbeiten" klicken → in Registerkarte „Laufweg" wechseln → Änderungen vornehmen → „Weiter" klicken

## 3.3.1 Einen Vorgang erzeugen

Um einen neuen Vorgang zu erzeugen, gehen Sie, wie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen" beschrieben, vor. Beachten Sie, dass Sie während der Erzeugung den Objekttyp „Vorgang" auswählen.

**Hinweis:** Vorgänge können ausschließlich innerhalb von Akten erzeugt werden. Eine Erstellung direkt am Schreibtisch ist nicht möglich!

**Hinweis:** Ein Vorgang kann automatisch erzeugt werden, indem eine Akte bei einem Eingangsdokument, welches noch keinem Vorgang zugeordnet wurde, eingetragen wird. Für weitere Informationen siehe Kapitel 3.5.8 „Ein Eingangsdokument zu einem neuen Vorgang zuordnen".

## 3.3.2 Einen Papiervorgang erzeugen

Auf Papier geführte Vorgänge können in der Fabasoft eGov-Suite Bayern genauso wie elektronische Vorgänge erzeugt und bearbeitet werden.

Um einen Papiervorgang zu erzeugen, gehen Sie folgendermaßen vor:

1. Erzeugen Sie den Vorgang mithilfe der Anleitung in Kapitel 2.1.1.1 „Ein Objekt neu erstellen", wobei Sie beim Erzeugen als Objekttyp „Vorgang" auswählen.
2. Wählen Sie im Metadatenfenster des Vorgangs im Feld Original den Eintrag „Papiervorgang/-akte" aus, um festzulegen, dass es sich um einen Papiervorgang handelt.

![img-4.jpeg](img-4.jpeg)

3. Klicken Sie auf die Schaltfläche „Weiter", um die vorgenommenen Änderungen zu speichern.

<!-- PDF page 171 -->

Benutzerhilfe

# 3.3.3 Einen Vorgang einer bestehenden Akte zuordnen

Das Zuordnen eines Vorgangs zu einer bestehenden Akte erfolgt durch Angabe der entsprechenden Akte im Feld Akte bei der Erfassung der Metadaten eines Vorgangs.

Um einen Vorgang einer bestehenden Akte zuzuordnen, gehen Sie folgendermaßen vor:

1. Wählen Sie während dem Erzeugen des Vorgangs in der Drop-down-Liste Akte die entsprechende Akte aus oder führen Sie eine Suche nach der gewünschten Akte aus (siehe Kapitel 2.12 „Suche“).
2. Klicken Sie auf die Schaltfläche „Weiter“, um die Änderungen zu speichern.

**Hinweis:** Wenn Sie einen Vorgang in einer Akte erzeugen wird das Feld Akte automatisch befüllt.

# 3.3.4 Einen Vorgang umschreiben

Um die Akte eines Vorgangs zu ändern, muss der Vorgang umgeschrieben werden. Gehen Sie hierfür folgendermaßen vor:

1. Lokalisieren Sie den Vorgang, der umgeschrieben werden soll.
2. Bringen Sie die Unterschrift „Umschreibung“ auf den Vorgang an, wie im Kapitel 2.1.2.10 „Eine Unterschrift auf einem Objekt anbringen“ beschrieben.

**Hinweis:** Es ist auch möglich, einen Vorgang über Drag &amp; Drop bzw. „Kopieren“ und „Verknüpfung einfügen“ umzuschreiben. In diesem Fall wird ein Dialog angezeigt mit dessen Schaltflächen Sie die Möglichkeit haben, den Vorgang umzuschreiben oder zu duplizieren.

# 3.3.5 Einen Vorgang stornieren

Die Stornierung eines Vorgangs erfolgt durch das Anbringen der Unterschrift „Stornieren“. Wie Sie eine Unterschrift auf einem Vorgang ausführen erfahren Sie in Kapitel 2.1.2.10 „Eine Unterschrift auf einem Objekt anbringen“.

## Ergebnis:

- Die Stornierung wird in den Metadaten des Vorgangs oder der Akte vermerkt.
- Eine Version des Vorgangs wird gesichert.
- Das Symbol des Vorgangs wird geändert.
- Der Laufweg wird unterbrochen.
- Die Stornierung wird an alle Dokumente und Schriftstücke weitergegeben.
- Der Vorgang wird in der Liste der stornierten Objekte der Akte eingetragen und aus der Liste der Vorgänge entfernt.

# 3.3.6 Die Stornierung eines Vorgangs aufheben

Die Stornierung eines Vorgangs kann mithilfe der Unterschrift „Stornierung aufheben“ aufgehoben werden.

## Ergebnis:

171

<!-- PDF page 172 -->

- Die Aufhebung der Stornierung wird in den Metadaten des Vorgangs oder der Akte vermerkt.
- Eine Version des Vorgangs oder der Akte wird gesichert.
- Das Symbol des Vorgangs wird geändert.
- Der Laufweg wird weitergeführt wie vor der Stornierung festgelegt.
- Die Aufhebung der Stornierung wird an alle Dokumente und Schriftstücke weitergegeben.
- Der Vorgang wird aus der Liste der stornierten Objekte der Akte entfernt und in die Liste der Vorgänge eingetragen.

Um die Stornierung eines Vorgangs aufzuheben, führen Sie auf den Vorgang die Unterschrift „Stornierung aufheben" aus. Die Anleitung hierzu finden Sie im Kapitel 2.1.2.10 „Eine Unterschrift auf einem Objekt anbringen", wobei die Unterschrift „Stornierung aufheben" gewählt werden muss.

**Hinweis:** Sollte auf diesem Vorgang keine Unterschrift „Stornierung aufheben" verfügbar sein, eine Unterschrift „Stornieren" aber existiert, müssen Sie den betroffenen Vorgang zuerst stornieren (siehe Kapitel 3.3.5 „Einen Vorgang stornieren").

## 3.3.7 Einen Vorgang duplizieren

Sie haben die Möglichkeiten einen Vorgang zu duplizieren. Gehen Sie hierfür folgendermaßen vor:

1. Lokalisieren Sie den zu duplizierenden Vorgang und legen Sie diesen auf Ihrem Schreibtisch ab.
2. Wählen Sie den Menüpunkt „Duplizieren" im Menü „Objekt" aus.
3. Wählen Sie die Akte aus, der der duplizierte Vorgang zugeordnet werden soll, z.B. durch eine Suche. Siehe hierzu auch Kapitel 2.12 „Suche".
4. Ändern Sie, wenn gewünscht, zusätzlich Metadaten des neuen Vorgangs.

**Hinweis:** Die Metadaten auf der Registerkarte „Vorgang" werden aus dem ursprünglichen Vorgang übernommen. Eine Ausnahme bildet allerdings das Feld Akte.

5. Schließen Sie das Duplizieren durch einen Klick auf die Schaltfläche „Weiter" ab.

**Hinweis:** Umlaufmappen und Registerblätter werden als leere Hülle mitdupliziert. Dokumente und deren Schriftstücke werden hingegen beim Duplizieren eines Vorgangs nicht dupliziert. Somit sind dem neuen Vorgang keine Dokumente zugeordnet.

## 3.3.8 Eine Unterschrift auf einen Vorgang anbringen

Sie haben die Möglichkeit, Zeichnungen in elektronischer Form auf einem Vorgang anzubringen. Dazu stehen je nach Benutzer, Rolle und Bearbeitungsstatus verschiedene Unterschriftenarten zur Verfügung.

**Hinweise:**

- Durch das Ausführen einer Unterschrift können sich der Status und der Bearbeitungsstatus sowie die Zugriffsrechte des Objekts ändern.

Benutzerhilfe
172

<!-- PDF page 173 -->

- Alle angebrachten Unterschriften werden auf der Registerkarte „Unterschriften“ des entsprechenden Objekts eingetragen.
- Es ist auch möglich einen Vorgang über die Arbeitsschritte von Aktivitäten zu unterschreiben.

Siehe hierzu auch Kapitel 2.11 „Unterschreiben“.

## 3.3.9 Laufweg von Vorgängen

### 3.3.9.1 Einen Laufweg festlegen

Der Laufweg wird bei der Erfassung der Metadaten eines Vorgangs festgelegt. Dies kann auf zwei verschiedene Arten erfolgen:

- Beim Erzeugen eines neuen Vorgangs (siehe Kapitel 3.3.1 „Einen Vorgang erzeugen“).
- Bei der Zuordnung von Dokumenten zu neuen Vorgängen (siehe Kapitel 3.5.8 „Ein Eingangsdokument zu einem neuen Vorgang zuordnen“).

![img-5.jpeg](img-5.jpeg)

Um einen Laufweg festzulegen, muss in den Metadaten des Vorgangs im Feld Standard-Laufweg ein Eintrag gewählt werden. Dies kann entweder durch direkte Auswahl eines Eintrags geschehen oder durch eine Suche (siehe Kapitel 2.12 „Suche“).

**Hinweis:** Der Laufweg ist in weiterer Folge durch Verfügungen oder durch die direkte Bearbeitung des Laufwegs auf der Registerkarte „Laufweg“ veränderbar.

**Hinweis:** Wird ein Laufweg erzeugt, allerdings kein Standard-Laufweg ausgewählt, wird die Aktivität Bearbeitung an den Benutzer, welcher in der Eigenschaft Federführung eingetragen wurde, verfügt.

Benutzerhilfe
173

<!-- PDF page 174 -->

Benutzerhilfe

## 3.3.9.2 Den Laufweg direkt bearbeiten

Für die Bearbeitung des Laufwegs steht ein grafischer Editor auf der Registerkarte „Laufweg“ in den Metadaten des jeweils beteiligten Vorgangs zur Verfügung. Weiters können Sie den grafischen Editor auch über den Kontextmenüeintrag „Laufweg öffnen“ einer Aktivität öffnen.

Um den Laufweg eines Vorgangs über die Aktivität zu bearbeiten, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Klicken Sie bei der gewünschten Aktivität auf den Kontextmenüeintrag „Laufweg öffnen“. Bei bereits bearbeiteten Aktivitäten wird der Zeitpunkt der Bearbeitung angezeigt.
3. Wurde der Laufweg lesend geöffnet, klicken Sie rechts unten im Formular auf „Bearbeiten“. Jetzt können Sie beispielsweise neue Aktivitäten hinzufügen oder Aktivitäten entfernen, eine Verfügung durchführen oder den Teilnehmer von Aktivitäten ändern.
4. Klicken Sie auf die Schaltfläche „Weiter“, um die vorgenommenen Änderungen zu speichern.

Um den Laufweg eines Vorgangs über die Metadaten des Vorgangs zu bearbeiten, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang oder das Dokument und klicken Sie auf den Kontextmenüeintrag „Eigenschaften“.
2. Wechseln Sie auf die Registerkarte „Laufweg“. Diese Registerkarte zeigt den gesamten Laufweg des Objekts an. Bei bereits bearbeiteten Aktivitäten wird zusätzlich der Zeitpunkt der Bearbeitung angezeigt. Wurden die Eigenschaften lesend geöffnet, müssen Sie rechts unten auf „Bearbeiten“ klicken, bevor Sie Änderungen am Laufweg vornehmen können.
3. Bearbeiten Sie den Laufweg, indem Sie beispielsweise neue Aktivitäten hinzufügen oder Aktivitäten entfernen, eine Verfügung durchführen oder den Teilnehmer von Aktivitäten ändern.

## 3.3.9.3 Verfügungen

### Überblick Verfügungen

- Werden verwendet, um die Aktivität im Zuge der formalen Erledigung des Vorgangs festzulegen (Laufweg).
- Verfügungen können in der Fabasoft eGov-Suite in einfacher und erweiterter Darstellung eingefügt werden

- Einfach: „Arbeitsvorrat“ → Rechtsklick auf Aktivität → Kontextmenüpunkt „Verfügungen“ klicken → Es erscheint die einfache Ansicht inkl. einer grafischen Darstellung
- Erweitert: „Arbeitsvorrat“ → Rechtsklick auf Aktivität → Kontextmenüpunkt „Verfügungen“ klicken → Es erscheint die einfache Ansicht inkl. einer grafischen Darstellung → „Erweiterte Darstellung“ unten wählen → Es erscheint die erweiterte Ansicht

174

<!-- PDF page 175 -->

Benutzerhilfe

# 3.3.9.3.1 Felder für das Erstellen von Verfügungen

Folgende Felder stehen in der einfachen und in der erweiterten Darstellung des Prozesseditors zur Verfügung:

- Verfügung
In diesem Feld kann die zu verfügende Aktivität ausgewählt werden.

- Verfügung umbenennen
In diesem Feld kann eine eigene Überschrift für die vorgeschriebene Aktivität angegeben werden.

- Abstrakter Teilnehmer
Um dieses Feld anzuzeigen, klicken Sie unter „Teilnehmer“ auf die Lupe mit einem Plus in der Mitte.

- In dieser Drop-down-Liste kann ein abstrakter Teilnehmer (z.B. „Prozessverantwortlicher“, „Aktueller Benutzer“) ausgewählt werden.

![img-6.jpeg](img-6.jpeg)

Die Aktivität wird dem zugeordneten Benutzer automatisch verfügt. Zum Ausblenden des Feldes klicken Sie wiederum auf die Lupe, die nun ein Minus in der Mitte aufzeigt.

**Beispiel:** Die Benutzerin Sabrina Sacher verfügt die Aktivität Kenntnisnahme dem Abstrakten Teilnehmer „Aktueller Benutzer“. Somit verfügt die Benutzerin die Aktivität sich selbst. Siehe hierzu auch Kapitel 3.3.9.5 „Abstrakte Teilnehmer“.

- Benutzer
Durch Angabe eines Benutzers wird genau diesem die entsprechende Aktivität zugewiesen. Benutzer können aus der Drop-down-Liste ausgewählt werden.

Zusätzlich kann über die Schaltfläche „Aus Hierarchie auswählen“ ein Benutzer aus der Organisationshierarchie ausgewählt werden oder mithilfe der Schaltfläche „Suchen“ eine Suche nach Benutzern durchgeführt werden. Auch die Schnellsuche über die Einfügen-Taste ist hier möglich (siehe Kapitel 2.12.13 „Schnellsuche“).

- Organisationseinheit
In diesem Feld kann eine konkrete Organisationseinheit angegeben werden, an die die Aktivität verfügt wird. Bei einer Organisationseinheit kann definiert werden, welche Stelle innerhalb der Organisationseinheit für den Arbeitsvorrat der Organisationseinheit verantwortlich ist. Benutzer, welche eine Rolle mit dieser Organisation einnehmen, erhalten die Aktivität in ihren Arbeitsvorrat. Auch die Schnellsuche über die Einfügen-Taste ist in diesem Feld möglich (siehe Kapitel 2.12.13 „Schnellsuche“).

**Hinweis:** Die gewünschte Organisationseinheit kann über die Schaltfläche „Aus

Benutzerhilfe

<!-- PDF page 176 -->

Hierarchie auswählen" ☐ aus der Organisationshierarchie ausgewählt werden oder mithilfe der Schaltfläche „Suchen“ kann eine Suche nach Organisationseinheiten durchgeführt werden.

- Stelle
In diesem Feld kann eine Stelle angegeben werden. Die Aktivität wird allen Benutzern, die diese Stelle einnehmen, zugewiesen. Wird die Aktivität von einem bestimmten Benutzer begonnen, wird die Aktivität wieder aus den Arbeitsvorräten der anderen Benutzer entfernt.

- Verteilerliste
Alternativ zu einem konkreten Benutzer kann eine Verteilerliste angegeben werden, in der mehrere Benutzer enthalten sind, an die diese Aktivität verfügt werden soll.
**Hinweis:** Die Verfügung wird parallel an alle Benutzer der Verteilerliste durchgeführt.

- Geschäftsgangvermerk
In diesem Feld kann ein Geschäftsgangvermerk erfasst werden.

Um die Einstellungen für eine zu verfügende Aktivität zu übernehmen, klicken Sie auf die Schaltfläche „Übernehmen“.

## 3.3.9.3.2 Einen Termin für eine Aktivität vergeben

Bei der Durchführung von Verfügungen können Termine und Fristen festgelegt werden.

**Hinweis:** In der einfachen Darstellung müssen die Felder zur Angabe von Terminen extra eingeblendet werden. Klicken Sie hierfür auf die Schaltfläche „Termine anzeigen“.

Folgende Eigenschaften stehen zur Angabe von Terminen und Fristen bei Aktivitäten zur Verfügung:

- Termin für Vorlage
Die Aktivität ist so lange auf Wiedervorlage, bis der angegebene Termin erreicht wurde. Das Aktivieren der Aktivität erfolgt automatisch bei Erreichen des angegebenen Termins.
**Hinweis:** Diese Eigenschaft ist nur beim Verfügen änderbar.

- Termin für Beginn
Gibt den Zeitpunkt an, bis zu dem die Aktivität begonnen werden soll.
**Hinweis:** Wird dieser Termin nicht eingehalten, werden die Arbeitsschritte der Aktivität *kursiv* dargestellt.

- Termin für Erledigung
Gibt den Zeitpunkt an, bis zu dem die Aktivität beendet sein soll.
**Hinweis:** Wird dieser Termin nicht eingehalten, werden die Arbeitsschritte der Aktivität *kursiv* dargestellt.

Um die Einstellungen für eine zu verfügende Aktivität zu übernehmen, klicken Sie auf die Schaltfläche „Übernehmen“.

Benutzerhilfe
176

<!-- PDF page 177 -->

Benutzerhilfe

# 3.3.9.3.3 Eine Verfügung in der einfachen Darstellung durchführen

Eine Verfügung kann in einer einfachen oder in einer erweiterten Darstellung durchgeführt werden. Die einfache Darstellung enthält eine grafische Vorschau über die zu verfügenden Aktivitäten und eine Verfügung kann mit wenigen Angaben durchgeführt werden.

Um eine Verfügung in der einfachen Darstellung durchzuführen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität, bei der der entsprechende Vorgang oder das entsprechende Dokument in der Spalte Gehört zu angezeigt wird.
3. Öffnen Sie das Kontextmenü der gewünschten Aktivität durch einen Klick mit der rechten Maustaste und führen Sie den Befehl „Verfügungen“ aus.

**Hinweis:** Der Befehl „Verfügungen“ steht auch im Kontextmenü von Vorgängen, Dokumenten und Schriftstücken zur Verfügung. In diesem Fall wird allerdings ein neuer Prozess gestartet.

**Hinweis:** Stehen Musterverfügungen zur Verfügung, werden diese zur Auswahl angeboten. Zum Erstellen einer Musterverfügung siehe Kapitel 5.2.3.2 „Erstellung und Verwendung von Musterverfügungen“.

4. Der Prozesseditor steht in einer einfachen und einer erweiterten Darstellung zur Verfügung. Wenn Sie sich in der erweiterten Darstellung befinden, klicken Sie auf die Schaltfläche „einfache Darstellung“ unten rechts, um eine Verfügung in der einfachen Darstellung durchzuführen.

5. Bearbeiten Sie die Verfügung und klicken Sie am Ende auf die Schaltfläche „Weiter“.

![img-7.jpeg](img-7.jpeg)

**Ergebnis:** Die Verfügung wird in den aktuellen Prozess eingefügt.

**Hinweis:** Wird eine Verfügung über das Kontextmenü eines Schriftstücks, Dokuments oder Vorgangs durchgeführt, wird ein neuer, zusätzlicher Prozess gestartet.

177

<!-- PDF page 178 -->

Sie haben nun die Möglichkeit, weitere, zu verfügende Aktivitäten, einzufügen. Klicken Sie auf die entsprechende +-Schaltfläche, um eine Aktivität vor, nach oder parallel zu einer bereits definierten Aktivität einzufügen.

![img-8.jpeg](img-8.jpeg)

In der grafischen Darstellung kann zwischen den einzelnen Aktivitäten der Verfügung gewechselt werden. Dazu muss auf die zu verfügende Aktivität geklickt werden. Die Aktivität wird durch eine schwarze Umrandung hervorgehoben und der es ist möglich, diverse Eingaben zu bearbeiten.

**Hinweis:** Es besteht auch die Möglichkeit, die Verfügungen mittels Drag &amp; Drop zu verschieben. Dazu steht Ihnen folgende Schaltfläche zur Verfügung:

![img-9.jpeg](img-9.jpeg)

## 3.3.9.3.4 Eine Verfügung in der erweiterten Darstellung durchführen

Um eine Verfügung in der erweiterten Darstellung durchzuführen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität, bei der der entsprechende Vorgang oder das entsprechende Dokument in der Spalte Gehört zu angezeigt wird.
3. Öffnen Sie das Kontextmenü der gewünschten Aktivität und führen Sie den Befehl „Verfügungen“ aus.

Der Prozesseditor steht in einer einfachen und einer erweiterten Darstellung zur Verfügung. Wenn Sie sich in der einfachen Darstellung befinden, klicken Sie auf die Schaltfläche „Erweiterte Darstellung“, um eine Verfügung in der erweiterten Darstellung durchzuführen.

4. Klicken Sie auf die Schaltfläche „Eintrag erzeugen“⁴. Um einen neuen Block einzufügen. Alternativ können Sie auch über die Schaltfläche „Eintrag hinzufügen“ einen neuen Eintrag zu einem bestehenden Block hinzufügen. Dadurch wird ein neuer Eintrag im Feld Verfügungen erzeugt.

Benutzerhilfe

<!-- PDF page 179 -->

Neue Aktivitäten für "A20 01.1.1/1" einfügen
Seite X

![img-10.jpeg](img-10.jpeg)

5. Bearbeiten Sie die Zeile (bzw. die Verfügung), die Sie bearbeiten möchten (siehe Kapitel 2.1.9 „Umgang mit Aggregaten“) und klicken Sie am Ende auf die Schalfläche „Weiter“.

**Ergebnis:** Die Verfügung wird in den aktuellen Prozess eingefügt.

**Hinweis:** Die erweiterte Darstellung erlaubt auch die Einstellung der Verfügungen an Stellvertreter. Folgende Optionen sind möglich:

- **Keine Stellvertretung**
Verfügt der Benutzer an eine Organisationseinheit und möchte ausschließen, dass ein Stellvertreter die Verfügung zur Bearbeitung erhält, so muss er dieses Häkchen setzen.

- **Keine benutzerbezogene Stellvertretung**
Verfügt der Benutzer an einen Anderen und möchte ausschließen, dass ein benutzerbezogener Stellvertreter die Verfügung zur Bearbeitung erhält, so muss er dieses Häkchen setzen.

### 3.3.9.3.5 Eine Sammelverfügung durchführen

Um eine Sammelverfügung durchzuführen, gehen Sie folgendermaßen vor:

1. Markieren Sie durch einfaches Anklicken und halten der Strg-Taste die gewünschten Aktivitäten bzw. Objekte und klicken Sie auf den Kontextmenüeintrag „Verfügungen“. Für weitere Informationen bezüglich Verfügungen wechseln Sie ins Kapitel 3.3.9.3 „Verfügungen“.

2. Definieren Sie die Verfügung. Weitere Informationen dazu finden Sie in den Kapiteln 3.3.9.3.2 „Einen Termin für eine Aktivität vergeben“ und 3.3.9.3.4 „Eine Verfügung in der erweiterten Darstellung durchführen“.

3. Klicken Sie auf die Schalthäcke „Weiter“, um die Änderungen zu speichern.

Benutzerhilfe

<!-- PDF page 180 -->

Hinweis: Eine Sammelverfügung kann sowohl im „Arbeitsvorrat“ als auch am „Schreibtisch“ durchgeführt werden.

## 3.3.9.3.6 Von einer Verfügung betroffene Objekte einsehen bzw. ändern

Um die Von Verfügung betroffene Objekte einer konkreten Aktivität einzusehen bzw. abhängig von Ihren Berechtigungen auch nachträglich zu ändern, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität, von der sie die betroffenen Objekte einsehen/ändern wollen.
3. Öffnen Sie das Kontextmenü dieser Aktivität und führen Sie den Befehl „Laufweg öffnen“ aus. Dadurch öffnet sich der komplette Prozess, welcher die Aktivität enthält.
4. Lokalisieren Sie die gewünschte Aktivität im Prozesseditor (die aktuelle in ihrem Arbeitsvorrat ist dabei grau hinterlegt) und öffnen Sie das Kontextmenü der Aktivität. (Entweder über den Pfeil rechts oben oder per Rechtsklick auf das Pfeil nach unten – Symbol.

![img-11.jpeg](img-11.jpeg)

![img-12.jpeg](img-12.jpeg)

5. Wählen Sie „Bearbeiten“ im Kontextmenü. Es öffnet sich ein Formular mit den Eigenschaften der Aktivität.
6. Wechseln Sie auf die Registerkarte „Was“. Die Liste Von Verfügung betroffene Objekte kann, abhängig von ihren Berechtigungen, nun erweitert werden:

- Mithilfe einer Suche bzw. durch das Einfügen einer Verknüpfung können weitere betroffene Objekte hinzugefügt werden.
- Mithilfe des Kontextmenüeintrags „Ausschneiden“ können Objekte aus der Liste entfernt werden.

7. Speichern Sie Ihre Änderungen durch Klick auf die Schaltfläche „Speichern“ und anschließend durch einen Klick auf die Schaltfläche „Weiter“.

Benutzerhilfe
180

<!-- PDF page 181 -->

Benutzerhilfe
181

# 3.3.9.3.7 Parallele Verfügungen definieren

Durch die Definition paralleler Verfügungen über die erweiterte Darstellung (siehe Kapitel 3.3.9.3.4 „Eine Verfügung in der erweiterten Darstellung durchführen“) können Aktivitäten parallel an verschiedene Personen verfügt werden. Die betroffenen Personen erhalten die Aktivitäten gleichzeitig in ihren Arbeitsvorrat.

Um eine parallele Verfügung in der einfachen Ansicht zu definieren können Sie eine Aktivität über oder unter eine bestehenden Aktivität im grafischen Editor einfügen:

![img-13.jpeg](img-13.jpeg)

Um eine parallele Verfügung einzufügen, setzen Sie bei der Erstellung des Häkchen „Parallel“ in der erweiterten Darstellung.

![img-14.jpeg](img-14.jpeg)

<!-- PDF page 182 -->

Benutzerhilfe
182

## 3.3.9.3.8 Medienübergang

Die Bearbeitung durch einen manuellen Teilnehmer ist folgendermaßen möglich:

- Papiereingänge werden eingescannt und zum Vorgang hinzugefügt.
- E-Faxe oder E-Mails werden Mithilfe von Drag &amp; Drop in den Vorgang übernommen.
- Meta- und Protokolldaten werden erfasst.
- Unterschriften und Kenntnisnahmen werden manuell übernommen.

Die für den Medienbruch verantwortliche Person gibt den elektronischen Vorgang durch Beenden der ihr zugeordneten Aktivität „Medienübergang“ im Arbeitsvorrat frei, leitet ihn weiter oder verfügt ihn. Laufwege außerhalb der Fabasoft eGov-Suite Bayern sind im Vorgang auf der Registerkarte „Laufweg“ durch die Aktivität Medienübergang nachgewiesen.

Um Ergebnisse aus einem Medienübergang zu übernehmen, gehen Sie folgendermaßen vor:

1. Durch einen Klick auf die Aktivität „Medienübergang“ und anschließendes Wechseln in die Ansicht „Arbeitsdokumente“ können Dokumente, die außerhalb der Fabasoft eGov-Suite Bayern bearbeitet wurden, in den elektronischen Vorgang mittels Drag &amp; Drop übernommen bzw. bestehende Objekte des Vorgangs bearbeitet werden.
2. Wurde der Vorgang gesperrt, so wird dieser durch Ausführen des Arbeitsschritts Vorgang entsperren nach erfolgter Bearbeitung durch den manuellen Teilnehmer entsperrt. Der Vorgang ist dann wieder bearbeitbar.
3. Um eine manuelle Unterschrift zu erfassen, klicken Sie auf den Arbeitsschritt Manuelle Unterschriften erfassen.

- Durch das Ausführen dieses Arbeitsschritts wird ein Dialog geöffnet, in dem Sie die betroffenen Vorgänge, Dokumente oder Schriftstücke auswählen können. Markieren Sie durch einfaches Anklicken und halten der Strg-Taste die Einträge, auf die sich die manuelle Unterschrift bezieht und klicken Sie auf die Schaltfläche „Weiter“.
- Erzeugen Sie im Feld Manuelle Unterschriften einen neuen Eintrag. Siehe hierzu auch Kapitel 2.1.9 „Umgang mit Aggregaten“.
- Erfassen Sie die manuelle Unterschrift und klicken Sie auf die Schaltfläche „Weiter“.

## 3.3.9.4 Farbkombinationen bei Aktivitäten

Aktivitäten werden im Laufweg je nach Status mit einer anderen Farbe hinterlegt. Folgende Tabelle zeigt die jeweiligen Farben zu den unterschiedlichen Zuständen.

[tbl-0.md](tbl-0.md)

<!-- PDF page 183 -->

[tbl-1.md](tbl-1.md)

Benutzerhilfe
183

<!-- PDF page 184 -->

[tbl-2.md](tbl-2.md)

## 3.3.9.5 Abstrakte Teilnehmer

Bei Verfügungen oder beim Einfügen von Aktivitäten im Prozesseditor kann der jeweilige betroffene Teilnehmer auch als „Abstrakter Teilnehmer“ definiert werden. Diese werden vom System in konkrete Teilnehmer aufgelöst.

Im Glossar finden Sie eine Auflistung der in der Fabasoft eGov-Suite Bayern zur Verfügung stehenden abstrakten Teilnehmer.

Um einen abstrakten Teilnehmer als Zielperson für eine Verfügung zu definieren, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die gewünschte Aktivität und klicken Sie auf den Kontextmenüeintrag „Verfügen“.
3. Falls vorhanden, klicken Sie auf die Schaltfläche  beim Feld Teilnehmer, um weitere mögliche Felder zur Auswahl des Benutzers einzublenden.
4. Wählen Sie im Feld Abstrakter Teilnehmer den gewünschten abstrakten Teilnehmer aus, dem Sie die Aktivität verfügen wollen.
5. Tragen Sie die restlichen gewünschten Daten der Verfügung ein und klicken Sie auf „Weiter“.

## 3.3.9.6 Verteilerlisten

### 3.3.9.6.1 Eine Verteilerliste erzeugen

Um eine neue Verteilerliste zu erzeugen, gehen Sie wie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ beschrieben vor. Beachten Sie, dass Sie während der Erzeugung den Objekttyp „Verteilerliste“ auswählen. Weitere Informationen bezüglich der Metadaten der Verteilerliste können im Kapitel 6.10 „Verteilerlisten“ nachgelesen werden.

Benutzerhilfe

<!-- PDF page 185 -->

Benutzerhilfe
185

# 3.3.9.6.2 Eine Verteilerliste in einer Verfügung verwenden

Wird beim Verfügen einer Aktivität eine Verteilerliste definiert, wird die Aktivität an alle im Verteiler definierten Benutzer verfügt.

![img-0.jpeg](img-0.jpeg)

![img-1.jpeg](img-1.jpeg)

Wurde ein Verteiler ausgewählt können Sie zusätzlich entscheiden, ob die Aktivitäten parallel oder sequentiell verfügt werden.

# 3.3.9.7 Wiedervorlage

## 3.3.9.7.1 Einen Vorgang / eine Umlaufmappe auf Wiedervorlage legen

Wird ein Vorgang oder Umlaufmappe auf Wiedervorlage gesetzt, wird die Aktivität des Vorgangs oder der Umlaufmappe von der Registerkarte „Zu tun“ des Arbeitsvorrats entfernt und auf die Registerkarte „Wiedervorlage“ verschoben.

Auf Wiedervorlage-liegende Aktivitäten kann man über die Schaltfläche „Wiedervorlage“ im Arbeitsvorrat einsehen.

Sobald der angegebene Wiedervorlagetermin eintritt, wird der Vorgang mit der betroffenen Aktivität automatisch wieder auf der Registerkarte „Zu tun“ des Arbeitsvorrats angezeigt.

Um einen Vorgang oder eine Umlaufmappe auf Wiedervorlage zu legen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität, die Sie auf Wiedervorlage legen wollen.
3. Führen Sie auf der Aktivität den Kontextmenübefehl „Wiedervorlage“ aus.
4. Legen Sie durch Auswahl der jeweiligen Option im Feld Art fest, ob Sie die Aktivität zu einem bestimmten Termin, oder für eine Zeitspanne auf Wiedervorlage legen wollen.

<!-- PDF page 186 -->

Benutzerhilfe
186

Termin:

Wiedervorlage
☐ X

Geschäftsgangvermerk

Wiedervorlagefrist *
Art *
☐ Termin
☐ Zeitspanne

Datum
31.01.2020

Zeitspanne:

Wiedervorlage
☐ X

Geschäftsgangvermerk

Wiedervorlagefrist *
Art *
☐ Termin
☐ Zeitspanne

Zeitspanne
5

Einheit
Woche(n)

5. Legen Sie die Wiedervorlagefrist fest und geben Sie, wenn gewünscht, einen Geschäftsgangvermerk ein.
Folgende Felder stehen für die Definition der Wiedervorlage zur Verfügung:

<!-- PDF page 187 -->

Geschäftsgangvermerk
In diesem Feld kann eine kurze Beschreibung für die Wiedervorlage erfasst werden.

Wiedervorlagefrist
Die Wiedervorlagefrist kann als bestimmtes Datum oder als Wiederholung angegeben werden. Dieses Feld teilt sich in folgende untergegliederte Felder:

- Art
In diesem Feld kann der Eintrag „Termin“ oder der Eintrag „Zeitspanne“ ausgewählt werden. Dadurch ist es möglich eine Wiedervorlagefrist oder einen Wiedervorlagetag festzulegen.
Hinweis: Dieses Feld bestimmt, ob die Eigenschaft Datum oder die Eigenschaften Einheit und Zeitspanne angezeigt werden.

- Datum
In diesem Feld wird jenes (zukünftige) Datum angegeben, an dem die Aktivität wieder vorgelegt werden soll.
Hinweis: Sie können hier auch die Kalenderfunktion zur Auswahl eines Datums verwenden, indem Sie auf das Kalender-Symbol klicken und ein Datum auswählen.
Hinweis: Dieses Feld wird nur angezeigt, wenn im Feld Art „Termin“ ausgewählt ist.

- Einheit
In diesem Feld kann eine Zeiteinheit für die Definition einer Wiedervorlagefrist angegeben werden (Tage, Wochen oder Monate).
Hinweis: Dieses Feld wird nur angezeigt, wenn im Feld Art „Zeitspanne“ ausgewählt ist.

- Zeitspanne
In diesem Feld kann eine Zahl eingegeben werden, um eine Wiedervorlagefrist oder einen Wiedervorlagetag festzulegen.
Hinweis: Dieses Feld wird nur angezeigt, wenn im Feld Art „Zeitspanne“ ausgewählt ist.

6. Klicken Sie auf die Schaltfläche „Weiter“, um die Eingaben zu speichern.

Benutzerhilfe
187

<!-- PDF page 188 -->

Benutzerhilfe
188

# 3.3.9.7.2 Eine auf Wiedervorlage gelegte Aktivität anzeigen

Auf Wiedervorlage-liegende Aktivitäten können Sie über die Schaltfläche „Wiedervorlage“ im Arbeitsvorrat einsehen.

## Arbeitsvorrat
Arbeitsvorrat - Kainz, Regina

- ☐ Wiedervorlage (4)
- ☐ Aktualisieren
- ☐ Vorgang erzeugen
- ☐ Umlaufmappe erzeugen
- ☐ Kopieren
- ☐ Link
- ☐ Zeitreise

# 3.3.9.7.3 Wiedervorlage aufheben

Auf Wiedervorlage gelegte Aktivitäten können entweder automatisch nach Ablauf der eingetragenen Frist oder manuell aktiviert werden. Die betroffene Aktivität wird dann automatisch von der Registerkarte „Wiedervorlage“ entfernt und auf die Registerkarte „Zu tun“ verschoben.

Um eine Wiederauflage manuell aufzuheben, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Öffnen Sie die auf Wiedervorlage gelegten Aktivitäten. (Siehe Kapitel 3.3.9.7.2 „Eine auf Wiedervorlage gelegte Aktivität anzeigen“).

<!-- PDF page 189 -->

3. Lokalisieren Sie die entsprechende Aktivität und führen Sie den Kontextmenübefehl „Aktivieren“ aus.

![img-2.jpeg](img-2.jpeg)

Hinweis: Achten Sie beim Öffnen des Kontextmenüs darauf, dass Sie sich über dem Namen des zu aktivierenden Objekts befinden, da Ihnen sonst ein anderes oder gar kein Kontextmenü angezeigt wird.

Benutzerhilfe
189

<!-- PDF page 190 -->

Benutzerhilfe

# 3.3.9.8 Die 3-geteilte Ansicht

Wird ein Linksklick auf eine Aktivität im Arbeitsvorrat ausgeführt, wird die 3-geteilte-Ansicht geöffnet:

![img-3.jpeg](img-3.jpeg)

Diese Ansicht bietet unter anderem die Möglichkeit, die Arbeitsschritte der Aktivität auszuführen oder Befehle aus dem Kontextmenü von Aktivitäten auszuführen (Bspw. „Beginnen“, „Verfügen“, „Wiedervorlage“, „Abschließen“, „Abgeben“, „Laufweg öffnen“), Standardmäßig befindet man sich in der Ansicht „Kurzinfo“, welche ausgewählte Eigenschaften über die Aktivität im rechten Teil der 3-geteilten-Sicht darstellt.

Zusätzlich stehen noch folgende 3 Schaltflächen zur Verfügung:

- Als Standarddarstellung verwenden:
Als Standarddarstellung verwenden" kann die aktuelle Ansicht für alle Objekte dieser Klasse, oder für alle Objekte gespeichert werden.

- „Ansicht „Übersicht“:
Anstelle der Kurzinformationen der Aktivität (rechts) wird nun eine PDF-Übersicht der Inhalte angezeigt.

- Ansicht „Inhalte“:
Anstelle der Kurzinformationen der Aktivität (rechts) wird nun die Objektlist des Prozessobjekts (Des Vorgangs oder der Umlaufmappe) angezeigt.

190

<!-- PDF page 191 -->

Hinweis: Abhängig davon, in welcher Ansicht man sich befindet (Kurzinfo, Übersicht, Inhalt) wird jeweils der Wechsel in die beiden anderen Ansichten angeboten.

## 3.3.10 Behandlung von Umlaufmappen

### Überblick Umlaufmappe

- Eine Umlaufmappe kann direkt in einem Vorgang oder im Arbeitsvorrat erzeugt werden. Umlaufmappen sind immer einem Vorgang zugeordnet.
- Erstellen einer Umlaufmappe im Vorgang: Rechtsklick auf Vorgang → „In neuem Fenster öffnen“ klicken → Schaltfläche „Neue Umlaufmappe“
- Erstellen einer Umlaufmappe im Arbeitsvorrat: Schaltfläche „Umlaufmappe erzeugen“
- Umlaufmappen ermöglichen:
- Mitzeichnungsverfahren
- Schlusszeichnungsverfahren
- Billigungsverfahren
- Kenntnisnahmen

## 3.3.10.1 Eine Umlaufmappe erzeugen

Um eine Umlaufmappe in einem Vorgang zu erstellen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang und klicken Sie auf den Kontextmenüeintrag „In neuem Fenster öffnen“.
2. Klicken Sie auf die Schaltfläche „Neue Umlaufmappe:

![img-4.jpeg](img-4.jpeg)

Benutzerhilfe
191

<!-- PDF page 192 -->

Hinweis: Umlaufmappen bekommen beim Erzeugen die Zugriffsdefinition bzw. ACL vom übergeordneten Vorgang vergeben. Beim Umregistrieren vom Vorgang erfolgt ggf. auch eine Anpassung der Zugriffsdefinition bzw. ACL.

Um eine Umlaufmappe im Arbeitsvorrat zu erstellen gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren Arbeitsvorrat.
2. Klicken Sie auf die Schaltfläche „Umlaufmappe“ erzeugen.

![img-5.jpeg](img-5.jpeg)

## 3.3.10.2 Aktivitäten einer Umlaufmappe

Auf der Umlaufmappe stehen folgende Aktivitäten zur Verfügung:

- Aufgabe
- Starten (automatische Aktivität, kann nicht manuell vorgeschrieben werden)
- Überarbeiten (automatische Aktivität, kann nicht manuell vorgeschrieben werden)
- Prüfen (automatische Aktivität, kann nicht manuell vorgeschrieben werden)
- Reinschrift erstellen
- Versenden
- Zur Billigung
- Zur Kenntnisnahme
- Zur Kenntnisnahme (hemmend)
- Zur Mitzeichnung
- Zur Schlusszeichnung
- Abschließen

Nähere Informationen zu den Aktivitäten finden Sie im Kapitel 7 Aktivitäten.

Hinweis: Umlaufmappen können nur einen Prozess besitzen.

Benutzerhilfe

<!-- PDF page 193 -->

Hinweis: Die Funktion „Weiterleiten“ wird im Kontextmenü von Aktivitäten von Umlaufmappen nicht angezeigt.

## 3.3.10.3 Zeichnungsverfahren

Der zur Zeichnung beauftragende Benutzer legt die zu zeichnenden Dokumente in die Umlaufmappe und verfügt die Umlaufmappe zum Zeichnungsberechtigten.

Für den Benutzer, der die Zeichnung durchführen soll, bestehen mehrere Möglichkeiten für das weitere Vorgehen:

- Das Dokument kann zur Bearbeitung geöffnet werden.
- Das Dokument kann in der PDF-Ansicht geöffnet werden.
- Zeichnungen können nicht abgewiesen bzw. zurückgewiesen werden.
- Die Zeichnung kann durchgeführt werden.

Wenn eine Zeichnung ausgeführt wurde, erhält der Prozessverantwortliche automatisch die Aktivität Prüfen vorgeschrieben. Diese erfordert keine Folgeaktivität. Ein Geschäftsgangvermerk (= Zeichnungen prüfen (Automatische Aktivität)) ist hinterlegt. Wenn eine Zeichnung (Billigung oder Schlusszeichnen) abgelehnt wurde, erhält der Prozessverantwortliche automatisch die Aktivität Überarbeiten mit dem Geschäftsgangvermerk „Zeichnung abgelehnt (Automatische Aktivität)“ vorgeschrieben.

Hinweis: Wenn der Prozessverantwortliche selbst die Zeichnung ausführt, wird keine automatische Nachfolgeaktivität eingefügt.

## 3.3.10.3.1 Mitzeichnungsverfahren

Ein Mitzeichnungsverfahren kann durch die Bearbeitung des Laufwegs oder über eine Verfügung eingeleitet werden. Die betroffenen Benutzer können nach der Prüfung des Sachverhalts eine Notiz erstellen, eine Mitzeichnung durchführen oder die Mitzeichnung ablehnen. Wird die Mitzeichnung abgelehnt, erhält der nachfolgende Benutzer in der Verfügungskette den Vorgang mit der entsprechenden Aktivität.

## 3.3.10.3.1.1 Ein Mitzeichnungsverfahren einleiten

Eine Mitzeichnung kann auf mehrere Arten durchgeführt werden:

- Durch den Kontextmenübefehl „Verfügungen“.
- Durch die direkte Bearbeitung des Laufwegs mit dem Laufweg-Editor.

Um ein Mitzeichnungsverfahren über den Kontextmenübefehl „Verfügungen“ einzuleiten, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“ und lokalisieren Sie die entsprechende Aktivität.
2. Wählen Sie im Kontextmenü der jeweiligen Aktivität den Eintrag „Verfügungen“, die Verfügungsart Zur Mitzeichnung und geben Sie die weiteren Metadaten ein. Klicken Sie auf „Weiter“.

Um ein Mitzeichnungsverfahren direkt über den Laufweg-Editor einzuleiten, gehen Sie folgendermaßen vor:

Benutzerhilfe
193

<!-- PDF page 194 -->

3. Wechseln Sie in Ihren „Arbeitsvorrat" und lokalisieren Sie die entsprechende Aktivität.
4. Klicken Sie auf den Kontextmenüeintrag „Laufweg öffnen", um den grafischen Editor für den Laufweg anzuzeigen.
5. Fügen eine neue Aktivität des Typs Zur Mitzeichnung hinzu. (Weitere Informationen hierzu finden Sie im Kapitel 3.3.9.3 „Verfügungen")

## 3.3.10.3.1.2 Mitzeichnung

Eine Erledigung einer Umlaufmappe kann mitgezeichnet werden, indem Sie die Unterschrift „Mitzeichnung" anbringen. Bei der Aktivität Zur Mitzeichnung steht dazu ein eigener Arbeitsschritt Mitzeichnung zur Verfügung.

Um eine Erledigung einer Umlaufmappe mitzuzeichnen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat".
2. Lokalisieren Sie die Aktivität Zur Mitzeichnung, bei der Sie die Zeichnung anbringen wollen.
3. Klicken Sie auf den Arbeitsschritt Mitzeichnung der Aktivität Zur Mitzeichnung.
4. Über die Schaltfläche „Zeichnen" können Sie die Zeichnung durchführen.

## 3.3.10.3.1.3 Eine Mitzeichnung ablehnen

Erhalten Sie eine Umlaufmappe mit der Aktivität Zur Mitzeichnung in Ihren Arbeitsvorrat, können Sie die Mitzeichnung auch ablehnen.

Um eine Mitzeichnung abzulehnen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat".
2. Lokalisieren Sie die entsprechende Aktivität Zur Mitzeichnung.
3. Klicken Sie auf den Arbeitsschritt Mitzeichnung ablehnen.
4. Klicken Sie auf die Schaltfläche „Zeichnen", um die Zeichnung abzulehnen.

## 3.3.10.3.2 Schlusszeichnungsverfahren

### 3.3.10.3.2.1 Ein Schlusszeichnungsverfahren einleiten

Eine Schlusszeichnung kann auf mehrere Arten durchgeführt werden:

- Durch den Kontextmenübefehl „Verfügungen".
- Durch die direkte Bearbeitung des Laufwegs mit dem Laufweg-Editor.

Um ein Schlusszeichnungsverfahren über den Kontextmenübefehl „Verfügungen" einzuleiten, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat" und lokalisieren Sie die entsprechende Aktivität.
2. Wählen Sie im Kontextmenü den Eintrag „Verfügungen", die Verfügungsart Zur Schlusszeichnung und geben Sie die weiteren Metadaten ein. Klicken Sie auf „Weiter".

Um ein Schlusszeichnungsverfahren direkt über den Laufweg-Editor einzuleiten, gehen Sie folgendermaßen vor:

Benutzerhilfe
194

<!-- PDF page 195 -->

1. Wechseln Sie in Ihren „Arbeitsvorrat" und lokalisieren Sie die entsprechende Aktivität.
2. Klicken Sie auf den Kontextmenüeintrag „Laufweg öffnen", um den grafischen Editor für den Laufweg anzuzeigen.
3. Fügen eine neue Aktivität des Typs Zur Schlusszeichnung hinzu. (Weitere Informationen zum grafischen Editor finden Sie im Kapitel 3.3.9.3 „Verfügungen")

## 3.3.10.3.2.2 Schlusszeichnung

Eine Umlaufmappe kann Schlussgezeichnet werden, indem Sie die Unterschrift „Schlusszeichnung" anbringen. Bei der Aktivität Zur Schlusszeichnung steht dazu ein eigener Arbeitsschritt zur Verfügung.

Um eine Erledigung einer Umlaufmappe Schlusszuziechen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat".
2. Lokalisieren Sie die Aktivität Zur Schlusszeichnung.
3. Klicken Sie auf den Arbeitsschritt Schlusszeichnung der Aktivität Zur Schlusszeichnung.
4. Klicken Sie auf die Schaltfläche „Zeichnen".

## 3.3.10.3.2.3 Eine Schlusszeichnung ablehnen

Um eine Schlusszeichnung abzulehnen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat" und lokalisieren Sie die gewünschte Aktivität Zur Schlusszeichnung.
2. Klicken Sie auf den Arbeitsschritt Schlusszeichnung ablehnen.
3. Klicken Sie auf die Schaltfläche „Zeichnen".

## 3.3.10.3.3 Billigungsverfahren

### 3.3.10.3.3.1 Ein Billigungsverfahren einleiten

Eine Billigung kann auf mehrere Arten durchgeführt werden:

- Durch den Kontextmenübefehl „Verfügungen".
- Durch die direkte Bearbeitung des Laufwegs mit dem Laufweg-Editor.

Um ein Billigungsverfahren über den Kontextmenübefehl „Verfügungen" einzuleiten, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat" und lokalisieren Sie die entsprechende Aktivität.
2. Wählen Sie im Kontextmenü den Eintrag „Verfügungen", die Verfügungsart Zur Billigung und geben Sie die weiteren Metadaten ein. Klicken Sie auf „Weiter".

Um ein Billigungsverfahren direkt über den Laufweg-Editor einzuleiten, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat" und lokalisieren Sie die entsprechende Aktivität.
2. Klicken Sie auf den Kontextmenüeintrag „Laufweg öffnen", um den grafischen Editor für den Laufweg anzuzeigen.

Benutzerhilfe
195

<!-- PDF page 196 -->

3. Fügen eine neue Aktivität des Typs Zur Billigung hinzu. (Weitere Informationen zum grafischen Editor finden sie im Kapitel 3.3.9.3 „Verfügungen“)

## 3.3.10.3.3.2 Billigung

Eine Erledigung einer Umlaufmappe kann gebilligt werden, indem Sie die Unterschrift „Billigung“ anbringen. Bei der Aktivität Zur Billigung steht Ihnen hierfür ein eigener Arbeitsschritt zur Verfügung.

Um eine Erledigung einer Umlaufmappe zu billigen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität, bei der die entsprechende Umlaufmappe in der Spalte Gehört zu angezeigt wird.
3. Klicken Sie auf den Arbeitsschritt Billigung zeichnen der Aktivität Zur Billigung.
4. Klicken Sie auf die Schaltfläche „Zeichnen“.

## 3.3.10.3.3.3 Eine Billigung ablehnen

Um die Billigung einer Erledigung einer Umlaufmappe abzulehnen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität, bei der die entsprechende Umlaufmappe in der Spalte Gehört zu angezeigt wird.
3. Klicken Sie auf den Arbeitsschritt Billigung ablehnen der Aktivität Zur Billigung.
4. Klicken Sie auf die Schaltfläche „Zeichnen“.

## 3.3.10.3.4 Die Aktivität „Kenntnisnahme“ bzw. „Kenntnisnahme (hemmend)“

Um anderen Benutzern den Sachverhalt eines Vorgangs bzw. einer Umlaufmappe zur Kenntnis zu bringen, können Sie über die Bearbeitung des Laufwegs oder über eine Verfügung eine Aktivität Kenntnisnahme bzw. Kenntnisnahme (hemmend) in den Laufweg einfügen. Die betroffenen Benutzer können nach der Prüfung des Sachverhalts eine Notiz hinterlassen und die Einsicht mit dem Arbeitsschritt Kenntnisnahme zeichnen bestätigen.

**Hinweis:** Erhält eine Person die Aktivität Zur Kenntnisnahme zugewiesen, so wird der Laufweg gleichzeitig mit der nachfolgenden Aktivität fortgesetzt.

**Hinweis:** Erhält eine Person die Aktivität Zur Kenntnisnahme (hemmend) zugewiesen, so wird der Laufweg wie bei allen anderen Aktivitäten erst nach dem Abschluss dieser Aktivität mit der nachfolgenden Aktivität fortgesetzt.

**Hinweis:** Nähere Informationen zur Bearbeitung des Laufwegs finden Sie im Kapitel 3.3.9.2 „Den Laufweg direkt bearbeiten“.

Um einen Vorgang bzw. eine Umlaufmappe zur Kenntnisnahme zu verfügen, führen Sie eine Verfügung mit der Aktivität Kenntnisnahme bzw. Kenntnisnahme (hemmend) an die gewünschten Benutzer durch. Die Kenntnisnahme wird mit einer Unterschrift gezeichnet und ist unter der

Benutzerhilfe
196

<!-- PDF page 197 -->

Registerkarte „Zeichnungen“ des Vorgangs ersichtlich. Weitere Informationen zur Durchführung einer Verfügung finden Sie im Kapitel 3.3.9.3 „Verfügungen“.

## 3.3.10.4 Versand von Umlaufmappen

### 3.3.10.4.1 Eine Reinschrift erzeugen

Vor dem Versand von Erledigungen oder Umlaufmappen muss eine Reinschrift erzeugt werden. Das Erstellen der Reinschrift vor dem Versand bietet die Möglichkeit, die zu versendenden Schriftstücke vor dem Versand zu kontrollieren.

**Hinweis:** Werden eine Erledigung bzw. eine Umlaufmappe versandt, wird die Reinschrift automatisch erstellt, sollte diese noch nicht existieren.

Für weitere Informationen zur Erstellung einer Reinschrift siehe Kapitel 3.4.5 „Reinschriften“.

### 3.3.10.4.2 Erzeugte Reinschriften anzeigen

Um erstelle Reinschriften anzuzeigen, gehen Sie wie folgt vor:

1. Lokalisieren Sie die Erledigung, deren Reinschrift angezeigt werden soll. (Über eine Suche oder im Aktenplan)
2. Öffnen Sie die Erledigung durch einen Klick auf diese.
3. Klicken Sie auf die Schaltfläche „Reinschriften“:

![img-6.jpeg](img-6.jpeg)

### 3.3.10.4.3 Erledigungen bzw. Umlaufmappen versenden

Für den Versand einer oder mehrerer Erledigungen oder Dokumente steht innerhalb einer Aktivität Versenden ein eigener Arbeitsschritt Versand durchführen zur Verfügung.

**Hinweis:** Die jeweilige Versandart für einen Empfänger wird im Zuge der Erstellung der Erledigung bzw. bei der Bearbeitung der Metadaten festgelegt. Nähere Informationen finden Sie im Kapitel 6.6 „Erledigung“.

Um eine Umlaufmappe zu versenden, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“ und lokalisieren Sie die gewünschte Aktivität Versenden.
2. Klicken Sie auf den Arbeitsschritt Versand durchführen der Aktivität Versenden. Die Erledigung wird finalisiert und an die Empfänger entsprechend der im Feld Empfänger angegebenen Versandart versendet.

Benutzerhilfe

<!-- PDF page 198 -->

Hinweis: Ist noch keine Reinschrift erstellt worden, wird diese im Zuge des Versendens erstellt.

3. Warten Sie bis die Reinschrift erzeugt wurde. Nach der Erzeugung wird ein Ergebnis mit eventuell auftretenden Fehlermeldungen (z.B. dass keine Versandart definiert wurde) angezeigt.
4. Beenden Sie die Aktivität durch den Arbeitsschritt Versand zeichnen.

Hinweis: Der Versand kann auch über das Kontextmenü der jeweiligen Erledigung durchgeführt werden.

## 3.3.10.5 Ein Dokument zur Umlaufmappe hinzufügen

Ein Dokument kann innerhalb einer Vorgangshierarchie mittels der Kontextmenü Aktion „Zu Umlaufmappe hinzufügen“ in die Arbeitsdokumente einer Umlaufmappe eingefügt werden. Es ist auch möglich über die Funktion eine neue Umlaufmappe zu erstellen. Das aktuelle Dokument wird dann in die Arbeitsdokumente der neuen Umlaufmappe eingefügt.

Um ein Dokument innerhalb einer Vorgangshierarchie zu einer Umlaufmappe hinzuzufügen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in die gewünschte Vorgangshierarchie und selektieren Sie ein Dokument.
2. Öffnen Sie das Kontextmenü und betätigen Sie das Menü „Zu Umlaufmappe hinzufügen“. Es erscheint der Dialog „Zu Umlaufmappe hinzufügen“:

![img-7.jpeg](img-7.jpeg)

3. Wählen Sie die gewünschte Umlaufmappe aus oder erzeugen Sie eine neue Umlaufmappe über die Schaltfläche „Neue Umlaufmappe erzeugen“.

## Ergebnis:

- Bestehende Umlaufmappe wurde ausgewählt: Das Dokument wird in die Arbeitsdokumente der ausgewählten Umlaufmappe eingefügt.
- „Neue Umlaufmappe erzeugen“ wurde ausgewählt: Es öffnet sich das Erzeugen Formular der Umlaufmappe und das Dokument ist in der Liste „Arbeitsdokumente“ vorhanden.

Benutzerhilfe
198

<!-- PDF page 199 -->

Benutzerhilfe
199

# 3.3.10.6 Eine Umlaufmappe duplizieren

Beim Duplizieren einer Umlaufmappe werden keine Eigenschaften übernommen. Insbesondere werden KEINE Dokumente/Schriftstücke übernommen.

# 3.3.10.7 Weitere Informationen zur Umlaufmappe

- Die Umlaufmappe wird auch beim „PDF exportieren“, der Mindbreeze Suche und dem „Management Center“ berücksichtigt.
- Objekte können mittels Copy/Paste zwischen der Liste „Arbeitsdokumente“ und „Ergänzende Liste“ verschoben werden.
- Umlaufmappen können storniert werden. Sie landen dabei auch in der Liste der „Stornierten Objekte“ des übergeordneten Vorgangs.

# 3.4 Behandlung von Erledigungen

[tbl-3.md](tbl-3.md)

# 3.4.1 Eine Erledigung erstellen

Eine Erledigung kann auf mehrere Arten erstellt werden:

- In einem Vorgang
- über den Kontextmenübefehl „Antworten“ eines Eingangsdokuments
- über den Kontextmenübefehl „Verwalten“ → „Ändern zu Erledigung“ eines Eingangsdokuments

Um eine Erledigung in einem Vorgang zu erstellen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang und klicken Sie auf den Kontextmenüeintrag „In neuem Fenster öffnen“.
2. Wechseln Sie auf die Registerkarte „Dokumente“, falls Sie sich auf einer anderen Registerkarte befinden.
3. Fügen Sie ein neues Objekt in die Objektliste ein. Die genaue Anleitung dazu finden Sie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen“, wobei Sie als Objekttyp „Erledigung“ auswählen müssen.

<!-- PDF page 200 -->

Benutzerhilfe

# 3.4.1.1 Eine Erledigung über den Kontextmenübefehl „Antworten“ erstellen

Soll auf ein Eingangsdokument auf einfache Weise geantwortet werden, so kann im Kontextmenü des Eingangsdokuments mit dem Menüpunkt „Antworten“ eine neue Erledigung mit den Adressaten und dem Betreff des Eingangsdokuments erzeugt werden.

Um auf ein Eingangsdokument zu antworten, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Eingangsdokument, auf das Sie antworten möchten.
2. Führen Sie den Kontextmenübefehl „Antworten“ aus.
3. Geben Sie die Metadaten ein und klicken Sie auf die Schaltfläche „Weiter“. Weitere Informationen zu den Metadaten einer Erledigung finden Sie im Kapitel 6.6 „Erledigung“.

**Hinweis:** Es ist nicht möglich, auf ein Eingangsdokument zu antworten, wenn

- das Eingangsdokument keinem Vorgang zugewiesen ist,
- der betreffende Vorgang bearbeitend geöffnet ist oder
- Ihre Benutzerrechte zur Bearbeitung der Dokumentenliste des Vorgangs nicht ausreichen.

# 3.4.1.2 Eine Erledigung über den Kontextmenübefehl „Ändern zu Erledigung“ erstellen

Wenn ein Eingangsdokument zu einer Erledigung umgewandelt werden soll (ein Objektklassenwechsel durchgeführt werden soll), so können Sie dies über den Kontextmenübefehl „Verwalten“ → „Ändern zu Erledigung“. Gehen Sie hierzu folgendermaßen vor:

1. Lokalisieren Sie das Eingangsdokument, welches in eine Erledigung umgewandelt werden soll.
2. Öffnen Sie das Kontextmenü und führen Sie den Menüpunkt „Verwalten“ und anschließend „Ändern zu Erledigung“ aus.

**Hinweis:** Folgende Voraussetzungen müssen erfüllt sein, um ein Eingangsdokument in eine Erledigung umwandeln zu können:

- Sie müssen das Recht besitzen das Eingangsdokument zu bearbeiten.
- Das Eingangsdokument muss einem Vorgang zugeordnet sein.
- Es dürfen keine aktiven oder auf Wiedervorlage liegende Aktivitäten für das Eingangsdokument existieren.
- Der Status des Eingangsdokuments muss in Bearbeitung oder Abgeschlossen sein.
- Der Bearbeitungsstatus des Eingangsdokuments muss einen der folgenden Werte enthalten:

- Erstellt
- Mitzeichnung abgelehnt
- Schlusszeichnung
- Schlusszeichnung abgelehnt
- z.A. verfügt

200

<!-- PDF page 201 -->

Benutzerhilfe

# 3.4.2 Geschäftszeichenbildung einer Erledigung

Das Geschäftszeichen einer Erledigung bildet sich aus den folgenden Attributen:

- Der zuständigen Organisationseinheit
- Dem Geschäftszeichen des Vorgangs
- Einer fortlaufenden Nummer

Das Geschäftszeichen kann über folgende Möglichkeiten geändert werden:

- Das Feld Zuständige Organisationseinheit wird geändert,
- die Erledigung wird einem anderen Vorgang oder
- der Vorgang zu einer anderen Akte umgeschrieben.

## Ändern des Geschäftszeichens mittels Änderung der zuständigen Organisationseinheit

1. Öffnen Sie die Eigenschaften der Erledigung im Bearbeitungsmodus.
2. Wählen Sie in dem Feld Zuständige Organisationseinheit die gewünschte Organisationseinheit.
**Hinweis:** Sie können in diesem Feld auch eine Suche durchführen.
3. Verwenden Sie die Schaltfläche „Weiter“, um Ihre Änderungen zu speichern.

## Änderung des Geschäftszeichens mittels Umschreibung

Um das Geschäftszeichen einer Erledigung mittels einer Umschreibung zu ändern, bringen Sie die Unterschrift „Umschreibung“ auf das Eingangsdokument oder den Vorgang, wie im Kapitel 3.3.4 „Einen Vorgang umschreiben“ bzw. Kapitel 2.11 „Unterschreiben“ beschrieben, an.

# 3.4.3 Einen Empfänger einer Erledigung definieren

Im Feld Adressaten in den Metadaten einer Erledigung werden die Empfänger angegeben, an die die Reinschrift der Erledigung versandt werden soll. Für weitere Informationen bezüglich der Bearbeitung eines Aggregats wechseln Sie ins Kapitel 2.1.9 „Umgang mit Aggregaten“.

Um einen neuen Empfänger einer Erledigung zu definieren gehen Sie wie folgt vor:

1. Lokalisieren Sie die Erledigung, welcher Sie Empfänger hinzufügen möchten.
2. Öffnen Sie die Eigenschaften der Erledigung über die Kontextmenüaktion „Eigenschaften“.
3. Wechseln Sie auf die Registerkarte „Adressaten“.
4. Klicken Sie auf „Bearbeiten“, sofern die Eigenschaften lesend geöffnet wurden.
5. Fügen Sie über die Schaltfläche „Eintrag hinzufügen“ neue Empfänger im Aggregat „Adressaten“ hinzu. (siehe auch Kapitel 2.1.9 „Umgang mit Aggregaten)

201

<!-- PDF page 202 -->

Benutzerhilfe
202

# Adressaten

[tbl-0.md](tbl-0.md)
[tbl-1.md](tbl-1.md)

6. Wählen Sie im nun geöffneten Formular eine Kategorie, eine Versandart sowie den entsprechenden Adressaten sowie optional weitere Eigenschaften.
Als Adressat können Sie Verteiler, Organisationen oder Personen definieren:

![img-0.jpeg](img-0.jpeg)

<!-- PDF page 203 -->

Hinweis: Für weitere Informationen zu den zur Verfügung stehenden Versandarten siehe Kapitel 3.3.10.4.3 „Erledigungen bzw. Umlaufmappen versenden“).

Hinweis: Standardmäßig ist die Kategorie „Empfänger“ vordefiniert.

7. Speichern Sie die Änderungen durch einen Klick auf die Schaltfläche „Weiter“.

## 3.4.3.1 Freitextadressaten in einer Erledigung erfassen

Adressaten können nicht nur mithilfe der Drop-down-Liste in Eigenschaft Adressat definiert werden, sie können auch als Freitext angegeben werden.

Um einen Freitextadressaten zu definieren gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Erledigung, welche den Freitextadressaten erhalten soll.
2. Öffnen Sie die Metadaten der Erledigung in der Bearbeitungsansicht.
3. Fügen Sie über die Schaltfläche „Eintrag hinzufügen“ einen neuen Empfänger im Aggregat „Adressaten“ hinzu. (siehe auch Kapitel 2.1.9 „Umgang mit Aggregaten“)
4. Erfassen Sie die Daten des Freitextadressaten.
5. Speichern Sie die Änderungen am Adressaten durch Klick auf die Schaltfläche „Weiter“.
6. Beenden Sie die Bearbeitungsansicht der Erledigung durch Klick auf die Schaltfläche „Weiter“.

## 3.4.3.2 Personen/Organisationen aus den Werten der Freitextfelder erzeugen

In der erweiterten Ansicht des Adressatenaggregats kann mittels der Schaltfläche Person/Organisation erzeugen aus den ausgefüllten Freitextfeldern eine Person/Organisation erzeugt werden.

Um eine Person/Organisation aus den Werten der Freitextfelder zu erzeugen gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Erledigung, welche den Freitextadressaten erhalten soll.
2. Öffnen Sie die Metadaten der Erledigung in der Bearbeitungsansicht.
3. Wechseln Sie zur Registerkarte „Adressaten“.
4. Fügen Sie im Feld Adressaten eine neue Zeile hinzu und öffnen Sie diese in der Detailansicht. Siehe hierzu auch Kapitel 2.1.9 „Umgang mit Aggregaten“.
5. Erfassen Sie die Daten des Freitextadressaten.
6. Speichern Sie die Änderungen durch Klick auf die Schaltfläche „Weiter“. Sie gelangen aus der Detailansicht des Empfängers zurück in die Bearbeitungsansicht der Erledigung.
7. Markieren Sie die betroffene(n) Zeile(n) und betätigen Sie die Schaltfläche „Person/Organisation erzeugen“.

Hinweis: Sollte nichts markiert oder bereits ein Empfänger eingetragen sein, erscheint eine Fehlermeldung.

Benutzerhilfe
203

<!-- PDF page 204 -->

Benutzerhilfe
204

# Adressaten

[tbl-2.md](tbl-2.md)

8. Wählen Sie die gewünschte Zielobjektklasse aus.

Person/Organisation erzeugen

Was wollen Sie erzeugen?

[tbl-3.md](tbl-3.md)

9. Wählen Sie den Kontaktraum aus, in welchem die Person bzw. die Organisationen erstellt werden soll:

Kontaktraum zuweisen

Kontaktraum *

10. Klick auf „Weiter".
Hinweis „An dieser Stelle wird eine Dublettenprüfung durchgeführt. (Siehe auch Kapitel 2.1.1.1.1 Dublettenprüfung)

# Ergebnis:

- „Person“ wurde ausgewählt: Es wird ein Personenobjekt erzeugt. Ggf. erscheint eine Hinweismeldung, dass noch Felder manuell nachzutragen sind.

<!-- PDF page 205 -->

- „Organisation“ wurde ausgewählt: Es wird ein Organisationsobjekt erzeugt. Ggf. erscheint eine Hinweismeldung, dass noch Felder manuell nachzutragen sind.
- „Person und Organisationen“ wurde ausgewählt: Es wird eine Organisation und ein Personenobjekt erzeugt. Die Organisation ist der Empfänger und die Person wird automatisch in die Eigenschaft Personen der Organisation eingetragen. Ggf. erscheint eine Hinweismeldung, dass noch Felder manuell nachzutragen sind.

## 3.4.3.3 Verwalten von Adressaten

Sie haben die Möglichkeit, Metadaten mehrerer Adressaten einer Erledigung gemeinsam zu bearbeiten. Hierfür steht in der Aggregatsliste Adressaten der Erledigung die Schaltfläche „Gemeinsam bearbeiten“ zur Verfügung.

Um mehrere Adressaten gleichzeitig zu bearbeiten gehen Sie wie folgt vor:

1. Lokalisieren Sie die Erledigung, deren Adressaten verwaltet werden sollen und öffnen Sie die Metadaten bearbeitend.
2. Markieren Sie alle Adressaten, für die Sie die Metadaten (z.B. die Versandart) bearbeiten möchten.

**Hinweis:** Wenn alle Empfänger der Erledigung geändert werden sollen, kann dieser Schritt übersprungen werden.

3. Klicken Sie auf die Schaltfläche „Gemeinsam bearbeiten“.

## Adressaten

![img-1.jpeg](img-1.jpeg)

4. Setzen Sie in dem angezeigten Dialog die Metadaten, die für alle Empfänger gesetzt werden sollen.

**Hinweis:** Sollten alle Empfänger bereits gemeinsame Metadaten haben, werden diese in dem Dialog angezeigt.

5. Klicken Sie auf die Schaltfläche „Weiter“, um die Änderungen zu bestätigen und den Dialog zu schließen.
6. Klicken Sie auf die Schaltfläche „Weiter“, um die Änderungen zu speichern und die bearbeitende Ansicht der Erledigung zu verlassen.

**Ergebnis:** Bei allen (markierten) Empfängern wurde der von Ihnen angegebene Wert eingetragen.

Benutzerhilfe
205

<!-- PDF page 206 -->

Benutzerhilfe
206

# 3.4.3.4 Import und Export von CSV-Dateien

Es besteht die Möglichkeit, die Adressaten einer Erledigung in Form einer CSV-Datei zu importieren oder auch eine bestehende Liste an Adressaten zu exportieren.

## Adressaten

[tbl-4.md](tbl-4.md)
[tbl-5.md](tbl-5.md)

Um eine CSV-Datei zu exportieren, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Erledigung, deren Empfänger in Form einer CSV-Datei exportiert werden sollen.
2. Öffnen Sie die Metadaten der Erledigung.
3. Wechseln Sie zur Registerkarte „Adressaten".
4. Klicken Sie auf die Schaltfläche „CSV-Export" im Adressaten-Aggregat und speichern Sie die Datei in Ihrem Lokalen Dateisystem.

**Ergebnis:** Die Liste der Adressaten der Erledigung wird als CSV-Datei in Ihrem lokalen Dateisystem gespeichert und kann z.B. mittels Microsoft Office Excel eingesehen werden.

Um eine CSV-Datei zu importieren, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Erledigung, deren Empfänger über den Import einer CSV-Datei definiert werden sollen.
2. Öffnen Sie die Metadaten der Erledigung.
3. Wechseln Sie auf die Registerkarte „Adressen".
4. Klicken Sie auf die Schaltfläche „CSV-Import" des Adressaten-Aggregats.
5. Wählen Sie eine CSV-Datei (in Form eines Microsoft Excel-Arbeitsblatts) innerhalb der Fabasoft eGov-Suite Bayern aus oder importieren Sie eine neue CSV-Datei über die Schaltfläche „Importieren".

**Ergebnis:** Die Adressaten aus der importierten CSV-Datei werden in der Liste der Adressaten der Erledigung eingefügt.

**Hinweis:** Sollten für die Erledigung bereits Empfänger definiert sein, werden diese ergänzt und nicht überschrieben.

<!-- PDF page 207 -->

Benutzerhilfe

# 3.4.4 Einen Dokumenttyp für eine Erledigung auswählen

In den Metadaten einer Erledigung kann ein Dokumenttyp für das Erstellen des Inhalts der Erledigung definiert werden.

Um einen Dokumenttypen in den Metadaten eines Dokuments auszuwählen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das gewünschte Dokument und führen Sie den Kontextmenübefehl „Eigenschaften bearbeiten“ aus.
2. Wählen Sie im Feld **Dokumenttyp** den gewünschten Dokumenttyp aus.

**Hinweis:** Wenn Sie keinen Eintrag zur Auswahl haben, haben Sie die Möglichkeit, danach zu suchen. Weitere Informationen dazu finden Sie im Kapitel 2.12 „Suche“.

**Hinweis:** Weitere Informationen zu den Metadaten einer Erledigung finden Sie im Kapitel 6.6 „Erledigung“.

**Hinweis:** Der zuletzt gewählte Dokumenttyp wird gespeichert und wird beim Erzeugen einer neuen Erledigung automatisch vorinitialisiert.

# 3.4.5 Reinschriften

## 3.4.5.1 Eine Reinschrift erstellen

Zum Erstellen einer Reinschrift einer Erledigung stehen folgende Möglichkeiten zur Verfügung:

- Erstellung über die Aktivität **Reinschrift erstellen**.
- Erstellung über den Kontextmenübefehl „Reinschrift“.

Um eine Reinschrift mithilfe der Aktivität **Reinschrift erstellen** zu erstellen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“ und lokalisieren Sie die gewünschte Aktivität **Reinschrift erstellen**.
2. Klicken Sie auf den Arbeitsschritt **Reinschrift erstellen** und warten Sie, bis die Reinschrift erstellt wurde.

**Hinweis:** Die Erstellung der Reinschrift kann je nach Menge der Empfänger und Schriftstücke der Erledigung längere Zeit in Anspruch nehmen.

Um eine Reinschrift über den Kontextmenübefehl „Reinschrift“ zu erstellen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Erledigung und klicken Sie auf den Kontextmenüeintrag „Reinschrift“ und anschließend „Reinschrift erstellen“.
2. Warten Sie, bis das System die Reinschrift erstellt hat.

## Ergebnis:

- Schriftstücke, welche als Serienbrief gekennzeichnet sind, werden aufgelöst.
- Schriftstücke, deren Originalformat nicht beibehalten werden soll, werden in das PDF-Format konvertiert.
- Das Symbol der Erledigung ändert sich.

207

<!-- PDF page 208 -->

Benutzerhilfe
208

# 3.4.5.2 Erstellte Reinschriften anzeigen

Es existieren folgende Möglichkeiten erstellte Reinschriften anzuzeigen:

- Über die Erledigung selbst (siehe Kapitel 3.3.10.4.2 Erzeugte Reinschriften anzeigen)
- Über den Arbeitsschritt Erzeugte Reinschriften anzeigen der Aktivität Reinschrift erstellen.

![img-2.jpeg](img-2.jpeg)

Um die erstellten Reinschriften einer Erledigung über die Aktivität Reinschrift erstellen anzuzeigen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“ und lokalisieren Sie die gewünschte Aktivität Reinschrift erstellen.
2. Klicken Sie auf den Arbeitsschritt Erzeugte Reinschriften anzeigen. Daraufhin wird ein Fenster eingeblendet, wo Sie die einzelnen Reinschriften anzeigen und je nach Ihren Benutzerrollen und Berechtigungen auch bearbeiten können.

# 3.4.5.3 Eine Reinschrifterstellung aufheben

Um eine Reinschrifterstellung aufzuheben, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Erledigung, deren Reinschrifterstellung aufgehoben werden soll.
2. Öffnen Sie das Kontextmenü der Erledigung und wählen Sie den Befehl „Reinschrifterstellung aufheben“.

Ergebnis: Das Dokument steht nach der Ausführung wieder zur Bearbeitung zur Verfügung, die Aufhebung der Reinschrifterstellung wird in den Eigenschaften der Erledigung protokolliert.

# 3.4.5.4 Hinzufügen einer Reinschrift

Duplikate von Reinschriften eines bereits finalisierten Dokuments können als Schriftstücke zu weiteren Dokumenten hinzugefügt werden.

Um eine Reinschrift als Schriftstück in ein Dokument als Kopie einzufügen, gehen sie folgendermaßen vor:

1. Lokalisieren Sie das zu kopierende Schriftstück.
2. Führen Sie den Kontextmenübefehl „Kopieren“ aus.
3. Wechseln Sie zu dem Dokument, bei welchem das Schriftstück hinterlegt werden soll.
4. Führen Sie den Kontextmenübefehl „In neuem Fenster öffnen“ aus. Es öffnet sich die Explorer-Ansicht des Dokuments.
5. Wechseln Sie auf die Registerkarte „Schriftstücke“.

<!-- PDF page 209 -->

6. Klicken Sie auf das Symbol Duplikat einfügen (alternativ auch als Menüpunkte im Menü „Zwischenablage“ verfügbar). Das Schriftstück wird als Kopie hinterlegt.

Hinweis: Bei Auswahl von Verknüpfung einfügen wird ein zusätzlicher Dialog angezeigt:

![img-3.jpeg](img-3.jpeg)

## 3.4.6 Den Inhalt einer Erledigung bearbeiten

Um den Inhalt einer Erledigung zu bearbeiten, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Erledigung, deren Inhalt bearbeitet werden soll.
2. Öffnen Sie das Kontextmenü der Erledigung und wählen Sie den Eintrag „In neuem Fenster öffnen“.
3. Führen Sie auf dem gewünschten Schriftstück den Kontextmenübefehl „Öffnen“ aus, um das Schriftstück in der zugeordneten Drittapplikation zu öffnen.
4. Wenn Sie die Bearbeitung des Schriftstücks abgeschlossen haben, benutzen Sie die Speicherfunktionalität der Applikation. Die Änderungen werden automatisch in die Fabasoft eGov-Suite Bayern übernommen.

## 3.4.7 Eine Erledigung kopieren oder duplizieren

Eine Erledigung kann, wie in Kapitel 2.1.2.7 „Ein Objekt kopieren und einfügen“ beschrieben, kopiert und eingefügt werden. Alternativ kann auch ein Duplikat eingefügt werden, wie ebenfalls im vorher genannten Kapitel beschrieben wird.

Hinweis: Sämtliche Eigenschaften einer Erledigung werden beim Duplizieren übernommen. Eine Ausnahme bildet das Feld Vorgang. Dieses Feld wird gesetzt, je nachdem an welcher Stelle der Fabasoft eGov-Suite Bayern Sie das Duplikat einfügen.

Beispiel: Das Duplikat einer Erledigung wird am Schreibtisch abgelegt. In diesem Fall wird das Feld Vorgang nicht gesetzt.

Beispiel: Das Duplikat einer Erledigung wird in einem Vorgang abgelegt. Dies bewirkt, dass in dem Feld Vorgang automatisch der Vorgang eingetragen wird, in dem das Duplikat abgelegt wurde.

Weitere Informationen bezüglich der Metadaten einer Erledigung finden Sie im Kapitel 6.6 „Erledigung“.

Benutzerhilfe
209

<!-- PDF page 210 -->

Benutzerhilfe

## 3.4.8 Eine Erledigung löschen

Wenn eine Erledigung gelöscht wird, werden alle darin enthaltenen Schriftstücke gelöscht. Eine Erledigung kann, wie in Kapitel 2.1.2.1 „Ein Objekt löschen“ beschrieben, gelöscht werden.

## 3.4.9 Ablage

Vorgänge werden nach den Zeichnungsverfahren und nach dem Versenden der Reinschrift abgelegt. Die Ablage erfolgt mithilfe der Aktivität Zum Akt und wird mit der Unterschrift „zum Akt.“ bestätigt.

**Hinweis:** Um einen Vorgang abzulegen, dürfen keine weiteren offenen Prozesse innerhalb des Vorgangs, dessen Dokumenten und Umlaufmappen, mehr existieren. Ausnahme sind Kenntnisnahme bzw. Kenntnisnahme (hemmend) Aktivitäten. Diese dürfen noch auf den Objekten laufen.

Bereits abgelegte Vorgänge können innerhalb der für einen Vorgang definierten Transferfrist wieder in Bearbeitung genommen werden. Dazu steht die Unterschrift „z.A. aufheben“ zur Verfügung.

## 3.4.9.1 Einen Vorgang zu den Akten verfügen

Die Ablage eines Vorgangs erfolgt Mithilfe der Aktivität Zum Akt. Diese Aktivität wird für die Abschlussverfügung verwendet, wenn aus Sicht der Bearbeiter kein Anlass zur weiteren Bearbeitung des Vorgangs besteht.

Um einen Vorgang zu den Akten zu verfügen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Arbeitsvorrat“ und lokalisieren Sie die Aktivität, bei der der entsprechende Vorgang in der Spalte Gehört zu angezeigt wird.
2. Klicken Sie auf den Arbeitsschritt zum Akt der Aktivität Zum Akt. Es wird die Unterschrift „z.A.“ ausgeführt.

**Ergebnis:**

- Das Symbol des Vorgangs ändert sich.
- Der Zugriffsschutz des Vorgangs wird geändert, um eine weitere Bearbeitung zu verhindern.
**Hinweis:** Benutzer, die eine Rolle mit der Stelle „Registratur“ besitzen haben die Möglichkeit, Dokumente zu einem abgeschlossenen Vorgang hinzuzufügen.
- Die Unterschrift wird in den Metadaten des Vorgangs, der Dokumente und der Schriftstücke vermerkt.
- Eine Version des Vorgangs wird gesichert.
- Die Eigenschaft vorgesehen/tatsächlich des Aggregats Transfer und die Eigenschaft Aussonderung (vorgesehen/tatsächlich) des Aggregats Aufbewahrung werden auf Basis der definierten Fristen initialisiert.

210

<!-- PDF page 211 -->

3.4.9.2 Einen z.A. verfügten Vorgang wieder in Bearbeitung nehmen

Abgelegte Vorgänge können mithilfe der Unterschrift „z.A. aufheben“ wieder in Bearbeitung genommen werden. Durch das Ausführen einer solchen Unterschrift erhält der ausführende Benutzer eine Aktivität Bearbeitung in seinen Arbeitsvorrat.

Hinweis: Die Ausführung dieser Unterschrift ist nur möglich, wenn die Transferfrist des Vorgangs noch nicht abgelaufen ist bzw. schon begonnen hat.

Um einen z.A. verfügten Vorgang wieder in Bearbeitung zu nehmen, führen Sie die Unterschrift „z.A. aufheben“ aus. Weitere Informationen zur Ausführung einer Unterschrift finden Sie im Kapitel 2.1.2.10 „Eine Unterschrift auf einem Objekt anbringen“.

Ergebnis:
- Das Symbol des Vorgangs ändert sich.
- Der Zugriffsschutz des Vorgangs wird geändert, sodass wieder eine Bearbeitung möglich ist.
- Die Unterschrift wird in den Metadaten des Vorgangs, der Dokumente und der Schriftstücke vermerkt.
- Eine Version des Vorgangs wird gesichert.

3.4.10 Behandlung von Registerblättern

Hinweis: Registerblätter können sowohl in Vorgängen als auch in Registerblättern erzeugt bzw. abgelegt werden.

Hinweis: Duplikate von Registerblättern können durch die Befehle „Duplikat einfügen“ und „Verknüpfung einfügen“ in anderen Vorgängen abgelegt werden. Hierbei wird nur das Registerblatt dupliziert, Dokumente innerhalb eines Registerblatts werden nicht dupliziert/kopiert.

3.4.10.1 Ein Registerblatt in einem Vorgang erzeugen

Um ein Registerblatt zu erzeugen gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang, dessen Dokumente gegliedert werden sollen.
2. Öffnen Sie den Vorgang durch einen Klick auf diesen oder durch den Kontextmenüeintrag „In neuem Fenster öffnen“.
3. Wechseln Sie auf die Registerkarte „Dokumente“, falls Sie sich auf einer anderen Registerkarte befinden.
4. Erzeugen Sie das Registerblatt wie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ beschrieben.

Ergebnis:
- Das Registerblatt wird im Vorgang abgelegt.
- Sollten sich zuvor noch keine Registerblätter im Vorgang befunden haben, wird nun zusätzlich die Registerkarte „Alle Dokumente“ angezeigt.

Benutzerhilfe

<!-- PDF page 212 -->

- Im Kontextmenü von Dokumenten und Registerblättern steht nun der Eintrag „Verwalten“ → „Gliedern“ zur Verfügung.

## 3.4.10.2 Ein Registerblatt in einem Registerblatt erzeugen

Um ein Registerblatt zu erzeugen gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Registerblatt, dessen Dokumente gegliedert werden sollen.
2. Öffnen Sie das Registerblatt durch einen Klick auf dieses
3. Erzeugen Sie das Registerblatt wie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ beschrieben.

**Ergebnis:** Das Registerblatt wird im Registerblatt abgelegt.

## 3.4.10.3 Einen Vorgang gliedern

Befinden sich Registerblätter in einem Vorgang, können die Dokumente und Registerblätter des Vorgangs darin abgelegt werden. Um Dokumente und Registerblätter eines Vorgangs in einem Registerblatt abzulegen, stehen folgende Möglichkeiten zur Verfügung:

- Über den Kontextmenüeintrag „Verwalten“ → „Gliedern“ von Dokumenten und Registerblättern.

**Hinweis:** Das Menü „Verwalten“ → „Gliedern“ steht bei Registerblättern nur zur Verfügung, wenn sich mehrere Registerblätter im Vorgang befinden.

- Mittels des Befehls „Verknüpfung einfügen“.
- Mittels Einfügen eines Duplikats des Dokuments bzw. Registerblatts im Registerblatt.
- Durch Erzeugen des Dokuments bzw. Registerblatts innerhalb des Registerblatts.
- Durch Verschieben der Dokumente bzw. Registerblätter mittels Drag &amp; Drop.
- Mittels der Suche und einfügen.
- Während dem Umschreiben eines Dokuments.

**Hinweis:** Über diese Möglichkeiten kann ein Dokument auch aus einem Registerblatt in die Liste der Dokumente eines Vorgangs gelegt werden.

**Hinweis:** Wird das Dokument in einem Registerblatt eingefügt und ist das Dokument noch nicht dem Vorgang des Registerblatts zugeordnet, wird dieses Dokument

- automatisch dem Vorgang zugewiesen,
- angeboten das Dokument umzuschreiben oder
- angeboten ein Duplikat des Dokuments einzufügen.

## 3.4.10.3.1 Hinzufügen eines Dokuments bzw. Registerblatts über den Kontextmenüeintrag „Gliedern“

Um ein Dokument bzw. Registerblatt über das Kontextmenü einem Registerblatt zuzuordnen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie den Vorgang des Dokuments bzw. Registerblatts, das in einem Registerblatt dieses Vorgangs abgelegt werden soll.

Benutzerhilfe
212

<!-- PDF page 213 -->

2. Navigieren Sie in den Vorgang durch einen Klick auf diesen.
3. Lokalisieren Sie das gewünschte Dokument bzw. Registerblatt innerhalb des Vorgangs.
Hinweis: Sollte sich das Dokument bereits in einem Registerblatt befinden, können Sie dieses auch über die Registerkarte „Alle Dokumente“ des Vorgangs lokalisieren.
4. Öffnen Sie das Kontextmenü des Dokuments bzw. Registerblatts und wählen Sie den Kontextmenüeintrag „Verwalten“ → „Gliedern“ aus.

![img-4.jpeg](img-4.jpeg)

![img-5.jpeg](img-5.jpeg)

5. Wählen Sie im angezeigten Dialog das Registerblatt, in dem das Dokument bzw. Registerblatt abgelegt werden soll, aus.
Hinweis: Befindet sich das gewählte Dokument bzw. Registerblatt bereits in einem Registerblatt wird im angezeigten Dialog ebenfalls der Vorgang angeboten.
Hinweis: Über diese Methode können nur Dokumente bzw. Registerblätter in einem Registerblatt des Vorgangs abgelegt werden, das dem Vorgang zugeordnet ist.

## 3.4.10.3.2 Hinzufügen eines Dokuments bzw. Registerblatts mittels der Befehle „Verknüpfung einfügen“ bzw. durch ablegen eines Duplikats

Um ein Dokument mittels „Verknüpfung einfügen“ oder durch das Ablegen eines Duplikats in einem Registerblatt abzulegen, gehen Sie wie im Kapitel 2.1.2.7 „Ein Objekt kopieren und einfügen“ beschrieben vor.

## 3.4.10.3.3 Hinzufügen eines Dokuments mittels der Suche

Um ein Dokument über die Suche in einem Registerblatt abzulegen, gehen Sie wie im Kapitel 2.12 „Suche“ beschrieben vor.

Benutzerhilfe

<!-- PDF page 214 -->

Benutzerhilfe

# 3.4.10.3.4 Hinzufügen des Dokuments bzw. Registerblatts durch Erzeugen innerhalb des Registerblatts

Um ein Dokument bzw. Registerblatt innerhalb eines Registerblatts zu erzeugen, gehen Sie wie in den Kapiteln 2.3.1 „Ein Dokument erstellen“, 3.4.1 „Eine Erledigung erstellen“ bzw. 3.4.10.2 „Ein Registerblatt in einem Registerblatt erzeugen“ beschrieben vor. Weiters können Schriftstücke direkt in das Registerblatt importiert werden, um ein Dokument zu erzeugen.

**Hinweis:** Dokumente, die in einem Registerblatt erzeugt werden, werden automatisch auf der Registerkarte „Alle Dokumente“ des Vorgangs abgelegt.

# 3.4.10.3.5 Hinzufügen des Dokuments bzw. Registerblatts durch Verschieben mittels Drag &amp; Drop

Um ein Dokument bzw. Registerblatt mittels Drag &amp; Drop in einem Registerblatt abzulegen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Dokument bzw. Registerblatt, welches in dem Registerblatt abgelegt werden soll.
2. Klicken Sie auf das Dokument bzw. Registerblatt und halten Sie die Maustaste gedrückt.
3. Ziehen Sie das Dokument bzw. Registerblatt auf das gewünschte Registerblatt und lassen Sie die Maustaste los.

**Hinweis:** Ist das Dokument bereits einem anderen Vorgang zugewiesen, wird ein Dialog angezeigt, über dessen Schaltflächen Sie das Dokument umschreiben bzw. duplizieren können.

**Hinweis:** Ist das Registerblatt bereits einem anderen Vorgang zugewiesen, wird ein Dialog angezeigt, welcher darauf hinweist, dass das Registerblatt nicht aus dem Vorgang entfernt werden kann.

# 3.4.10.3.6 Hinzufügen des Dokuments während der Umschreibung

Wird ein Dokument mittels der Unterschrift „Umschreiben“ einem Vorgang, welcher Registerblätter enthält, umgeschrieben, kann sofort bei der Auswahl des Vorgangs ebenfalls ein Registerblatt ausgewählt werden. Für weitere Informationen zum Anbringen einer Unterschrift siehe Kapitel 2.11 „Unterschreiben“.

## Ergebnis:

- Das Dokument wird aus der Liste der Dokumente des Vorgangs in das gewählte Registerblatt verschoben.

**Hinweis:** Wurde der Vorgang ausgewählt, wird das Dokument aus dem Registerblatt in die Liste der Dokumente des Vorgangs verschoben.

**Hinweis:** Das Dokument kann auf der Registerkarte „Alle Dokumente“ des Vorgangs weiterhin eingesehen werden.

- Das gewählte Registerblatt wird in der Eigenschaft Registerblatt des Dokuments eingetragen.

**Hinweis:** Wurde der Vorgang ausgewählt, wird die Eigenschaft Registerblatt geleert.

214

<!-- PDF page 215 -->

Benutzerhilfe
215

# 3.4.10.4 Ein Registerblatt löschen

Um ein Registerblatt zu löschen, gehen Sie wie im Kapitel 2.1.2.1 „Ein Objekt löschen“ beschrieben vor.

**Hinweis:** Ein Registerblatt kann nur gelöscht werden, wenn sich keine Objekte in diesem Registerblatt befinden.

# 3.4.11 Die Seitenansicht

Die Seitenansicht zeigt alle relevanten Informationen zu einer Akte, einem Vorgang, einer Umlaufmappe bzw. einem Dokument in einem übersichtlich gegliederten PDF-Dokument und steht zur Betrachtung und zum Download im Rahmen der Drittapplikation Adobe Acrobat Reader zur Verfügung.

Um die Seitenansicht aufzurufen, stehen folgende Möglichkeiten zur Verfügung:

- Über die Schaltfläche „Seitenansicht“
- Über den Kontextmenübefehl „Seitenansicht“

Um die Seitenansicht über die Schaltfläche „Seitenansicht“ aufzurufen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die entsprechende Akte, den entsprechenden Vorgang bzw. das entsprechende Dokument.
2. Navigieren Sie in das entsprechende Objekt durch einen Klick auf dieses.
3. Klicken Sie auf die Schaltfläche „Seitenansicht“, um die Seitenansicht aufzurufen.

**Hinweis:** Nur bei Umlaufmappen werden auch die Metadaten/Laufwegs Informationen in der Seitenansicht angezeigt. Bei sämtlichen anderen Objekten werden nur die Schriftstücke dargestellt.

# 3.5 Behandlung von Eingangsdokumenten

## Überblick Eingangsdokumente

- Erfassung durch
- Bei existierendem Schriftstück im „Postkorb“: Schriftstück auswählen → Schaltfläche „Erfassen“ klicken
- Neues Dokument erstellen:
- Postkorb → Registerkarte „Erfasste Eingänge“ → Schaltfläche „Neu“
- Innerhalb eines Vorgangs / einer Umlaufmappe → Schaltfläche „Neu“
- Beispiel „eMail aus Outlook“: E-Mail in Outlook markieren → Strg + C betätigen → zur Fabasoft eGov-Suite Bayern wechseln → Strg + V betätigen → im Dialogfeld „Erfassen zu“ die Objektklasse „Eingangsdokument“ wählen
- Eingangsdokumente können neuen und bestehenden Vorgängen zugeordnet werden

<!-- PDF page 216 -->

Benutzerhilfe
216

# 3.5.1 Ein Eingangsdokument erfassen

Die Erfassung eines elektronischen Schriftstücks kann auf mehrere Arten erfolgen:

- Über das Widget „Postkörbe“: Durch die Auswahl eines existierenden Schriftstücks in einem der Postkörbe und Klick auf die Schaltfläche „Erfassen“.
- Über das „Widget“ Postkörbe auf der Registerkarte „Erfasste Eingänge“: Erstellen über die „Neu“ Schaltfläche.
- Innerhalb eines Vorgangs der einer Umlaufmappe: Erstellen über die „Neu“ Schaltfläche.

Hinweis: Bei den beiden letzteren Erstellungsmöglichkeiten ist noch kein Schriftstück im Eingangsdokument hinterlegt.

Um ein neues Schriftstück zu einem Eingangsdokument hinzuzufügen, gehen Sie wie folgt vor:

1. Klicken Sie auf das jeweilige Eingangsdokument
2. Wählen Sie die Schaltfläche „Neu“ um ein neues Dokument zu erstellen
3. Wählen Sie die gewünschte Objektklasse, vergeben Sie einen Namen für das Dokument und bestätigen Sie den Dialog mit „Weiter“.

Um ein bestehendes Schriftstück zu einem Eingangsdokument hinzuzufügen, gehen Sie wie folgt vor:

1. Klicken Sie auf das jeweilige Eingangsdokument
2. Wählen Sie „Zur Listenansicht wechseln“
3. Fügen Sie zuvor kopierte Schriftstücke aus der Zwischenablage ein oder lokalisieren Sie die entsprechenden Schriftstücke über eine Suche und fügen diese ein.
Weitere Informationen zum Kopieren und Einfügen von Objekten finden Sie in Kapitel „2.1.2.7 Ein Objekt kopieren und einfügen“ bzw. weitere Informationen zur Suche in Kapitel 2.12 „Suche“.

Beim Erstellen eines Eingangsdokuments können diverse Metadaten eingegeben werden.
Weitere Informationen zu den Metadaten eines Eingangsdokuments finden Sie im Kapitel 6.5 „Eingangsdokument“.

## Ergebnis:

- Es wird ein Eingangsdokument erzeugt. (Weitere) Dokumente können durch einen Klick auf das Eingangsdokument hinzugefügt werden.
- Der Laufweg wird begonnen. Der federführende Benutzer (der Benutzer, welcher das Eingangsdokument erstellte) erhält das Eingangsdokument mit der Aktivität Eingang im Arbeitsvorrat.

# 3.5.2 Eine E-Mail aus Microsoft Office Outlook in die Fabasoft eGov-Suite Bayern erfassen

E-Mails können direkt aus Microsoft Outlook in die Fabasoft eGov-Suite Bayern übernommen werden. Anschließend kann die E-Mail zu einem Eingangsdokument erfasst oder direkt einem Vorgang zugeordnet werden. Bei zuordnen zu einem Vorgang muss die Zielobjektklasse „Eingangsdokument“ entsprechend ausgewählt werden.

<!-- PDF page 217 -->

Um eine E-Mail aus Microsoft Outlook zu erfassen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in das „Postkörbe“ Widget.
2. Öffnen Sie Microsoft Outlook und markieren Sie durch einfaches Anklicken die gewünschte E-Mail.
3. Betätigen Sie die Tastenkombination Strg + C, um die E-Mail in die Zwischenablage zu kopieren.
4. Wechseln Sie zurück zur Fabasoft eGov-Suite Bayern.
5. Betätigen Sie im jeweiligen „Postkorb“ die Tastenkombination Strg + V, um das Objekt aus der Zwischenablage einzufügen und bestätigen Sie den erscheinenden Dialog mit einem Klick auf die Schaltfläche „Ja“.

**Hinweis:** Es besteht auch die Möglichkeit, eine E-Mail per Drag &amp; Drop in die Fabasoft eGov-Suite Bayern zu importieren. Ziehen Sie dazu die E-Mail in den Postkorb der Fabasoft eGov-Suite Bayern und klicken Sie auf „Ja“, um den Import zu bestätigen.

**Hinweis:** Sie haben auch die Möglichkeit, eine E-Mail aus Microsoft Office Outlook über die Schaltflächen „Ablegen“ und „Erfassen“ zu importieren. Siehe hierzu die Kapitel 3.6.5.2 „Ein Schriftstück aus Microsoft Outlook direkt einem Dokument zuordnen“ bzw. 2.1.2.8.2 „Ein Objekt über die Office Button Funktion „Ablegen“ importieren“.

Sollte eine importierte E-Mail Anhänge enthalten, erhalten Sie im Zuge des Imports folgende Importmöglichkeiten:

![img-6.jpeg](img-6.jpeg)

Benutzerhilfe
217

<!-- PDF page 218 -->

„Original-E-Mail (Standard)“: Importiert die E-Mail und erzeugt ein Objekt des Typs „E-Mail (Microsoft Office Outlook)“. Die Anlagen werden beim erzeugten Objekt hinterlegt und können über das Kontextmenü eingesehen werden.
„Original-E-Mail und Anhang getrennt“: Importiert die E-Mail und den Anhang, jedoch werden für den Anhang entsprechende, vom E-Mail-Objekt separate, Objekte erstellt.
„E-Mail-Text und Anhang getrennt“: Importiert die E-Mail und erzeugt ein Objekt des Typs „E-Mail (Microsoft Office Outlook)“. Die Anlagen werden beim erzeugten Objekt hinterlegt und können über das Kontextmenü eingesehen werden. Der Anhang wird aus dem E-Mail-Objekt entfernt.
„Nur E-Mail-Text“: Importiert den Anhang nicht und erzeugt nur ein Objekt des Typs „E-Mail (Microsoft Office Outlook)“.
„Nur Anhang“: Erzeugt für jeden Anhang der E-Mail ein Objekt, jedoch wird die E-Mail selbst nicht importiert.

## 3.5.3 Eine Sammelerfassung durchführen

Über eine Sammelerfassung können mehrere Schriftstücke zu einem Eingangsdokument erfasst werden. Um eine Sammelerfassung durchzuführen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihr „Postkörbe“ Widget und klicken Sie auf den entsprechenden Postkorb.
2. Markieren Sie die Schriftstücke, die zu einem neuen Eingangsdokument erfasst werden sollen und klicken Sie auf die Schaltfläche „Erfassen“.
3. Es erfolgt eine Abfrage, ob eine Sammelerfassung durchgeführt werden soll.

X

Sammelerfassung der ausgewählten Objekte

Wollen Sie eine Sammelerfassung durchführen?

[tbl-6.md](tbl-6.md)

4. Klicken Sie auf die Schaltfläche „Ja, Sammelerfassung durchführen“.

**Hinweis:** Wenn Sie die ausgewählten Schriftstücke einzeln zu jeweils einem Eingangsdokument erfassen möchten, folgen Sie der Anleitung im Kapitel 3.5.4 „Eine Einzelerfassung durchführen“.

5. Erfassen Sie die Metadaten des Eingangsdokuments.

**Ergebnis:**

Benutzerhilfe
218

<!-- PDF page 219 -->

- Es wird ein Eingangsdokument erzeugt, dem als Inhalt die Schriftstücke zugeordnet wurden.
- Die Schriftstücke werden aus der Liste Postkorb entfernt und das erfasste Eingangsdokument auf der Registerkarte „Erfasste Eingänge“ abgelegt. Anhand der Spalte Gehör zu können Sie erkennen, ob ein Eingangsdokument bereits einem Vorgang zugeordnet wurde.
- Falls Sie das Kontrollkästchen zur Erstellung eines Laufwegs gesetzt haben, wird ein neuer Laufweg erzeugt. Der im Feld Federführung angegebene Benutzer erhält das Eingangsdokument mit der Aktivität Eingang in seinen Arbeitsvorrat.

Hinweis: Eine Sammelerfassung ist auch auf Ihrem „Schreibtisch“ durch Markieren mehrere Schriftstücke und anschließend dem Kontextmenüeintrag „Erfassen“ möglich.

Hinweis: Wenn die Einstellung Auswahl der Objektklasse beim Erfassen in der Arbeitsumgebung aktiviert ist, erscheint eine Objektklassenauswahldialog.

## 3.5.4 Eine Einzelerfassung durchführen

Sie haben die Möglichkeit, im Postkorb mehrere Schriftstücke zu markieren und einzeln als Dokumente zu erfassen. Gehen Sie hierzu folgendermaßen vor:

1. Wechseln Sie auf Ihren Homescreen, klicken Sie auf das Widget „Postkörbe“ und wechseln in den entsprechenden Postkorb durch einen Klick auf diesen.
2. Markieren Sie durch einfaches Anklicken und halten der Strg-Taste die Schriftstücke, welche Sie zu neuen Eingangsdokumenten erfasst werden sollen und klicken Sie auf die Schaltfläche „Als Dokument erfassen“.
3. Es erfolgt eine Abfrage, ob eine Sammelerfassung durchgeführt werden soll

X

Sammelerfassung der ausgewählten Objekte

Wollen Sie eine Sammelerfassung durchführen?

[tbl-7.md](tbl-7.md)

4. Klicken Sie auf die Schaltfläche „Nein, Schriftstücke einzeln erfassen“.
Hinweis: Wenn Sie die ausgewählten Schriftstücke gemeinsam zu einem neuen Eingangsdokument erfassen möchten, folgen Sie der Anleitung im Kapitel 3.5.3 „Eine Sammelerfassung durchführen“.
5. Sie haben nun die Möglichkeit, für jedes selektierte Schriftstück ein Eingangsdokument zu erzeugen. Befüllen Sie die gewünschten Metadaten des Eingangsdokuments und klicken Sie auf die Schaltfläche „Weiter“.

Benutzerhilfe
219

<!-- PDF page 220 -->

Hinweis: Da Sie für jedes Schriftstück ein Eingangsdokument erzeugen, wird bei einem Klick auf die Schaltfläche „Weiter“ automatisch der Dialog zum Erzeugen eines Eingangsdokuments angezeigt, bis das letzte Schriftstück erfasst wurde. Nachdem das letzte Schriftstück erfasst wurde, wird wieder der „Postkorb“ angezeigt.

Hinweis: Durch einen Klick auf die Schaltfläche „Abbrechen“ werden die Erfassung des aktuellen und aller nachfolgenden Schriftstücke abgebrochen. Bereits erfasste Schriftstücke bleiben bestehen und sind unter „Erfasste Eingänge“ des „Postkorbs“ einsehbar.

## Ergebnis:

- Es wird ein Eingangsdokument für jedes Schriftstück erzeugt, dem als Inhalt je ein Schriftstück zugeordnet wurde.
- Die Schriftstücke werden aus der Liste *Zu erfassende Schriftstücke* entfernt und die erfassten Eingangsdokumente auf der Registerkarte „Erfasste Eingänge“ abgelegt. Anhand der Spalte *Gehört zu* können Sie erkennen, ob ein Eingangsdokument bereits einem Vorgang zugeordnet wurde.
- Falls Sie das Kontrollkästchen zur Erstellung eines Laufwegs gesetzt haben, wird ein neuer Laufweg erzeugt. Der im Feld *Federführung* angegebene Benutzer erhält die Eingangsdokumente mit der Aktivität *Eingang* in seinen Arbeitsvorrat.

Hinweis: Eine Einzelerfassung ist auch auf Ihrem „Schreibtisch“ über den Kontextmenüeintrag „Erfassen“ möglich.

Hinweis: Wenn die Einstellung *Auswahl der Objektklasse beim Erfassen* in der Arbeitsumgebung aktiviert ist, erscheint eine Objektklassenauswahldialog.

## 3.5.5 Ein Eingangsdokument über den Kontextmenübefehl „Ändern zu Eingangsdokument“ erstellen

Wenn eine Erledigung zu einem Eingangsdokument umgewandelt werden soll (ein Objektklassenwechsel durchgeführt werden soll) so können Sie dies über den Kontextmenübefehl „Verwalten“ → „Ändern zu Eingangsdokument“. Gehen Sie hierzu folgendermaßen vor:

1. Lokalisieren Sie die Erledigung, welche in ein Eingangsdokument umgewandelt werden soll.
2. Öffnen Sie das Kontextmenü und wählen Sie den Menüpunkt „Verwalten“ → „Ändern zu Eingangsdokument“.

Hinweis: Sollte bereits eine Reinschrift erstellt worden sein, die Erledigung storniert oder zum Akt gelegt wurde, so steht der Menüpunkt „Verwalten“ → „Ändern zu Eingangsdokument“ nicht zur Verfügung.

## 3.5.6 Revisionssicherheit für Eingangsdokumente

Beim Importieren eines Schriftstücks in ein Eingangsdokument bzw. bei dem Erfassen eines Schriftstücks wird von diesem Schriftstück eine automatische Version erstellt. Dadurch wird die Nachvollziehbarkeit des Urzustandes beim Import gewährleistet und die Formate (z.B. von DOC- ins PDF-Format) werden nicht geändert. Dadurch können zu einem späteren Zeitpunkt

Benutzerhilfe
220

<!-- PDF page 221 -->

Kopien von Schriftstücken in einem bearbeitbaren Format erstellt werden. Die Beschreibung enthält entsprechende Informationen:

![img-7.jpeg](img-7.jpeg)

Für weitere Informationen zum Lesen einer Version siehe Kapitel 2.10.2 „Eine Version anzeigen“.

## 3.5.7 Ein Eingangsdokument prüfen bzw. sichten

Durch einen Klick auf die Aktivität „Eingang“ selbst können die Eigenschaften des Eingangsdokuments sowie die Inhalte (Schriftstücke) eingesehen bzw. auch geändert werden.

![img-8.jpeg](img-8.jpeg)

Hinweis: Das Verhalten eines Klicks auf die Aktivität „Eingang“ entspricht einem Klick auf das Eingangsdokument selbst.

## 3.5.7.1 Einen Absender eintragen oder aus einem Adressverzeichnis auswählen

Bei der Eingangserfassung kann in den Metadaten des Eingangsdokuments im Feld Adressaten ein bereits bestehender Absender angegeben werden. Die Bedienung dieses Feldes und weitere verfügbare Befehle dazu finden Sie im Kapitel 2.1.9 „Umgang mit Aggregaten“. Siehe hierzu auch Kapitel 2.2.1 „Globales Adressverzeichnis“.

## 3.5.7.2 Ein Eingangsdokument duplizieren

Über die Aktivität Eingang im Arbeitsvorrat des Benutzers können Eingangsdokumente inklusive der enthaltenen Schriftstücke dupliziert werden. Durch Ausführen des Arbeitsschritts Eingangsdokument duplizieren wird das entsprechende Eingangsdokument dupliziert und es wird eine neue Aktivität Eingang für das neu erstellte Eingangsdokument im Arbeitsvorrat dargestellt.

Benutzerhilfe

<!-- PDF page 222 -->

![img-0.jpeg](img-0.jpeg)

Um ein Eingangsdokument zu duplizieren, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“ und lokalisieren Sie die gewünschte Aktivität *Eingang* des Eingangsdokuments, das dupliziert werden soll.
2. Klicken Sie auf den Arbeitsschritt *Eingangsdokument duplizieren*. Dadurch wird das Eingangsdokument samt seinen Schriftstücken dupliziert und das Formular zum Erzeugen eines neuen Eingangsdokuments geöffnet.
3. Erfassen Sie, falls gewünscht, zusätzliche oder abweichende Metadaten des duplizierten Eingangsdokuments und klicken Sie auf die Schaltfläche „Weiter“, um die Änderungen zu speichern.

## 3.5.7.3 Ein Eingangsdokument löschen

Beim Löschen eines Eingangsdokuments werden alle enthaltenen Schriftstücke sowie zugehörige Prozesse gelöscht.

Das Löschen eines Eingangsdokuments erfolgt analog zur Beschreibung im Kapitel 2.1.2.1 „Ein Objekt löschen“.

**Hinweis:** Zusätzlich steht Ihnen bei der Aktivität *Eingang* der Arbeitsschritt *Eingang löschen* zur Verfügung. Siehe hierzu auch Kapitel 7.1 „Die Aktivität *Eingang*“.

## 3.5.8 Ein Eingangsdokument zu einem neuen Vorgang zuordnen

Eingangsdokumente können auf verschiedene Weisen zu einem neuen Vorgang zugeordnet werden:

Über den „Arbeitsvorrat“

Die Zuordnung zu einem neuen Vorgang erfolgt über die Aktivität *Eingang* durch Ausführen des Arbeitsschritts *Vorgang erzeugen und Eingang zuordnen*.

![img-1.jpeg](img-1.jpeg)

Um ein Eingangsdokument über den „Arbeitsvorrat“ zu einem neuen Vorgang zuzuordnen, gehen Sie folgendermaßen vor:

Benutzerhilfe

<!-- PDF page 223 -->

1. Wechseln Sie in Ihren „Arbeitsvorrat“ und lokalisieren Sie die Aktivität, bei der das gewünschte Eingangsdokument in der Spalte Gehört zu angezeigt wird.
2. Klicken Sie bei der entsprechenden Aktivität Eingang auf den Arbeitsschritt Vorgang erzeugen und Eingang zuordnen. Dadurch wird ein neuer Vorgang erstellt und das Eingangsdokument wird zu dem ausgewählten Vorgang zugeordnet.
3. Erfassen Sie die Metadaten des Vorgangs und klicken Sie auf die Schaltfläche „Weiter“. Nähere Informationen zu den Metadaten eines Vorgangs finden Sie im Kapitel 6.9 „Vorgang“.

Über den „Postkorb“:

Um ein Eingangsdokument über Ihren Postkorb zu einem neuen Vorgang zuzuordnen, gehen Sie folgendermaßen vor:

1. Wechseln Sie in das Widget „Postkörbe“ und öffnen Sie den gewünschten Postkorb.
2. Wechseln Sie auf die Registerkarte „Erfasste Eingänge“.
3. Lokalisieren Sie das Eingangsdokument, welches einem neuen Vorgang zugeordnet werden soll.
4. Führen Sie einen Rechtsklick auf das Eingangsdokument aus und wählen Sie die Option „Eigenschaften“. Sofern die Eigenschaften lesend geöffnet wurden klicken Sie in der Leiste unten auf „Bearbeiten“ um in die Bearbeitungsansicht zu wechseln.
5. Erzeugen Sie einen neuen Vorgang über die im Feld Vorgang angezeigte Schaltfläche „Erzeugen“.

![img-2.jpeg](img-2.jpeg)

6. Schließen Sie die Erfassung durch Klicken auf die Schaltfläche „Weiter“ ab.

Hinweis: Wenn in dem Postkorb eine Aufräumexpression hinterlegt ist, findet ein automatisches Aufräumen der Eigenschaft „Erfasste Eingänge“ statt. Die 100 zuletzt entfernten Objekte aus „Erfasste Eingänge“ werden in der Eigenschaft „Zuletzt beendet“ angezeigt.

Benutzerhilfe

<!-- PDF page 224 -->

Über den „Schreibtisch“

Um ein Eingangsdokument über den „Schreibtisch“ zu einem neuen Vorgang zuzuordnen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Öffnen Sie die Metadaten des Eingangsdokuments in der Bearbeitungsansicht.
3. Erzeugen Sie einen neuen Vorgang über die im Feld Vorgang angezeigte Schaltfläche „Erzeugen“ ⚡.
4. Schließen Sie die Erfassung durch Klicken auf die Schaltfläche „Weiter“ ab.

**Hinweis:** Wird bei einem Eingangsdokument in der Eigenschaft Akte direkt eine Akte ausgewählt, wird automatisch ein neuer Vorgang erzeugt und das Eingangsdokument diesem Vorgang zugeordnet.

## 3.5.9 Eingangsdokument zu einem bestehenden Vorgang zuordnen

Eingangsdokumente können zu einem bestehenden Vorgang zugeordnet werden. Hierfür stehen mehrere Möglichkeiten zur Verfügung:

### Über den „Arbeitsvorrat“

Um ein Eingangsdokument über Ihren „Arbeitsvorrat“ zu einem bestehenden Vorgang zuzuordnen gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Arbeitsvorrat“ und lokalisieren Sie die Aktivität Eingang, bei der das gewünschte Eingangsdokument in der Spalte Gehört zu angezeigt wird.
2. Klicken Sie bei der entsprechenden Aktivität auf den Arbeitsschritt Vorgang suchen und Eingang zuordnen.
3. Suchen Sie in dem Feld Vorgang nach dem Vorgang, dem das Eingangsdokument zugeordnet werden soll. Siehe hierzu auch Kapitel 2.12 „Suche“.
4. Mit einem Klick auf die Schaltfläche „Weiter“ wird das Eingangsdokument dem Vorgang zugeordnet.

### Über den „Postkorb“

Um ein Eingangsdokument über Ihren Postkorb einem bestehenden Vorgang zuzuordnen gehen Sie bitte folgendermaßen vor:

1. Wechseln Sie in das Widget „Postkörbe“ und öffnen Sie den gewünschten Postkorb.
2. Wechseln Sie auf die Registerkarte „Erfasste Eingänge“.
3. Klicken Sie auf die Schaltfläche „Einem Vorgang zuordnen“.

Benutzerhilfe
224

<!-- PDF page 225 -->

![img-3.jpeg](img-3.jpeg)

![img-4.jpeg](img-4.jpeg)

4. Wählen Sie im nun geöffneten Formular einen Vorgang aus oder suchen Sie im Feld Vorgang nach dem Vorgang, zu dem das Eingangsdokument zugeordnet werden soll. Siehe hierzu auch Kapitel 2.12 „Suche".
5. Durch einen Klick auf die Schaltfläche „Weiter" werden die Änderungen gespeichert.

Über den „Schreibtisch"

1. Wechseln Sie auf Ihren „Schreibtisch".
2. Öffnen Sie die Metadaten des Eingangsdokuments in der Bearbeitungssicht.
3. Suchen Sie im Feld Vorgang nach dem Vorgang, zu dem das Eingangsdokument zugeordnet werden soll. Siehe hierzu auch Kapitel 2.12 „Suche".
4. Durch einen Klick auf die Schaltfläche „Weiter" werden die Änderungen gespeichert.

Benutzerhilfe
225

<!-- PDF page 226 -->

Benutzerhilfe
226

# 3.6 Behandlung von Schriftstücken

## Überblick Schriftstücke

- Bearbeitung: Rechtsklick auf das Dokument → Kontextmenüeintrag „Öffnen zum Bearbeiten“ klicken
- Lesen: Rechtsklick auf das Dokument → Kontextmenüeintrag „Öffnen zum Lesen“ klicken
- Annotationen:
- Über Kontextmenüeintrag „Annotieren“
- Über Arbeitsvorrat: Aktivität „Eingang“ des zu annotierenden Schriftstücks anklicken → Arbeitsschritt „annotieren“ ausführen
- Die Fabasoft eGov-Suite Bayern bietet Annotierungswerkzeuge wie „Hand“, „Textannotation“ oder „Stempel“
- Dokumente können importiert werden
- Per Drag &amp; Drop
- Markieren der Datei, die importiert werden soll → Strg + C betätigen &gt; in die Fabasoft eGov-Suite wechseln → Strg + v betätigen → „Ja“ klicken
- Schriftstück einem Vorgang zuordnen: Rechtsklick auf Schriftstück → „Als Dokument erfassen“ klicken → Metadaten erfassen → „Weiter“ (r.o.) klicken

## 3.6.1 Ein Schriftstück zur Bearbeitung öffnen

Um ein Schriftstück zur Bearbeitung zu öffnen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück und klicken Sie auf den Kontextmenüeintrag „Öffnen“.
2. Bearbeiten Sie das Schriftstück, speichern Sie es danach ab und schließen Sie das Programm zur Bearbeitung.

**Ergebnis:** Das Schriftstück wurde innerhalb der Fabasoft eGov-Suite Bayern aktualisiert und steht zur weiteren Bearbeitung zur Verfügung.

## 3.6.2 Ein Schriftstück zum Lesen öffnen

Um ein Schriftstück zum Lesen zu öffnen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück und klicken Sie auf den Kontextmenüeintrag „Öffnen“.
2. Betrachten Sie das Schriftstück und schließen Sie das Drittprogramm anschließend.

## 3.6.3 Annotationen auf Schriftstücken

**Hinweis:** Um Annotationen an einem Schriftstück anbringen, lesen bzw. löschen zu können muss in der Domäne bzw. dem Mandanten des Benutzers eine Dateiendung für Annotationen definiert sein. Das Definieren dieser Dateiendung ist eine administrative Aufgabe und wird im Kapitel 5.3.6 „Definieren einer Dateiendung für Annotationen“ beschrieben.

<!-- PDF page 227 -->

Annotationen können mittels Kontextmenü „Annotationen“ auf einem Schriftstück angebracht werden.

Bestehende Annotationen können ebenfalls über das Kontextmenü „Annotationen“ gelesen bzw. gelöscht werden.

## 3.6.3.1 Ein Schriftstück annotieren

### Ein Schriftstück über das Kontextmenü annotieren

Um ein Schriftstück über das Kontextmenü zu annotieren, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück, das annotiert werden soll.
2. Öffnen Sie das Kontextmenü des Schriftstücks durch Klick mit der rechten Maustaste.
3. Wählen Sie den Kontextmenüeintrag „Annotationen“ → „Annotieren“ aus. Das Schriftstück wird in das Format für das Annotieren konvertiert und im Viewer geöffnet.
4. Bringen Sie die gewünschten Annotationen an und schließen Sie das Schriftstück.

### Ergebnis:

- Es wird ein zusätzliches Symbol bei dem Schriftstück angezeigt, um anzuzeigen, dass Annotationen auf diesem Schriftstück vorhanden sind.
**Hinweis:** Ist das Schriftstück in einem Dokument abgelegt, wird das zusätzliche Symbol ebenfalls bei dem Dokument angezeigt.

- Der eigentliche Inhalt des Schriftstücks wird nicht verändert, da Annotationen separat gespeichert werden.
**Hinweis:** Da die Annotationen separat zum eigentlichen Inhalt des Schriftstücks gespeichert werden, wird beim Öffnen des Schriftstücks zum Lesen oder Bearbeiten auch der Inhalt ohne Annotationen lesend bzw. bearbeitend geöffnet.

## 3.6.3.2 Annotationswerkzeuge

Nachdem das Menü „Annotieren“ bzw. der Arbeitsschritt ausgeführt wurde, stehen folgende Annotationswerkzeuge zur Verfügung:

### 3.6.3.2.1 Hand

Das „Hand“-Werkzeug erlaubt das Verschieben von bereits erstellen Annotationen.

1. Wählen Sie zuerst das „Hand“-Werkzeug aus.
2. Markieren Sie hierzu durch einfaches Anklicken die zu verschiebende Annotation.
3. Verschieben Sie diese bei gedrückter linker Maustaste.

![img-5.jpeg](img-5.jpeg)

### 3.6.3.2.2 Textannotation

Mit dem „Textannotation“-Werkzeug kann für eine bestimmte Textpassage eine Textannotation angebracht werden. Hierzu wird nach dem markieren der Textpassage ein Textfeld zur Eingabe der Textannotation geöffnet.

Benutzerhilfe

<!-- PDF page 228 -->

![img-6.jpeg](img-6.jpeg)

1. Wählen Sie zuerst das „Textannotation"-Werkzeug aus.
2. Markieren Sie anschließend den Text, zu welcher Sie eine Textannotation anbringen wollen.
3. Geben Sie einen Text in dem geöffneten Textfeld ein und drücken Sie auf Speichern.

## 3.6.3.2.3 Hervorheben

Das „Hervorheben"-Werkzeug ermöglicht das farbliche Hervorheben spezifischer Textpassagen.

![img-7.jpeg](img-7.jpeg)

1. Wählen Sie zuerst das „Hervorheben"-Werkzeug aus.
2. Wenn nicht die gewünschte Farbe im „Farbauswahl"-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl" beschrieben.
3. Markieren Sie anschließend die gewünschte Textpassage.

## 3.6.3.2.4 Freihandhervorheben

![img-8.jpeg](img-8.jpeg)

Das „Freihandhervorheben"-Werkzeug ermöglicht das farbliche Hervorheben durch freihandziehen der Maus.

1. Wählen Sie zuerst das „Freihandhervorheben"-Werkzeug aus.

Benutzerhilfe

<!-- PDF page 229 -->

2. Wenn nicht die gewünschte Farbe im „Farbauswahl“-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl“ beschrieben.
3. Markieren Sie anschließend die gewünschte Stelle.

## 3.6.3.2.5 Linie

Das „Linien“-Werkzeug ermöglicht das Zeichnen von Linien im Schriftstück. Die Linie wird über dem Inhalt erstellt.

![img-9.jpeg](img-9.jpeg)

## Lorem Ipsum

Lorem ipsum dolor sit amet, consetetur sadipscing elitr, se labore et dolore magna aliquyam erat, sed diam voluptua. dolores et ea rebum. Stet clita kasd gubergren, no sea taki amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.

1. Wählen Sie zuerst das „Linien“-Werkzeug aus.
2. Wenn nicht die gewünschte Farbe im „Farbauswahl“-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl“ beschrieben.
3. Wählen Sie Startpositionen der Linie und ziehen Sie bei gedrückter linker Maustaste die Linie.
4. Lassen Sie die linke Maustaste los, wenn Sie der Mauszeiger die gewünschte Zielposition erreicht hat.

## 3.6.3.2.6 Rechteck (gefüllt)

Das Erstellen von gefüllten Rechtecken ist mit dem „Rechteck (gefüllt)“-Werkzeug möglich. Das Rechteck verdeckt Inhalte.

1. Wählen Sie zuerst das „Rechteck (gefüllt)“-Werkzeug aus.
2. Wenn nicht die gewünschte Farbe im „Farbauswahl“-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl“ beschrieben.
3. Wählen Sie Startpositionen des Rechtecks und ziehen Sie bei gedrückter linker Maustaste das Rechteck.
4. Lassen Sie die linke Maustaste los, wenn das Rechteck die gewünschte Größe erreicht hat.

Benutzerhilfe
229

<!-- PDF page 230 -->

![img-10.jpeg](img-10.jpeg)

## 3.6.3.2.7 Rechteck

Im Gegensatz zum „Rechteck (gefüllt)“-Werkzeug, wird beim „Rechteck“-Werkzeug nur der Rand des Rechtecks gezeichnet.

![img-11.jpeg](img-11.jpeg)

1. Wählen Sie zuerst das „Rechteck“-Werkzeug aus.
2. Wenn nicht die gewünschte Farbe im „Farbauswahl“-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl“ beschrieben.
3. Wählen Sie Startpositionen des Rechtecks und ziehen Sie bei gedrückter linker Maustaste das Rechteck.
4. Lassen die linke Maustaste los, wenn das Rechteckt die gewünscht Größe erreicht hat.

## 3.6.3.2.8 Post-it

Ein „Post-it“ kann an jeder Stelle des Schriftstücks platziert werden und ist somit im Gegensatz zur „Textannotation“ nicht an Text gebunden. Der Inhalt des „Post-its“ ist jederzeit änderbar.

![img-12.jpeg](img-12.jpeg)

1. Wählen Sie das „Post-it“-Werkzeug aus.
2. Wenn nicht die gewünschte Farbe im „Farbauswahl“-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl“ beschrieben.

Benutzerhilfe

<!-- PDF page 231 -->

3. Bringen Sie das „Post-it“ mit einem Klick mit der linken Maustaste an der gewünschten Position an.
4. Ändern Sie den Inhalt des „Post-its“.

## 3.6.3.2.9 Freihandzeichnung

Das „Freihandzeichnung“-Werkzeug erlaubt das Anbringen von selbst gezeichneten Annotationen.

![img-13.jpeg](img-13.jpeg)

1. Wählen Sie das „Freihandzeichnung“-Werkzeug.
2. Wenn nicht die gewünschte Farbe im „Farbauswahl“-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl“ beschrieben.
3. Halten Sie zum Zeichnen die linke Maustaste gedrückt.
4. Lassen Sie die linke Maustaste los, wenn sie mit der Zeichnung fertig sind.

## 3.6.3.2.10 Farbauswahl

![img-14.jpeg](img-14.jpeg)

Durch die „Farbauswahl“ können Annotationen in verschiedenen Farben angebracht werden. Dazu muss vor dem Anbringen der Annotation die gewünschte Farbe in der „Farbauswahl“ getroffen werden.

1. Klicken Sie auf „Farbauswahl“.
2. Wählen Sie die gewünschte Farbe.

**Hinweis:** Das Farbauswahl-Control sieht je nach verwendetem Browser unterschiedlich aus.

Benutzerhilfe

<!-- PDF page 232 -->

Benutzerhilfe
232

# 3.6.3.2.11 Einfärben

Mit dem „Einfärben“-Werkzeug können die Farben bestehender Annotationen nachträglich geändert werden.

![img-15.jpeg](img-15.jpeg)

1. Wählen Sie das „Einfärben“-Werkzeug aus.
2. Wenn nicht die gewünschte Farbe im „Farbauswahl“-Werkzeug ausgewählt wurde, ändern Sie diese wie in 3.6.3.2.10 „Farbauswahl“ beschrieben.
3. Markieren Sie durch einfaches Anklicken die Annotation, deren Farbe Sie ändern wollen.

# 3.6.3.2.12 Löschen

Das Entfernen von bereits erstellen Annotationen ist mit dem „Löschen“-Werkzeug möglich.

![img-16.jpeg](img-16.jpeg)

1. Wählen Sie zuerst das „Löschen“-Werkzeug.
2. Selektieren Sie dann die zu löschende Annotation.

# 3.6.3.2.13 Stempel

Mit dem „Stempel“-Werkzeug können konfigurierte Stempel am Schriftstück angebracht werden.

1. Nach dem Selektieren des „Stempel“-Werkzeugs öffnet sich der Stempelauswahl-Dialog.

<!-- PDF page 233 -->

Benutzerhilfe
233

![img-17.jpeg](img-17.jpeg)

Abbrechen

2. Nachdem ein Stempel ausgewählt wurde, kann dieser durch einen Klick auf das Dokument angebracht werden.

![img-18.jpeg](img-18.jpeg)

Hinweis: Die Farbe des Stempels kann nicht durch die „Farbauswahl“ geändert werden. Diese ist beim Stempel-Objekt hinterlegt.

Hinweis: Die 3 Stempel „EINGANG GESICHTET“, „RECHNERISCH RICHTIG“ und „SACHLICH RICHTIG“ stehen jedem Benutzer zur Verfügung. Zusätzliche Stempel können in der Eigenschaft „Stempel“ in der „Arbeitsumgebung“ aus Dateien im PNG-Format erstellt werden.

### 3.6.3.2.14 Aktive Ebene

Jede Annotation wird auf genau einer Ebene (der aktiven Ebene) angebracht. Welche Ebene gerade aktiv ist, ist in der Annotationswerkzeugleiste ersichtlich.

<!-- PDF page 234 -->

Benutzerhilfe
234

![img-19.jpeg](img-19.jpeg)

# Lorem Ipsum

Lorem ipsum dolor sit amet, consetetur sadipscing elitr, se labore et dolore magna aliquyam erat, sed diam voluptua. dolores et ea rebum. Stet clita kasd gubergren, no sea taki amet. Lorem ipsum dolor sit amet, consetetur sadipscing e

Die aktive Ebene kann gewechselt werden.

1. Klicken Sie auf „Aktive Ebene".
2. Im sich öffnendem Dialog „Aktive Ebene auswählen" wählen Sie die Ebene aus, die aktiv sein soll.

Aktive Ebene auswählen

X

Wählen Sie die Ebene aus, die aktiv sein soll. Neue Annotationen werden immer auf der gerade aktiven Ebene angebracht.

[tbl-0.md](tbl-0.md)

Abbrechen
Neue Ebene

## 3.6.3.2.15 Neue Ebene erstellen

Für jeden Benutzer, der das Menü „Annotieren" auf ein Schriftstück ausführt, wird eine neue Ebene erstellt. Zusätzlich können manuell neue Ebenen erzeugt werden.

1. Klicken Sie auf „Aktive Ebene".
2. Im sich öffnendem Dialog „Aktive Ebene auswählen" klicken Sie auf „Neue Ebene".

<!-- PDF page 235 -->

Aktive Ebene auswählen

X

Wählen Sie die Ebene aus, die aktiv sein soll. Neue Annotationen werden immer auf der gerade aktiven Ebene angebracht.

![img-20.jpeg](img-20.jpeg)

3. Vergeben Sie einen Namen, wählen Sie eine Farbe und wählen Sie aus, ob die Ebene Privat (nur für Sie sichtbar) sein soll. Mit einem Klick auf „Weiter“ wird die neue Ebene erzeugt.

![img-21.jpeg](img-21.jpeg)

## 3.6.3.2.16 Sichtbare Ebenen auswählen

Annotationen können gefiltert werden, falls nur bestimmte Annotationen dargestellt werden sollen.

1. Mit einem Klick auf „Ebenen“ öffnet sich die Auswahl der sichtbaren Ebenen.

Benutzerhilfe

<!-- PDF page 236 -->

Akto e Ebene: Kairz0001, Regina

# Lorem Ipsum

Lorem ipsum dolor sit amet, consetetur sadipscing elitr, se labore et dolore magna aliquyam erat, sed diam voluptua. dolores et ea rebum. Stet clita kasd gubergren, no sea taki amet. Lorem ipsum dolor sit amet, consetetur sadipscing e

# Sichtbare Ebenen auswählen

Wählen Sie die Ebenen aus, die sichtbar sein sollen. Eine Mehrfachmarkierung kann durch das Markieren der Checkboxen ausgeführt werden. Die gerade aktive Ebene ist immer sichtbar und ist in der Liste daher nicht enthalten.

![img-22.jpeg](img-22.jpeg)

# Schließen

2. Wählen Sie alle Ebenen aus, die sichtbar sein sollen und Schließen Sie den Dialog mit einem Klick auf „Schließen“.

**Hinweis:** Die gerade aktive Ebene ist immer sichtbar und wird im Dialog daher nicht zur Selektion angeboten.

## 3.6.3.3 Lesen von Annotationen

Beim Lesen einer Annotation wird das Schriftstück nicht gesperrt, dies bietet die Möglichkeit, die Kommentare der Annotationen anzuzeigen und gleichzeitig das Schriftstück zu bearbeiten.

### Eine Annotation über das Kontextmenü lesen

Um eine Annotation über das Kontextmenü einzusehen gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das annotierte Schriftstück.
2. Öffnen Sie das Kontextmenü mittels der rechten Maustaste und wählen Sie den Kontextmenüeintrag „Annotationen“ aus.

**Ergebnis:** Das Schriftstück wird mit den angebrachten Annotationen lesend geöffnet. Dadurch haben Sie die Möglichkeit, das Schriftstück selbst bearbeitend zu öffnen.

## 3.6.3.4 Annotationen löschen

Wenn Annotationen nicht länger benötigt werden, können diese wieder gelöscht werden.

Benutzerhilfe

<!-- PDF page 237 -->

Benutzerhilfe
237

# Annotationen über das Kontextmenü löschen

1. Lokalisieren Sie das annotierte Schriftstück.
2. Öffnen Sie das Kontextmenü mittels der rechten Maustaste und wählen Sie den Kontextmenüeintrag „Annotationen“ → „Annotationen löschen“ aus.

## Ergebnis:

- Alle Annotationen des Schriftstücks werden gelöscht.
- Das Symbol des SchriftstückS, welches auf Annotationen hinweist, wird entfernt.
**Hinweis:** Sollte sich das Schriftstück in einem Dokument befinden, wird das zusätzliche Symbol ebenfalls bei dem Dokument entfernt.

## 3.6.3.5 Ebenen löschen

Wenn Ebenen nicht länger benötigt werden, können diese wieder gelöscht werden.

1. Lokalisieren Sie das annotierte Schriftstück.
2. Öffnen Sie das Kontextmenü mittels der rechten Maustaste und wählen Sie den Kontextmenüeintrag „Annotationen“ → „Ebenen löschen“ aus.
3. Selektieren Sie die gewünschte/n Ebene/n und betätigen Sie die Schaltfläche „Markierte Ebenen Löschen“. Sollen alle Ebenen gelöscht werden, kann alternativ die Schaltfläche „Alle Ebenen Löschen“ ausgeführt werden.

![img-23.jpeg](img-23.jpeg)

## Ergebnis:

- „Alle Ebenen Löschen“ wurde ausgeführt: Alle Annotations-Ebenen des Schriftstücks werden gelöscht.
- „Markierte Ebenen Löschen“ wurde ausgeführt: Die selektierten Annotations-Ebenen des Schriftstücks werden gelöscht.

<!-- PDF page 238 -->

Benutzerhilfe
238

# 3.6.3.6 PDF mit Annotationen exportieren

Annotationen können zur Weiterverarbeitung in ein eigenes PDF Objekt exportiert werden.

1. Lokalisieren Sie das annotierte Schriftstück.
2. Öffnen Sie das Kontextmenü mittels der rechten Maustaste und wählen Sie den Kontextmenüeintrag „Annotationen“ → „Annotationen fixieren“ aus.
3. Selektieren Sie die gewünschte/n Ebene/n und betätigen Sie die Schaltfläche „Markierte Ebenen exportieren“. Sollen alle Ebenen exportiert werden, kann alternativ die Schaltfläche „Alle Ebenen exportieren“ ausgeführt werden.

![img-24.jpeg](img-24.jpeg)

Hinweis: Der Dialog wird nur angezeigt, wenn mehrere Ebenen vorhanden sind.

4. Führen Sie die gewünschte Schaltfläche im Dialog „Annotiertes Objekt ablegen“ aus.

![img-25.jpeg](img-25.jpeg)

# Ergebnis:

- „Am Schreibtisch speichern“ wurde ausgeführt: Erzeugtes PDF Objekt wird am Schreibtisch des Benutzers abgelegt.

<!-- PDF page 239 -->

- „Im Geschäftsobjekt registrieren“ wurde ausgeführt: Erzeugtes PDF Objekt wird im aktuellen Geschäftsobjekt abgelegt.
**Hinweis:** Die Schaltfläche „Im Geschäftsobjekt registrieren“ wird nur angezeigt, wenn das Schriftstück ein Geschäftsobjekt besitzt.
- „Herunterladen“ wurde ausgeführt: Das erzeugte PDF wird heruntergeladen.
- „Weiter“ wurde ausgeführt: Der Dialog wird verlassen.

## 3.6.4 Schwärzen von Schriftstücken

Inhalte von Schriftstücken können mit Hilfe der Annotationsfunktion geschwärzt und digital geschwärzt exportiert werden.

**Hinweis:** Um Schwärzungen an einem Schriftstück anbringen, lesen bzw. löschen zu können, muss in der Domäne bzw. in der Arbeitsumgebung oder im Mandanten des Benutzers die Eigenschaft „Annotationssoftware“ auf „Browser“ gestellt werden.

## 3.6.4.1 Ein Schriftstück schwärzen

Um ein Schriftstück zu schwärzen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück, das geschwärzt werden soll.
2. Öffnen Sie das Kontextmenü des Schriftstücks durch Klick mit der rechten Maustaste.
3. Wählen Sie den Kontextmenüeintrag „Schwärzungen“ → „Schwärzen“ aus.
4. Tragen Sie einen Namen für die Schwärzung ein.
5. Schwärzen Sie die gewünschten Inhalte und schließen Sie das Schriftstück.

### Ergebnis:

- Es wird ein zusätzliches Symbol ☐ bei dem Schriftstück angezeigt, um anzuzeigen, dass Schwärzungen auf diesem Schriftstück vorhanden sind.
**Hinweis:** Ist das Schriftstück in einem Dokument abgelegt, wird das zusätzliche Symbol ebenfalls bei dem Dokument angezeigt.
- Der eigentliche Inhalt des Schriftstücks wird nicht verändert, da Schwärzungen separat gespeichert werden.
**Hinweis:** Da die Schwärzungen separat zum eigentlichen Inhalt des Schriftstücks gespeichert werden, wird beim Öffnen des Schriftstücks zum Lesen oder Bearbeiten auch der Inhalt ohne Schwärzungen lesend bzw. bearbeitend geöffnet.

**Hinweis:** Auf die gleiche Weise wie bei Annotationen können einzelne Schwärzungen über die Funktion „Löschen“ gelöscht werden. Weitere Informationen siehe Kapitel 3.6.3 „Annotationen auf Schriftstücken“.

## 3.6.4.2 Anbringen von Schwärzungen

Schwärzungen können auf drei Arten angebracht werden.

### Schwärzen

Benutzerhilfe
239

<!-- PDF page 240 -->

![img-26.jpeg](img-26.jpeg)

Mit dem „Schwärzen“-Werkzeug kann eine Schwärzung für eine spezifische Textpassage angebracht werden. Gehen Sie folgendermaßen vor:

1. Wählen Sie das „Schwärzen“-Werkzeug.
2. Markieren Sie die zu schwärzende Textpassage.

**Ergebnis:** Der von Ihnen markierte Text wird gräulich hinterlegt.

## Rechteck (gefüllt)

![img-27.jpeg](img-27.jpeg)

Mit dem „Rechteck (gefüllt)“-Werkzeug können auch Bilder geschwärzt werden. Gehen Sie folgendermaßen vor:

1. Wählen Sie das „Rechteck (gefüllt)“-Werkzeug.
2. Markieren Sie den zu schwärzenden Bereich.

**Ergebnis:** Der von Ihnen markierte Bereich wird gräulich hinterlegt.

## Schwärzen über die Suche

![img-28.jpeg](img-28.jpeg)

Benutzerhilfe
240

<!-- PDF page 241 -->

Mit dem „Dokument durchsuchen“-Werkzeug kann nach einem Suchbegriff im Dokument gesucht werden und auf die Vorkommnisse eine Schwärzung durchgeführt werden. Gehen Sie folgendermaßen vor:

1. Wählen Sie das „Dokument durchsuchen“-Werkzeug.
2. Geben Sie einen Suchbegriff ein. Es erfolgt automatisch die Suche nach dem Begriff.
3. Klicken Sie auf die Schaltfläche „Schwärzen“ im Suchdialog um das aktuelle Sucherergebnis zu schwärzen und das nächste Vorkommnis des Suchbegriffs zu finden.

![img-29.jpeg](img-29.jpeg)

Ergebnis: Der von Ihnen markierte Text wird gräulich hinterlegt.

Das Anbringen von Schwärzungen kann mittels Regel für Schwärzungen unterstützt werden. Anhand von Regeln werden im Viewer bei der Suche, Vorschläge für Suchbegriffe unterbreitet. Voraussetzung für die Verwendung der Funktionalität ist, dass „Regeln für Schwärzungen“ konfiguriert sind (siehe 5.7.4 Konfiguration von Regeln für Schwärzung) und die Vorbedingungen der Regeln erfüllt sind. Wenn Regeln zur Verfügung stehen, können diese vor dem Anbringen der Schwärzung ausgewählt werden:

![img-30.jpeg](img-30.jpeg)

Im Viewer stehen die durch die Regeln evaluierten Vorschläge im Suchdialog zur Verfügung:

![img-31.jpeg](img-31.jpeg)

Benutzerhilfe
241

<!-- PDF page 242 -->

Durch Klick auf einen Vorschlag, wird der Vorschlag als Suchbegriff eingefügt und die Suche wird automatisch gestartet.

Wenn ein Vorschlag abgearbeitet wurde, kann dies mittels eines Klicks auf die Box neben dem jeweiligen Vorschlag rein optisch gekennzeichnet werden:

![img-0.jpeg](img-0.jpeg)

Die als abgearbeitet gekennzeichneten Vorschläge können mittels der Einstellung „Versteckte abgearbeitete Vorschläge“ bei Bedarf ausgeblendet werden:

![img-1.jpeg](img-1.jpeg)

## 3.6.4.3 Schwärzung finalisieren

Zum Erzeugen einer digitalen Schwärzung wählen Sie das Menü „Schwärzung finalisieren“. Das Ergebnis ist eine PDF-Datei, in der Texte nicht mehr markierbar sind. Gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück, dessen Schwärzung Sie finalisieren wollen.
2. Öffnen Sie das Kontextmenü des Schriftstücks und wählen Sie den Menüeintrag „Schwärzungen“ → „Schwärzung fixieren“ aus.
3. Wählen Sie die zu finalisierende Schwärzung aus.

### Ergebnis:

- „Am Schreibtisch speichern“ wurde ausgeführt: Erzeugtes PDF Objekt wird am Schreibtisch des Benutzers abgelegt.
- „Im Geschäftsobjekt registrieren“ wurde ausgeführt: Erzeugtes PDF Objekt wird im aktuellen Geschäftsobjekt abgelegt.
**Hinweis:** Die Schaltfläche „Im Geschäftsobjekt registrieren“ wird nur angezeigt, wenn das Schriftstück ein Geschäftsobjekt besitzt.
- „Herunterladen“ wurde ausgeführt: Das erzeugte PDF wird heruntergeladen.
- „Weiter“ wurde ausgeführt: Der Dialog wird verlassen.

Benutzerhilfe

<!-- PDF page 243 -->

Benutzerhilfe

# 3.6.4.4 Schwärzung umbenennen

Bereits erstellte Schwärzungen können umbenannt werden.

1. Lokalisieren Sie das Schriftstück, dessen Schwärzung Sie umbenennen wollen.
2. Öffnen Sie das Kontextmenü des Schriftstücks und wählen Sie den Menüeintrag „Schwärzung umbenennen“ aus.
3. Wählen Sie die Schwärzung aus, welche Sie umbenennen wollen.
4. Wählen Sie einen neuen Namen aus.

**Ergebnis:** Die Schwärzung wurde umbenannt.

# 3.6.4.5 Schwärzung löschen

Bereits erstellte Schwärzungen können gelöscht werden.

1. Lokalisieren Sie das Schriftstück, dessen Schwärzung Sie löschen wollen.
2. Öffnen Sie das Kontextmenü des Schriftstücks und wählen Sie den Menüeintrag „Schwärzung löschen“ aus.
3. Markieren die Schwärzungen, welche Sie löschen wollen oder wählen Sie „Alles löschen“, wenn Sie alle Schwärzungen auf dem Schriftstück löschen wollen.
4. Bestätigen Sie die Löschung.

**Ergebnis:**

- Die Schwärzung wurde gelöscht.
- Das zusätzliche Symbol $\mathcal{L}$ welches auf Schwärzungen hinweist, wird entfernt.
**Hinweis:** Sollte sich das Schriftstück in einem Dokument befinden, wird das zusätzliche Symbol ebenfalls bei dem Dokument entfernt.

# 3.6.5 Ein Schriftstück importieren/exportieren

Ein Schriftstück kann entweder in die Fabasoft eGov-Suite Bayern importiert oder von dort exportiert werden. Nähere Informationen hierzu finden Sie im Kapitel 2.1.2.8 „Ein Objekt importieren“ bzw. im Kapitel 2.1.2.8.1 „Unterstützte Dateiformate“.

# 3.6.5.1 Ein Papierdokument über (Massen-)Scanning erfassen

Papiereingänge werden an dedizierten Scan-Arbeitsplätzen durch Scannen in elektronische Schriftstücke überführt, die auf elektronischem Weg nach vordefinierten Regeln in Postkörbe (eine Sammlung von Schriftstücken) geordnet werden.

Für Massen-Scanning ist der Einsatz dedizierter Scan-Arbeitsplätze vorgesehen, auf denen das Produkt Kofax Ascent Capture installiert ist. Der Scan-Vorgang wird aus der Benutzeroberfläche von Kofax Ascent Capture aktiviert.

Funktionen für die Massendatenerfassung in Bezug auf Scannen von Papierdokumenten werden ressortspezifisch für bestimmte Scan-Arbeitsplätze im Rahmen der dafür definierten Funktionalität von Kofax Ascent Capture mittels Übergabeskript zur Verfügung gestellt.

243

<!-- PDF page 244 -->

Wird ein Papiereingang in der zentralen Posteingangsstelle eingescannt, so kann das Dokument der zuständigen Organisationseinheit, Abteilung oder Person über den Posteingangspool zugeordnet werden. Je nach Organisationsstruktur empfiehlt es sich, für die jeweilige Organisationseinheit, Abteilung oder Person, welche diese Eingänge erfasst, einen eigenen Posteingangspool zu erzeugen. Die Posteingangsstelle kann dadurch sofort nach dem Scannen die Eingänge der richtigen Organisationseinheit zuteilen. Der Eingang wird in elektronischer Form im Posteingang der zuständigen Organisationseinheit unter „Postkorb“ angezeigt und kann sofort erfasst und mit einer Geschäftszahl versehen werden.

## 3.6.5.2 Ein Schriftstück aus Microsoft Outlook direkt einem Dokument zuordnen

Neben der Möglichkeit eine E-Mail oder ein E-Fax direkt mittels Drag &amp; Drop aus Microsoft Outlook zu importieren, können Sie eine E-Mail über die Microsoft Outlook Schaltflächen in die Fabasoft eGov-Suite Bayern importieren, einem Dokument und in weiterer Folge einem Vorgang zuordnen.

**Hinweis:** Sollten Ihnen in Microsoft Outlook die erwähnten Schaltflächen nicht zur Verfügung stehen, wenden Sie sich bitte an Ihre Administratorin bzw. Ihren Administrator.

Um eine E-Mail direkt aus Microsoft Outlook einem Dokument und in weiterer Folge einem Vorgang zuzuordnen, gehen Sie folgendermaßen vor:

1. Öffnen Sie die E-Mail oder das E-Fax, welche/s Sie in die Fabasoft eGov-Suite Bayern übernehmen möchten in Ihrem E-Mail-Programm.

![img-2.jpeg](img-2.jpeg)

2. Wählen Sie im Menü „Datei“ auf den Befehl „Erfassen“.

3. Nach dem Import der E-Mail haben Sie die Möglichkeit zu entscheiden, ob Sie die E-Mail zu einem neuen Eingangsdokument oder einer neuen Erledigung zuordnen möchten.

**Hinweis:** Sie haben im Zuge des Imports die Möglichkeit zu entscheiden, ob der Anhang der E-Mail, sofern vorhanden, als eigenständiges Objekt importiert werden soll. Siehe hierzu auch Kapitel 3.5.2 „Eine E-Mail aus Microsoft Office Outlook in die Fabasoft eGov-Suite Bayern erfassen“.

**Hinweis:** Sollten Sie die E-Mail getrennt zum Inhalt importieren, können Sie entscheiden, ob Sie eine Sammelerfassung oder eine Einzelerfassung durchführen

Benutzerhilfe
244

<!-- PDF page 245 -->

möchten. Siehe hierzu auch Kapitel 3.5.3 „Eine Sammelerfassung durchführen" und Kapitel 3.5.4 „Eine Einzelerfassung durchführen".

4. Erfassen Sie die Metadaten des Dokuments und schließen Sie die Erzeugung durch Klick auf die Schaltfläche „Weiter" ab.

Ergebnis: Die neuen Dokumente werden in dem ausgewählten Container abgelegt.

Hinweis: Wenn Sie eine E-Mail als Schriftstück importieren wollen, oder einem bestehenden Dokument zuordnen möchten, beachten Sie die Beschreibung im Kapitel 2.1.2.8.2 „Ein Objekt über die Office Button Funktion „Ablegen" importieren".

Hinweis: Der Befehl „Erfassen" steht auch in anderen Microsoft Office Produkten, wie z.B. Microsoft Office Word, zur Verfügung.

## 3.6.6 Ein Schriftstück löschen oder stornieren

Schriftstücke können über den Menü- bzw. Kontextmenübefehl „Löschen" gelöscht bzw. in den Papierkorb verschoben werden (siehe Kapitel 2.1.2.1 „Ein Objekt löschen").

Die Stornierung eines Schriftstücks oder Dokuments erfolgt durch die Unterschrift „Stornieren" (siehe Kapitel 2.1.2.10 „Eine Unterschrift auf einem Objekt anbringen"). Wenn ein Schriftstück storniert wird, bewirkt dies Folgendes:

- Die Stornierung wird in den Metadaten des Schriftstücks vermerkt.
- Eine Version des Schriftstücks wird gesichert.
- Das Symbol des Schriftstücks wird geändert, damit stornierte Schriftstücke optisch erkennbar sind.
- Eine Stornierung kann durch die Unterschrift „Stornierung aufheben" wieder rückgängig gemacht werden (siehe Kapitel 2.1.2.10 „Eine Unterschrift auf einem Objekt anbringen").
- Stornierte Schriftstücke können weiterhin über die Suche gefunden und in eine Liste übernommen werden.

Hinweis: Stornierte Objekte werden in die Liste der stornierten Objekte verschoben. Diese Liste steht als eigene Registerkarte am jeweiligen Vorgang zur Verfügung.

![img-3.jpeg](img-3.jpeg)

## 3.6.7 Ein Schriftstück direkt zu einem Vorgang zuordnen

Um ein Schriftstück direkt einem Vorgang zuzuordnen, gehen Sie folgendermaßen vor:

Benutzerhilfe

<!-- PDF page 246 -->

1. Lokalisieren Sie das Schriftstück, das Sie zu einem Vorgang hinzufügen möchten und klicken Sie auf den Kontextmenüeintrag „Erfassen“ bzw. im Postkorb auf die Schaltfläche „Erfassen“.

![img-4.jpeg](img-4.jpeg)

2. Erfassen Sie die Metadaten des neuen Eingangsdokuments und klicken Sie auf „Weiter“. Hinweis: Bei einer Erfassung mehrerer Schriftstücke wird, wenn Sie im Dialog auf „Nein, Einzelerfassung durchführen“ klicken, für jedes Schriftstück ein neues Eingangsdokument angelegt, es erscheint also für jedes Schriftstück eine Maske mit den Metadaten eines neuen Eingangsdokuments. Wenn Sie im Dialog auf „Ja, Sammelerfassung durchführen“ klicken, wird lediglich ein Eingangsdokument erzeugt, welches alle gewählten Schriftstücke enthält.

Hinweis: Weiters haben Sie die Möglichkeit, ein Schriftstück direkt in einen Vorgang zu importieren oder das aus dem lokalen Dateisystem in Microsoft Office geöffnete Schriftstück importieren. Siehe hierzu die Kapitel 3.6.5.2 „Ein Schriftstück aus Microsoft Outlook direkt einem Dokument zuordnen“ und 2.1.2.8 „Ein Objekt importieren“.

## 3.6.8 Ein zugeordnetes Schriftstück einem Dokument als Kopie hinzufügen

Um das zugeordnete Schriftstück einem Dokument hinzuzufügen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Schriftstück, das Sie in das Dokument einfügen wollen und markieren Sie dieses.
2. Klicken Sie auf die Schaltfläche „Kopieren“, um das Objekt in die Zwischenablage zu kopieren.
3. Lokalisieren Sie das Dokument, in das Sie das Schriftstück hinzufügen möchten.
4. Klicken Sie auf den Kontextmenüeintrag „In neuem Fenster öffnen“.
5. Wechseln Sie über die Schaltfläche „Listenansicht“ in die Listenansicht, sollte die PDF-Übersicht angezeigt werden.
6. Klicken Sie auf die Schaltfläche „Duplikat einfügen“, um eine Kopie im Dokument einzufügen.

Benutzerhilfe

<!-- PDF page 247 -->

Hinweis: Der Befehl „Verknüpfung einfügen“ fügt das Originalobjekt ein, d.h. es wird nur auf das eigentliche Objekt verwiesen und das Schriftstück umgeschrieben, sollte es bereits einem Dokument zugewiesen sein. Ist ein Schriftstück bereits einem Dokument zugeordnet, wird, wenn der Befehl „Verknüpfung einfügen“ gewählt wird, ein Dialog angezeigt, der die Möglichkeit bietet, das Schriftstück umzuschreiben oder ein Duplikat des Schriftstücks einzufügen.

Hinweis: Ein Duplikat ist ein eigenständiges Objekt, bei dem während der Erstellung Metadaten und Inhalte übernommen wurden.

## 3.6.9 Ein Schriftstück kopieren

Ein Schriftstück kann, wie in Kapitel 2.1.2.7 „Ein Objekt kopieren und einfügen“ beschrieben, kopiert und eingefügt werden. Zum Beispiel kann ein Schriftstück vom Schreibtisch in ein Dokument kopiert und eingefügt werden.

Hinweis: Der Befehl „Verknüpfung einfügen“ fügt das Originalobjekt ein, d.h. es wird nur auf das eigentliche Objekt verwiesen. Ist ein Schriftstück bereits einem Dokument zugeordnet, wird, wenn der Befehl „Verknüpfung einfügen“ gewählt wird, ein Dialog angezeigt, der die Möglichkeit bietet, das Schriftstück umzuschreiben oder ein Duplikat des Schriftstücks einzufügen.

## 3.6.10 Einen Postkorb auswählen

Stehen für einen Benutzer aufgrund entsprechender Zugriffsberechtigungen und Konfiguration mehrere Postkörbe zur Verfügung, so kann innerhalb des „Postkörbe“ Widget zwischen den verschiedenen Postkörben gewechselt werden.

![img-5.jpeg](img-5.jpeg)

Hinweis: Postkörbe können in der Arbeitsumgebung eines Benutzers und bei Organisationseinheiten definiert werden.

## 3.6.11 Ein Schriftstück aus dem Postkorb löschen

Sie haben die Möglichkeit, Schriftstücke aus dem Postkorb zu löschen. Gehen Sie hierzu folgendermaßen vor:

1. Wechseln Sie in Ihren Postkorb. (Widget „Postkörbe“).
2. Selektieren Sie das bzw. die zu löschenden Schriftstück/e.
3. Wählen Sie im Menü „Objekt“ den Menüpunkt „Löschen“ aus.

Benutzerhilfe

<!-- PDF page 248 -->

4. Bestätigen Sie die Frage, ob Sie das Objekt löschen möchten.
**Hinweis:** Sollte ein globaler Papierkorb eingerichtet sein, werden Sie gefragt, ob Sie das Schriftstück in den globalen Papierkorb legen möchten.

## 3.7 Status eines Geschäftsobjekts

In der Fabasoft eGov-Suite Bayern erhalten Geschäftsobjekte im Zuge der Bearbeitung verschiedene Status. Im Zuge der Weiterentwicklung wurde der Status durch die Eigenschaften Status und Bearbeitungsstatus ersetzt, um einen genauen Überblick über den aktuellen Status des Geschäftsobjekts zu ermöglichen. In der folgenden Tabelle wird erläutert, welchen Status ein Geschäftsobjekt bei einem Ereignis erhält.

[tbl-0.md](tbl-0.md)

Benutzerhilfe
248

<!-- PDF page 249 -->

[tbl-1.md](tbl-1.md)

## 3.8 XDOMEA

Hinweis: Weiterführende Informationen zu den übergebenen Feldern bzw. Metadaten sowie zu technischen Details können auf der Webseite https://www.xrepository.de/Inhalt/urn:uuid:84876825-9c36-4e33-ae24-95d14a39467b.xhtml eingesehen werden.

## 3.8.1 XDOMEA Paket importieren

Um ein XDOMEA Paket in die Fabasoft eGov-Suite Bayern zu importieren, gehen Sie folgendermaßen vor:

1. Gehen Sie wie in Kapitel 2.1.2.8 „Ein Objekt importieren“ beschrieben vor und befolgen Sie die Anweisungen, die in diesem Kapitel zu finden sind.
Hinweis: Da es sich bei dem importierten Objekt im Dateisystem um ein ZIP-Paket handelt, überprüft die Fabasoft eGov-Suite Bayern die importierte Datei, um korrekt ein Objekt des Typs „XDOMEA Paket“ erzeugen zu können bzw. aus anderen ZIP-Paketen, welche kein XDOMEA Paket enthalten, ein Objekt des Typs „Zip-Objekt“ zu erzeugen.

2. Klicken Sie auf den Kontextmenübefehl „Abgabe laden“. Durch die Ausführung dieses Befehls werden die zu importierenden Objekte (Akten, Vorgänge und Dokumente) in der Datei erzeugt.
Hinweis: Standardmäßig wird jedes Dokument als Eingangsdokument importiert.

3. Klicken Sie auf den Kontextmenübefehl „Eigenschaften bearbeiten“ und wechseln Sie auf die Registerkarte „XDOMEA Import“, um die importierten Objekte einzusehen.

Hinweis: Sollte eine Zuordnung zu einem Aktenplankennzeichen, einer Akte oder einem Vorgang notwendig sein, wird dies direkt im Zuge des Ladens des XDOMEA Pakets für jedes Objekt von dem Benutzer verlangt.

Hinweis: Beim Importieren eines XDOMEA Pakets werden die Werte für Nachrichtengruppe, Nachricht automatisch gesetzt.

Hinweis: Beim Import eines XDOMEA Pakets werden auch Empfänger- und Absenderinformationen des XDOMEA Pakets übernommen.

## 3.8.2 XDOMEA Paket exportieren

Für den Export von XDOMEA Paketen gibt es drei unterschiedliche Möglichkeiten:

- Über die Aktivität Versenden mit der Versandart „Elektronische Zustellung (XML)“.
- Auf Ihrem „Schreibtisch“.

## Über die Aktivität Versenden

Benutzerhilfe

<!-- PDF page 250 -->

Um ein XDOMEA Paket über eine Aktivität Versenden zu exportieren, gehen Sie folgendermaßen vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“ und lokalisieren Sie die gewünschte Aktivität Versenden.
2. Stellen Sie sicher, dass beim gewünschten Empfänger einer Erledigung, die sich im betroffenen Vorgang befindet, die Versandart „Elektronische Zustellung (XML)“ ausgewählt wurde.
3. Klicken Sie auf den Arbeitsschritt Versand durchführen und wählen Sie die gewünschte Erledigung aus. Jene Absender, bei denen in der Versandart der Eintrag „Elektronische Zustellung (XML)“ ausgewählt wurde, erhalten ein XDOMEA Paket nach der Abfertigung einer Reinschrift.

## Über Ihren „Schreibtisch“

Um ein XDOMEA Paket am „Schreibtisch“ zu exportieren, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Erzeugen Sie mithilfe der Anleitung in Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ ein neues Objekt vom Typ „XDOMEA Paket“.
**Hinweis:** Im Feld XDOMEA Export Objekte auf der Registerkarte „XDOMEA Export“ müssen zu exportierende Objekte festgelegt werden.
3. Führen Sie den Kontextmenübefehl „XDOMEA Paket übermitteln“ aus, warten Sie, bis das System den Vorgang abgeschlossen hat und klicken Sie im angezeigten Dialog auf die Schaltfläche „Herunterladen“.
4. Nutzen Sie die Speicherfunktionalität Ihres Browsers (Microsoft Edge, Firefox, etc.), um die Datei in Ihrem lokalen Dateisystem zu speichern.

## 3.9 Allgemeine Funktionen zu Dokumenten

### 3.9.1 Die Metadaten eines Dokuments lesen und bearbeiten

Die Metadaten eines Dokuments können von Benutzern im Rahmen ihrer Zugriffsrechte, wie in den Kapiteln 2.1.2.2 „Die Metadaten eines Objekts lesen“ und 2.1.2.3 „Die Metadaten eines Objekts bearbeiten“ beschrieben, gelesen bzw. bearbeitet werden.

### 3.9.2 Ein Dokument stornieren

Um ein Dokument zu stornieren, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Dokument, das storniert werden soll.
2. Öffnen Sie das Kontextmenü des Dokuments, klicken Sie auf den Eintrag „Unterschriften“ und führen Sie die Unterschrift „Stornieren“ aus.

**Ergebnis:**

- Das Symbol des Dokuments wird geändert.
- Die Stornierung wird in den Metadaten des Dokuments auf der Registerkarte „Unterschriften“ im Feld Unterschriften vermerkt.

Benutzerhilfe
250

<!-- PDF page 251 -->

- Es wird eine Version des Dokuments gesichert.
- Ist das Dokument einem Vorgang zugeordnet, wird es in die Liste der stornierten Objekte verschoben.

Hinweis: Wird ein Dokument storniert, so werden auch alle darin enthaltenen Schriftstücke storniert.

## 3.9.3 Die Stornierung eines Dokuments aufheben

Um die Stornierung eines Dokuments aufzuheben, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Dokument, dessen Stornierung aufgehoben werden soll.
2. Öffnen Sie das Kontextmenü des Dokuments, klicken Sie auf den Eintrag „Unterschriften“ und führen Sie die Unterschrift „Stornierung aufheben“ aus.

### Ergebnis:

- Das Symbol des Dokuments wird geändert.
- Das Aufheben der Stornierung wird in den Metadaten des Dokuments auf der Registerkarte „Unterschriften“ im Feld Unterschriften vermerkt.
- Es wird eine Version des Dokuments gesichert.
- Ist das Dokument einem Vorgang zugeordnet, wird es aus der Liste der stornierten Objekte entfernt.

## 3.9.4 Zulässige Schriftstück Objektklassen

Bei den zulässigen Objektklassen innerhalb von Schriftstücken wird zwischen Erzeugen (Erzeugen Dialog) und Einfügen (Suche, Duplizieren und Verknüpfung einfügen) unterschieden. Direkt erzeugen lässt sich nur eine bestimmte Auswahl an Objektklassen jener Klassen, die auch beim Einfügen erlaubt sind. Der Hintergrund hierfür ist, dass z.B. ein E-Mail Objekt selten direkt erzeugt wird (statt dessen werden bereits vorhandene Mails importiert) und durch das Ausblenden solcher Objektklassen der Erzeugen Dialog weitaus übersichtlicher wird.

## 3.10 Aussonderung und Auslagerung

Das 4-stufige Aussonderungsverfahren kann über die XDOMEA 2.1 Schnittstelle durchgeführt werden. Die Voraussetzung dafür ist, dass das Zielarchiv diese Schnittstelle unterstützt und auch standardkonforme XDOMEA Pakete zurückliefert.

Die Aussonderung mit XDOMEA kann über das Widget Aussonderung durchgeführt werden.

Hinweis: Die Fabasoft eGov-Suite Bayern setzt bei den XDOMEA Pakten, welche im Rahmen der Aussonderung in der Fabasoft eGov-Suite Bayern erzeugt werden die Nachrichtengruppe und die Nachricht automatisch.

Es stehen eine manuelle sowie eine automatische Aussonderung zur Verfügung, die Vorgehensweisen werden in den folgenden Kapiteln beschrieben.

Die notwendigen Konfigurationen zur Aussonderung werden im Kapitel 5.4 „Aussonderung“ beschrieben.

Benutzerhilfe
251

<!-- PDF page 252 -->

Benutzerhilfe

# 3.10.1 Manuelle Aussonderung

Die Aussonderung kann bei deaktivierter automatischer Aussonderung folgendermaßen durchgeführt werden:

## 3.10.1.1 Erstellung einer geplanten Aussonderung

Als Startpunkt für die Aussonderung müssen Sie eine geplante Aussonderung erzeugen. Hierfür gehen Sie wie folgt vor:

1. Wechseln Sie in das Widget „Aussonderungen“ durch einen Klick auf dieses am Homescreen.
2. Erzeugen Sie in der Registerkarte „Geplante Aussonderung“ eine neue geplante Aussonderung.
3. Definieren Sie das „Von“ und „Bis“ Datum. Dieses Datum ist für den geplanten Aussonderungstermin der betroffenen Vorgänge relevant.
4. Schließen Sie die Erstellung mit einem Klick auf die Schaltfläche „Weiter“.
5. Öffnen Sie über einen Klick die soeben erzeugte „geplante Aussonderung“.
6. Aktualisieren Sie die Ansicht. (Rechtsklick → Aktualisieren)

**Ergebnis:** Es werden alle Vorgänge angezeigt, die für diesen Aussonderungszeitraum relevant sind.

## 3.10.1.2 Objekte dem Archiv zur Bewertung übermitteln

Der erste Schritt im Aussonderungsprozess ist die Erstellung eines Anbieterverzeichnisses für das Archiv. Um dies durchzuführen gehen Sie wie folgt vor:

1. Wechseln Sie in das Widget „Aussonderungen“ durch einen Klick auf dieses am Homescreen.
2. Wechseln Sie in die gewünschte geplante Aussonderung
3. Erzeugen Sie in der Registerkarte „Verzeichnisse“ ein neues Objekt
4. Das System initialisiert die XDOMEA Nachrichtengruppe und die XDOMEA Nachricht mit den Werten „Aussonderung durchführen“ und „Anbieterverzeichnis“. Als Absender wird ihr Benutzer eingetragen.

**Hinweis:** Das System öffnet nur dann automatisiert ein Konstruktorformular für ein XDOMEA-Paket, sofern in der Domäne des Benutzers, Reiter „eGov-Suite“ sowohl der Haken bei „Verwendung von XDOMEA für die Aussonderung“ gesetzt ist sowie eine „Organisation für den XDOMEA-Empfänger“ definiert wurde. Das Setzen dieser Eigenschaften ist eine administrative Aufgabe.

5. Wählen Sie als Empfänger das gewünschte Archiv aus.
6. Auf der Registerkarte „XDOMEA Export“ sind die Vorgänge der geplanten Aussonderung vorbefüllt.

**Hinweis:** Als XDOMEA Export Objekte werden die referenzierten Akten der Vorgänge eingetragen. Die Akten werden aber nicht ausgesondert, sondern die Vorgänge. Diese sind in den „zu exportierenden Folgeobjekten“ eingetragen.

7. Beim Klick auf „Weiter“ wird das XDOMEA Paket gespeichert.

252

<!-- PDF page 253 -->

8. Öffnen Sie das Kontextmenü des XDOMEA Pakets und wählen Sie den Eintrag „XDOMEA Paket übermitteln“ aus. Jetzt wird das XDOMEA Paket generiert.
**Hinweis:** Der Name des XDOMEA Pakets ändert sich nun auf den eindeutigen Bezeichner lt. XDOMEA Spezifikation.

9. Nach dem Export haben Sie die Möglichkeit mit der Schaltfläche „Herunterladen“ das XDOMEA Paket als ZIP Archiv zu exportieren.
**Hinweis:** Das XDOMEA Paket kann mit der „Herunterladen“ Funktionalität der Fabasoft eGov-Suite auch später heruntergeladen werden.

10. Speichern Sie das XDOMEA Paket auf ihrem Computer.
**Hinweis:** Die Zustellung an das Archiv muss bei der manuellen Aussonderung organisatorisch gelöst werden.

**Ergebnis:**

- Das XDOMEA Paket wurde erzeugt und heruntergeladen und verbleibt zur Dokumentation in der Liste „Verzeichnisse“:

![img-6.jpeg](img-6.jpeg)

**3.10.1.3 Ein Bewertungsverzeichnis importieren**

Hat das Archiv die Schriftgutobjekte bewertet, übermittelt es an den Benutzer der Fabasoft eGov-Suite Bayern ein XDOMEA Paket des Typs „Bewertungsverzeichnis“. Der Import des Bewertungsverzeichnisses wird wie folgt durchgeführt:

1. Öffnen Sie das Widget „Aussonderungen“ am Homescreen.
2. Wechseln Sie in die gewünschte geplante Aussonderung.
3. Wechseln Sie auf die Registerkarte „Verzeichnisse“
4. Importieren Sie das Bewertungsverzeichnis mit Drag and Drop in die Liste „Verzeichnisse“
**Hinweis:** Das System erkennt das Bewertungsverzeichnis automatisch
5. Wählen Sie im Kontextmenü den Menüeintrag „Bewertungsverzeichnis laden“ aus. Das System lädt das XDOMEA Paket und passt die Aussonderungsart der betroffenen Objekte an:

Benutzerhilfe

<!-- PDF page 254 -->

Benutzerhilfe
254

# Geladenes Berwertungsverzeichnis

## XDOMEA Importlog

Für das Objekt "A10 000/2" wurde die Aussonderungsart von "A" auf "V" geändert.

[tbl-2.md](tbl-2.md)

**Hinweis:** Zusätzlich ändert sich der Bearbeitungsstatus der bewerteten Objekte auf „Bewertet“.

6. Mit einem Klick auf „Weiter“ wird die Maske wieder geschlossen und Sie können mit dem nächsten Punkt fortfahren

## Ergebnis:

- Das Bewertungsergebnis des Archivs wurde in die Objekte übernommen. Es kann nun die Abgabe initiiert werden.

### 3.10.1.4 Die Abgabe initiieren

Nach der Bewertung muss der Anwender die Abgabe an das Archiv bzw. die Vernichtung der bewerteten Objekte durchführen. Als erster Schritt in diesem Teilprozess muss die Abgabe initiiert werden. Hierfür gehen Sie wie folgt vor:

1. Wechseln Sie in das Widget „Aussonderung“.
2. Wechseln Sie in die gewünschte geplante Aussonderung.
3. Wechseln Sie auf die Registerkarte „Verzeichnisse“.
4. Lokalisieren Sie das geladene Bewertungsverzeichnis und führen Sie im Kontextmenü den Menüeintrag „Abgabe initiieren“ aus.
5. Das System erstellt nun eine neue Aktivität „Abgabe“, die Sie in Ihren Arbeitsvorrat zugestellt bekommen.

**Hinweis:** Weitere Details zur Aktivität „Abgabe“ finden Sie im Kapitel „7.24 Die Aktivität Abgabe“.

## Ergebnis:

- Es wurde eine Aktivität „Abgabe“ erstellt und Ihnen vorgeschrieben.

### 3.10.1.5 Abgabe durchführen

Mit der Aktivität „Abgabe“ können nun, anhand der Bewertung des Archivs, die Objekte gelöscht, oder dem Archiv übermittelt werden. Um diese Schritte durchzuführen, gehen Sie wie folgt vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität „Abgabe“.

<!-- PDF page 255 -->

3. Vernichten Sie die zu vernichtenden Objekte mit einem Klick auf den Arbeitsschritt „Vernichten“.

**Hinweis:** Es werden alle Dokumente und Schriftstücke der zu vernichtenden Vorgänge vernichtet. Beim Vorgang selbst werden die nicht mehr benötigten Metadaten entfernt und eine Markierung wird angebracht. Am Symbol erkennt man, dass der Vorgang vernichtet wurde.

4. Die zu archivierenden Objekte können über den Arbeitsschritt „Abgabe durchführen“ in ein XDOMEA Paket übermittelt werden. Das neue XDOMEA Paket wird geöffnet.

5. Wählen Sie als Empfänger das gewünschte Archiv aus.

6. Auf der Registerkarte „XDOMEA Export“ sind die Vorgänge der geplanten Aussonderung vorbeifüllt.

**Hinweis:** Als XDOMEA Export Objekte werden die referenzierten Akten der Vorgänge eingetragen. Die Akten werden aber nicht ausgesondert, sondern die Vorgänge. Dieser sind in den „zu exportierenden Folgeobjekten eingetragen“.

7. Beim Klick auf „Weiter“ wird das XDOMEA Paket generiert.

8. Nach dem Export haben Sie die Möglichkeit mit der Schaltfläche „Herunterladen“ das XDOMEA Paket als ZIP Archiv zu exportieren.

9. Speichern Sie das XDOMEA Paket auf ihrem Computer.

**Hinweis:** Die Zustellung an das Archiv muss bei der manuellen Aussonderung organisatorisch gelöst werden.

10. Schließen Sie die Aktivität und schließen Sie über das Kontextmenü und dem Menü Eintrag „Prozess erledigen“ die Aktivität ab.

**Ergebnis:**

- Das XDOMEA Paket für die Übermittlung an das Archiv wurde erstellt und heruntergeladen.

## 3.10.1.6 Archivresultat laden

Für die übermittelten Vorgänge muss das Archiv nun eine positive oder eine negative Abgabebestätigung an die Fabasoft eGov-Suite Bayern übermitteln. Erst dann kann eine Löschung durchgeführt werden. Wie Sie das Archivresultat des Archivs laden wird in den folgenden Schritten beschrieben:

1. Wechseln Sie in das Widget „Aussonderung“.
2. Wechseln Sie in die gewünschte geplante Aussonderung
3. Wechseln Sie auf die Registerkarte „Verzeichnisse“
4. Importieren Sie das Bewertungsverzeichnis mit Drag and Drop in die Liste „Verzeichnisse“

**Hinweis:** Das System erkennt das Bewertungsverzeichnis automatisch

5. Wählen Sie im Kontextmenü den Menüeintrag „Archivresultat laden“ aus. Das System lädt das XDOMEA Paket und passt den Status der betroffenen Vorgänge auf „Übernahme von Archiv bestätigt“ an. Dadurch können die zu löschenden Vorgänge über einen AT-Job gelöscht werden. Die Einrichtung dieses AT-Jobs ist im Kapitel 5.4.3 „AT-Job zum Löschen von archivierten Objekten“ beschrieben.

Benutzerhilfe

<!-- PDF page 256 -->

Hinweis: Für Objekte, die zurückgewiesen wurden, muss für eine Aussonderung der Aussonderungsprozess neu gestartet werden.

6. Mit einem Klick auf „Weiter" wird die Bearbeitung beendet und die Aussonderung konnte erfolgreich abgeschlossen werden.

## Ergebnis:

- Die Vorgänge wurden archiviert und können nun gelöscht werden.

## 3.10.2 Automatische Aussonderung

Die automatische Aussonderung muss durch einen Administrator aktiviert werden. Die Vorgehensweise hierzu wird in dem Kapitel 5.4.2 „Aktivieren der automatischen Aussonderung" beschrieben.

## 3.10.2.1 Erstellung einer geplanten Aussonderung

Als Startpunkt für die Aussonderung müssen Sie eine geplante Aussonderung erzeugen. Hierfür gehen Sie wie folgt vor:

1. Wechseln Sie in das Widget „Aussonderung".
2. Erzeugen Sie in der Registerkarte „Geplante Aussonderung" eine neue geplante Aussonderung.
3. Definieren Sie das „Von" und „Bis" Datum. Dieses Datum ist für den geplanten Aussonderungstermin der betroffenen Vorgänge relevant.
4. Schließen Sie die Erstellung mit einem Klick auf die Schaltfläche „Weiter".
5. Öffnen Sie über einen Doppelklick die soeben erzeugte „geplante Aussonderung".
6. Aktualisieren Sie die Ansicht.

## Ergebnis:

- Es werden alle Vorgänge angezeigt, die für diesen Aussonderungszeitraum relevant sind.

![img-7.jpeg](img-7.jpeg)

![img-8.jpeg](img-8.jpeg)

Benutzerhilfe
256

<!-- PDF page 257 -->

Benutzerhilfe

# 3.10.2.2 Objekte dem Archiv zur Bewertung übermitteln

Der erste Schritt im Aussonderungsprozess ist die Erstellung eines Anbieterverzeichnisses für das Archiv. Um dies durchzuführen gehen Sie wie folgt vor:

1. Wechseln Sie in das Widget „Aussonderung“.
2. Wechseln Sie in die gewünschte geplante Aussonderung.
3. Erzeugen Sie in der Registerkarte „Verzeichnisse“ ein neues Objekt.
4. Das System initialisiert die XDOMEA Nachrichtengruppe und die XDOMEA Nachricht mit den Werten „Aussonderung durchführen“ und „Anbieterverzeichnis“. Als Absender wird ihr Benutzer eingetragen.
5. Wählen Sie als Empfänger das gewünschte Archiv aus.
6. Auf der Registerkarte „XDOMEA Export“ sind die Vorgänge der geplanten Aussonderung vorbeifüllt.

Hinweis: Als XDOMEA Export Objekte werden die referenzierten Akten der Vorgänge eingetragen. Die Akten werden aber nicht ausgesondert, sondern die Vorgänge. Dieser sind in den „zu exportierenden Folgeobjekten eingetragen“.

7. Beim Klick auf „Weiter“ wird das XDOMEA Paket gespeichert.
8. Öffnen Sie das Kontextmenü des XDOMEA Pakets und wählen Sie den Eintrag „XDOMEA Paket übermitteln“ aus. Sie sehen folgende Information:

„XDOMEA Export wird asynchron durchgeführt“.

Zusätzlich erscheint folgender Hinweis:

```
Es wurde eine Aktion für "CEEF1F18-91F1-F104-2828-D00000000000_Aussonderung.Anbieterverzeichnis.0501" zur Warteschlange "Meine Exportwarteschlange" hinzugefügt.
Links:
CEEF1F18-91F1-F104-2828-D00000000000_Aussonderung.Anbieterverzeichnis.0501
Meine Exportwarteschlange
```

Hinweis: Der Name des XDOMEA Pakets ändert sich nun auf den eindeutigen Bezeichner lt. XDOMEA Spezifikation, wenn der Export asynchron ausgeführt wurde.

9. Mit einem Klick auf „Weiter“ ist die Erstellung des Anbieterverzeichnisses in Auftrag gegeben.

# Ergebnis:

- Die Erstellung des XDOMEA Pakets für das Anbieterverzeichnis wurde in Auftrag gegeben.

# 3.10.2.3 Bestätigung des Erhalts des Anbieterverzeichnisses

Durch den Ablauf der automatischen Aussonderung erhält die Fabasoft eGov-Suite auch Bestätigungspakete. Für die Bestätigung des Erhalts des Anbieterverzeichnisses lädt der Schnittstellencontroller das XDOMEA Paket automatisiert in die Fabasoft eGov-Suite Bayern. Es erscheint bei Ihnen in der Aussonderung. Um die Empfangsbestätigung zu prüfen gehen Sie wie folgt vor:

1. Wechseln Sie in das Widget „Aussonderung“.

<!-- PDF page 258 -->

2. Wechseln Sie in die gewünschte geplante Aussonderung.
3. Wechseln Sie auf die Registerkarte „Verzeichnisse".
4. Lokalisieren Sie das XDOMEA Paket, welches „0504" am Ende stehen hat.
Hinweis: Dieses Objekt dient nur zur Dokumentation. Sie müssen damit nichts Weiteres durchführen.
Hinweis: Ist das Paket noch nicht vorhanden, wurde das entsprechende Anbieterverzeichnis noch nicht angenommen.

## 3.10.2.4 Bewertungsverzeichnis wurde importiert

Die automatisierte Aussonderung kümmert sich selbst darum, dass die Bewertungsverzeichnisse in die Fabasoft eGov-Suite Bayern importiert werden. Beim Erhalt eines Bewertungsverzeichnisses müssen folgende Schritte durchführen, um den Aussonderungsprozess fortzusetzen:

1. Wechseln Sie in Ihren „Arbeitsvorrat".
2. Lokalisieren Sie die Aktivität „Bewertungsverzeichnis verfügbar".
3. Mit dem Arbeitsschritt „Eigenschaften" können Sie die Metadaten des XDOMEA Bewertungsverzeichnisses prüfen.
4. Mit dem Arbeitsschritt „Bewertungsverzeichnis laden", lädt das System das XDOMEA Paket und passt die Aussonderungsart der betroffenen Objekte an:

### Geladenes Bewertungsverzeichnis

XDOMEA Importlog

Für das Objekt "A10 000/2" wurde die Aussonderungsart von "A" auf "V" geändert.

Bewertete Objekte

[tbl-3.md](tbl-3.md)

Hinweis: Zusätzlich ändert sich der Bearbeitungsstatus der bewerteten Objekte auf „Bewertet".

5. Mit einem Klick auf „Weiter" wird die Maske wieder geschlossen und Sie können mit dem nächsten Punkt fortfahren.
6. Mit einem Klick auf den Arbeitsschritt „Abgabe initiieren" erstellt das System erstellt eine neue Aktivität „Abgabe", die Sie in Ihren Arbeitsvorrat zugestellt bekommen.
Hinweis: Weitere Details zur Aktivität „Abgabe" finden Sie im Kapitel „7.24 Die Aktivität Abgabe".
7. Schließen Sie die Aktivität und schließen Sie über das Kontextmenü und dem Menü Eintrag „Prozess erledigen" die Aktivität ab.

### Ergebnis:

- Das Bewertungsergebnis des Archivs wurde in die Objekte übernommen.

Benutzerhilfe
258

<!-- PDF page 259 -->

Die Abgabe wurde initiiert.

## 3.10.2.5 Abgabe durchführen

Mit der Aktivität „Abgabe“ können nun, anhand der Bewertung des Archivs, die Objekte gelöscht, oder dem Archiv übermittelt werden. Um diesen Schritt durchzuführen, gehen Sie wie folgt vor:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität „Abgabe“.
3. Vernichten Sie die zu vernichtenden Objekte mit einem Klick auf den Arbeitsschritt „Vernichten“.

**Hinweis:** Es werden alle Dokumente und Schriftstücke der zu vernichtenden Vorgänge vernichtet. Beim Vorgang selbst werden die nicht mehr benötigten Metadaten entfernt und eine Markierung wird angebracht. Am Symbol erkennt man, dass der Vorgang vernichtet wurde.

4. Die zu archivierenden Objekte können über den Arbeitsschritt „Abgabe durchführen“ in ein XDOMEA Paket übermittelt werden. Das neue XDOMEA Paket wird geöffnet.
5. Wählen Sie als Empfänger das gewünschte Archiv aus.
6. Auf der Registerkarte „XDOMEA Export“ sind die Vorgänge der geplanten Aussonderung vorbefüllt.

**Hinweis:** Als XDOMEA Export Objekte werden die referenzierten Akten der Vorgänge eingetragen. Die Akten werden aber nicht ausgesondert, sondern die Vorgänge. Dieser sind in den „zu exportierenden Folgeobjekte eingetragen“.

7. Beim Klick auf „Weiter“ sehen Sie folgende Information:
„XDOMEA Export wird asynchron durchgeführt“.
Zusätzlich erscheint folgender Hinweis:

```
Es wurde eine Aktion für "CEEF1F18-91F1-F104-2828-D00000000000_Aussonderung.Anbieterverzeichnis.0501" zur Warteschlange "Meine Exportwarteschlange" hinzugefügt.
Links:
CEEF1F18-91F1-F104-2828-D00000000000_Aussonderung.Anbieterverzeichnis.0501
Meine Exportwarteschlange
```

**Hinweis:** Der Name des XDOMEA Pakets ändert sich nun auf den eindeutigen Bezeichner lt. XDOMEA Spezifikation, wenn der Export asynchron ausgeführt wurde.
**Hinweis:** Das Aussonderungsverzeichnis wird auch in der geplanten Aussonderung auf der Registerkarte „Verzeichnisse“ abgelegt.

8. Schließen Sie die Aktivität und schließen Sie über das Kontextmenü und dem Menü Eintrag „Prozess erledigen“ die Aktivität ab.

## Ergebnis:

- Das XDOMEA Paket für die Übermittlung an das Archiv wurde erstellt und heruntergeladen.

Benutzerhilfe
259

<!-- PDF page 260 -->

Benutzerhilfe

# 3.10.2.6 Archivresultat wurde importiert

Die automatisierte Aussonderung kümmert sich selbst darum, dass die Importbestätigungen vom Archiv in die Fabasoft eGov-Suite Bayern importiert werden. Beim Erhalt einer Importbestätigung müssen folgende Schritte durchführen, um den Aussonderungsprozess abzuschließen:

1. Wechseln Sie in Ihren „Arbeitsvorrat“.
2. Lokalisieren Sie die Aktivität „Archivresultat geladen“.
3. Mit dem Arbeitsschritt „Protokoll öffnen“ können Sie Statusübergänge der betroffenen Objekte sichten.

Nun können die zu löschenden Vorgänge über einen AT-Job gelöscht werden. Die Einrichtung dieses AT-Jobs ist im Kapitel 5.4.3 „AT-Job zum Löschen von archivierten Objekten“ beschrieben.

**Hinweis:** Für Objekte, die zurückgewiesen wurden, muss für eine Aussonderung der Aussonderungsprozess neu gestartet werden.

4. Schließen Sie die Aktivität und schließen Sie über das Kontextmenü und dem Menü Eintrag „Prozess erledigen“ die Aktivität ab.

# 3.11 Management Center für Geschäftsobjekte

Im Management Center für Geschäftsobjekte haben Sie die Möglichkeit, ausfolgenden Übersichten zu wählen, welche in den jeweiligen Kapiteln genauer beschrieben werden:

- Dokumente (siehe Kapitel 3.11.2 „Dokumente“)
- Aktivitäten (siehe Kapitel 3.11.3 „Aktivitäten“)
- Aktueller Status der Dokumente (siehe Kapitel 3.11.4 „Aktueller Status der Dokumente“)
- Fristen der Aktivitäten anzeigen (siehe Kapitel 3.11.5 „Fristen der Aktivitäten anzeigen“)
- Offene Aktivitäten (siehe Kapitel 3.11.6 „Offene Aktivitäten anzeigen“)
- Berechtigte Benutzer (siehe Kapitel 3.11.7 „Berechtigte Benutzer anzeigen“)

Sie haben die Möglichkeit, mit den Schaltflächen im oberen Bereich des Management Centers zwischen den einzelnen Übersichten zu wechseln.

[tbl-4.md](tbl-4.md)

**Hinweis:** Das Management Center kann im Kontext folgender Objektklassen geöffnet werden:

- Akte
- Vorgang
- Aktenplaneintrag
- Organisationseinheit

Zum Öffnen des Management Centers für Geschäftsobjekte gehen Sie folgendermaßen vor:

1. Lokalisieren Sie das Geschäftsobjekt (z.B. den Vorgang), auf welches Sie das Management Center für Geschäftsobjekte aufrufen möchten.

260

<!-- PDF page 261 -->

2. Öffnen Sie das Geschäftsobjekt und klicken Sie auf die Schaltfläche „Management Center öffnen“ aus.

![img-9.jpeg](img-9.jpeg)

## 3.11.1 Funktionen der grafischen Darstellung

Wenn für das Management Center für Geschäftsobjekte die grafische Darstellung für die Übersicht aktiviert wurde, haben Sie die Möglichkeit, die Darstellung der grafischen Ansicht für Ihr Interesse anzupassen. Konkret stehen folgende Möglichkeiten zur Verfügung:

- Hervorheben eines Eintrags
- Ausblenden einzelner Einträge

## Hervorheben eines Eintrags

Um einen Eintrag in der grafischen Ansicht hervorzuheben klicken Sie auf diesen. Hierdurch wird der Eintrag optisch in der Übersicht hervorgehoben.

**Hinweis:** Durch Klick auf einen Eintrag bei gedrückter Strg-Taste können mehrere Einträge hervorgehoben werden.

**Beispiel:** Die Erledigungen sollen in der Grafik hervorgehoben werden. Daher wird auf das „Tortenstück“ für Erledigungen geklickt.

![img-10.jpeg](img-10.jpeg)

## Ergebnis:

Benutzerhilfe
261

<!-- PDF page 262 -->

![img-0.jpeg](img-0.jpeg)
Vorgang
Eingangsdokument
Erledigung
Undaufmappe
Registerblatt

Der gewählte Eintrag wird in der Grafik versetzt und dadurch hervorgehoben.

## Ausblenden eines Eintrags

Um einen Eintrag in der grafischen Darstellung auszublenden klicken Sie auf dessen Eintrag in der Legende der Ansicht. Ausgeblendete Einträge können durch einen weiteren Klick auf den Eintrag in der Legende wieder eingeblendet werden.

**Hinweis:** Es können auch mehrere Einträge auf diese Weise ausgeblendet werden.

**Beispiel:** Aus der Grafik sollen Erledigungen ausgeblendet werden. Daher wird auf den Eintrag „Erledigung“ in der Legende geklickt.

![img-1.jpeg](img-1.jpeg)
Vorgang
Eingangsdokument
Erledigung
Undaufmappe
Registerblatt

## Ergebnis:

- Die Eingangsdokumente werden aus der Grafik ausgeblendet.
- Der Eintrag für interne Stücke in der Legende wird ausgegraut dargestellt.

Benutzerhilfe
262

<!-- PDF page 263 -->

![img-2.jpeg](img-2.jpeg)

![img-3.jpeg](img-3.jpeg)

Benutzerhilfe
263

<!-- PDF page 264 -->

Benutzerhilfe
264

# 3.11.2 Dokumente

Die Übersicht „Dokumente“ enthält Informationen zu den Inhalten des jeweiligen Geschäftsstücks. Es wird angezeigt, wie viele Objekte welcher Klasse sich darin befinden.

![img-4.jpeg](img-4.jpeg)

# 3.11.3 Aktivitäten

Die Übersicht „Aktivitäten“ enthält Informationen über die Aktivitäten der Inhalte des Geschäftsstücks. Es wird angezeigt, wie viele offene bzw. wie viele abgeschlossene Aktivitäten sich darin befinden.

![img-5.jpeg](img-5.jpeg)

# 3.11.4 Aktueller Status der Dokumente

Die Übersicht „Aktueller Status der Dokumente“ enthält Informationen über den Status der Inhalte des Geschäftsstücks. Es wird eine Grafik angezeigt, welche die Anzahl an Geschäftsstücken pro Status wiederspiegelt.

<!-- PDF page 265 -->

![img-6.jpeg](img-6.jpeg)

## 3.11.5 Fristen der Aktivitäten anzeigen

In dieser Übersicht werden sämtliche Aktivitäten des Geschäftsobjekts und dessen untergeordneter Objekte angezeigt, welche mindestens einen der folgenden Eigenschaften gesetzt haben:

- Termin für Beginn
- Termin für Vorlage
- Termin für Erledigung

![img-7.jpeg](img-7.jpeg)

## 3.11.6 Offene Aktivitäten anzeigen

In dieser Übersicht werden sämtliche Aktivitäten des aktuellen Geschäftsobjekts und dessen untergeordneten Objekte angezeigt, welche einen der folgenden Status haben:

- Kann beginnen
- Begonnen
- Warten auf Vorlage
- Wartezustand

![img-8.jpeg](img-8.jpeg)

Benutzerhilfe

<!-- PDF page 266 -->

Benutzerhilfe
266

# 3.11.7 Berechtigte Benutzer anzeigen

In dieser Übersicht wird eine Übersicht der Berechtigten Benutzer des aktuellen Geschäftsobjekts angezeigt.

Hinweis: Diese Übersicht enthält keine Information über vergebene Berechtigungen der untergeordneten Geschäftsobjekte.

![img-9.jpeg](img-9.jpeg)

# 3.12 Rechercheauftrag

Auf Basis des Suchordner Administration existier die Objektklasse Rechercheauftrag, über die es möglich ist, im System über diverse Kriterien recherchieren zu können. Die Besonderheit liegt darin, dass Sie lediglich die Sucheinstellungen definieren und die Fabasoft eGov-Suite übernimmt die Generierung der notwendigen Suchen. Nachdem die Fabasoft eGov-Suite, je nach eingegebenen Daten, eine Vielzahl von Suchen generieren muss, wird die Recherche im Hintergrund durchgeführt. Als Ausgangspunkt dient der Use-Case Objekte heranholen auf Basis des Rechercheordners.

Durch den Rechercheauftrag werden Sie nun wesentlich bei der Tätigkeit unterstützt Informationen zu einem Sachverhalt oder einer Person zusammenzutragen. In weiterer Folge können auch mehrere Rechercheaufträge zusammen verarbeitet werden.

Folgende allgemeine Rahmenbedingungen existieren zum Rechercheauftrag:

- Das Ergebnis einer Recherche soll keine Duplikate enthalten.
- Es dürfen nur die Treffer ermittelt werden, auf die Sie bereits Zugriff haben.
- Die Recherche wird ausschließlich im Schriftgut ausgeführt (ohne Teamroom und Schreibtisch).
- Die Recherche wird mit einer Kombination der Sucharten (Mindbreeze, Datenbank oder kombiniert) durchgeführt.

<!-- PDF page 267 -->

- Aufgrund der Komplexität der erforderlichen Abfragen und der potenziell hohen Trefferzahl wird die Recherche asynchron abgearbeitet.
- Sie können vom System über den Abschluss benachrichtigt werden.
- Sie haben die Möglichkeit, die Trefferliste weiter zu verarbeiten.
- Es ist möglich, das Ergebnis der Recherche auch außerhalb der Fabasoft eGov-Suite bereitzustellen.

## 3.12.1 Durchführung einer Recherche

Als berechtigter Anwender kann der Rechercheauftrag am Schreibtisch oder in einem Ordner erzeugt werden. Nach der Definition eines Namens muss der Use-Case Objekte heranholen über das Kontextmenü ausgeführt werden:

![img-10.jpeg](img-10.jpeg)

Anschließend muss eine der folgenden Suchdefinition ausgewählt werden:

![img-11.jpeg](img-11.jpeg)

## Recherche mit einer Person

Es werden Geschäftsobjekte auf Basis eines Vornamens und ein eines Nachnamens gesucht.

![img-12.jpeg](img-12.jpeg)

## Recherche mit Suchbegriff(en)

Es werden Geschäftsobjekte auf Basis von mindestens einem und maximal drei Suchbegriffen

Benutzerhilfe
267

<!-- PDF page 268 -->

gesucht. Die Suchbegriffe können mit AND, NEAR und OR verknüpft werden.

![img-13.jpeg](img-13.jpeg)

# Recherche mit Suchbegriff(en) und Person

Es werden Geschäftsobjekte auf Basis eines Vornamens und ein eines Nachnamens gesucht. Zusätzlich werden Geschäftsobjekte auf Basis von mindestens einem und maximal drei Suchbegriffen gesucht. Die Suchbegriffe können mit AND, NEAR und OR verknüpft werden.

![img-14.jpeg](img-14.jpeg)

# Folgende Optionen sind verfügbar:

![img-15.jpeg](img-15.jpeg)

Benutzerhilfe

<!-- PDF page 269 -->

Benutzerhilfe
269

# Datum ab

Es werden nur Suchtreffer für das Rechercheergebnis berücksichtigt, die ab dem hier eingegebenen Datum erzeugt wurden.

# Datum bis

Es werden nur Suchtreffer für das Rechercheergebnis berücksichtigt, die bis zu dem hier eingegebenen Datum erzeugt wurden.

# Schlagworte

Es werden nur Suchtreffer für das Rechercheergebnis berücksichtigt, die die hier eingegebenen Schlagwörter hinterlegt haben. Sind mehrere Schlagwörter definiert, so müssen alle angeführten Schlagwörter dem Suchtreffer zugewiesen sein.

# Organisationseinheit

Es werden nur Suchtreffer für das Rechercheergebnis berücksichtigt, die von der hier eingegeben Organisationseinheit erzeugt wurden.

# Inklusive untergeordnete Organisationseinheiten

Wurde das Feld Organisationseinheit für die Einschränkung des Rechercheergebnisses befüllt, so kann über diese Option zusätzlich bestimmt werden, ob auch die untergeordneten Organisationseinheiten berücksichtigt werden sollen. Es werden demnach nur Suchtreffer berücksichtigt, die von der Organisationseinheit oder von einer untergeordneten Organisationseinheiten erzeugt wurden.

# Aktenplaneintrag

Es werden nur Suchtreffer für das Rechercheergebnis berücksichtigt, die dem hier definierten Aktenplaneintrag zugeordnet sind.

# Inklusive untergeordnete Aktenplaneinträge

Wurde das Feld Aktenplaneintrag für die Einschränkung des Rechercheergebnisses befüllt, so kann über diese Option zusätzlich bestimmt werden, ob auch die untergeordneten Aktenplaneinträge berücksichtigt werden sollen. Es werden demnach nur Suchtreffer berücksichtigt, die entweder im referenzierten Aktenplaneintrag oder in einem untergeordneten Aktenplaneintrag zugeordnet sind.

Zusätzlich zu den Sucheinstellungen existieren auch noch allgemeine Einstellungen, die vor allem das Suchergebnis organisieren. Diese können mit einem Klick auf die Schaltfläche „Alle Optionen einblenden“ aktiviert werden:

```html
[tbl-0.md](tbl-0.md)
```

Folgende Optionen sind verfügbar:

```html
[tbl-1.md](tbl-1.md)
```

<!-- PDF page 270 -->

Kriterien für die Aufteilung des Suchergebnisses

Das Rechercheergebnis kann je nach eingegebenen Suchkriterien sehr viele Einträge beinhalten. Mit der Definition eines Kriteriums kann das Rechercheergebnis unterteilt und somit für Sie übersichtlicher gestaltet werden. Folgende Optionen sind verfügbar.

- Treffermenge: Das Rechercheergebnis wird in Ordner mit der angegebenen Treffermenge aufgeteilt. Es muss zusätzlich das Feld Treffermenge angegeben werden.
- Eigentümer Gruppe: Das Rechercheergebnisse wird anhand der Eigentümergruppe aufgeteilt. Die Ergebnisordner erhalten den Namen der Gruppe.
- Datum (nach Jahren getrennt): Das Rechercheergebnis wird anhand des Erzeugungsjahres der jeweiligen Objekte aufgeteilt.

Treffermenge

Mit der Eingabe einer Treffermenge steuern Sie die Anzahl der Objekte bei der Aufteilung. Wird zum Beispiel der Wert 50 angegeben, so werden jeweils für 50 Objekte ein neuer Ordner im Rechercheergebnis erzeugt. Sie müssen hier einen Wert zwischen 25 und 9999 eingeben.

Soll der Anwender bei einer Fertigstellung informiert werden, so kann er im Feld *Fertigstellung melden an (E-Mail Adresse)* eine gültige E-Mail Adresse eintragen. Diese wird, sofern eine E-Mail Adresse beim Benutzer hinterlegt ist auch von dort initialisiert.

Nach der Bestätigung des Dialogs mit einem Klick auf die Schaltfläche Weiter wird die Warteschlange mit einem Auftrag befüllt und der Anwender muss nun warten, bis der AT-Job die Warteschlange verarbeitet hat.

3.12.2 Dokumentation der Suchen

Wurde ein Rechercheauftrag erfolgreich abgearbeitet, so können Sie die ausgeführten Suchen über die Metadaten in den allgemeinen Eigenschaften des Suchordners Administration einsehen. Hierfür muss der entsprechende Bericht geöffnet werden:

```html
[tbl-2.md](tbl-2.md)
```

3.12.3 Arbeiten mit Rechercheaufträgen

Nach den durchgeführten Suchen können Sie die Ergebnisse organisieren oder weiterverarbeiten. Für die Verarbeitung von mehreren Rechercheaufträgen und der Anreicherung derer mit weiteren Informationen stellt die Fabasoft eGov-Suite neben der

Benutzerhilfe

<!-- PDF page 271 -->

manuellen Verarbeitung Automatismen über das Kontextmenü Verarbeitungs-Funktionen zur Verfügung. Generell gilt hierfür:

- Nach der Operation wird ein neuer Rechercheauftrag erzeugt und abgelegt.
- Jedes Objekt kommt auch im neuen Rechercheauftrag nur einmal vor.
- Je nach Größe der Rechercheaufträge kann dies etwas Zeit in Anspruch nehmen
- Es werden untergeordnete Rechercheaufträge auch für die Bearbeitung berücksichtigt

Folgende Verarbeitungs-Funktionen stehen zur Verfügung:

## Zusammenführen

Der Rechercheauftrag kann mit weiteren Rechercheaufträgen zusammengeführt werden.

## Verschneiden

Es wird auf Basis des Rechercheauftrags eine Schnittmenge mit weiteren Rechercheaufträgen ermittelt. Es bleiben demnach nur die Objekte über, die in allen Rechercheaufträgen enthalten sind.

## Subtrahieren

Es werden auf Basis des Rechercheauftrags die angegebenen Rechercheaufträge abgezogen.

## Aufsplitten

Auf Basis der Eigentümer Organisationseinheit werden eigene Rechercheaufträge erzeugt und abgelegt.

## Vorgänge bereitstellen

Auf Basis der Objekte im Rechercheauftrag werden nur die Vorgänge herausgerechnet und zur Verfügung gestellt.

## Akten bereitstellen

Auf Basis der Objekte im Rechercheauftrag werden nur die Akten herausgerechnet und zur Verfügung gestellt.

## Übergeordnete Vorgänge ergänzen

Auf Basis der Objekte im Rechercheauftrag werden die Vorgänge herausgerechnet und im bestehenden Rechercheergebnis ergänzt.

## Übergeordnete Akten ergänzen

Auf Basis der Objekte im Rechercheauftrag werden die Akten herausgerechnet und im bestehenden Rechercheergebnis ergänzt.

## Bezüge ergänzen

Auf Basis der Objekte im Rechercheauftrag werden die Bezüge herausgerechnet und im bestehenden Rechercheergebnis ergänzt.

## 3.12.4 Vergabe von Rechten

Um Rechercheergebnisse für andere Anwender oder Organisationseinheit zugänglich zu machen können Rechte über die Sicherheitsregisterkarte vergeben werden. Die Rechte werden auf die untergeordneten Rechercheaufträge propagiert, nicht jedoch auf die Rechercheergebnisse!

Benutzerhilfe
271

<!-- PDF page 272 -->

Benutzerhilfe

## 3.12.5 Export

Wurden die Objekte abschließend organisiert kann es notwendig sein, die Ergebnisse in ein anderes Format zu überführen. Hierfür gibt es zwei Standardprodukt-Funktionalitäten, die verwendet werden können:

### Export als PDF

Befindet man sich in einem Rechercheauftrag, kann über das Menü Daten Exportieren ein PDF erstellt werden. Der Anwender kann hierbei die gewünschten Spalten auswählen. Es werden neben den Rechercheergebnissen in der aktuellen Objektliste auch die untergeordneten Rechercheergebnisse weiterverfolgt und somit die Summe in das PDF exportiert.

### Export als Tabelle für das Einfügen in einem Tabellenkalkulationsprogramm (z.B. Microsoft Excel)

Befindet man sich in einem Rechercheauftrag, kann über das Menü Datentabelle/Kopieren eine Tabelle in die Zwischenablage überführt werden. Es werden neben den Rechercheergebnissen in der aktuellen Objektliste auch die untergeordneten Rechercheergebnisse weiterverfolgt und somit die Summe in die Tabelle exportiert. Diese kann anschließen in das Tabellenprogramm eingefügt werden.

## 4 Zugriffsdefinitionen und Access Control Lists (ACLs)

Zugriffsdefinitionen und ACLs definieren Zugriffsrechte für Objekte in der Fabasoft eGov-Suite Bayern. Jedes Objekt hat zumindest eine ACL zugewiesen, also auch Benutzer, Organisationseinheiten, Stellvertreter, Objektklassen und sogar Zugriffsdefinitions- und ACL-Objekte. So werden z.B. durch die ACLs von „Objektklassen"-Objekten die für Benutzer sicht- bzw. instanzierbaren Klassen festgelegt.

## 4.1 Zugriffsdefinitionen

**Hinweis:** Dies betrifft z.B. Vorgänge. Die ACL eines Schriftstücks am Schreibtisch, welches noch keinem Dokument zugeordnet ist, kann hingegen direkt geändert werden.

**Beispiel:** Der Status eines Vorgangs ändert sich von *In Bearbeitung auf Abgeschlossen*. Aufgrund der Zugriffsdefinition wird die ACL von „ACL für allgemeine Vorgangsdaten" auf die ACL „ACL für abgeschlossene allgemeine Vorgangsdaten" gesetzt.

Für Informationen zum Aufbau einer Zugriffsdefinition siehe Kapitel 6.26 „Zugriffsdefinition".

### 4.1.1 Zugriffsdefinition auswählen

Zugriffsdefinitionen können auf der Registerkarte „Sicherheit" im Feld Zugriffsdefinition ausgewählt werden. Die aus der Zugriffsdefinition berechnete ACL wird im Feld ACL-Objekt eingetragen.

### 4.1.2 Zugriffsdefinition entfernen

Zugriffsdefinitionen können auf der Registerkarte „Sicherheit" im Feld Zugriffsdefinition ausgetragen werden, sofern für diese Objektklasse das Feld Zugriffsdefinition nicht als Pflichtfeld definiert ist.

272

<!-- PDF page 273 -->

Hinweis: Wird eine Zugriffsdefinition entfernt, gilt weiterhin die ACL für das Objekt.

## 4.1.3 Zugriffsdefinitionen bei Vorlagen

Vorlagen nehmen in Hinblick auf Sicherheitseinstellungen eine Sonderstellung ein.

Für Vorlagen ist es technisch möglich, eine Zugriffsdefinition auszuwählen. Da es aber bei Vorlagen keine Statusübergänge gibt, ist die Auswahl einer Zugriffsdefinition nicht sinnvoll.

Hinweis: Wird ein Objekt auf Basis einer Vorlage erzeugt, gelten für das neue Objekt die herkömmlichen Sicherheitseinstellungen, unabhängig von der ACL der Vorlage.

## 4.1.4 Vordefinierte Zugriffsdefinitionen

Die Fabasoft eGov-Suite Bayern stellt eine Reihe von Zugriffsdefinitionen zur Verfügung, welche ACLs für Objekte definieren, je nach Status des Objekts.

Es stehen folgende Zugriffsdefinitionen zur Verfügung:

- Aktengebunden
- Persönlich und Vorgesetzte
- Eigene Organisationseinheit und Linienorganisation
- Eigene Organisationseinheit und Vorgesetzte
- Eigene Organisationseinheit und Vorgesetzte (ohne Zentralregistratur)
- Eigene Organisationseinheit
- Personalangelegenheiten
- Eigener Mandant
- Persönliche Objekte
- Persönlich

## 4.2 ACLs

### 4.2.1 3-Welten-Philosophie

Die Fabasoft eGov-Suite Bayern kennt keinen "Super-User". Man muss einen Benutzer (oder eine Organisationseinheit) dezidiert zu allen ACLs hinzufügen, um das "Super-User" Konzept zu realisieren. Stattdessen teilt sich das Organisationsmodell der Fabasoft eGov-Suite Bayern Benutzer in grundsätzlich drei Welten:

- Benutzer: Endanwender der Fabasoft eGov-Suite Bayern. Er arbeitet mit Anwendungsobjekten von Geschäftsprozesslösungen in seiner Arbeitsumgebung.
- Administrator: Ein Administrator ist berechtigt, administrative Aufgaben in einer Fabasoft eGov-Suite Bayern Domäne wahrzunehmen. Ein Administrator hat dafür eine spezielle Ausbildung absolviert, ist sich seiner Verantwortung bewusst und trägt im Zweifelsfall auch die volle Verantwortung seiner Tätigkeit.

Benutzerhilfe
273

<!-- PDF page 274 -->

- Entwickler: Ein Entwickler ist berechtigt, Softwarekomponenten und Komponentenobjekte für Geschäftsprozess-Lösungen zu erstellen, d.h. Erzeugen von Objektklassen, Eigenschaften, Typen, Symbole, ...

## Wichtige ACLs des Basissystems sind:

- „Standard-ACL“ und „Standard-ACL für allgemeine Objekte“: Benutzer dürfen diese Objekte instanzieren, suchen und lesen.
- „ACL für Objekte zur Administration“: Benutzer dürfen diese Objekte suchen und lesen aber nicht erzeugen. Administratoren sollten in diese ACL mit den gleichen Rechten wie der Eigentümer des Objekts aufgenommen werden.
- „ACL für Objekte zur Entwicklung“: Benutzer dürfen diese Objekte nur mehr lesen. Entwickler sollten in diese ACL mit den gleichen Rechten wie der Eigentümer des Objekts aufgenommen werden.

## 4.2.2 Zuordnung der Zugriffsrechte

Wird ein Objekt erzeugt (instanziert), so werden von der Fabasoft eGov-Suite Bayern automatisch die Zugriffsrechte für dieses Objekt folgendermaßen festgelegt:

- Das Attribut Eigentümer des erzeugten Objektes wird auf den Benutzer gesetzt, der dieses Objekt erzeugt.
- Benutzer arbeiten im Kontext einer Rolle, so wird das Attribut Organisationseinheit des erzeugten Objektes auf die Organisationseinheit der aktuellen Rolle gesetzt.
- Dem erzeugten Objekt wird eine ACL der nachfolgenden Prioritäten zugewiesen:

- Falls der Objektklasse des erzeugten Objektes eine Standard-ACL zugeordnet ist (im Attribut Standard-ACL für neue Objekte bzw. Standard-Zugriffsdefinition für neue Objekte des Objektklassen-Objektes), so wird dem erzeugten Objekt diese ACL bzw. Zugriffsdefinition zugeordnet.
- Für bestimmte Objekte der Administration (z.B. Benutzer, Organisationseinheit, Domänen, ...) bzw. Entwicklung (z.B. Objektklasse, Eigenschaften, Typen) wird nicht die ACL „Standard-ACL“, sondern „ACL für Objekte zur Administration“ bzw. „ACL für Objekte zur Entwicklung“ vergeben.
- Trifft keiner der genannten Fälle zu, so wird dem erzeugten Objekt die ACL „Standard-ACL“ zugewiesen. Diese ACL legt im Wesentlichen fest, dass der Eigentümer des Objekts alle Rechte hat, und alle anderen Benutzer das Objekt suchen und lesen dürfen.

## 4.2.3 Dynamische ACLs

Eine ACL in der Fabasoft eGov-Suite Bayern definiert, welcher Benutzer welche Zugriffsrechte auf ein Objekt hat und was diese Person mit dem Objekt tun kann. Die Berechtigungen der Benutzer können durch Kombination der folgenden Einträge bestimmt werden:

### Domäne/Domänentyp

- Alle Domänen
- Domäne des Eigentümers

Benutzerhilfe
274

<!-- PDF page 275 -->

- Domäne des Objekts
- Eigenschaft mit Domäne
- Domäne

## Organisationseinheit/Strukturreinheit

- Alle Organisationseinheiten
- Organisationseinheit des Objekts
- Eigenschaft mit Organisationseinheit/Strukturreinheit
- Organisationseinheit
- Strukturreinheit
- Übergeordnete Objekte

## Benutzer/Stelle

- Alle Benutzer
- Eigentümer des Objekts
- Eigenschaft mit Benutzer/Stelle
- Benutzer
- Stelle

## 4.2.4 Vorkonfigurierte ACLs

[tbl-3.md](tbl-3.md)

Benutzerhilfe
275

<!-- PDF page 276 -->

[tbl-4.md](tbl-4.md)

Benutzerhilfe
276

<!-- PDF page 277 -->

Benutzerhilfe
277

[tbl-5.md](tbl-5.md)

<!-- PDF page 278 -->

Benutzerhilfe
[tbl-6.md](tbl-6.md)

<!-- PDF page 279 -->

[tbl-7.md](tbl-7.md)

Benutzerhilfe
279

<!-- PDF page 280 -->

[tbl-8.md](tbl-8.md)

## 4.2.5 Vergabe von Zusatzberechtigungen

Um Zusatzberechtigungen (Lese- und Änderungsberechtigung) zu vergeben, gehen Sie bitte folgendermaßen vor:

1. Lokalisieren Sie das Objekt, für das Zusatzberechtigungen vergeben werden sollen und öffnen Sie dessen Metadaten bearbeitend.
2. Wechseln Sie auf die Registerkarte "Sicherheit".
3. In den Eigenschaften Benutzer/Organisationseinheiten mit Leseberechtigung und Benutzer/Organisationseinheiten mit Änderungsberechtigung können Sie Benutzer und Organisationseinheiten mittels der Schaltflächen der Symbolleiste in die Liste aufnehmen.

**Hinweis:** Um Benutzer und Organisationseinheiten zu entfernen, klicken Sie bitte mit der rechten Maustaste auf das zu entfernende Objekt und wählen Sie den Kontextmenüeintrag „Ausschneiden“.

4. Klicken Sie auf die Schaltfläche mit "Weiter", um Ihre Änderung zu speichern.

## 4.2.6 ACL für allgemein zugängliche Daten (Schreibtisch)

Mit dieser ACL ist gewährleistet, dass Benutzer einer anderen Behörde Leserechte auf Objekte erhalten. Objekte mit dieser ACL können gesucht und es können Eigenschaften, Inhalte sowie der Zugriffsschutz gelesen werden.

Um einem Objekt die „ACL für allgemein zugängliche Daten (Schreibtisch)“ zuzuordnen, gehen Sie wie folgt vor:

1. Lokalisieren Sie das Objekt, für das die ACL vergeben werden soll und öffnen Sie dessen Metadaten bearbeitend.
2. Wechseln Sie auf die Registerkarte „Sicherheit“. Wählen Sie in der Eigenschaft ACL-Objekt die „ACL für allgemein zugängliche Daten (Schreibtisch)“ aus.
3. Klicken Sie auf die Schaltfläche „Weiter“, um die Änderungen zu speichern.

**Ergebnis:** Dem Objekt ist nun die „ACL für allgemein zugängliche Daten (Schreibtisch)“ zugeordnet.

## 4.2.7 ACL für inaktive Objekte

Um einem Objekt die „ACL für inaktive Objekte“ zuzuordnen, gehen Sie wie folgt vor:

Benutzerhilfe
280

<!-- PDF page 281 -->

1. Lokalisieren Sie das Objekt, für das die „ACL für inaktive Objekte" vergeben werden soll und öffnen Sie dessen Metadaten bearbeitend.
2. Wechseln Sie auf die Registerkarte „Sicherheit". Wählen Sie in der Eigenschaft ACL-Objekt die „ACL für inaktive Objekte" aus.
3. Klicken Sie auf die Schaltfläche „Weiter", um die Änderungen zu speichern.

Ergebnis: Dem Objekt ist nun die „ACL für inaktive Objekte" zugeordnet.

Hinweis: Fach- und Domainadministratoren haben weiterhin lesenden und bearbeitenden Zugriff auf das inaktive Objekt.

## 5 Fachadministration

In diesem Kapitel finden Sie Informationen zu wesentlichen Aufgaben für administrative Stellen, insbesondere für Fachadministratoren beschrieben.

## 5.1 Definitionen

### 5.1.1 Aufbauorganisation

Eine Aufbauorganisation repräsentiert das Organigramm (z.B. eines Amtes) und umfasst folgende Bereiche:

- Benutzer
- Hierarchien von Organisationseinheiten (z.B. Organisationseinheiten, Abteilungen).

Hinweis: Diese werden in der Fabasoft eGov-Suite Bayern über die Eigenschaften Untergeordnete Organisationseinheit und Übergeordnete Organisationseinheit abgebildet.

- Stellen (Funktionsbeschreibungen in den Organisationseinheiten) (Eine Beschreibung der Stellen, welche in der Fabasoft eGov-Suite Bayern existieren, finden Sie im Glossar)
- Rollen (Stellen, die ein Benutzer in einer Organisationseinheit einnehmen kann, z.B. „Leiter/in der Abteilung 2")
- Stellvertretungen

### Grundlagen zur Aufbauorganisation

Die Fabasoft eGov-Suite Bayern definiert ein Organisationsmodell, mit dem die Organisation durch abstrakte und konkrete Strukturelemente abgebildet werden kann. Auf Basis dieser Strukturelemente können u.a. Zugriffsrechte vergeben werden.

### 5.1.1.1 Konkrete Struktureinheiten

#### Organisationseinheit (OE)

Eine Organisationseinheit ist ein Element, das speziell für die Abbildung der Aufbauorganisation einer Behörde verwendet wird.

Benutzerhilfe
281

<!-- PDF page 282 -->

Wenn Benutzer einer Organisationseinheit mit der Fabasoft eGov-Suite Bayern arbeiten, so wird für das entsprechende Organisations-Objekt zusätzlich ein konkretes OE-Objekt erfasst, bei dem das Organisations-Objekt referenziert wird.

## Benutzer

Wenn eine Person auch als Fabasoft eGov-Suite Bayern Benutzer arbeitet, so wird zusätzlich ein Benutzer-Objekt erfasst, bei dem das entsprechende Personen-Objekt referenziert wird. Als eGov-Suite Bayern Benutzer kann diese Person Rollen im System einnehmen.

## 5.1.1.2 Abstrakte Strukturelemente

Zur Modellierung werden unabhängig von physischen Personen oder Personengruppen Stellen beziehungsweise Struktureinheiten verwendet. Im Gegensatz zu Organisationseinheiten bilden Struktureinheiten allerdings keine hierarchische Beziehung.

### Struktureinheit

Struktureinheiten werden zum Erstellen einer Aufbauorganisation (Abbildung von Organisationsstrukturen) verwendet, ohne dabei physische Personen oder Personengruppen anzugeben. Eine Struktureinheit definiert einen abstrakten Bereich oder ein abstraktes Personenteam mit spezifischen Aufgabengebieten in einer Aufbauorganisation.

Beispiel für Struktureinheit: Abteilung

### Stelle

Ein Stelle-Objekt wird zur Gliederung einer Struktureinheit in funktionale Aufgaben und Zuständigkeiten verwendet. Stellen können Empfänger von Aktivitäten für Vorgänge im Arbeitsvorrat sein. In jeder Organisationseinheit kann eine Stelle als Standard-Empfänger von Vorgängen festgelegt werden.

Beispiele für Stellen sind: Registrator/in, Leiter/in.

## 5.1.1.3 Zugriffsdefinitionen

Über Zugriffsdefinitionen werden die ACLs für die einzelnen Status eines Objekts definiert. Siehe hierzu auch 4.1 „Zugriffsdefinitionen“.

**Beispiel:** Der Status eines Objekts Ändert sich auf *In Bewertung*. Die Zugriffsdefinition des Objekts definiert für diesen Status eine andere ACL, als derzeit vergeben ist. Somit wird automatisch die definierte ACL für Objekte mit dem Status *In Bewertung* vergeben.

## 5.1.1.4 Access Control Lists (ACLs)

Eine ACL legt eine Liste von Zugriffsrechten fest. Jede Zeile der ACL definiert ein Zugriffsrecht in einer Domäne in Kombination mit einem Organisationseinheiten-Kontext und einem Benutzer-Kontext.

Für die daraus resultierende Rolle werden konkrete Rechte (Zugriffsklassen) ein- und ausgeschaltet (z.B. das Recht zu suchen, Metadaten zu bearbeiten, Primärinhalte zu lesen etc.).

Jedes Objekt referenziert eine ACL. Führen Benutzer eine Aktion auf ein Objekt aus (z.B. Metadaten lesen), so identifiziert das System die aktuelle Rolle, prüft die dem Objekt

Benutzerhilfe
282

<!-- PDF page 283 -->

zugeordnete ACL und stellt fest, ob für seine konkrete Rolle in der ACL der konkrete Zugriff erlaubt ist.

Das Zugriffsprofil von Benutzern ergibt sich aus den Objekten, bei denen die Benutzer auf Grund der zugeordneten ACLs Zugriffsrechte haben.

Siehe hierzu auch 4.2 „ACLs“.

## 5.1.1.5 Rollen und Mandanten

Die aktuelle Rolle eines Benutzers ist für Objekte der Aufbauorganisation (Benutzer, Organisationseinheiten, etc.) besonders wichtig. Der aktuelle Kontext eines Benutzers (setzt sich zusammen aus: Benutzer, Stelle und Mandant) wird zum Beispiel für die Auswertung der Zugriffsrechte herangezogen. Wichtig ist dies zum Beispiel bei der Suche nach Objekten oder bei der Darstellung verschiedener Eigenschaften und Registerkarten.

Wenn sich ein Benutzer am System anmeldet, wird diesem die erste Rolle aus der Eigenschaft Rollen des Benutzer-Objekts zugewiesen, die das Kennzeichen „Standard“ gesetzt hat. Außerdem wird der erste Mandant gewählt, der das Kennzeichen „Standard“ gesetzt hat.

## 5.1.2 Benutzerverwaltung

Benutzer der Fabasoft eGov-Suite Bayern benötigen zum Arbeiten ein eigenes Benutzerobjekt, in dem u.a. die Rolle(n) des Benutzers und seine Arbeitsumgebung definiert werden.

## 5.1.2.1 Personen-Objekte

In der Fabasoft eGov-Suite Bayern werden die Benutzer- und Personenstammdaten getrennt voneinander verwaltet. Ein Personen-Objekt wird zur Haltung der persönlichen Stammdaten (z.B. Adresse, Telefonnummern, etc.) einer Person verwendet, während ein Benutzer-Objekt die sicherheits- und systemrelevanten Informationen (z.B. Login-Name, Rollen, etc.) enthält. Aufgrund dieser Trennung können in der Aufbauorganisation auch Personen erfasst werden. Um ein Benutzer-Objekt mit dem entsprechenden Personen-Objekt zu verknüpfen, muss in der Eigenschaft Person in den Metadaten des Benutzerobjekts das entsprechende Personen-Objekt angegeben werden.

Personen-Objekte, die zur Aufbauorganisation gehören, sind amterübergreifend, also über alle Mandanten lesbar.

## 5.1.2.2 Stellvertretung/Benutzerstellvertretungsobjekt

In der Fabasoft eGov-Suite Bayern arbeitet jeder Benutzer prinzipiell im Kontext einer Rolle. Die Kombination aus Benutzer, Organisationseinheit und Stelle bestimmt im Wesentlichen die Zugriffsrechte auf die Geschäftsfälle des Benutzers. Da es jedoch aus diversen Gründen (z. B. Krankheit, Urlaub, Geschäftsreise) möglich ist, dass jemand seine Aufgaben nicht wahrnehmen kann, muss es einer anderen Person ermöglicht werden, diese Aufgaben anstelle des ursprünglich verantwortlichen Benutzers durchzuführen.

Deshalb besteht in der Fabasoft eGov-Suite Bayern die Möglichkeit, zu jeder Rolle, die einem Benutzer zugeordnet ist, einen oder mehrere Stellvertreter zu definieren. Der Stellvertreter kann die Stellvertreterrolle in einem festgelegten Zeitraum (z. B. bei Urlaub) einnehmen, um im

Benutzerhilfe
283

<!-- PDF page 284 -->

Rahmen der für die Stellvertretung definierten Zugriffsrechte auf die Geschäftsfälle des Vertretenen zuzugreifen.

Dafür ist es notwendig, dass durch die Fachadministration dem Benutzer ein Stellvertretungsobjekt zur Verfügung gestellt wird.

Die Metadaten des Benutzerstellvertretung-Objekts sind im Kapitel 6.17 „Benutzerstellvertretung“ beschrieben.

Ein Benutzer kann außerdem persönlich vertreten werden. Die persönliche Vertretung ermöglicht dem Stellvertreter den Zugriff auf Aktivitäten, die im Laufweg des Vertretenen persönlich vorgeschrieben wurden.

## 5.1.2.3 Arbeitsumgebungen

Die Arbeitsumgebung legt benutzerspezifische Einstellungen fest. Dazu gehören häufig verwendete Objekte, Sprache, Währung, Schreibtisch, etc.

Benutzer können mehrere, müssen jedoch mindestens eine Arbeitsumgebung haben. Jede dieser Arbeitsumgebungen definiert selbst wiederum benutzerspezifische Einstellungen.

Im Rahmen der Metadatenbearbeitung eines Benutzer-Objekts muss die Arbeitsumgebung festgelegt werden. Es ist dazu notwendig, dass das Benutzer-Objekt mit Eigenschaften bearbeitend geöffnet wird. Anschließend wechselt man auf die Registerkarte „Umgebungen“ und kann hier die im Kapitel 6.16.2 „Registerkarte „Umgebungen“ beschriebenen Eigenschaften setzen.

## 5.1.2.4 Metadaten der Arbeitsumgebung

In den folgenden Kapiteln werden diejenigen Metadaten der Arbeitsumgebung beschrieben, welche für die Administration von Bedeutung sind:

### 5.1.2.4.1 Häufig verwendet

Diese Liste dient u.a. Informationszwecken und beinhaltet die Objekte, die von dem Benutzer am häufigsten verwendet werden. Ein Objekt wird nach dem Auswählen in die Aufzählung aufgenommen.

### 5.1.2.4.2 Arbeitsumgebung

Die Metadaten der Arbeitsumgebung sind in dem Kapitel 6.18 „Arbeitsumgebung (Administrative Sicht)“ beschrieben.

## 5.1.3 Globaler Papierkorb

Um ein ungewolltes, endgültiges Löschen zu verhindern, kann bei jedem Mandanten auf der Registerkarte „System-Konfiguration“ in der Eigenschaft Globaler Papierkorb ein Globaler Papierkorb eingerichtet werden, der alle vernichteten Objekte aufnimmt. Globale Papierkörbe werden dabei in Benutzerordner strukturiert (sobald ein Benutzer ein Objekt in den Papierkorb gelegt hat), welche wiederum in Datumsordner unterteilt sind (Löschdatum des Objekts).

Benutzerhilfe
284

<!-- PDF page 285 -->

Beim globalen Papierkorb kann eine Zeitspanne definiert werden, nach der Objekte „ablaufen“. Alle abgelaufenen Objekte können tatsächlich vernichtet werden. Ebenso besteht die Möglichkeit, noch nicht abgelaufene Objekte zu vernichten.

Die Beschreibung der Metadaten eines globalen Papierkorbs finden Sie im Kapitel 6.20 „Globaler Papierkorb“.

## 5.1.4 Feiertage und Zeitspannen

Die termingerechte Bearbeitung von Geschäftsfällen spielt in einer öffentlichen Verwaltung eine zentrale Rolle. Im Rahmen des Workflows der Fabasoft eGov-Suite Bayern können für das Verfügen, Weiterleiten und auf Wiedervorlage legen von Aktivitäten Termine festgelegt werden, wobei arbeitsfreie Tage berücksichtigt werden können. Wird durch den Benutzer ein Termin ausgewählt, der arbeitsfrei ist bzw. auf einen Feiertag fällt, wird dieser durch eine entsprechende Meldung darauf aufmerksam gemacht.

Die globalen Einstellungen für Feiertagslegung und Fristlegung erfolgen auf Mandanten-Ebene. In der Konfiguration können dabei mithilfe einer Feiertagstabelle Werktage, Feiertage und Zeitspannen festgelegt werden.

## 5.1.4.1 Feiertagstabellen verwalten

In den Eigenschaften des Mandanten kann durch den Administrator auf der Registerkarte „System-Konfiguration“ in der Eigenschaft Verwendete Feiertage und Zeitspannen ein Feiertagstabelle-Objekt erzeugt und eingetragen werden. Nähere Informationen zu den Metadaten einer Feiertagstabelle finden Sie im Kapitel 6.21 „Feiertagstabelle“.

## 5.1.4.2 Feiertage verwalten

Feiertage können in einem Verwaltungswerkzeug am Schreibtisch oder direkt in der Eigenschaft Feiertage einer Feiertagstabelle erzeugt werden. Eine Beschreibung der Metadaten finden Sie im Kapitel 6.22 „Feiertage“.

## 5.1.4.3 Zeitspannen verwalten

Zeitspannen können in einem Verwaltungswerkzeug am Schreibtisch oder direkt in der Eigenschaft Feiertage einer Feiertagstabelle erzeugt werden. Eine Beschreibung der Metadaten finden Sie im Kapitel 6.23 „Zeitspanne“.

## 5.1.4.4 Zeitspannen verwenden

Die verwendbaren Zeitspannen können grundsätzlich in allen Datums- und Zeiteigenschaften eingesehen werden, indem mit der rechten Maustaste auf das Eingabefeld des Datums bzw. der Zeit geklickt wird. Sind keine Zeitspannen in der aktuellen Feiertagstabelle definiert, erscheint einzig und allein der Menüeintrag „Jetzt“. Sind Zeitspannen in der aktuellen Feiertagstabelle definiert, wird für jede einzelne ein eigener Menüeintrag generiert.

Durch Auswahl eines Eintrags aus diesem Menü wird zum bereits eingetragenen Datum andernfalls zum aktuellen Datum die Länge der Zeitspanne hinzuaddiert und als (neues) Datum (mit Zeit) eingetragen.

Benutzerhilfe
285

<!-- PDF page 286 -->

# 5.1.5 Workflow

## 5.1.5.1 Voreinstellungen im Workflow

Über Voreinstellungen im Workflow kann das Verhalten beim Verfügen, Weiterleiten und Anzeigen von Aktivitäten im Workflow der Fabasoft eGov-Suite Bayern beeinflusst werden. Voreinstellungen im Workflow können auf folgenden Ebenen hierarchisch definiert werden:

- In der Arbeitsumgebung, Eigenschaft Voreinstellungen im Workflow
- In Benutzer-Objekten, Eigenschaft Persönliche Voreinstellungen im Workflow
- In Organisationseinheiten-Objekten, Eigenschaft Organisationseinheiten-Voreinstellungen im Workflow
- In der Workflow-Konfiguration des Mandanten, Eigenschaft Globale Voreinstellungen im Workflow

Wenn Voreinstellungen im Workflow mittels „Eigenschaften bearbeiten“ geöffnet werden, stehen folgende Eigenschaften zur Verfügung:

- Übergeordnete Voreinstellungen überschreiben: Die Einstellung „Ja“ bewirkt, dass die Angaben in hierarchisch untergeordneten Voreinstellungen im Workflow nicht mehr berücksichtigt werden. Die Hierarchie ist Arbeitsumgebung &gt; Benutzer &gt; Gruppe &gt; Workflow-Konfiguration des Mandanten.

Beispiel: Sind in der Arbeitsumgebung Voreinstellungen im Workflow definiert und ist in diesen die Eigenschaft Übergeordnete Voreinstellungen überschreiben auf „Ja“ gesetzt, so werden die Voreinstellungen, die beim Benutzer, in der Gruppe oder im Mandanten definiert sind, nicht mehr berücksichtigt (=nur die Voreinstellungen im Workflow der Arbeitsumgebung kommen zum Zug).

- Letzte bearbeitete Aktivität hervorheben: Wird diese Eigenschaft auf „Ja“ gesetzt, wird jene Aktivität farblich hervorgehoben, die als letzte bearbeitet wurde.
- Bevorzugte &lt;...&gt;: Die in diesen Objektlisten definierten Objekte werden in den jeweiligen Eigenschaften als Vorauswahl in Drop-down-Listen angeboten. Damit können die in der Drop-down-Liste angebotenen Objekte auf die relevanten eingeschränkt werden.
Hinweis: Wird in den jeweiligen Eigenschaften eine Suche durchgeführt, werden alle suchbaren Objekte zur Auswahl angeboten.
- Muster für Verfügungen: Wenn Muster für Verfügungen zum Einsatz kommen, können hier jene definiert werden, die beim Durchführen von Verfügungen zur Auswahl angeboten werden sollen.
- Maximale Anzahl an Einträgen in „Übernommene Aktivitäten“: Über diese Eigenschaft kann die Anzahl der Einträge in der Liste der übernommenen Aktivitäten eingeschränkt werden.
Hinweis: Die Liste der übernommenen Aktivitäten wird bei der Übernahme einer Aktivität durch den Stellvertreter aktualisiert, dadurch kann es vorkommen, dass die Einträge in dieser Liste bis zu der nächsten Übernahme einer Aktivität den definierten Maximalwert überschreitet.

Benutzerhilfe

<!-- PDF page 287 -->

Benutzerhilfe

# 5.1.5.2 Im Workflow beteiligte Benutzer und Organisationseinheiten

Administratoren und der Support bekommen auf der Registerkarte „Sicherheit“ zusätzlich noch die Eigenschaften Im Workflow beteiligte Benutzer und Im Workflow beteiligte Organisationseinheiten angezeigt.

Hier haben diese Stellen die Möglichkeit, im Workflow beteiligte Benutzer und Organisationseinheiten über den Kontextmenüeintrag „Ausschneiden“ zu entfernen und ihnen somit die Workflowrechte zu entziehen.

# 5.1.5.3 Prozessdefinitionen

Prozessdefinitionen sind Komponentenobjekte, die als Vorlagen für Prozesse (Prozessinstanzen) dienen können, d.h. in der Fabasoft eGov-Suite Bayern können etwa beim Erzeugen von Vorgängen Prozessdefinitionen gewählt werden, um einen bereits vorgefertigten Laufweg zu erstellen.

Relevante Eigenschaften von Prozessdefinitionen sind:

- Mehrsprachiger Name: In diesem Feld wird der (sprachabhängige) Name der Prozessdefinition hinterlegt.
- Status der Prozessdefinition: Dieses Auswahlfeld dient zur Klassifizierung der Verwendbarkeit der Prozessdefinition, wobei die Werte In Bearbeitung, Verwendbar, Als Subprozess verwendbar und Nicht verwendbar zur Verfügung stehen. Neue Prozessdefinitionen erhalten als Initialwert den Status In Bearbeitung.

Hinweis: Der definierte Status beeinflusst nicht die Verwendbarkeit der Prozessdefinition als Prozessdefinition bei einem Vorgang.

# 5.1.5.4 Musterverfügungen

Laufwege von Aufträgen können vom Benutzer direkt beeinflusst werden, z.B. über den grafischen Prozesseditor oder über den Menüeintrag Verfügen aus dem Kontextmenü einer Aktivität.

Prozesse, die im Ablauf immer wieder gleich sind (Standardprozesse) können für die Benutzer bereits vordefiniert werden. Die Benutzer haben dann die Möglichkeit, Standardlaufwege einfach und schnell auszuwählen und sind nicht gezwungen, immer wieder die gleichen Einstellungen zu treffen.

Diese Standardprozesse können für die Benutzer als sogenannte Musterverfügungen hinterlegt werden.

# 5.1.6 Einen Bericht konfigurieren

Eine „Berichtsvorlage“ ist ein Komponentenobjekt, das für die Erstellung von Berichten verwendet werden kann. In dieser Vorlage wird definiert, welche Objektklassen berücksichtigt werden und welche Auswertung durchgeführt wird. Zusätzlich können Skripts hinterlegt werden, die das Layout und die Art der Darstellung (z.B. Gruppierung, Summenbildung, Trennzeichen usw.) bestimmen.

Hinweise:

Benutzerhilfe

<!-- PDF page 288 -->

- Ein neues Objekt der Objektklasse Berichtsvorlage kann nur in einem Verwaltungswerkzeug von einem Domänenadministrator erzeugt werden.
- Berichtvorlagen müssen für eine ausgewählte Anwendergruppe (Benutzer mit definierten Rollen) explizit zur Verfügung gestellt werden. Dies geschieht mithilfe des Konfigurationsobjektes der Klasse „Konfiguration für Active Report Extensions“ in der Eigenschaft Verfügbare Berichtsvorlagen.

Auf der Registerkarte „Berichtsvorlage“ stehen folgende Felder für die Definition einer Berichtsvorlage zur Verfügung:

- **Standard-Berichtsvorlage verwenden**: In diesem Feld wird festgelegt, ob die im Konfigurationsobjekt der Softwarekomponente Active Report Extension im Feld Standard-Berichtsvorlage hinterlegte Berichtsvorlage verwendet wird oder nicht. Diese Option sollte gewählt sein, da die Aufbereitung der Daten als HTML dadurch festgelegt wird.
- **Berichtsvorlagendefinition**: In diesem Feld werden verschiedene Parameter für die Erstellung des Berichts definiert.
- **Ausdruck**: Die Bezeichnung des Berichts kann statisch festgelegt oder dynamisch mithilfe eines Ausdrucks (Expression) ermittelt werden.
- **Objektklasse/Suchmuster**: In diesem Feld kann die Suche auf eine Objektklasse eingeschränkt oder ein Suchmuster angegeben werden.
- **Objekte des Berichts**: In diesem Feld können konkrete Objekte angegeben werden, die für die Erstellung des Berichts verwendet werden sollen.
- **Einschränkungen**: In diesem Feld können Einschränkungen der auszuwertenden Objekte vorgenommen werden.
- **Suchformularseite verwenden**: In diesem Feld kann ein Suchformular angegeben werden, das bevor der Bericht generiert wird zur Eingabe weiterer Suchkriterien angezeigt wird. Dadurch können die auszuwertenden Objekte eingeschränkt werden.
- **Einschränkende Eigenschaften**: In diesem Feld können Eigenschaften hinterlegt werden. Bevor der Bericht generiert wird, können Benutzer für diese Eigenschaften weitere Suchkriterien angeben.
- **Feste Einschränkung der Suche (WHERE-Klausel)**: In diesem Feld kann eine WHERE-Bedingung angegeben werden, um die auszuwertenden Objekte weiter einzuschränken.
- **Ausdruck**: In diesem Feld kann ein Ausdruck (Expression) angegeben werden, um die auszuwertenden Objekte weiter einzuschränken.
- **Softwarekomponente**: In diesem Feld wird eine Softwarekomponente angegeben, der diese Einstellungen zugeordnet werden. Durch die Angabe einer Softwarekomponente bleiben die Einstellungen nach einem Update erhalten.
- **Ausgabe**: In diesem Feld können ausgegebene Zeilen und Spalten definiert werden.
- **Ausgabeoptionen**: In diesem Feld können verschiedene Optionen für die Ausgabe des Berichts festgelegt werden.

## 5.1.7 Fachdaten am Aktenplaneintrag konfigurieren

Um Fachdaten am Aktenplaneintrag zu konfigurieren, gehen Sie folgendermaßen vor:

Benutzerhilfe
288

<!-- PDF page 289 -->

1. Öffnen Sie durch Klicken mit der rechten Maustaste auf den Aktenplaneintrag, für den Sie ein Fachdatum konfigurieren wollen, dessen Kontextmenü und klicken Sie auf den Menüeintrag „Eigenschaften“.
2. Wechseln Sie in den Eigenschaften auf die Registerkarte „FAI“.
3. Im Feld „Erlaubte Begriffe“ klicken Sie auf „Eintrag hinzufügen“ und anschließend auf „Neu“, um ein neues „Fachdaten Begriff“ Objekt zu erstellen. Es öffnet ein Dialogfenster. Hier klicken Sie auf die Objektklasse „Fachdaten Begriff“ und geben eine Referenz ein (bitte beachten Sie, dass hier keine Leerzeichen verwendet werden dürfen und vermeiden Sie Sonderzeichen). Als Komponente wählen Sie „Built-in Settings“.

![img-0.jpeg](img-0.jpeg)

4. Im nächsten Fenster können Sie das Fachdatum noch genauer beschreiben (mehrsprachiger Name, Ober- und Unterbegriffe) und einen Fachdaten Typ auswählen (siehe Tabelle). Bestätigen Sie Ihre Auswahl mit „Weiter“. Das Fachdatum wird nun im Feld „Erlaubte Begriffe“ angezeigt.
5. Fügen Sie im Feld „Initialisierungswerte für Fachdaten“ durch Klick auf „Eintrag hinzufügen“ eine neue Zeile hinzu.

![img-1.jpeg](img-1.jpeg)

6. Im nächsten Dialogfenster öffnen Sie durch Klick auf das Suchen-Symbol im „Suchen und hinzufügen“ das Drop-Menü mit den möglichen Objektklassen. Wählen Sie die Objektlassen aus, für die Sie das Fachdatum konfigurieren wollen.

Benutzerhilfe
289

<!-- PDF page 290 -->

Benutzerhilfe
290

![img-2.jpeg](img-2.jpeg)
Initialisierungswerte für Fachdaten (1 von 1)

7. Klicken Sie nun auf „Eintrag hinzufügen“ in der Eigenschaft „Werte“. Es öffnet sich ein neues Dialogfenster.
8. Wählen Sie im neuen Fenster das Fachdatum aus und bestimmen Sie den Wert. Bestätigen Sie die Eingabe durch Klicken auf „Weiter“.
Hinweis: Dieser Wert wird nur beim Erstellen eines neuen Objektes des Aktenplaneintrags übernommen. Für bestehende Objekte muss der Wert manuell vom Sachbearbeiter eingetragen werden.
9. Bestätigen Sie Ihre Eingaben und schließen sie die übrigen Dialogfenster durch klicken auf „Weiter“. Das Fachdatum ist nun konfiguriert.

## Beispiel: Boolescher Typ

1. Wechseln Sie auf die Registerkarte „FAI“ des Aktenplaneintrags.
2. Erzeugen Sie in der Liste Erlaubte Begriffe einen Fachdaten Begriff mit dem Namen „Vertraulich“ und Fachdaten Typ „Boolscher Typ“.

![img-3.jpeg](img-3.jpeg)

3. Als nächstes erzeugen Sie eine neue Zeile im Aggregat Initialisierungswerte für Fachdaten und wechseln Sie in die Detailansicht.

<!-- PDF page 291 -->

4. Fügen Sie in die Eigenschaft „Objektklassen" die Objektklasse „Erledigung" per Suche ein und befüllen Sie das Aggregat „Werte" mit einer Zeile für die boolsche Eigenschaft „Vertraulich". Optional können Sie auch einen Wert vergeben.

![img-4.jpeg](img-4.jpeg)

5. Speichern Sie den Aktenplaneintrag ab.

**Ergebnis:**

- Das Fachdatum „Vertraulich" steht in der gesamten Aktenplaneintrag Hierarchie zur Verfügung. Bei Erledigungen ist das Fachdatum bereits initialisiert.
- In den Formularen der Geschäftsobjekte wird die Registerkarte „Fachdaten" angezeigt.

Hinweis: Es stehen nur Schlagworte/Fachdaten Begriffe zur Verfügung, welche in der Liste Erlaubte Begriffe eingetragen sind.

## 5.1.8 Suchordner Administration

Der Suchordner Administration wurde eingerichtet, um die Administratoren bei der Massendatenbearbeitung zu unterstützen. Der Suchordner Administration bietet die Möglichkeit, Änderungen an vielen Objekten gleichzeitig durchzuführen, sowie Eigenschaften dieser Objekte unabhängig von den bei der Objektklasse definierten Formularen zu bearbeiten.

## 5.1.8.1 Eigenschaften übertragen

Mithilfe der Operation „Eigenschaften übertragen" im Kontextmenü eines „Suchordners Administration" können die Werte mehrerer Eigenschaften eines Musterobjektes auf mehrere Objekte übertragen werden. Der Fachadministrator kann somit, ohne jedes Objekt einzeln bearbeiten zu müssen, in wenigen Klicks eine Sammelbearbeitung der Eigenschaften von mehreren Objekten durchführen.

Dem Fachadministrator stehen zwei Möglichkeiten zur Auswahl jener Objekte zur Verfügung, deren Eigenschaften bearbeitet werden sollen:

- Definition und Hinterlegung eines Suchmusters
- Definition in der Objektlisten-Eigenschaft Eigenschaften übertragen

Falls ein Suchmuster und auch eine Objektliste definiert sind, werden die Eigenschaften auf die Objekte der Objektliste übertragen.

Benutzerhilfe

<!-- PDF page 292 -->

Drei Übertragungsarten der Eigenschaften stehen zur Verfügung:

- „Überschreiben“
Ersetzt die aktuellen Werte bei allen gefundenen bzw. ausgewählten Objekten mit den Werten des Musterobjekts.

- „Hinzufügen“
Den entsprechenden Objekten werden die ausgewählten Eigenschaften des Musterobjekts hinzugefügt. Falls eine Eigenschaft Singular ist (z.B. String, Boolean, ...) verhält sich „Hinzufügen“ gleich wie „Überschreiben“.

- „Löschen“
Die Übertragungsart „Löschen“ leert die zu übertragenden Eigenschaften aller gefundenen bzw. ausgewählten Objekte und setzt diese somit auf NULL.

## 5.1.8.2 Eigenschaften synchronisieren

Mit der Operation „Eigenschaften synchronisieren“ im Kontextmenü des „Suchordners Administration“ können die Werte von Eigenschaftspfaden auf Eigenschaften übernommen werden. Für alle gefundenen bzw. ausgewählten Objekte werden die Werte der Quell-Eigenschaftspfade auf die Ziel-Eigenschaften entsprechend der Übertragungsart übertragen.

## 5.1.8.3 Admin-Funktionen

Im Kontextmenü eines Suchordner Administration stehen Ihnen weitere Funktionen als Unterpunkte des Kontextmenüpunktes „Admin-Funktionen“ zur Verfügung, welche in den folgenden Kapiteln näher beschrieben werden.

Es wird empfohlen zumindest die Admin Funktionen 5.1.8.3.1 „Aktualisierung des Objektnamens“, 5.1.8.3.3 „Akten in Aktenplaneintrag eintragen“ und 5.1.8.3.4 „Berichtigung von „Bezügen““ nach einem Update der Fabasoft eGov-Suite Bayern auszuführen.

Die gewünschten Objekte, auf denen die jeweilige Admin Funktion ausgeführt werden soll, können über zwei Wege definiert werden:

- Ein Suchmuster
Hinweis: Wenn Sie ein Suchmuster zum Ermitteln der Objekte verwenden möchten, muss das Suchmuster zuerst erzeugt werden, da Sie beim Ausführen der Funktion keine Möglichkeit haben, ein Suchmuster zu erzeugen.

- Durch Ablage der Objekte im Suchordner Administration
Weiters haben Sie die Möglichkeit, alle Änderungen, die im Zuge der Admin-Funktionen gemacht werden, in einer neuen Version zu speichern. Hierzu können Sie in dem Feld Änderungen in einer Version den Wert „Ja“ angeben. Im Rahmen des Erzeugens einer neuen Version können Sie auch in dem Feld Beschreibung für neue Version eine Beschreibung angeben (entspricht dem Feld Beschreibung der zu sichernden Version, wenn Sie eine Version eines Objekts speichern möchten).
Hinweis: Das Feld Beschreibung für neue Version ist nur bearbeitbar, wenn in dem Feld Änderung in neuer Version speichern der Wert „Ja“ gesetzt wurde.

Damit die Transaktionen nicht zu groß werden empfiehlt es sich, einen Commit-Block zu definieren. Nach der Änderung von der angegebenen Anzahl von Objekten wird ein

Benutzerhilfe
292

<!-- PDF page 293 -->

Transaktions-Commit ausgeführt und somit werden die Änderungen für diese Objekte gespeichert. Ist dieser Wert nicht definiert, wird ein Standardwert von „100“ verwendet.

Möchten Sie die Operation in einem Report dokumentiert haben, so kann diese Einstellung hier getroffen werden. Nach Abschluss der Operation wird ein Report geöffnet, in dem das Ergebnis für jedes Objekt angeführt ist.

## 5.1.8.3.1 Aktualisierung des Objektnamens

Der Kontextmenüpunkt „Aktualisierung des Objektnamens“ bietet Ihnen die Funktionalität, auf allen Objekten die Bildung des Objektnamens neu berechnen und setzen zu lassen.

## 5.1.8.3.2 Setzen der Eigentümer

Diese Admin-Funktion bietet Ihnen die Möglichkeit, auf allen Objekten im Suchordner Administration bzw. den Objekten, welche über ein Suchmuster gefunden werden, einen neuen Eigentümer und/oder eine neue Organisationseinheit zu definieren.

**Hinweis:** Werden die Felder Neuer Eigentümer oder Neue Organisationseinheit nicht gesetzt, so werden die jeweiligen Eigenschaften Eigentümer bzw. Organisationseinheit nicht überschrieben.

## 5.1.8.3.3 Akten in Aktenplaneintrag eintragen

Diese Funktionalität stellt sicher, dass sämtliche Akten in den Listen der jeweiligen Aktenplaneinträge vorhanden sind.

## 5.1.8.3.4 Berichtigung von „Bezügen“

Stellt sicher, dass für Vorgänge, die vor dem Upgrade der Fabasoft eGov-Suite Bayern erstellt wurden, die „Bezüge“ in der Baumansicht verwendet werden können.

## 5.1.9 Verwalten von Transfer- und Aufbewahrungsfristen

In Aktenplaneinträgen, Akten und Vorgängen werden in den Eigenschaften Transferfrist bzw. Aufbewahrungsfrist die jeweiligen Aussonderungsfristen hinterlegt. Diese Fristen werden in Form von Objekten der Klasse „Frist“ definiert. Fristen können von Administratoren in einem Verwaltungswerkzeug erzeugt werden; zur Definition einer Frist sind in der Fabasoft eGov-Suite Bayern folgende Eigenschaften relevant:

- **Name:** In diesem Feld ist der gewünschte Name für die Frist einzugeben, der die Frist beschreibt.
- **Jahre bzw. Monate bzw. Tage:** Mithilfe dieser Eigenschaften wird die Länge der Frist definiert. Für gewöhnlich genügt die Eingabe der (ganzen) Jahre und Monate. Nötigenfalls kann zusätzlich in der Eigenschaft Zeitspanne eine kleinere Spanne festgelegt werden.
- **Hinweis:** Die Gesamtdauer ergibt sich aus der Summe aller Einträge.

Benutzerhilfe
293

<!-- PDF page 294 -->

Benutzerhilfe
294

# 5.1.9.1 Fristen beim Mandanten übergreifenden Arbeiten

Wenn Mandanten-übergreifend gearbeitet wird, so ist darauf zu achten, dass alle Benutzer Zugriff auf die im Aktenplaneintrag, der Akte bzw. Vorgang verwendeten Objekte der Klasse „Frist“ haben. Diese Zugriffsrechte werden z.B. beim Anbringen der Unterschrift „z.A.“ benötigt.

Alternativ können Sie die mit der Fabasoft eGov-Suite Bayern mitgelieferten Objekte der Klasse „Frist (Komponentenobjekt)“ verwenden, sollten diese Ihren Anforderungen genügen. Die Verwendung dieser Objekte bietet den Vorteil, dass keine Zugriffsrechte vergeben werden müssen, da alle Benutzer ausreichenden Zugriff auf diese Objekte besitzen.

# 5.2 Anleitungen zu Fachadminprozessen

## 5.2.1 Organisationseinheiten

Im Folgenden werden verschiedene Aktionen beschrieben, die ein Fachadministrator zur Anpassung der Organisationseinheiten vornehmen kann.

### 5.2.1.1 Eine Organisationseinheit anlegen

Zum Anlegen einer neuen Organisationseinheit gehen Sie wie folgt vor:

1. Wechseln Sie auf Ihren Schreibtisch.
2. Wählen Sie in der Menüleiste den Menüpunkt „Neu“.
3. Selektieren Sie aus der angebotenen Liste den Typ „Organisationseinheit“.
4. Legen Sie den Namen der Organisationseinheit (Kurzbezeichnung) fest und bestätigen Sie mit „Weiter“. Die Organisationseinheit wird auf den Schreibtisch gelegt.
5. Wählen Sie über einen Rechtsklick auf die neue Organisationseinheit die Option „Eigenschaften bearbeiten“ aus, um die Metadaten zu bearbeiten.
6. Legen Sie die Eigenschaft „Behörde“ und die restlichen Metadaten der Organisationseinheit fest.

Für nähere Informationen der Metadaten von Organisationseinheiten siehe Kapitel 6.19 „Organisationseinheit“.

### 5.2.1.2 Eine Organisationseinheit verschieben

Gehen Sie hierzu wie folgt vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Suchen Sie die übergeordnete OE der zu verschiebenden Organisationseinheit über die Lupensuche.
3. Wählen Sie die Organisationseinheit aus und legen Sie diese durch Bestätigen mit „Weiter“ auf dem Schreibtisch ab.
4. Öffnen Sie die Eigenschaften der Organisationseinheit bearbeitend.
5. Schneiden Sie die zu verschiebende OE aus der Eigenschaft Untergeordnete Organisationseinheiten über das Kontextmenü (Rechtsklick) durch Auswählen des Menüpunkts Ausschneiden aus und Bestätigen Sie mit „Weiter“.
**Hinweis:** Die Organisationseinheit befindet sich in der Zwischenablage.

<!-- PDF page 295 -->

6. Lokalisieren Sie die gewünschte Zielorganisationseinheit, siehe Punkt 2 und 3.
7. Fügen Sie die in der Zwischenablage befindliche Organisationseinheit über den Menüpunkt Zwischenablage „Verknüpfung einfügen“ der Eigenschaft Untergeordnete Organisationseinheiten hinzu.

## 5.2.1.3 Eine Organisationseinheit deaktivieren

Gehen Sie hierzu wie folgt vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Suchen Sie die gewünschte Organisationseinheit über die Lupensuche.
3. Wählen Sie die Organisationseinheit aus und legen Sie diese durch Bestätigen mit „Weiter“ auf dem Schreibtisch ab.
4. Bearbeiten Sie die Metadaten der Organisationseinheit.
5. Die Deaktivierung einer Organisationseinheit erfolgt durch Setzen des Feldes Aktiv auf den Wert „Nein“.
6. Bestätigen Sie die Änderung mit „Weiter“.

## 5.2.2 Benutzer

Im Folgenden werden verschiedene Aktionen beschrieben, die ein Fachadministrator zur Anpassung der Benutzer vornehmen kann. Um Personen den Zugang zur Fabasoft eGov-Suite Bayern zu gewähren, muss ein Benutzer-Objekt für jede Person angelegt werden.

## 5.2.2.1 Einen neuen Benutzer anlegen

Um einen Benutzer zu erzeugen gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren Schreibtisch.
2. Klicken Sie auf die Schaltfläche „Neu“ und wählen Sie den Typ „Benutzer“ aus. Bestätigen Sie mit „Weiter“. Es öffnet sich nun der sogenannte Wizard zum Anlegen eines neuen Benutzers.

**Hinweis:** Benutzer-Objekte können entweder in einem Verwaltungswerkzeug, auf dem Schreibtisch oder in der Liste der „Benutzerobjekte“ in der Domänen-Administration erzeugt werden.

3. Geben Sie die gewünschten Metadaten des neuen Benutzerobjekts ein und bestätigen Sie mit „Weiter“.
4. Legen Sie gewünschten Metadaten im Formular Zusätzliche Einstellungen fest und bestätigen Sie mit „Beenden“.

**Hinweis:** Sie haben an dieser Stelle die Möglichkeit gleich ein Stellvertretungsobjekt, eine Arbeitsumgebung und einen Postkorb für diesen Benutzer anzulegen. Diese werden erst beim ersten Login dieses Benutzers angelegt.

Die wichtigsten Metadaten des Objektyps „Benutzer“ werden im Kapitel 6.16 „Benutzer“ beschrieben.

Benutzerhilfe
295

<!-- PDF page 296 -->

Benutzerhilfe
296

# 5.2.2.2 Die Stammdaten eines Benutzers pflegen

1. Suchen Sie das betroffene Benutzer-Objekt als Administrator.
2. Öffnen Sie die Metadaten des Benutzers bearbeitend.
3. Bearbeiten Sie die Daten die Sie ändern wollen.
4. Schließen Sie die Änderungen mit „Weiter“ ab.

# 5.2.2.3 Rollen vergeben

Um einem Benutzer eine Rolle zu vergeben, gehen Sie folgendermaßen vor:

1. Suchen Sie das betroffene Benutzer-Objekt als Administrator.
2. Öffnen Sie die Metadaten des Benutzers bearbeitend.
3. Auf der Registerkarte „Benutzer“ finden Sie das Feld Rollen.
4. Erzeugen Sie eine neue Zeile in dem Feld Rollen.
5. Wählen Sie nun die gewünschte Rolle und speichern Sie die Änderungen durch Klick auf die Schaltfläche „Weiter“.

Im Feld Rollen muss pro Rolle eine Stelle vergeben werden. Verfügbare Stellen können in der DropDown-Auswahlliste ausgewählt werden.

**Hinweis:** Die Stellen Domänenadministrator, Support und Administration können nur von Benutzern mit der Stelle Domänenadministrator vergeben werden.

# 5.2.2.4 Ein Benutzerstellvertretungsobjekt anlegen

Ein Benutzerstellvertretungsobjekt kann gleich mit Hilfe des Wizard zum Anlegen eines neuen Benutzers automatisch angelegt werden.

**Hinweis:** Jedem Benutzerobjekt muss genau ein individuelles Stellvertretungsobjekt zugewiesen werden, damit die Stellvertretung ausgeübt und vom Benutzer eingerichtet werden kann.

Wollen Sie das Benutzerstellvertretungsobjekt nachträglich erstellen, gehen Sie wie folgt vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Suchen Sie das gewünschte Benutzerobjekt mit Hilfe der Lupensuche.
3. Wählen Sie das Benutzerobjekt aus und Bestätigen Sie mit „Weiter“ um das Objekt auf dem Schreibtisch abzulegen.
4. Öffnen Sie mit einem Rechtsklick auf das Benutzerobjekt das Kontextmenü und wählen Sie den Menüpunkt „Eigenschaften“.
5. Wählen Sie in der Eigenschaft Stellvertretungen die Schaltfläche „Neu“ aus.
6. Bearbeiten Sie das soeben erstellte Benutzerstellvertretungsobjekt „Neufassung von Benutzerstellvertretung“ durch Rechtsklick und Auswahl des Menüpunkts „Eigenschaften“.

<!-- PDF page 297 -->

7. Wechseln Sie auf die Registerkarte Sicherheit und legen Sie in der Eigenschaft Eigentümer den Benutzer als Eigentümer fest und bestätigen Sie mit „Weiter“.
8. Klicken Sie im Metadatenformular des Benutzers auf „Übernehmen“, damit der Name des Stellvertretungobjekts aus dem Benutzerobjekt übernommen wird. Schließen Sie die Einrichtung mit „Weiter“ ab.

Die Einrichtung der Stellvertretung durch den Benutzer kann wie im Kapitel 2.14 „Stellvertretung“ beschrieben erfolgen.

## 5.2.2.5 Eine Benutzerstellvertretung deaktivieren

Prinzipiell kann eine Stellvertretung durch den jeweiligen Gültigkeitsbereich, also durch das Setzen des Start- und Enddatums der Stellvertretung aktiviert bzw. deaktiviert werden.

Meldet sich ein Benutzer am System an, während die Stellvertretung aktiviert ist, wird vom System gefragt, ob die Stellvertretung beendet werden soll. Wird hier „Ja“ gewählt, wird die Stellvertretung beendet.

Um eine Benutzerstellvertretung generell zu „deaktivieren“, muss in der entsprechenden Eigenschaft auf dem Register „Stellvertretungen“ in den Metadaten des Benutzer-Objektes der Verweis auf das Benutzerstellvertretung-Objekt entfernt werden. Dies geschieht, indem aus der Drop-down-Liste der leere Eintrag in der ersten Zeile der Liste ausgewählt wird.

**Hinweis:** Alternativ kann das Enddatum gesetzt oder die Stellvertreter ausgetragen werden.

## 5.2.3 Geschäftsgang

Im Folgenden werden verschiedene Aktionen beschrieben, die ein Fachadministrator zur Anpassung des Workflows vornehmen kann.

## 5.2.3.1 Einen Posteingang einrichten

In einem Posteingang können alle gescannten Dokumente erfasst werden, indem man im Posteingang ein Verzeichnis in der lokalen Dateistruktur auswählt. Das Verzeichnis wird im Feld Pfad zum Importverzeichnis im Posteingang angegeben. Der Inhalt des Verzeichnisses kann über die Schaltfläche „Verzeichnisinhalt importieren“ in den jeweiligen Postkorb übernommen werden.

### 5.2.3.1.1 Einen neuen Posteingang erzeugen und Metadaten bearbeiten

Ein Posteingang kann, wie im Kapitel 2.1.1.1 „Ein Objekt neu erstellen“ durch die Auswahl des Typs „Posteingang“ erzeugt werden.

### 5.2.3.1.2 Einen Posteingang zur Verfügung stellen

Um den Posteingang für die Benutzer zur Verfügung stellen zu können, gibt es zwei Möglichkeiten:

Den Posteingang für die ganze Organisationseinheit zur Verfügung stellen

1. Suchen Sie die Organisationseinheit und legen Sie diese auf dem Schreibtisch ab.

Benutzerhilfe
297

<!-- PDF page 298 -->

2. Klicken Sie mit der rechten Maustaste auf die OE und wählen Sie den Menüpunkt „Eigenschaften“ aus.
3. Wählen Sie die Registerkarte „Einstellungen“ aus.
4. Klicken Sie im Feld „Posteingangsdefinition“ auf „Eintrag hinzufügen“ und wählen Sie den Postkorb der OE aus.
5. Klicken Sie auf „Übernehmen“ und bestätigen Sie mit „Weiter“.

Den Posteingang für einen einzelnen Benutzer zur Verfügung stellen

1. Suchen Sie die Arbeitsumgebung des Benutzers und legen Sie diese auf dem Schreibtisch ab.
2. Klicken Sie mit der rechten Maustaste auf die Arbeitsumgebung und wählen Sie den Menüpunkt „Eigenschaften“ aus.
3. Wählen Sie die Registerkarte „E-Government“ aus.
4. Klicken Sie im Feld „Posteingangsdefinition“ auf „Eintrag hinzufügen“ und wählen Sie den entsprechenden Postkorb aus.
5. Klicken Sie auf „Übernehmen“ und bestätigen Sie mit „Weiter“.

## 5.2.3.2 Erstellung und Verwendung von Musterverfügungen

Zentrales Objekt für die Verwaltung einer Musterverfügung ist ein Objekt vom Typ „Voreinstellungen im Workflow“.

Um eine Musterverfügung bei einer „Voreinstellung im Workflow“ zu hinterlegen, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie z.B. einen beliebigen Vorgang.
Hinweis: Es ist empfohlen einen Vorgang zu verwenden, welchen Sie verfügen möchten.
2. Öffnen Sie das Kontextmenü auf den Vorgang und wählen Sie „Verfügen“.
3. Wählen Sie, wie gewohnt, Verfügungen und Teilnehmer aus.
4. Klicken Sie auf die Schaltfläche „Als Muster speichern“.
5. Wählen Sie unter „Speichern unter“ einen Speicherort aus.
Hinweis: Der Speicherort definiert, welche Benutzer Rechte auf die Musterverfügung haben.
6. Definieren Sie in der Eigenschaft „Verwendbar für“, für welche Objektklasse die Musterverfügung zu Verfügung stehen soll.
Hinweis: Zur Verfügung steht die Schnittmenge der Objektklassen aus den verwendeten Aktivitätsdefinitionen.
7. Vergeben Sie einen Namen und speichern Sie die Musterverfügung durch Klick auf die Schaltfläche „Speichern“.

Sobald eine Musterverfügung gespeichert wurde, kann diese im Verfügen-Dialog über die Schaltfläche „Muster einfügen“ eingefügt werden.

Hinweis: Der Fachadministrator kann die vom Benutzer angelegten Musterverfügungen bei Bedarf unter Voreinstellungen im Workflow des Benutzers löschen.

Benutzerhilfe
298

<!-- PDF page 299 -->

Benutzerhilfe

# 5.2.3.3 Suchmuster für Vorgänge ohne Laufweg

Dem Administrator und dem Support wird ein Skript für Vorgänge ohne Laufweg zur Verfügung gestellt.

Es wird nach allen Vorgängen gesucht, bei denen

- der Wert der Eigenschaft *Laufweg* erzeugen auf „Ja“ steht und
- keine Aktivitäten mit dem Status *In Bearbeitung* oder keine Aktivitäten mit dem Status *Auf Wiedervorlage* (Termin für Vorlage ist eingetragen und liegt in der Zukunft) vorhanden ist.

Die Suchergebnisse werden in einem Ordner mit dem Namen „Vorgänge ohne Laufweg“ auf dem Schreibtisch abgelegt.

**Hinweis:** Es werden nur Objekte hinterlegt, auf die der suchende Benutzer Zugriff hat.

Um den Ordner „Vorgänge ohne Laufweg“ auf dem Schreibtisch zu erzeugen, gehen Sie folgendermaßen vor:

1. Wechseln Sie auf Ihren „Schreibtisch“.
2. Wählen Sie aus dem Schreibtischmenü „Extras“ → „Vorgänge ohne akt. Laufweg“.
3. Es wird automatisch ein Ordner mit dem Namen „Vorgänge ohne akt. Laufweg“ erzeugt und am Schreibtisch abgelegt oder aktualisiert falls er schon vorhanden ist. In diesem finden Sie die entsprechenden Vorgänge.

# 5.2.3.4 Wiederherstellen von Objekten aus dem globalen Papierkorb

Objekte im globalen Papierkorb können durch den Menübefehl „Wiederherstellen“ wiederhergestellt werden. Beim Wiederherstellen erhalten die wiederhergestellten Objekte die definierte ACL für wiederhergestellte Objekte. Sollte keine ACL für wiederhergestellte Objekte definiert sein, muss der wiederherstellende Benutzer für die korrekte Vergabe einer ACL Sorge tragen, da sonst Probleme bei der Zugriffsberechtigung entstehen können.

**Hinweis:** Bei der Wiederherstellung von Vorgängen und Dokumenten ist die Reihenfolge beim Wiederherstellen zu beachten. Es muss immer zuerst der Vorgang wiederhergestellt werden, bevor Dokumente in diesem Vorgang wiederhergestellt werden können.

**Hinweis:** Beim Wiederherstellen von Objekten aus den Papierkörben werden die wiederhergestellten Objekte nicht automatisch auf dem Schreibtisch des Eigentümers gelegt.

# 5.2.3.5 Definieren des Zeitraums für die langfristige Wiedervorlage

**Hinweis:** Dies kann nur von einem Domänenadministrator vorgenommen werden.

Um einen anderen Zeitraum zu definieren, ab dem eine Wiedervorlage als langfristig gilt, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Workflow-Konfiguration Ihrer Domäne bzw. Ihres Mandanten.
2. Öffnen Sie die Metadaten der Workflow-Konfiguration.
3. Wechseln Sie auf die Registerkarte „Arbeitsvorrat“, falls Sie sich auf einer anderen Registerkarte befinden.

299

<!-- PDF page 300 -->

4. Wählen Sie in der Eigenschaft Zeitspanne, ab wann eine Suspendierung als langfristig gilt die Zeitspanne aus, ab der eine Wiedervorlage als langfristig gelten soll.
5. Speichern Sie die Änderungen durch Klick auf die Schaltfläche „Weiter“.

Hinweis: In der Fabasoft eGov-Suite Bayern wird aktuell nicht zwischen langfristigen und nicht-langfristigen Aktivitäten unterschieden. Der Wert der Eigenschaft Zeitspanne ist dementsprechend „sofort“:

Ergebnis:
- Alle Aktivitäten, welche länger als für den definierten Zeitraum auf Wiedervorlage liegen, werden in den Arbeitsvorräten der Benutzer auf der Registerkarte „Frist größer ...“ angezeigt.

5.2.3.6 Bearbeiten von Prozessdefinitionen

Mithilfe des Symbols Prozesselement erzeugen können im Prozesseditor Prozessdefinitionen bearbeitet werden. Die dabei relevanten Optionen sind:
- „Prozess einfügen“: Ermöglicht die Einbindung bereits bestehender Prozessdefinitionen als Subprozesse.
- „Aktivität einfügen“: Ermöglicht die Einbindung bestehender Aktivitäten, wobei genau die für die Vorgangsbearbeitung relevanten Aktivitätsdefinitionen zur Auswahl angeboten werden. In der Folge werden so genannte Aktivitätsdefinitionsreferenzen in die Prozessdefinition eingefügt.

Hinweis: Folgende weitere Optionen stehen in Prozessdefinitionen zur Verfügung, auf welche jedoch aufgrund ihrer Komplexität nicht weiter eingegangen wird:
- „Aktivität erzeugen“: Ermöglicht die Erstellung neuer Aktivitätsdefinitionen.
- „Bedingungselement erzeugen“: Ermöglicht die Erstellung von IF-Bedingungen.
- „Fallunterscheidungselement erzeugen“: Ermöglicht die Erstellung von CASE-Abfragen.
- „Wiederholungselement erzeugen“: Ermöglicht die Erstellung von REPEAT-Schleifen.
- „Warteaktion erzeugen“: Ermöglicht die Erstellung von Warteaktionen (Warteaktionen können in Verbindung mit AT-Jobs dazu eingesetzt werden, den Ablauf eines Workflows für bestimmte Zeit zu verzögern).

Für alle Punkte gilt: Im Hintergrund werden jeweils neue Komponentenobjekte angelegt, für welche jeweils gegebenenfalls Softwarekomponente, Referenz (und Eigentümer) geprüft werden müssen.

5.3 Softwarekomponenten und Komponentenobjekte

Eine wesentliche Klasse von Objekten in der Fabasoft eGov-Suite Bayern stellen Komponentenobjekte dar. Komponentenobjekte zeichnen sich dadurch aus, dass sie durch eine Softwarekomponente und eine Referenz (eindeutig) identifiziert werden können.

Die allgemeine Darstellung ist dabei:
<referenz der="" softwarekomponente="">&gt;@<major-domain-id>.<minor-domain-id>:<referenz>

Benutzerhilfe</referenz></minor-domain-id></referenz>

<!-- PDF page 301 -->

Beispiele für Komponentenobjekte sind etwa Objektklassen, Eigenschaften, Aktionen, Formulare und Formularseiten, Stellen und Struktureinheiten sowie Aktivitäts- und Prozessdefinitionen.

## 5.3.1 Eine lokale Softwarekomponente erzeugen

Der Domänenadministrator hat das Recht, in einem Verwaltungswerkzeug eine lokale Softwarekomponente zu erzeugen. „Lokal“ deswegen, weil die Softwarekomponente im jeweiligen Mandanten erzeugt wird und somit automatisch deren Major-Domain-ID und Minor-Domain-ID übernimmt. Siehe hierzu auch Kapitel 6.25 „Softwarekomponente“.

## 5.3.2 Komponentenobjekte erzeugen

Beim Erzeugen von Komponentenobjekten sind grundsätzlich die beiden Pflichteigenschaften Softwarekomponente und Referenz zu befüllen. Die Referenz muss dabei innerhalb der Softwarekomponente eindeutig sein.

## 5.3.3 Amts-/Dienstbezeichnungen verwalten

Amts-/Dienstbezeichnungs-Objekte sind Komponentenobjekte, welche zentral administriert werden. Siehe hierzu auch Kapitel 6.24 „Amts-/Dienstbezeichnung“.

## 5.3.4 Synchronisierungsfunktionalität „Folio Ordner“

Falls ein Benutzer der Fabasoft eGov-Suite Bayern den Folio Ordner verwenden möchte, haben Sie die Möglichkeit, dies über folgende Schritte zu ermöglichen:

1. Lokalisieren Sie das Objekt des Benutzers.
2. Öffnen Sie die Metadaten des Benutzerobjekts lesend und wechseln Sie auf die Registerkarte „Umgebungen“.
3. Öffnen Sie die Standard-Arbeitsumgebung des Benutzers, welche Sie im Feld Umgebungen finden, bearbeitend.
4. Wechseln Sie auf die Registerkarte „Arbeitsumgebung (Erweitert)“.
5. Aktivieren Sie den Folio Ordner für den Benutzer durch Setzen der Eigenschaft Folio Ordner ermöglichen auf „Ja“.
6. Speichern Sie die Änderungen über die Schaltfläche „Weiter“.

Siehe hierzu auch Kapitel 2.6 „Synchronisierungsfunktionalität „Folio Ordner““.

## 5.3.5 Konfiguration Objektklassenzuordnung

Beim direkten Import wird automatisch (sofern der Objektklassenauswahl Dialog deaktiviert ist) ein neues Dokument erzeugt, welches das importierte Schriftstück als Inhalt erhält. Die Objektklasse wird dabei über die Datei-Endung des Schriftstücks bestimmt. Über das Aggregat Zuordnung der Objektklasse beim direkten Erfassen (in der Domäne auf der Registerkarte „eGov-Suite“) lassen sich domänenweit Datei-Endungen Objektklassen zuordnen. In folgendem Beispiel wurde u.a. definiert, dass beim direkten Erfassen einer PDF-Datei ein Eingangsdokument erzeugt werden soll.

Benutzerhilfe
301

<!-- PDF page 302 -->

Zieht ein Benutzer der Domäne nun eine PDF-Datei in einen Vorgang, dann wird ein Eingangsdokument im Vorgang erzeugt.

![img-0.jpeg](img-0.jpeg)

Hinweis: Die Zuordnung über Expression (kann in der Administrations-Konfiguration hinterlegt werden) wird weiterhin bei der Auswertung beachtet. Für den Fall, dass eine Datei-Endung mehrfach vorkommt, wird immer die Zuordnung dieser Eigenschaft herangezogen.

Hinweis: Es können mehrere Datei-Endungen eingetragen werden. Sie müssen mit einem Strichpunkt getrennt werden. Außerdem wird die Klein- und Großschreibung ignoriert.

## 5.3.6 Definieren einer Dateiendung für Annotationen

Um den Benutzern die Annotation von Schriftstücken zu ermöglichen, muss eine Dateiendung für Annotationen in der Domäne bzw. dem Mandanten des Benutzers definiert werden. Um diese Dateiendung zu konfigurieren, gehen Sie folgendermaßen vor:

1. Lokalisieren Sie die Domäne bzw. den Mandanten des Benutzers.
2. Öffnen Sie die Metadaten des Mandanten bzw. der Domäne bearbeitend.
3. Wechseln Sie auf die Registerkarte „eGov-Suite“, falls Sie sich auf einer anderen Registerkarte befinden.
4. Tragen Sie in der Eigenschaft Dateiendung für Annotationen die Dateiendung ein, in die das Schriftstück zum Anbringen und lesen von Annotationen konvertiert werden soll.
5. Speichern Sie die Änderungen durch Klick auf die Schaltfläche „Weiter“.

Ergebnis: Die Benutzer dieser Domäne bzw. dieses Mandanten können Annotationen nun auf Schriftstücke anbringen bzw. bestehende Annotationen lesen oder löschen.

## 5.4 Aussonderung

### 5.4.1 Aktivierung der XDOMEA Aussonderung

#### 5.4.1.1 Aussonderungsmodus „XDOMEA“ aktivieren

Damit bei der Aussonderung das XDOMEA Format verwendet wird, muss diese Möglichkeit zuerst beim betroffenen Mandanten aktiviert werden. Um die Aktivierung durchzuführen gehen Sie wie folgt vor:

1. Lokalisieren Sie den gewünschten Mandanten
2. Öffnen Sie über das Kontextmenü und den Menüeintrag „Eigenschaften“ die Eigenschaften des Mandanten
3. Wechseln Sie auf die Registerkarte „eGov-Suite“
4. Setzen Sie das Flag „Verwendung von XDOMEA für die Aussonderung“ auf „Ja“

Benutzerhilfe

<!-- PDF page 303 -->

5. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter"

**Ergebnis:**
- Die XDOMEA-Aussonderung ist für diesen Mandanten aktiviert

### 5.4.1.2 Hinterlegung der gültigen Archivorganisationen

Bei der Durchführung der XDOMEA Aussonderung dürfen als Empfänger nur gültige Archive ausgewählt werden. Die verfügbaren Organisationen müssen pro Mandant konfiguriert werden. Die konfigurierten Organisationen können vom Anwender bei der Aussonderung ausgewählt werden.

Um die Organisationen zu konfigurieren gehen Sie wie folgt vor:

1. Lokalisieren Sie den gewünschten Mandanten
2. Öffnen Sie über das Kontextmenü und den Menüeintrag „Eigenschaften“ die Eigenschaften des Mandanten
3. Wechseln Sie auf die Registerkarte „eGov-Suite“
4. Hinterlegen Sie in der Eigenschaft „Organisationen für den XDOMEA-Empfänger“ die gewünschten Archivorganisationen aus.
**Hinweis:** Sind die Organisationen noch nicht vorhanden, müssen diese zuvor erzeugt werden.
5. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter“

**Ergebnis:**
- Bei der Erstellung von XDOMEA-Paketen im Kontext der Aussonderung stehen die Archivorganisationen als Empfänger zur Verfügung.

### 5.4.2 Aktivieren der automatischen Aussonderung

#### 5.4.2.1 Asynchronen Aussonderungsmodus aktivieren

Um die automatische Aussonderung zu aktivieren, muss am Mandanten der asynchrone Modus aktiviert werden. Um dies durchzuführen gehen Sie wie folgt vor:

1. Lokalisieren Sie den gewünschten Mandanten
2. Öffnen Sie über das Kontextmenü und den Menüeintrag „Eigenschaften bearbeiten“ die Eigenschaften des Mandanten
3. Wechseln Sie auf die Registerkarte „eGov-Suite“
4. Setzen Sie das Flag „Asynchroner Export für XDOMEA Pakete“ auf „Ja“
5. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter“

**Ergebnis:**
- Bei der Erstellung eines XDOMEA Pakets im Kontext der Aussonderung wird das Flag „Asynchroner Export“ beim XDOMEA Paket auf „Ja“ initialisiert.

Benutzerhilfe
303

<!-- PDF page 304 -->

- Bei Starten des Exports wird der Anwender auf die Asynchrone Ausführung aufmerksam gemacht:

![img-1.jpeg](img-1.jpeg)

Außerdem erscheint folgender Hinweis:

![img-2.jpeg](img-2.jpeg)

## 5.4.2.2 Definition des Dateipfads für die Speicherung des XDOMEA Pakets

Nach dem asynchronen Export des XDOMEA Pakets wird dieses in einem dafür vorgehsehen Ordner im Dateisystem gespeichert. Um diesen Zielpfad zu konfigurieren gehen Sie wie folgt vor:

1. Lokalisieren Sie die Hauptdomäne (nicht den Mandanten)
2. Öffnen Sie über das Kontextmenü und den Menüeintrag „Eigenschaften“ die Eigenschaften der Domäne
3. Wechseln Sie auf die Registerkarte „System-Konfiguration“
4. Setzen Sie in der Eigenschaft „Dateipfad für XDOMEA-Aussonderung“ den gewünschten Pfad (z.B. C:\XDOMEA).

Hinweis: Der Pfad wird aus der Sicht des Benutzers des AT-Services, der den asynchronen Job ausführt, gesehen. Der Pfad muss demnach vom AT-Server aus erreichbar sein!

5. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter“

Ergebnis:

Benutzerhilfe
304

<!-- PDF page 305 -->

- Der asynchrone XDOMEA Export speichert das entpackte XDOMEA Paket in dem definierten Verzeichnis:

![img-3.jpeg](img-3.jpeg)

## 5.4.2.3 Erstellung der Liste für die asynchrone Aussonderung

Die im Dateisystem gespeicherten XDOMEA Pakete werden von einem externen Schnittstellen-Controller an das entsprechende Archiv übermittelt. Damit die Zielarchive und die dazugehörigen XDOMEA Pakete identifiziert werden können, müssen diese Zugehörigkeiten in der Fabasoft eGov-Suite gespeichert werden. Dies wird in einem Objekt der Klasse „Liste für asynchrone Aussonderung“ durchgeführt. Um dieses Objekt zu erstellen, gehen Sie wie folgt vor:

1. Lokalisieren Sie die Hauptdomäne (nicht den Mandanten)
2. Öffnen Sie über das Kontextmenü und den Menüeintrag „Eigenschaften“ die Eigenschaften der Domäne
3. Wechseln Sie auf die Registerkarte „System-Konfiguration“
4. Erstellen Sie in der Eigenschaft „Liste für asynchrone Aussonderung“ ein neues Objekt und definieren Sie einen Namen.
5. Schließen Sie die Erstellung mit einem Klick auf die Schaltfläche „Weiter“
6. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter“

**Ergebnis:**

- Der synchrone XDOMEA Export speichert das XDOMEA Paket nicht nur im Dateisystem, sondern auch einen entsprechenden Eintrag in dem Objekt „Liste für asynchrone Aussonderung“.

## 5.4.2.4 Konfiguration einer Warteschlange

Für den asynchronen Export muss eine Warteschlange eingerichtet werden. Das Vorhandensein einer Warteschlange ist für das Ausführen des asynchronen Jobs essentiell und muss unbedingt durchgeführt werden.

Die Konfiguration einer Warteschlange und die Ausführung über ein Fabasoft AT-Service wird im Kapitel 5.5 „Warteschlangen für die asynchrone Verarbeitung“ beschrieben.

Benutzerhilfe

<!-- PDF page 306 -->

Benutzerhilfe
306

# 5.4.3 AT-Job zum Löschen von archivierten Objekten

Damit archivierte Objekte vom System gelöscht werden können, muss ein AT-Job konfiguriert werden. Um eine automatische Aufgabe für die Löschung zu erstellen, gehen Sie wie folgt vor:

1. Navigieren Sie über die Domänenadministration zu den Benutzerobjekten
2. Wählen Sie die Registerkarte „Liste der Automatischen Aufgaben“ aus
3. Klicken Sie auf die Schaltfläche „Aktualisieren“ sollten hier keine Einträge sichtbar sein.
**Hinweis:** Wird nach dem Aktualisieren noch nichts angezeigt, ist in dieser Installation kein AT-Service installiert.
4. Erzeugen Sie eine „Liste der Automatischen Aufgaben“ und definieren Sie einen Namen
5. Navigieren Sie in dieses neue Objekt durch einen Linksklick auf dieses
6. Erzeugen Sie eine neue Aufgabe und definieren Sie einen Namen
7. Öffnen Sie die Eigenschaften dieser neuen Aufgabe
8. Definieren Sie in der Eigenschaft „Objekt“ den Benutzer aus unter dem das Service läuft.
**Hinweis:** Das hier eingetragene Objekt hat aber keine Auswirkung.
9. Suchen Sie in der Eigenschaft „Aktion“ die Aktion „DEPRECONFIG@15.1001:SearchAndDestroyDeletableObjects“
10. Definieren Sie über die Eigenschaften „Wiederholung“ und „Art der Wiederholung wie oft der AT-Job ausgeführt werden soll.“
11. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter“

# Ergebnis:

Der AT-Job ist angelegt und kann über das Fabasoft AT-Service ausgeführt werden:

[tbl-0.md](tbl-0.md)

<!-- PDF page 307 -->

Benutzerhilfe
307

# 5.4.4 REST Urls für die automatische Aussonderung

Ein Archiv oder ein Schnittstellencontroller muss über definierte URLs der Fabasoft eGov-Suite Bayern die notwendigen Informationen zukommen lassen. In den folgenden Kapiteln werden die aufzurufenden URLs beschrieben.

## 5.4.4.1 Neue Anbieterverzeichnisse ermitteln

Um verfügbare Anbieterverzeichnisse für einen bestimmten Empfänger (=Archiv) zu ermitteln muss folgende REST-Url aufgerufen werden:

**Url:**

http://<server>/<webservice>/requestxdomeapackage?type=0501&amp;receiver=<objektadresse empfänger="">

**REST Typ:** HTTP-GET

**Parameter:**

- type: 0501
- receiver: Objektadresse des Organisationsobjekts in der Fabasoft eGov-Suite.

**Antworten:**

- Antwort solange Pakete verfügbar sind: Paket-ID Strings (entspricht dem Namen des Ordners): z.B.: CEEF1F23-37F1-F104-1942-D00000000000_Aussonderung.Anbieterverzeichnis.0501
- Antwort, wenn keine Pakete verfügbar sein: nopackage

**Hinweis:**

Der Schnittstellencontroller muss die Pakete im Zielordner löschen, wenn diese verarbeitet wurden, da diese sonst immer wieder angeboten werden. Erst wenn der Ordner mit dem Namen des Pakets gelöscht wurde, wird das nächste Paket angeboten.

## 5.4.4.2 Empfangsbestätigung für den Erhalt des Anbieterverzeichnisses übermitteln

Um Empfangsbestätigungen zu bestimmten Anbieterverzeichnissen zu übermitteln muss folgende REST-Url aufgerufen werden:

**Url:**

http://<server>/fsc/submitxdomeapackage?sourcepackageid=CEEF1F23-37F1-F104-1942-D00000000000_Aussonderung.Anbieterverzeichnis.0501

**Parameter:**

- sourcepackageid: Objektadresse des Anbieterverzeichnisses in der Fabasoft eGov-Suite.
- Das XDOMEA Paket muss als binäre Payload dem POST-Request übergeben werden.

**REST Typ:** HTTP-POST

**Antworten:**

- Antwort OK: {"result":"OK"}
- Antwort NOK: {"result":"NOK"} bzw. REST Error</server></objektadresse></webservice></server>

<!-- PDF page 308 -->

Benutzerhilfe
308

# 5.4.4.3 Bewertungsverzeichnis für ein Anbieterverzeichnis übermitteln

Um Bewertungsverzeichnisse zu bestimmten Anbieterverzeichnissen zu übermitteln muss folgende REST-Url aufgerufen werden:

## Url:

http://<server>/fsc/submitxломераскаде?sourcepackageid=CEEF1F23-37F1-F104-1942-D000000000000_Aussonderung.Anbieterverzeichnis.0501

## Parameter:

- sourcepackageid: Objektadresse des Anbieterverzeichnisses in der Fabasoft eGov-Suite.
- Das XDOMEA Paket muss als binäre Payload dem POST-Request übergeben werden.

REST Typ: HTTP-POST

## Antworten:

- Antwort OK: Paket 0505 (Empfangsbestätigung) als binary Payload der Antwort
- Antwort NOK: {"result":"NOK"} bzw. REST Error

# 5.4.4.4 Neue Aussonderungsverzeichnisse ermitteln

Um verfügbare Aussonderungsverzeichnisse für einen bestimmten Empfänger (=Archiv) zu ermitteln muss folgende REST-Url aufgerufen werden:

## Url:

http://<server>/<webservice>/requestxломераскаде?type=0503&amp;receiver=<objektadresse empfänger="">

REST Typ: HTTP-GET

## Parameter:

- type: 0503
- receiver: Objektadresse des Organisationsobjekts in der Fabasoft eGov-Suite.

## Antworten:

- Antwort solange Pakete verfügbar sind: Paket-ID Strings (entspricht dem Namen des Ornders): z.B.: CEEF1F23-37F1-F104-1942-D000000000000_Aussonderung.Anbieterverzeichnis.0501
- Antwort, wenn keine Pakete verfügbar sein: nopackage

## Hinweis:

Der Schnittstellencontroller muss die Pakete im Zielordner löschen, wenn diese verarbeitet wurden, da diese sonst immer wieder angeboten werden. Erst wenn der Ordner mit dem Namen des Pakets gelöscht wurde, wird das nächste Paket angeboten.

# 5.4.4.5 Importbestätigung für das Aussonderungsverzeichnis übermitteln

Um Importbestätigungen zu bestimmten Aussonderungsverzeichnissen zu übermitteln muss folgende REST-Url aufgerufen werden:

## Url:</objektadresse></webservice></server></server>

<!-- PDF page 309 -->

http://<server>/fsc/submitxdomeapackage?sourcepackageid=CEEF1F18-91F1-F104-4910-D00000000000_Aussonderung.Aussonderung.0503

## Parameter:

- sourcepackageid: Objektadresse des Aussonderungsverzeichnisses in der Fabasoft eGov-Suite.
- Das XDOMEA Paket muss als binäre Payload dem POST-Request übergeben werden.

REST Typ: HTTP-POST

## Antworten:

- Antwort OK: 0506 Paket als binary Payload des POST-Request
- Antwort NOK: {"result":"NOK"} bzw. REST Error

## 5.5 Warteschlangen für die asynchrone Verarbeitung

Damit asynchrone Verarbeitungen in der Fabasoft eGov-Suite (z.B. Aussonderung) korrekt funktionieren muss zumindest eine Warteschlange in der Domäne verfügbar sein. In diesem Kapitel finden Sie die notwendigen Informationen, um diese Funktionalität zu konfigurieren.

## 5.5.1 Konfiguration der Warteschlangen

Für die automatisierte asynchrone Verarbeitung muss im Mandanten bzw. in der Domäne zumindest eine Warteschlange vorhanden sein. Um Warteschlangen zu konfigurieren gehen Sie wie folgt aus.

1. Lokalisieren Sie den gewünschten Mandanten
2. Öffnen Sie über das Kontextmenü und den Menüeintrag „Eigenschaften“ die Eigenschaften des Mandanten
3. Wechseln Sie auf die Registerkarte „System-Konfiguration“
4. Erzeugen bzw. hinterlegen Sie im Feld „Warteschlangen“ zumindest eine Warteschlange.

Hinweis: Werden hier mehrere Warteschlangen hinterlegt verwendet das System diese zur Lastverteilung. Die Tasks werden somit gleichberechtigt auf alle verfügbaren Warteschlangen aufgeteilt.

5. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter“

## Ergebnis:

Zumindest eine Warteschlange ist im System konfiguriert und kann für die automatische asynchrone Verarbeitung und in AT-Jobs verwendet werden.

Benutzerhilfe</server>

<!-- PDF page 310 -->

Domain 1.1890 (Aktuelle Domäne): Bearbeiten
Rolle

System-Konfiguration

Komponenten-Konfigu...

![img-4.jpeg](img-4.jpeg)

☐ Internationaler Teamroom aktiv

## 5.5.2 AT-Job zum Ausführen von Warteschlangen

Damit die Warteschlange von einem AT-Service ausgeführt werden kann muss eine automatische Aufgabe in der Fabasoft eGov-Suite erstellt werden. Für jede im System zu verarbeitende Warteschlange muss eine automatische Aufgabe existieren. Um eine automatische Aufgabe für eine Warteschlange zu erstellen gehen Sie wie folgt vor:

1. Navigieren Sie über die Domänenadministration zu den Benutzerobjekten
2. Wählen Sie die Registerkarte „Liste der Automatischen Aufgaben“ aus
3. Klicken Sie auf die Schaltfläche „Aktualisieren“ sollten hier keine Einträge sichtbar sein. **Hinweis:** Wird nach dem Aktualisieren noch nichts angezeigt ist in dieser Installation kein AT-Service installiert.
4. Erzeugen Sie eine „Liste der Automatischen Aufgaben“ und definieren Sie einen Namen
5. Navigieren Sie in dieses neue Objekt mit einem Doppelklick
6. Erzeugen Sie eine neue Aufgabe und definieren Sie einen Namen
7. Öffnen Sie die Eigenschaften dieser neuen Aufgabe
8. Definieren Sie in der Eigenschaft „Objekt“ die gewünschte Warteschlange
9. Suchen Sie in der Eigenschaft „Aktion“ die Aktion FSCQUEUE@15.1001:PerformQueue
10. Definieren Sie über die Eigenschaften „Wiederholung“ und „Art der Wiederholung wie oft der AT-Job ausgeführt werden soll.
11. Speichern Sie die Änderung mit einem Klick auf die Schaltfläche „Weiter“

Benutzerhilfe

<!-- PDF page 311 -->

Benutzerhilfe
311

# Ergebnis:

Der AT-Job ist angelegt und kann über das Fabasoft AT-Service ausgeführt werden:

[tbl-1.md](tbl-1.md)

# 5.6 Aktivieren des Fabasoft Viewers

Der Fabasoft Viewer kann an drei unterschiedlichen Stellen Aktivieren werden. In einer Domäne, einem Mandanten oder direkt auf der Arbeitsumgebung eines Benutzers.

Zum Aktivieren des Fabasoft Viewers in einer Domäne oder einem Mandanten gehen Sie folgendermaßen vor:

1. Navigieren Sie über die Domänenadministration zu den Domänenobjekten
2. Wechseln Sie auf die Registerkarte „Domänen"
3. Lokalisieren Sie die gewünschte „Domäne" bzw. den gewünschten „Mandaten" und öffnen Sie diesen über das Kontextmenü und den Menüeintrag „Eigenschaften"
4. Wechseln Sie auf die Registerkarte „eGov-Suite"
5. Setzen Sie das Flag von "Verwendung des Viewers" auf „Ja"

<!-- PDF page 312 -->

Zum Aktivieren des Fabasoft Viewers für einen bestimmten Benutzer gehen Sie folgendermaßen vor:

1. Navigieren Sie über die Domänenadministration zu den Benutzerobjekten
2. Wechseln Sie auf die Registerkarte „Arbeitsumgebungen“
3. Kopieren Sie die Arbeitsumgebung und legen Sie diese auf Ihrem Schreibtisch ab.
4. Markieren Sie die Arbeitsumgebung am Schreibtisch und führen Sie die Menüaktion „Objekt“ – „Alle Eigenschaften“ durch.
5. Setzen Sie das Flag von „Verwendung des Viewers der Fabasoft eGov-Suite“ auf „Ja“

## 5.7 Annotationen

### 5.7.1 Bulk-Job für Anzeige von annotiertem Inhalt und Originalinhalt

Hinweis: Dieser Schritt ist nur bei einem Upgrade durchzuführen, wenn die Quellversion kleiner als die Version 2019 Update Rollup 1 war.

Für die Migration des Annotationsmodells müssen folgende Massenverarbeitungen als Systemadministrator ausgeführt werden.

- APPANNOTATIONS@15.1001:BulkMigrateRedactionsToNewModel
- APPANNOTATIONS@15.1001:BulkMigrateAnnotationsToNewModel

Diese beiden Massenverarbeitungen migrieren das Bestandsmodell der Annotationen auf das neue Objektmodell. Dies betrifft annotierte Schriftstücke und Schwärzungen.

### 5.7.2 Konfiguration des Cachings für Annotationen

Für jeden Mandanten/Domäne müssen Cachebereiche für das Annotieren eingerichtet werden. Es werden für jeden Mandanten 5 Cachebereich als Initialkonfiguration empfohlen. Dafür müssen für jeden Mandanten 5 Objekte der Objektklasse "Container für zwischengespeicherte Annotationsinhalte" erstellt und beim Mandanten in der Eigenschaft "Container für zwischengespeicherte Annotationen" auf der Registerkarte "eGov-Suite" eingehängt werden. Erst dann ist das Caching für diesen Mandanten aktiv.

Für die Automatisierung kann folgende Massenverarbeitung aufgerufen werden:

- APPANNOTATIONS@15.1001:BulkCreateCacheContainer

Dieser Massenverarbeitung erzeugt für jede Domäne und jeden Mandanten fünf eigenständige Cache Container und hinterlegt diese.

### 5.7.3 AT-Job für den Cleanup des Annotations-Caches

Die Inhalte in dem Annotationscache haben nur die dort eingestellt Gültigkeitsdauer (Eingestellt sind 24 Stunden). Damit die Caches wiederverwendet werden können muss der Cache aufgeräumt werden. Der AT-Job kann global oder für jeden Mandanten einzeln konfiguriert werden.

Folgende Aktion muss als AT-Job einmal in der Nacht ausgeführt werden:

- APPANNOTATIONS@15.1001:CleanupCaches

Benutzerhilfe
312

<!-- PDF page 313 -->

Wird die Aktion auf ein allgemeines Objekt ausgeführt wird nach allen Domänen gesucht und das Aufräumen der Caches angestoßen.

## 5.7.4 Konfiguration von Regeln für Schwärzung

Damit beim Schwärzen Vorschläge angezeigt werden, müssen entsprechende Regeln hinterlegt werden. Diese können in der aktuellen Domäne, dem Mandanten, der Gruppe oder in der Arbeitsumgebung des Benutzers in der Eigenschaft „Regeln für Schwärzung“ APPANNOTATIONS@15.1001:redactionrules hinterlegt werden. Wenn in der Arbeitsumgebung Regeln definiert sind, werden jene aus der Domäne, der Gruppe und dem Mandanten ignoriert.

Folgende „Regel für Schwärzung“-Objekte werden standardmäßig im Produkt mitgeliefert:

### Personenbezogene Daten der Akte

Die personenbezogenen Daten der einzelnen Adressaten der übergeordneten Akte werden als Vorschlag angeboten.

#### Personenbezogen Daten der Adressaten:

- Die Freitextfelder „Vorname“, „Nachname“ und „E-Mail“.
- Wenn als Adressat eine Person eingetragen ist wird das Feld „Vorname“, „Nachname“ und „E-Mail-Adressen“ des Personenobjekts verwendet.
- Wenn als Adressat eine Organisation eingetragen ist wird das Feld „Kurzname“ und „Name (vollständig)“ des Organisationobjekts verwendet.
- Wenn als Adressat ein Verteiler eingetragen ist werden die personenbezogenen Daten der aufgelösten Adressatenobjekte verwendet.

**Vorbedingung:** Übergeordnete Akte ist vorhanden.

### Personenbezogene Daten des Vorgangs

Die personenbezogenen Daten der einzelnen Adressaten des übergeordneten Vorgangs werden als Vorschlag angeboten.

#### Personenbezogen Daten der Adressaten:

- Die Freitextfelder „Vorname“, „Nachname“ und „E-Mail“.
- Wenn als Adressat eine Person eingetragen ist wird das Feld „Vorname“, „Nachname“ und „E-Mail-Adressen“ des Personenobjekts verwendet.
- Wenn als Adressat eine Organisation eingetragen ist wird das Feld „Kurzname“ und „Name (vollständig)“ des Organisationobjekts verwendet.
- Wenn als Adressat ein Verteiler eingetragen ist werden die personenbezogenen Daten der aufgelösten Adressatenobjekte verwendet.

**Vorbedingung:** Übergeordneter Vorgang ist vorhanden.

### Personenbezogene Daten des Dokuments

Die personenbezogenen Daten der einzelnen Adressaten des übergeordneten Dokuments werden als Vorschlag angeboten.

#### Personenbezogen Daten der Adressaten:

- Die Freitextfelder „Vorname“, „Nachname“ und „E-Mail“.

Benutzerhilfe
313

<!-- PDF page 314 -->

- Wenn als Adressat eine Person eingetragen ist wird das Feld „Vorname“, „Nachname“ und „E-Mail-Adressen“ des Personenobjekts verwendet.
- Wenn als Adressat eine Organisation eingetragen ist wird das Feld „Kurzname“ und „Name (vollständig)“ des Organisationobjekts verwendet.
- Wenn als Adressat ein Verteiler eingetragen ist werden die personenbezogenen Daten der aufgelösten Adressatenobjekte verwendet.

Vorbedingung: Übergeordnetes Dokument ist vorhanden.

## Geschäftsrelevante Daten

Die Geschäftszeichen des übergeordneten Dokuments, des übergeordneten Vorgangs und der übergeordneten Akte werden als Vorschlag angeboten.

Vorbedingung: Übergeordnetes Dokument ist vorhanden.

## 5.8 Reorganisation

Die neue Objektklasse „Reorganisation (FSCADM@15.1001:Reorganization)“ dient zur Durchführung von Reorganisationen. „Reorganisationen“ können von „Administrator“ am Schreibtisch erstellt werden.

![img-5.jpeg](img-5.jpeg)

## 5.8.1 Erstellung einer Reorganisation

Beim Erstellen einer Reorganisation müssen folgenden Eigenschaften befüllt werden:

### Aktion

Referenz: FSCADM@15.1001:reorganizecontext

Die Aktion, welche ausgeführt werden soll. Zur Auswahl stehen

- Objekt austauschen
- Objekt entfernen
- Gruppe bei Aktivitäten und Prozessen ändern
- Stelle bei Aktivitäten und Prozessen ändern

### Objekt austauschen

Benutzerhilfe
314

<!-- PDF page 315 -->

Ersetzt das Objekt aus „Auslösendes Objekt“ bei den gefundenen Objekten durch das Objekt in „Ersatzobjekt“

## Objekt entfernen

Entfernt das Objekt aus „Auslösendes Objekt“ aus den gefundenen Objekten

Anmerkung:

Hier muss auch ein „Ersatzobjekt“ gewählt werden, da bestimmte Eigenschaften nicht leer sein dürfen

## Gruppe bei Aktivitäten und Prozessen ändern

Ändert die Organisationseinheit bei bestehenden Aktivitäten und Prozessen. Als Ersatzobjekt können nur Organisationseinheiten gewählt werden, bei welchen der Benutzer aus der Eigenschaft „Auslösendes Objekt“ Mitglied ist.

Anschließend muss ein „Zusätzliches Ersatzobjekt“ gewählt werden. In diesem Fall stehen die Stellen zur Verfügung, welche aufgrund des Benutzers und der Organisationseinheit eingeschränkt wurden.

## Stelle bei Aktivitäten und Prozessen ändern

Ändert die Stelle bei bestehenden Aktivitäten und Prozessen. Als Ersatzobjekt können nur Stellen des Benutzers aus der Eigenschaft „Auslösendes Objekt“ ausgewählt werden.

Anschließend muss ein „Zusätzliches Ersatzobjekt“ gewählt werden. In diesem Fall stehen die Organisationseinheit nur in der Verfügung, welche aufgrund des Benutzers und der Stelle eingeschränkt wurden.

## Auslösendes Objekt

Referenz: FSCADM@15.1001:triggerobject

Das Objekt, welches die Reorganisation auslöst. So wird zum Beispiel nach Vorgängen gesucht, in welchen der Benutzer aus der Eigenschaft „Auslösendes Objekt“ in der Eigenschaft "Eigentümer/in" (COOSYSTEM@1.1:objowner) eingetragen ist

## Ersatzobjekt

Referenz: FSCADM@15.1001:exchangeobject

Das Objekt, welches statt dem "Auslösendes Objekt" in die konfigurierten Eigenschaften eingetragen wird. Diese Eigenschaft muss auch befüllt werden, wenn als Aktion "Objekt entfernen" (FSCADM@15.1001:CtxRemoveObject) ausgewählt wird, da manche Eigenschaften nicht leer sein dürfen

So wird in diesem Fall zum Beispiel ein Benutzer durch einen anderen Benutzer ersetzt.

## Zusätzliches Ersatzobjekt

Referenz: FSCADM@15.1001:additionalexchangeobject

Diese Eigenschaft steht zur Verfügung, wenn eine Aktion das Setzten bzw. ersetzten eines zusätzlichen Objekts erfordert, wie zum Beispiel beim Austauschen der Organisationseinheit in der Eigenschaft "Prozessinitiator", in welcher zusätzlich die Stelle, passend zur Organisationseinheit gesetzt werden muss

Benutzerhilfe
315

<!-- PDF page 316 -->

Benutzerhilfe

# 5.8.2 Durchführen einer Reorganisation

Nach dem Erstellen einer "Reorganisation" (FSCADM@15.1001:Reorganization) stehen in der Explore-Ansicht zwei Menüs zur Verfügung

## 5.8.2.1 Ermitteln der Betroffenen Objekte

Das Menü "Betroffene Objekte ermitteln" (FSCADM@15.1001:MenuSetObjectsToReorganize) sucht Objekte auf Basis der Konfiguration in dem Customization Point "Reorganisation" (FSCADM@15.1001:cpreorganizeobject) in der neuen Konfiguration "Fachadministration" (FSCADM@15.1001:Configuration) und den Werten in dem Reorganisationsobjekt und legt diese in dem Reorganisationsobjekt ab.

## 5.8.2.2 Reorganisation durchführen

Das Menü „Reorganisation durchführen“ (FSCADM@15.1001:MenuReorganizeObjects) führt die Reorganisation auf Basis der Konfiguration in dem Customization Point "Reorganisation" (FSCADM@15.1001:cpreorganizeobject) und den Werten in dem Reorganisationsobjekt auf die Objekte im Reorganisationsobjekt aus.

Um die Nachvollziehbarkeit zu garantieren, können nach dem Ausführen des Menüs "Reorganisation durchführen" (FSCADM@15.1001:MenuReorganizeObjects) die Eigenschaften im Reorganisationsobjekt nicht mehr geändert werden. Alle geänderten Objekte werden in die neue Eigenschaft und Registerkarte "Erledigt" (FSCADM@15.1001:storedqboldone) verschoben. Zusätzlich wird pro Reorganisation ein Bericht erstellt und in dem Reorganisationsobjekt gespeichert.

Die Eigenschaft "Warteschlange für Admin-Aktionen verwenden" (FSCADM@15.1001:usequeue) ermöglicht die Wahl zwischen dem sofortigen Ausführen von "Betroffene Objekte ermitteln" bzw. "Reorganisation durchführen" oder der Verwendung der Warteschlange.

## 5.8.3 Konfiguration - Fachadministration

Im dem Konfigurationsobjekt «Fachadministration» wird gesteuert, nach welchen Objektklassen und in welcher Eigenschaft in diesem Objekt gesucht werden soll.

So wird zum Beispiel nach Vorgängen gesucht, in welchen der Benutzer in der Eigenschaft «Eigentümer» eingetragen ist.

316

<!-- PDF page 317 -->

Benutzerhilfe
317

![img-6.jpeg](img-6.jpeg)

## 5.9 Neue Spalteneinstellungsdialoge freischalten

Die neuen Spalteneinstellungsdialoge vereinfachen sowohl das Speichern als auch das Laden von Spalteneinstellungen.

## 5.9.1 Aktivieren der Customizing App

Ab der Version 2025 der Fabasoft eGov-Suite muss die Customizing App nicht mehr in den Organisationseinheiten hinterlegt werden. Anstelle dessen wird die Customizing App an zentraler Stelle in der Hauptdomäne hinterlegt. Die erforderlichen Einstellungen sind durch die Systemadministration vorzunehmen.

## 5.9.2 Vorlagen und Voreinstellungen

Nach dem Hinterlegen der App wird ein Objekt der Objektklasse „Vorlagen und Voreinstellungen“ am Homescreen von jedem, im Konfigurationsobjekt des „Vorlagen und Voreinstellungen“-Objekts berechtigten Benutzers abgelegt. Wenn im Anschluss weitere Benutzer berechtigt werden, dann wird auch bei diesen ein „Vorlagen und Voreinstellungen“ Objekt auf dessen Homescreen abgelegt.

<!-- PDF page 318 -->

![img-7.jpeg](img-7.jpeg)

![img-8.jpeg](img-8.jpeg)

In diesem Objekt stehen „Persönliche Voreinstellungen“ als auch „Sammlungen für Vorlagen und Voreinstellungen“ zur Verfügung.

![img-9.jpeg](img-9.jpeg)

## Persönliche Voreinstellungen

Die Spalteneinstellungen, welche unter „Persönliche Voreinstellungen“ aufscheinen stehen nur dem aktuellen Benutzer zur Verfügung. Zum Ablegen von Spalteneinstellungen in den „Persönlichen Spalteneinstellungen“ muss beim Speichern von Spalteneinstellungen bei „Speichern unter“ das Objekt „Persönlichen Voreinstellungen“ ausgewählt werden.

## Sammlungen für Vorlagen und Voreinstellungen

In den Sammlungen für Vorlagen und Voreinstellungen werden jene Objekte hinterlegt, welche allen berechtigen Benutzern zur Verfügung stehen sollen.

Zum Ablegen von Spalteneinstellungen in der jeweiligen Sammlung muss beim Speichern von Spalteneinstellungen bei „Speichern unter“ die Sammlung ausgewählt werden.

Benutzerhilfe

<!-- PDF page 319 -->

Die Berechtigungen können in den jeweiligen Sammlungen beim Klick auf „Berechtigungen“ eingesehen werden:

![img-10.jpeg](img-10.jpeg)

**Änderungsberechtigt**: Neue Spalteneinstellungen können in dieser Sammlung abgelegt werden. Die Sammlung steht beim Speichern von Spalteneinstellungen unter „Speichern unter“ zur Verfügung.

**Leseberechtigt**: Die Sammlung kann eingesehen werden, es ist weder das Verwenden noch das Speichern von Spalteneinstellungen möglich.

**Nutzer**: Die Spalteneinstellungen aus der Sammlung können geladen werden.

Benutzer können in mehreren Eigenschaften eingetragen werden.

## 5.9.3 Administrieren von Vorlagen und Voreinstellungen

Zum Administrieren der „Vorlagen und Voreinstellungen“ kann über „Zur Konfiguration wechseln“ in das dazugehörige „Customizing Configuration“ Objekt gewechselt werden, welches pro Organisationseinheit beim Hinterlegen der Customizing App erstellt wird.

In dem „Customizing Configuration“ Objekt können wiederum unter „Berechtigungen“ „App-Administratoren“ und „App-Benutzer“ eingestellt werden.

Jede/r/s Benutzer/Organisationseinheit/Team welches in einer Sammlung für Vorlagen und Voreinstellungen hinterlegt wird, muss in dem „Customizing Configuration“ Objekt unter „App-Benutzer“ eingetragen werden.

„App-Administratoren“ können neue Sammlungen erstellen.

## 5.9.4 Persönliche Voreinstellungen – Vorlagen und Voreinstellungen – Sammlung für Voreinstellungen

### Persönliche Voreinstellungen

Dieses Objekt wird in der Arbeitsumgebung gespeichert und kann über die Vorlagensammlung geöffnet werden. Darin sind die persönlichen Spalteneinstellungen und Muster für Verfügungen zu finden. Neue Objekte können darin abgelegt werden, wenn „Persönliche Voreinstellungen“ bei „Speichern unter“ während dem Erstellen von Spalteneinstellungen bzw. Muster für Verfügungen ausgewählt wird.

Benutzerhilfe

<!-- PDF page 320 -->

# Vorlagen und Voreinstellungen

Dieses Objekt wird beim Aktivieren der Customizing App am Homescreen abgelegt und dient rein zur Visualisierung. Dies bedeutet, dass dort die Objekte aus der „Persönlichen Voreinstellung“ und die „Sammlungen für Voreinstellungen“ angezeigt werden, auf welche der Benutzer berechtigt ist.

# Sammlung für Voreinstellungen

In der Eigenschaft „Sammlungen für Vorlagen und Voreinstellungen“ werden alle Sammlungen angezeigt, auf welche der Benutzer berechtigt ist. Dieses Objekt dient zum Teilen von Spalteneinstellungen mit anderen Benutzern, Organisationseinheiten bzw. Teams.

# 5.9.5 Zuordnung ändern

Das Menü „Zuordnung ändern“ dient zum Verschieben von Spalteneinstellungen und Musterverfügungen zwischen „Sammlungen für Vorlagen und Voreinstellungen“ bzw. den „Persönlichen Voreinstellungen“.

Das Menü kann über das Kontextmenü auf die betroffenen Objekte bzw. über Drag and Drop auf „Sammlungen für Vorlagen und Voreinstellungen“ aufgerufen werden.

![img-11.jpeg](img-11.jpeg)

Benutzerhilfe

<!-- PDF page 321 -->

Benutzerhilfe

# 5.9.5.1 Zuordnungstyp

In dieser Eigenschaft kann zwischen „Original zuweisen" und „Duplikat zuweisen" gewählt werden.

Bei „Original zuweisen" wird das Objekt in das Ziel, welches unter „Speichern unter" ausgewählt wurde, verschoben.

Bei „Duplikat zuweisen" wird ein Duplikat des Objekts in dem Ziel, welches unter „Speichern unter" ausgewählt wurde, abgelegt. Das originale Objekt wird nicht verschoben.

# 5.9.5.2 Speichern unter

In dieser Eigenschaft muss entweder eine „Sammlung für Vorlagen und Voreinstellungen" oder die „Persönlichen Voreinstellungen" als Speicherort ausgewählt werden.

## Anmerkung:

Zur Verfügung stehen jene „Sammlungen für Vorlagen und Voreinstellungen", in welchen der Benutzer unter „Alle Rechte" bzw. „Änderungsberechtigt" eingetragen ist.

Wenn „Zuordnung ändern" über Drag and Drop aufgerufen wird, steht die Eigenschaft „Speichern unter" nicht zur Verfügung.

# 5.9.5.3 Einstellungen für alle Objekte verwenden

Diese Eigenschaft besagt, ob die aktuellen Einstellungen der Eigenschaften „Zuordnungstyp" und „Speichern unter" für alle Folgeobjekte automatisch nach dem Klick auf „Weiter" angewandt werden sollen.

## Anmerkung:

Die Eigenschaft ist nur sichtbar, wenn mindestens zwei Objekte markiert wurden.

# 5.10 Konfigurieren der Anrede

Zur manuellen Konfiguration der Anrede kann die Eigenschaft Konfiguration zur Berechnung der Anrede (COOELAK@1.1001:salutationconfiguration) auf der Aktuellen Domäne, auf der Registerkarte eGov-Suite verwendet werden.

# 5.10.1 Ausdruck zur Berechnung der Anrede

Für die Anpassung der Anrede steht in der Eigenschaft Konfiguration zur Berechnung der Anrede die Low-Code Expression Eigenschaft Ausdruck zur Berechnung der Anrede (COOELAK@1.1001:setexpression) zur Verfügung. Darin kann der Inhalt der Anrede definiert werden.

# 5.10.1.1 Eingangsparameter

Die Expression Eigenschaft verfügt über drei Eingangsparameter:

- addressee - Hierbei handelt es sich um ein Objekt der Objektklasse Person

321

<!-- PDF page 322 -->

- addrline - Hierbei handelt es sich um eine Aggregatszeile des Typs Adressat/in (COOELAK@1.1001:Addressee)
- govobj - Hierbei handelt es sich um ein Objekt der Objektklasse E-Government Objekt

Auf Basis dieser Parameter und deren Eigenschaften können unterschiedliche Anreden definiert werden. Hierbei ist zu beachten, dass nicht immer alle drei Parameter befüllt sind. Daher ist in den Low-Code Expression immer zur prüfen ob Parameter vorhanden sind.

## 5.10.1.2 Ausgangsparameter

Als Ausgangsparameter wird eine Zeichenkette erwartet. Zum Beispiel:

return #FSCFOLIO@1.1001:SalutationGenericShortStr.Print();

### Anmerkung:

Die Aktion „Print“ liest aus dem Zeichenkettenobjekt auf Basis der aktuellen Sprache des Benutzers den richtigen Inhalt aus.

## 5.10.2 Kontext

In jeder Zeile der Eigenschaft Konfiguration zur Berechnung der Anrede muss zusätzlich die Eigenschaft Kontext (COOELAK@1.1001:setcontext) definiert werden. Diese Eigenschaft dient zum Differenzieren, in welchem Kontext welche Anrede verwendet werden soll. Mit dem Kontext Standard (COOELAK@1.1001:CtxSalutationDefault) kann der System-Standard überschrieben werden.

## 5.10.2.1 Verfügbare Kontexte

Folgende Kontexte stehen zur Verfügung:

### Standard

COOELAK@1.1001:CtxSalutationDefault

Bei der Verwendung dieses Kontexts wird der System-Standard überschrieben.

### Übernehmen von Werten aus Personen-Objekten in die Adressateneigenschaft

EGOVBASE @15.1001:CtxSalutationInitAddressee

Dieser Kontext wird beim Auswählen eines Adressaten-Objekts in der Eigenschaft Adressat/innen verwendet.

#FSCFOLIO@1.1001:SalutationGenericShortStr.Print()

### Anrede im Personenobjekt

CCAPRECONFIG@15.1001:CtxSalutationPersSalutation

Dieser Kontext dient zum Konfigurieren der Anrede beim Ändern des Geschlechts einer Person.

### Serienbrieffeld: Anrede Briefkopf

Benutzerhilfe
322

<!-- PDF page 323 -->

CCAPRECONFIG@15.1001:CtxSalutationLetterSalutation

Dieser Kontext wird beim Serienbrieffeld „Anrede_Briefkopf" verwendet.

## Serienbrieffeld: Geschlecht Anrede

CCAPRECONFIG@15.1001:CtxSalutationGenderSalutation

Dieser Kontext wird beim Serienbrieffeld „Geschlecht_Anrede" verwendet.

## Serienbrieffeld: Briefanrede

CFGBAYERN@15.1400:CtxSalutationLetterSalutation

Dieser Kontext wird beim Serienbrieffeld „Briefanrede" und „Kopieempfaenger_Briefanrede" verwendet.

## Doc Property: Zuständiger Sachbearbeiter/Eigentümer des Dokumentes (Anrede aus Geschlecht)

CFGBAYERN@15.1400:CtxOwnerSalutationFromGender

Dieser Kontext wird beim Doc Property „OwnerSalutationFromGender" verwendet.

## 5.10.3 Beispiel

```c
FSCFOLIO@1.1001:Sex gender;
if (addrline) {
gender = addrline.COOELAK@1.1001:addrgender;
} else if (addressee) {
gender = addressee.FSCFOLIO@1.1001:perssex;
}
String salutationstring;
switch (gender) {
case SEX_MALE:
salutationstring = #FSCFOLIO@1.1001:SalutationMaleStr.Print();
break;
case SEX_FEMALE:
salutationstring = #FSCFOLIO@1.1001:SalutationFemaleStr.Print();
break;
default:
salutationstring = #FSCFOLIO@1.1001:SalutationGenericShortStr.Print();
}
return salutationstring;
```

In diesem Beispiel wird zuerst geprüft, ob die Parameter „addrline" oder „addressee" befüllt sind.

Je nachdem welcher Parameter befüllt ist, wird aus ihnen die Eigenschaft „Geschlecht" ausgelesen.

Im Anschluss wird auf Basis des ausgelesenen Geschlechts der Inhalt von Zeichenkettenobjekte zurückgegeben.

Benutzerhilfe

<!-- PDF page 324 -->

# 6 Formulare

## 6.1 Allgemeine Formularseiten

### 6.1.1 Registerkarte „Aussonderung“

![img-0.jpeg](img-0.jpeg)

Auf der Registerkarte „Aussonderung“ stehen Ihnen folgende Metadaten zur Verfügung:

- **Transfer**
- **Transferfrist**: Im Feld **Transferfrist** wird in Form einer Frist der Zeitraum angegeben, innerhalb dem zu den Akten verfügte Geschäftsobjekte unmittelbar wieder in Bearbeitung genommen werden können. Innerhalb dieses Zeitraums können die Akten, die Vorgänge und die Dokumente für Bearbeitungen im ursprünglichen Dateiformat zur Verfügung gestellt werden.
- **Vorgesehen/tatsächlich**: In diesen Feldern wird der vorgesehen und tatsächliche Zeitpunkt der Aufbewahrung/des Transfers angegeben. Die Erfassung des Datums kann manuell oder auch über den Kalender erfolgen.

- **Aufbewahrung**
- **Aufbewahrungsfrist**: Im Feld **Aufbewahrungsfrist** wird in Form einer Frist der Zeitraum angegeben, für den Akten, Vorgänge und Dokumente aufbewahrt werden.
- **Aussonderung (vorgesehen/tatsächlich)**: In diesen Feldern wird der vorgesehene und tatsächliche Zeitpunkt der Aussonderung angegeben.
- **Aufbewahrungsort/-medium**: In diesem Feld wird der Aufbewahrungsort bzw. das Medium, das für die Aufbewahrung verwendet wird, angegeben.
- **Aussonderungsart**: In diesem Feld kann die Aussonderungsart (Vernichten und Anbieten) für Akten, Vorgänge und Dokumente angegeben werden. Die Aussonderung selbst erfolgt automatisch nach Eintreffen des Endes der Aufbewahrung (Zeitpunkt der Aussonderung).

Benutzerhilfe

<!-- PDF page 325 -->

Benutzerhilfe
325

# 6.1.2 Registerkarte „Laufweg“

![img-1.jpeg](img-1.jpeg)

Der Laufweg eines Vorgangs kann auf der Registerkarte „Laufweg“ eingesehen und bearbeitet werden. Für die Bearbeitung steht ein graphischer Prozesseditor zur Verfügung.

Ein Laufweg kann bearbeitet werden, indem man beispielsweise neue Aktivitäten hinzufügt oder Aktivitäten entfernt.

# 6.1.3 Registerkarte „Umschreibungen“

![img-2.jpeg](img-2.jpeg)

- Protokollierung: In diesem Feld kann die aktuelle Protokollierung des Dokuments eingesehen werden.

<!-- PDF page 326 -->

# 6.1.4 Registerkarte „Bezüge"

![img-3.jpeg](img-3.jpeg)

Auf der Registerkarte „Bezüge“ stehen Ihnen folgende Metadaten zur Verfügung:

- Bezüge zu vorhergehenden Vorgängen/Akten: In dieser Liste besteht die Möglichkeit, auf andere vorgelagerte Akten bzw. Vorgänge zu verweisen.
Hinweis: Wird in dieser Eigenschaft eine Akte bzw. ein Vorgang eingetragen, erfolgt automatisch eine Referenzierung. Siehe hierzu auch Kapitel 3.2.3 „Bezüge eintragen“.
- Bezüge zu nachfolgenden Vorgängen/Akten: In dieser Liste besteht die Möglichkeit, auf andere Akten bzw. Vorgängen zu verweisen.
Hinweis: Wird in dieser Eigenschaft eine Akte bzw. ein Vorgang eingetragen, erfolgt automatisch eine Referenzierung. Siehe hierzu auch Kapitel 3.2.3 „Bezüge eintragen“.
- Bezüge: In diesem Feld kann auf eine Akte oder einen Vorgang in nicht elektronischer Form verwiesen werden.

# 6.1.5 Registerkarte „Unterschriften“

![img-4.jpeg](img-4.jpeg)

Auf der Registerkarte „Unterschriften“ werden durchgeführte Unterschriften protokolliert:

Benutzerhilfe

<!-- PDF page 327 -->

- Unterschriften: Alle elektronischen Unterschriften, die z.B. auf einem Vorgang oder Dokument ausgeführt wurden, werden in dieser Liste angeführt. Mithilfe der Schaltfläche „Details anzeigen“ kann zwischen einfacher und vollständiger Ansicht gewechselt werden.
- Manuelle Unterschriften: In diesem Feld werden alle nicht elektronischen Unterschriften aufgelistet, die z.B. an einem Vorgang oder Dokument angebracht wurden. Diese können zum Beispiel im Rahmen der Aktivität Medienübergang angebracht werden. Mithilfe der Schaltfläche „Details anzeigen“ kann zwischen einfacher und vollständiger Ansicht gewechselt werden.
- Einfache/Vollständige Ansicht: Mittels der Schaltfläche „Details anzeigen“ (oben rot markiert) kann der Benutzer entscheiden, ob er sich sämtliche Metadaten einer Unterschrift anzeigen lässt oder lediglich die Wichtigsten.

## 6.1.6 Registerkarte „Erstellung“

![img-5.jpeg](img-5.jpeg)

Auf der Registerkarte „Erstellung“ stehen folgende Felder für das Erfassen der Metadaten zur Verfügung:

- Name: In diesem Feld wird der Name (bei Akte, Vorgang und Dokument das Geschäftszeichen) des Objekts angezeigt.
- Erzeugt am/um: In diesem Feld werden das Datum und die Uhrzeit vermerkt, an dem das Objekt erstellt wurde.
- Erzeugt von: Dieses Feld gibt Auskunft über den Benutzer, der das Objekt erstellt hat.
- Letzte Änderung am/um: In diesem Feld werden das Datum und die Uhrzeit vermerkt, an dem die letzte Änderung an dem Objekt durchgeführt wurde.
- Letzte Änderung von: Dieses Feld gibt Auskunft über den Benutzer, der die letzten Änderungen am Objekt durchgeführt hat.
- Objektklasse: Dieses Feld zeigt die Objektklasse des Objekts an.
- Adresse: Die COO-Adresse des Objekts.

Benutzerhilfe

<!-- PDF page 328 -->

# 6.1.7 Registerkarte „Sicherheit"

![img-6.jpeg](img-6.jpeg)

Auf der Registerkarte „Sicherheit“ stehen folgende Felder für das Erfassen der Metadaten zur Verfügung:

- Eigentümer: Dieses Feld bestimmt den Eigentümer des Objekts, der häufig mit speziellen Rechten ausgestattet ist.
- Organisationseinheit: Dieses Feld bestimmt die zuständige Organisationseinheit des Objekts.
- Zugriffsdefinition: Hier kann eine vordefinierte Zugriffsdefinition ausgewählt werden.
- ACL-Objekt: Dieses Feld beinhaltet die ACL, die bei dem ausgewählten Objekt hinterlegt ist. In der ACL sind die Zugriffsrechte auf das Objekt geregelt.
Hinweis: ACL steht für „Access Control List“ (Liste mit Zugriffsrechten).
- Sperre: Diese Eigenschaft beinhaltet Informationen über eine eventuell vorhandene dauerhafte Sperre des Objekts.
- Benutzer/Organisationseinheiten mit Änderungsberechtigung: In diesem Feld können Benutzer bzw. Organisationseinheiten festgelegt werden, die zusätzliche Bearbeitungsrechte für das Objekt bekommen sollen.

Benutzerhilfe

<!-- PDF page 329 -->

- Benutzer/Organisationseinheiten mit Leseberechtigung: In diesem Feld können Benutzer bzw. Organisationseinheiten festgelegt werden, die zusätzliche Leserechte für das Objekt bekommen sollen.
- Mitgeführte Benutzer/Organisationseinheiten mit Leseberechtigung: Wird z.B. bei einem Vorgang ein Benutzer unter Benutzer/Organisationseinheiten mit Leseberechtigung hinterlegt, so wird dieser auch auf die im Vorgang enthaltenen Dokumente und Schriftstücke weitergegeben, damit der jeweilige Benutzer auch auf diese Objekte die entsprechenden Rechte hat. Der jeweilige Benutzer wird dann automatisch bei den Dokumenten und Schriftstücken in der Eigenschaft Mitgeführte Benutzer/Organisationseinheiten mit Leseberechtigung eingetragen.
- Mitgeführte Benutzer/Organisationseinheiten mit Änderungsberechtigung: Wird z.B. bei einem Vorgang ein Benutzer unter Benutzer/Organisationseinheiten mit Änderungsberechtigung hinterlegt, so wird dieser auch auf die im Vorgang enthaltenen Dokumente und Schriftstücke weitergegeben, damit der jeweilige Benutzer auch auf diese Objekte die entsprechenden Rechte hat. Der jeweilige Benutzer wird dann automatisch bei den Dokumenten und Schriftstücken in der Eigenschaft Mitgeführte Benutzer/Organisationseinheiten mit Änderungsberechtigung hinterlegt.
- Im Workflow beteiligte Benutzer: In diesem Feld werden die Benutzer automatisch eingetragen, die durch den Workflow Rechte auf das aktuelle Objekt besitzen.
- Im Workflow beteiligte Organisationseinheiten: In diesem Feld werden die Organisationseinheiten automatisch eingetragen, die durch den Workflow Rechte auf das aktuelle Objekt besitzen.
- Ehemals im Workflow beteiligte Benutzer: In diesem Feld werden automatisch die Benutzer eingetragen, in der Vergangenheit Workflowberechtigungen am Objekt besaßen.
- Ehemals im Workflow beteiligte Organisationseinheiten: In diesem Feld werden automatisch die Organisationseinheiten eingetragen, welche in der Vergangenheit Workflowberechtigungen am Objekt besaßen.

## 6.1.8 Registerkarte „Fachdaten“

![img-7.jpeg](img-7.jpeg)

Benutzerhilfe
329

<!-- PDF page 330 -->

Auf der Registerkarte „Fachdaten“ stehen folgende Felder für das Erfassen der Metadaten zur Verfügung:

- Fachdaten: In diesem Feld können Fachdaten eingetragen werden.
- Fachdatenliste: Die Werte aus dem Aggregat Fachdaten werden beim Übernehmen des Geschäftsobjekts formatiert aufgelistet.

## 6.2 Widget „Arbeitsvorrat“

In diesem Kapitel werden die möglichen Registerkarten, die Widget „Arbeitsvorrat“ angezeigt werden, beschrieben.

### 6.2.1 Registerkarte „Zu tun“

Auf der Registerkarte „Zu tun“ werden alle Aktivitäten angezeigt, bei denen Sie mitbeteiligt sind und die Sie als Benutzer noch zu erledigen haben.

### 6.2.2 Registerkarte „Zuletzt beendet“

Im Arbeitsvorrat eines Benutzers wird automatisch eine bestimmte Anzahl von zuletzt beendeten Aktivitäten auf der Registerkarte „Zuletzt beendet“ eingetragen. Damit ist es für den Benutzer einfacher, unmittelbar nach dem Beenden und Weiterleiten der Aktivität noch einmal auf die Aktivität zuzugreifen. In der Objektliste werden alle Aktivitäten abgelegt, die der Eigentümer des Arbeitsvorrats zuletzt weitergeleitet, zugeteilt, abgelehnt oder vorgeschrieben hat. Die maximale Anzahl der Aktivitäten, die in dieser Objektliste abgelegt werden, kann mithilfe der Eigenschaft Anzahl der beendeten Aktivitäten, die im Arbeitsvorrat angezeigt werden konfiguriert werden.

**Hinweis:** Übersteigt die Anzahl der beendeten Aktivitäten die Anzahl der in der Objektliste Zuletzt beendet anzuzeigenden Aktivitäten, so wird die jeweils älteste Aktivität der Liste nicht mehr angezeigt. Aktivitäten, die aus diesem Grund nicht mehr in der Objektliste erfasst sind, werden auch nach Erhöhung der Anzahl der in dieser Liste angezeigten Aktivitäten nicht wieder angezeigt.

**Hinweis:** Die Konfiguration der Anzahl der beendeten Aktivitäten, die im Arbeitsvorrat angezeigt werden, ist nur für Benutzer mit administrativem Zugang möglich.

### 6.2.3 Registerkarte „Übernommene Aktivitäten“

Auf der Registerkarte „Übernommene Aktivitäten“ werden jene Aktivitäten aufgelistet, die von Ihrem Stellvertreter bereits übernommen wurden. Diese Aktivitäten befinden sich daher nicht mehr auf der Registerkarte „Zu tun“.

### 6.2.4 Registerkarte „Wiedervorlage“

Auf der Registerkarte „Wiedervorlage“ des Arbeitsvorrats können Aktivitäten eingesehen werden, welche auf Wiedervorlage gelegt wurden. Für weitere Informationen zur Wiedervorlage siehe Kapitel 3.3.9.7 „Wiedervorlage“.

Benutzerhilfe

<!-- PDF page 331 -->

Hinweis: Die Registerkarte Wiedervorlage können Sie über die Schaltfläche „Wiedervorlage“ erreichen.

## 6.3 Aktenplan

![img-8.jpeg](img-8.jpeg)

Auf der Registerkarte „Aktenplan“ stehen folgende Felder für das Erfassen der Metadaten eines Aktenplans zur Verfügung:

- Bezeichnung: In diesem Feld kann ein Name (Bezeichnung) für den Aktenplan angegeben werden.
- Aktenplanaufbau: In diesem Feld kann eine Beschreibung zum hierarchischen Aufbau des Aktenplans angegeben werden, z.B. 4-stufig mit Ableitungen.
- Aktenplaneinträge: In diesem Feld stehen die dem Aktenplan zugeordneten Aktenplaneinträge.

## 6.4 Aktenplaneintrag

Dieses Kapitel beschreibt die Metadaten eines Aktenplaneintrags. Abhängig von Ihrer Rolle und der durchzuführenden Tätigkeit (Erzeugen, Suchen bzw. Eigenschaften lesen/bearbeiten) stehen nicht immer alle beschriebenen Registerkarten bzw. Metadaten zur Verfügung. Die Bearbeitbarkeit der angezeigten Felder wird dadurch ebenfalls beeinflusst.

Benutzerhilfe
331

<!-- PDF page 332 -->

# 6.4.1 Registerkarte „Aktenplaneintrag"

[tbl-0.md](tbl-0.md)

Auf der Registerkarte „Aktenplaneintrag“ stehen folgende Felder für das Erfassen der Metadaten eines Aktenplaneintrags zur Verfügung:

- Aktenplankennzeichen: In diesem Feld wird die Zuordnung einer Akte zu einem Aktenplan definiert. Das Aktenplankennzeichen wird für die Bildung eines Geschäftszeichens herangezogen.
- Kurzbezeichnung: In diesem Feld kann eine Kurzbezeichnung für den Aktenplaneintrag erfasst werden. Die Kurzbezeichnung beinhaltet eine kurze Beschreibung des Aktenplaneintrags.
- Ableitung: In diesem Feld kann eine Bezeichnung der Ableitung einer Akte eingetragen werden. Wird eine Ableitung angegeben, so wird diese Bezeichnung vorangehend mit einem Punkt am Ende in die Namensbildung von Akten aufgenommen.
- Aktenplanebene: In diesem Feld wird der Typ des Aktenplaneintrags festgelegt. Es kann unterschieden werden zwischen „Hauptgruppe“, „Obergruppe“, „Gruppe“, „Untergruppe“ und „Betreffseinheit“. Wobei Akten nur in einer „Betreffseinheit“ angelegt werden können. Die anderen Ebenen dienen zur Strukturierung des Aktenplans.

Benutzerhilfe

<!-- PDF page 333 -->

- Zugriffsdefinition für Akten: In diesem Feld kann ein Zugriffsschutz für Akten festgelegt werden, die in diesem Aktenplaneintrag erzeugt oder z.B. durch Umschreiben zugeordnet werden. Wird die Zugriffsdefinition eines Aktenplaneintrags nachträglich geändert, so hat dies keine Auswirkungen auf bereits in diesem Aktenplaneintrag angelegte Akten. Ihre Zugriffsdefinition bleibt bestehen.

- Beschreibung des Aktenplaneintrags: In diesem Feld kann der Aktenplaneintrag genauer in einem Textfeld beschrieben werden.

- Schlagworte: In dieser Liste können Schlagworte für die Beschlagwortung hinterlegt werden. Schlagworte können zur Beschreibung eines Aktenplaneintrags verwendet werden.

- Dokumenttypen: Dieses Feld erfasst eine Liste von Dokumenttypen. Wird in einem Vorgang einer Akte aus diesem Aktenplaneintrag eine Erledigung erstellt, so werden nur jene Dokumenttypen in der Erledigung zur Auswahl angeboten, die in diesem Aktenplaneintrag eingetragen sind.

- Transferfrist: In diesem Feld wird die Transferfrist für die zugeordneten Akten festgelegt. Die Transferfrist legt den Zeitraum fest, innerhalb dem z.A.-verfügte Dokumente, Vorgänge und Akten unmittelbar wieder in Bearbeitung genommen werden können. Innerhalb dieses Zeitraums kann das Dokument, der Vorgang oder die Akte für Bearbeitungen im ursprünglichen Dateiformat zur Verfügung gestellt werden.

- Aufbewahrungsfrist: In diesem Feld kann eine Aufbewahrungsfrist angegeben werden. Die Aufbewahrungsfrist bestimmt den Zeitraum, in dem Dokumente, Vorgänge und Akten nach der Bearbeitung für den Zugriff bei der aktenführenden Stelle aufzubewahren sind.

- Aussonderungsart: Nach Ablauf der Aufbewahrungsfrist erfolgt die Aussonderung in Abhängigkeit von der angegebenen Aussonderungsart. Dokumente, Vorgänge oder Akten werden entweder vernichtet oder an das zuständige Archiv übermittelt. Folgende Aussonderungsarten stehen zur Verfügung:

- „A - Anbieten“ Dokumente, Vorgänge oder Akten sind nach Ablauf der Aufbewahrungsfrist dem zuständigen Archiv als archivwürdig zu übermitteln.
- „V - Vernichten“ Dokumente, Vorgänge oder Akten können nach Ablauf der Aufbewahrungsfrist vernichtet werden.

- Aufbewahrungsort: In diesem Feld kann der Aufbewahrungsort der elektronischen Akten, Vorgänge, Dokumente und Schriftstücke festgehalten werden.

- Standard-Laufwege: Einem Aktenplaneintrag können ein oder mehrere Standard-Laufwege zugeordnet werden. Diese stehen dann für Vorgänge der Akten, die diesem Aktenplaneintrag zugeordnet sind, zur Verfügung.

- Übergeordneter Aktenplan: In diesem Feld wird (soweit vorhanden) ein übergeordneter Aktenplan eingetragen.

- Übergeordneter Aktenplaneintrag: Aktenplaneinträge können hierarchisch verschachtelt werden. In diesem Feld werden die Aktenplaneinträge angezeigt, die diesem Aktenplaneintrag übergeordnet sind.

- Untergeordnete Aktenplaneinträge: Aktenplaneinträge können hierarchisch verschachtelt werden. In diesem Feld werden die Aktenplaneinträge angezeigt, die diesem Aktenplaneintrag untergeordnet sind.

Benutzerhilfe
333

<!-- PDF page 334 -->

Benutzerhilfe
334

# 6.4.2 Registerkarte „Regeln“

![img-9.jpeg](img-9.jpeg)

Auf der Registerkarte „Regeln“ stehen Ihnen folgende Metadaten zur Verfügung:

- Betreff innerhalb der Hierarchie beim Erzeugen vererben: Dieses Feld bestimmt, ob der Inhalt des Felds Beschreibung des Aktenplaneintrags in das Feld Beschreibung des Aktenplaneintrags des Aktes bzw. den Vorgang übernommen wird.
- Prozesse kopieren: Dieses Feld bestimmt, ob beim Kopieren des Vorgangs, die diesem Aktenplaneintrag/Dokumenttyp zugeordnet sind, auch die Prozesse mitkopiert werden.

# 6.4.3 Registerkarte „FAI“

![img-10.jpeg](img-10.jpeg)

Auf der Registerkarte „FAI“ stehen folgende Felder zur Erfassung der Metadaten zur Verfügung:

- Initialisierungswerte für Fachdaten: In diesem Aggregat kann die Vorinitialisierung von Fachdaten auf bestimmten Objektklassen eingestellt werden.
- Erlaubte Begriffe: Nur die Schlagwörter und Fachdaten Begriffe, welche in dieser Eigenschaft hinterlegt sind, können innerhalb der Aktenplanhierarchie verwendet werden.

<!-- PDF page 335 -->

Benutzerhilfe
335

# 6.5 Eingangsdokument

## 6.5.1 Registerkarte „Eingang“

Auf der Registerkarte „Eingang“ stehen folgende Felder zur Erfassung der Metadaten zur Verfügung:

[tbl-1.md](tbl-1.md)

- Vorgang: In diesem Feld wird der Vorgang angezeigt, dem das Eingangsdokument zugeordnet ist.
- Registerblatt: In diesem Feld wird das Registerblatt angezeigt, in dem das Eingangsdokument abgelegt ist.
- Datum: In diesem Feld wird vermerkt, wann das Dokument eingegangen ist. Dieses Feld wird beim Erzeugen automatisch mit dem aktuellen Tagesdatum befüllt.
- Fremdes Geschäftszeichen: In diesem Feld kann, falls erforderlich, das Geschäftszeichen einer anderen Organisation eingetragen werden.
- Titel: In diesem Feld kann der Titel des Eingangsdokuments angegeben werden. Der Titel wird im Namen (Geschäftszeichen) des Eingangsdokuments mit angezeigt.
- Betreff: In diesem Feld kann der Betreff des Eingangsdokuments eingegeben werden. Der Betreff sollte aussagekräftig sein, da eine kurze, prägnante Betreffzeile eine schnelle thematische Zuordnung ermöglicht.

<!-- PDF page 336 -->

- Dokumenttyp: In diesem Feld kann ein Dokumenttyp hinterlegt werden, um etwa in der Folge darin hinterlegte Eingangsbestätigungen zum Eingangs-dokument hinzuzufügen.
- Schlagworte: In diesem Feld können Schlagworte für die Beschlagwortung des Eingangs-dokuments hinterlegt werden. Schlagworte können zur Beschreibung eines Eingangs-dokuments verwendet werden.
- Hinweise: In diesem mehrzeiligen Textfeld können allgemeine Informationen zur Erledigung hinterlegt werden.

## 6.5.2 Registerkarte „Adressaten“

![img-11.jpeg](img-11.jpeg)

Auf der Registerkarte „Adressaten“ stehen folgende Felder für das Erfassen der Metadaten zur Verfügung:

- Adressaten: Hier können die Absender des Eingangs-dokuments u.a. mit gewünschter Versandart (E-Mail, Papier, etc.) hinterlegt werden.

Benutzerhilfe
336

<!-- PDF page 337 -->

# 6.6 Erledigung

## 6.6.1 Registerkarte „Erledigung“

[tbl-2.md](tbl-2.md)

Auf der Registerkarte „Erledigung“ stehen folgende Felder für das Erfassen der Metadaten einer Erledigung zur Verfügung:

- **Vorgang**: In diesem Feld wird der Vorgang angezeigt, dem die Erledigung zugeordnet ist.
- **Registerblatt**: In diesem Feld wird das Registerblatt angezeigt, in dem die Erledigung abgelegt ist.
- **Bezug zu Eingangsdokument**: In diesem Feld kann ein Eingangsdokument hinterlegt werden, auf das sich die Erledigung bezieht, z.B. wenn die Erledigung ein Antwortschreiben auf ein Eingangsdokument ist.

**Hinweis**: Dieses Feld wird automatisch befüllt, wenn auf ein Eingangsdokument geantwortet wird. Siehe hierzu auch Kapitel 3.4.1.1 „Eine Erledigung über den Kontextmenübefehl „Antworten“ erstellen“.

- **Datum**: Hier kann ein Datum hinterlegt werden das vom tatsächlichen Briefdatum abweicht.

Benutzerhilfe

<!-- PDF page 338 -->

- Titel: In diesem Feld kann der Titel der Erledigung angegeben werden. Der Titel wird im Namen (Geschäftszeichen) der Erledigung mit angezeigt.
- Betreff: In diesem Feld kann der Betreff der Erledigung eingegeben werden. Der Betreff sollte aussagekräftig sein, da eine kurze, prägnante Betreffzeile eine schnelle thematische Zuordnung ermöglicht.
- Dokumenttyp: In diesem Feld muss beim Erzeugen einer Erledigung ein Dokumenttyp hinterlegt werden. Je nach gewähltem Dokumenttyp sind unterschiedliche Vorlagen im Feld Vorlage verfügbar.
- Vorlage: In diesem Feld kann beim Erzeugen der Erledigung die zu verwendende Vorlage ausgewählt werden. Je nach gewähltem Dokumenttyp sind unterschiedliche Vorlagen verfügbar.
Hinweis: Dieses Metadatum steht nur beim Erzeugen einer Erledigung zur Verfügung.
- Zuständig für die Sachbearbeitung: In diesem Feld kann der/die zuständige Sachbearbeiter/in hinterlegt werden.
- Zuständige Organisationseinheit: In diesem Feld wird die zuständige Organisationseinheit hinterlegt. Für die Initialisierung gilt dabei folgende Regel: Wenn das Feld „Organisationskennzeichen zur GZ-Bildung“ der Organisationseinheit der aktiven Rollen befüllt ist, wird dieser Wert als Initialisierungswert bei neu erzeugten Erledigungen verwendet; ansonsten wird die Organisationseinheit der aktiven Rollen selbst als Initialisierungswert verwendet.
Hinweis: Der Wert in der Eigenschaft kann bis zur Finalisierung verändert werden, was in der Folge eine Änderung des Geschäftszeichens der Erledigung bewirkt.
- Schlagworte: In diesem Feld können Schlagworte für die Beschlagwortung der Erledigung hinterlegt werden. Schlagworte können zur Beschreibung einer Erledigung verwendet werden.
- Dokumentbezogene Hinweise: In diesem mehrzeiligen Textfeld können allgemeine Informationen zur Erledigung hinterlegt werden.
- Finalisiert am: In diesem Feld werden das Datum und die Uhrzeit vermerkt, an dem die Erledigung versendet wurde.
Hinweis: Dieses Feld wird erst nach der Reinschrifterstellung/dem Versand angezeigt.
- Finalisiert von: In diesem Feld wird der Benutzer vermerkt, der die Erledigung versendet hat.
Hinweis: Dieses Feld wird erst nach der Reinschrifterstellung/dem Versand angezeigt.

Benutzerhilfe
338

<!-- PDF page 339 -->

Benutzerhilfe
339

# 6.6.2 Registerkarte „Adressaten“

![img-12.jpeg](img-12.jpeg)

- Adressaten: Hier können die Empfänger der Erledigung u.a. mit gewünschter Versandart (E-Mail, Papier, etc.) hinterlegt werden.

# 6.6.3 Registerkarte „Anlagen“

![img-13.jpeg](img-13.jpeg)

Auf der Registerkarte „Anlagen“ stehen folgende Felder für die Erfassung der Metadaten einer Erledigung:

<!-- PDF page 340 -->

- Gemeinsame Anlagen: In diesem Feld können allgemeine Anlagen angegeben werden, die mitversendet werden sollen. Es können nur Schriftstücke als Anlagen angegeben werden, die in der Erledigung enthalten sind, zu dem die Anlage zugeordnet werden soll.
- Alternative Beschreibung der Anlagen: In diesem mehrzeiligen Textfeld können Informationen zu den Anlagen angegeben werden.
- Übersicht persönliche Anlagen: Zeigt die persönlichen Anlagen der jeweiligen Empfänger an.

Hinweis: Die Liste der Schriftstücke einer Erledigung kann über den Befehl „In neuem Fenster öffnen" eingesehen werden. Siehe hierzu auch Kapitel 2.1.2.6 „Ein Objekt in einem neuen Fenster öffnen".

## 6.7 Umlaufmappe

### 6.7.1 Registerkarte „Umlaufmappe"

Auf der Registerkarte „Umlaufmappe" stehen folgende Felder zur Verfügung:

![img-14.jpeg](img-14.jpeg)

- Vorgang: In diesem Feld wird der Vorgang angezeigt, dem die Umlaufmappe zugeordnet ist. Das Feld ist ein Pflichtfeld.
- Titel: In diesem Feld kann der Name der Umlaufmappe definiert werden. Ist kein Name definiert, dann wird das Feld automatisch mit „Neue Umlaufmappe" gesetzt.
- Betreff: In diesem Feld kann der Betreff der Umlaufmappe eingegeben werden. Der Betreff sollte aussagekräftig sein, da eine kurze, prägnante Betreffzeile eine schnelle thematische Zuordnung ermöglicht.
- Status: In diesem Feld wird der Status der Umlaufmappe angezeigt (z. B. In Bearbeitung).
- Bearbeitungsstatus: In diesem Feld wird der Bearbeitungsstatus der Umlaufmappe angezeigt (z.B. Erstellt).

Benutzerhilfe

<!-- PDF page 341 -->

# 6.7.2 Registerkarte „Unterschriften“

![img-15.jpeg](img-15.jpeg)

Auf der Registerkarte „Unterschriften“ stehen folgende Felder zur Verfügung:

- Unterschriften: Alle elektronischen Unterschriften, die auf der Umlaufmappe angebracht wurden. Mithilfe der Schaltfläche „Details anzeigen“ kann zwischen einfacher und vollständiger Ansicht gewechselt werden.
- Unterschriften zu Arbeitsdokumenten: Alle elektronischen Unterschriften, die auf den aktuellen Arbeitsdokumenten ausgeführt wurden, werden in dieser Liste angeführt. Mithilfe der Schaltfläche „Details anzeigen“ kann zwischen einfacher und vollständiger Ansicht gewechselt werden.
- Manuelle Unterschriften zu Arbeitsdokumenten: In diesem Feld werden alle nicht elektronischen Unterschriften aufgelistet, die auf den aktuellen Arbeitsdokumenten angebracht wurden. Mithilfe der Schaltfläche „Details anzeigen“ kann zwischen einfacher und vollständiger Ansicht

Benutzerhilfe

<!-- PDF page 342 -->

Benutzerhilfe
342

# 6.8 Akte

## 6.8.1 Registerkarte „Akte“

[tbl-0.md](tbl-0.md)

Auf der Registerkarte „Akte“ stehen folgende Felder zur Verfügung:

- Aktenplaneintrag: In diesem Feld wird der Aktenplaneintrag, in dem sich die Akte befindet, angezeigt. Der Aktenplaneintrag einer Akte kann über das Umschreiben der Akte geändert werden.
- Kurzbezeichnung des Aktenplaneintrags: In diesem Feld wird die Kurzbezeichnung des Aktenplaneintrags angezeigt, in welchem sich der Akt befindet.
- Titel: In diesem Feld kann der Titel der Akte angegeben werden. Der Titel wird im Namen (Geschäftszeichen) der Akte mit angezeigt.
- Betreff: In diesem Feld kann der Betreff der Akte eingegeben werden. Der Betreff sollte aussagekräftig sein, da eine kurze, prägnante Betreffzeile eine schnelle thematische Zuordnung ermöglicht.
- Schlagworte: In diesem Feld können Schlagworte für die Beschlagwortung der Akte hinterlegt werden. Schlagworte können zur Beschreibung einer Akte verwendet werden.
- Zugriffsdefinition für Vorgänge: Mithilfe dieser Eigenschaft kann die Zugriffsdefinition für neu erzeugte Vorgänge in der Akte festgelegt werden. Bei den neuen Vorgängen wird die

<!-- PDF page 343 -->

angegebene Zugriffsdefinition auf der Registerkarte „Sicherheit“ in dem Feld Zugriffsdefinition hinterlegt.

- Gültig ab: In diesem Feld wird der Zeitpunkt angegeben, ab dem das Objekt gültig ist.
- Gültig bis: In diesem Feld wird der Zeitpunkt angegeben, bis zu welchem das Objekt gültig ist.
- Fortlaufende Nummerierung: Wird diese Eigenschaft auf „Nein“ gesetzt, wird keine automatische Subzahl generiert, d. h. auf die Nummerierung der Vorgänge sowie der Dokumente in den Vorgängen wird verzichtet.

## 6.8.2 Registerkarte „Bezüge“

![img-0.jpeg](img-0.jpeg)

Die Registerkarte „Bezüge“ enthält folgende Felder:

- Bezüge: In diesem Feld können Verweise auf Akten oder Vorgänge eingefügt werden, die nicht in elektronischer Form vorliegen.
- Bezüge zu vorhergehenden Vorgängen/Akten: In dieser Liste besteht die Möglichkeit, auf andere vorgelagerte Akten bzw. Vorgänge zu verweisen.
Hinweis: Wird in dieser Eigenschaft eine Akte bzw. ein Vorgang eingetragen, erfolgt automatisch eine Referenzierung. Siehe hierzu auch Kapitel 3.2.3 „Bezüge eintragen“.
- Bezüge zu nachfolgenden Vorgängen/Akten: In dieser Liste besteht die Möglichkeit, auf andere Akten bzw. Vorgänge zu verweisen.
Hinweis: Wird in dieser Eigenschaft eine Akte bzw. ein Vorgang eingetragen, erfolgt automatisch eine Referenzierung. Siehe hierzu auch Kapitel 3.2.3 „Bezüge eintragen“.

## 6.9 Vorgang

### 6.9.1 Registerkarte „Vorgang“

Auf der Registerkarte „Vorgang“ stehen folgende Felder zur Verfügung:

Benutzerhilfe
343

<!-- PDF page 344 -->

A20 011/1 (Vorgang) Bearbeiten
Seite 29

![img-1.jpeg](img-1.jpeg)

- Akte: In diesem Feld besteht die Möglichkeit, die übergeordnete Akte festzulegen.
- Aktenbetreff: In diesem Feld wird der Betreff der Akte, der der Vorgang zugeordnet ist, angezeigt.
- Titel: In diesem Feld können Sie den Titel des Vorgangs festlegen.
- Betreff: In diesem Feld können Sie den Betreff des Vorgangs festlegen.
- Schlagworte: In dieser Liste können Begriffe für die Beschlagwortung des Vorgangs hinterlegt werden.
- Status: In diesem Feld wird der Status des Vorgangs angezeigt (z. B. In Bearbeitung).
- Bearbeitungsstatus: In diesem Feld wird der Bearbeitungsstatus des Vorgangs angezeigt (z.B. Erstellt).
- Original: In diesem Feld können Papierakte ("Papiervorgang/-akte") bzw. Akte die teilweise in Papierform vorliegen ("Hybridvorgang/-akte") gekennzeichnet werden.
- Hinweis: Standardmäßig ist der Eintrag "Elektronischer Vorgang/Akte" ausgewählt.

Benutzerhilfe

<!-- PDF page 345 -->

- Zusatzzeichen – Auswahl: In diesem Feld können vordefinierte Zusatzzeichen ausgewählt werden. Das ausgewählte Zusatzzeichen wird im Feld Zusatzzeichen angezeigt.
- Zusatzzeichen: In diesem Feld wird der Wert eines ausgewählten Zusatzzeichens angezeigt.
- Manuelle Wiedervorlage für Papiervorgänge
- Wer (man. WV - Auswahl): Durch Auswahl eines Benutzers oder einer Organisationseinheit wird das Feld "Wer (man. WV)" entsprechend befüllt. Gleichzeitig wird auch in das Feld "Wann (man. WV)" das aktuelle Datum eingetragen.
- Hinweis: Die Auswahl selbst (Benutzer bzw. Organisationseinheit) wird nicht gespeichert.
- Wer (man. WV): Dieses Feld dient zu Eingabe der Verantwortung für die manuellen Wiedervorlage eines Papier- oder Hybridvorgangs.
- Wann (man. WV): Dieses Feld dient zu Eingabe des Termins für die manuelle Wiedervorlage eines Papier- oder Hybridvorgangs.
- Was (man. WV): Dieses Feld dient zu Eingabe der Beschreibung für die manuelle Wiedervorlage eines Papier- oder Hybridvorgangs.
- Manueller Lauf für Papiervorgänge
- Wer (man. Lauf - Auswahl): Durch Auswahl eines Benutzers oder einer Organisationseinheit wird das Feld "Wer (man. Lauf)" entsprechend befüllt. Gleichzeitig wird auch in das Feld "Wann (man. Lauf)" das aktuelle Datum eingetragen.
- Hinweis: Die Auswahl selbst (Benutzer bzw. Organisationseinheit) wird nicht gespeichert.
- Wer (man. Lauf): Dieses Feld dient zu Eingabe der Verantwortung für den manuellen Lauf eines Papier- oder Hybridvorgangs.
- Wann (man. Lauf): Dieses Feld dient zu Eingabe des Termins für den manuellen Lauf eines Papier- oder Hybridvorgangs.
- Was (man. Lauf): Dieses Feld dient zu Eingabe der Beschreibung für den manuellen Lauf eines Papier- oder Hybridvorgangs.
- Manueller Lauf für Papiervorgänge – Historie: Diese Liste zeigt die Historie bzgl. des manuellen Laufes von Papiervorgängen.
- Hinweise zur Berechnung:
- Die Historie wird grundsätzlich beim Speichern des Vorgangs neu berechnet
- Neue Einträge werden immer an erster Stelle hinzugefügt, d.h., unabhängig vom Wert in "Wann (man. Lauf)"
- Die Schlüsseleigenschaft ist einzig und allein "Wer (man. Lauf)", d.h. nur wenn "Wer (man. Lauf)" befüllt ist, wird die Historie erweitert: Wenn sich der Wert in "Wer (man. Lauf)" geändert, hat wird ein neuer Eintrag hinzugefügt, andernfalls (also bei unverändertem "Wer (man. Lauf)"), wird der bestehende (erste) Eintrag bzgl. "Wann (man. Lauf)" und "Was (man. Lauf)" aktualisiert.
- Fortlaufende Nummerierung: Mit Hilfe dieses Feldes kann gesteuert werden, ob in das Geschäftszeichen von Vorgängen im konkreten Akt bzw. von Dokumenten im konkreten Vorgang eine laufende Nummer integriert werden soll oder nicht.
- Hinweise: Hier können Hinweise notiert werden, die sich auf den Vorgang beziehen.

Benutzerhilfe
345

<!-- PDF page 346 -->

Benutzerhilfe
346

# 6.9.2 Registerkarte „Adressaten“

![img-2.jpeg](img-2.jpeg)

Auf der Registerkarte „Adressaten“ stehen folgende Felder zur Verfügung:

- Adressat: In diesem Feld können Verweise auf die Adressaten festgelegt werden.
- Hinweis: Hier definierte Adressaten werden beim Erzeugen einer Erledigung automatisch als Empfänger eingetragen.

# 6.9.3 Registerkarte „Bezüge“

![img-3.jpeg](img-3.jpeg)

Auf der Registerkarte „Bezüge“ stehen folgende Felder zur Verfügung:

- Bezüge zu vorhergehenden Vorgängen/Akten: In dieser Liste besteht die Möglichkeit, auf andere vorangegangene Akten bzw. Vorgänge zu verweisen.
- Hinweis: Wird in dieser Eigenschaft eine Akte bzw. ein Vorgang eingetragen, erfolgt automatisch eine Referenzierung. Siehe hierzu auch 3.2.3 „Bezüge eintragen“.

<!-- PDF page 347 -->

- Bezüge zu nachfolgenden Vorgängen/Akten: In dieser Liste besteht die Möglichkeit, auf andere Akten bzw. Vorgängen zu verweisen.
Hinweis: Wird in dieser Eigenschaft eine Akte bzw. ein Vorgang eingetragen, erfolgt automatisch eine Referenzierung. Siehe hierzu auch 3.2.3 „Bezüge eintragen“.
- Bezüge: In diesem Feld können Verweise auf Akten oder Vorgänge eingefügt werden, die nicht in elektronischer Form vorliegen.

## 6.10 Verteilerlisten

![img-4.jpeg](img-4.jpeg)

Auf der Registerkarte „Verteilerliste“ stehen folgende Felder zur Verfügung:

- Mehrsprachiger Name: In diesem Feld wird der sprachabhängige Name des Objekts definiert.
- Im Laufweg beteiligte Teilnehmer: In diesem Feld werden alle Teilnehmer dieser Verteilerliste definiert.
- Sofort expandieren: Dieses Feld legt fest, ob die Verteilerliste sofort aufgelöst wird oder ob im Vorschreibungseditor die abstrakten Teilnehmer angezeigt werden sollen.
Hinweis: Um sofort überprüfen zu können, ob alle Teilnehmer wie gewünscht aufgelöst wurden, sollte dieses Feld auf „Ja“ gesetzt werden.
- Nur aktive Benutzer berücksichtigen: Dieses Feld legt fest, ob nur aktive Benutzer berücksichtigt werden sollen.
- Standardrolle des Benutzers verwenden, wenn keine Rolle angegeben: Dieses Feld legt fest, ob die Standardrolle des Benutzers verwendet werden soll, wenn im Feld Betroffene Teilnehmer keine Rolle festgelegt wurde.
Hinweis: Die Rolle eines Benutzers setzt sich aus den Werten der Felder Gruppe und Stelle des Benutzerobjekts zusammen.

Benutzerhilfe

<!-- PDF page 348 -->

# 6.11 Organisation

## 6.11.1 Registerkarte „Organisation"

![img-5.jpeg](img-5.jpeg)

Auf der Registerkarte „Organisation“ stehen folgende Metadaten zur Verfügung:

- Kontaktraum: Zugeordneter Kontaktraum der Organisation.
- Name (vollständig): In diesem Feld kann der vollständige Name der Organisation angegeben werden.
- Kurzname: In diesem Feld kann der Kurzname der Organisation angegeben werden.
- Nachgestellter Titel: In diesem Feld kann ein nachgestellter Titel eines Adressaten angegeben werden. Wird beim Adressaten Feld ein Adressat eingetragen, dann wird dieses Feld mit den Daten desausgewählten Adressaten überschrieben.
- Personen: In diesem Feld können die Angestellten der Organisation definiert werden. Wenn eine Person eingetragen wird, wird die Eigenschaft Organisation der ausgewählten Person automatisch mit der richtigen Organisation befüllt.

Benutzerhilfe

<!-- PDF page 349 -->

Benutzerhilfe
349

# 6.11.2 Registerkarte „Kontakt“

![img-6.jpeg](img-6.jpeg)

Auf der Registerkarte „Kontakt“ stehen Ihnen folgende Metadaten zur Verfügung:

- Adresse: In diesem Feld können Adressen des Kontakts (Person oder Organisation) angegeben werden.
- E-Mail-Adressen: In diesem Feld können E-Mail-Adressen angegeben werden.
- Telefonnummern: In diesem Feld können die Telefonnummern eines Kontakts (Person oder Organisation) angegeben werden. Jeder Telefonnummer kann ein Typ und eine Beschreibung zugeordnet werden. Bei Verwendung von Adressatenlisten dient dieser Typ zum Filtern der Telefonnummern.
- Websites: In diesem Feld können Adressen zu einer oder mehreren Websites angegeben werden.
- Besuchszeiten: Dieses Feld dient zur Hinterlegung von Informationen zu den Besuchszeiten der Organisation (bzw. auch der zugehörigen Organisationseinheit)
- Verkehrsanbindung: Dieses Feld dient zur Hinterlegung von Informationen zur Verkehrsanbindung der Organisation (bzw. auch der zugehörigen Organisationseinheit).
- Dienstgebäude: Dieses Feld dient zur Hinterlegung von Informationen zum Dienstgebäude der Organisation/Person (bzw. auch der zugehörigen Organisationseinheit/des zugehörigen Benutzers)

<!-- PDF page 350 -->

Benutzerhilfe
350

# 6.11.3 Registerkarte „Erweitert“

![img-7.jpeg](img-7.jpeg)

Auf der Registerkarte „Erweitert“ stehen folgende Metadaten zur Verfügung:

- Optionale Adressangaben: In diesem Feld werden dokumentbezogene Hinweise für einen Adressaten erfasst.
- Zusatz 1-5: Es gibt Anwendungsfälle, bei denen die vordefinierten Serienbrieffelder bei Erledigungen nicht ausreichen. Je nach Fachbereich gibt es da unterschiedliche Anforderungen. Damit nicht extra für die einzelnen Fälle spezifische Serienbrieffelder definiert werden müssen, wurde das Adressatenaggregat der Geschäftsobjekte bzw. die Formulare der Objektklassen Person und Organisation um 5 zusätzliche Felder erweitert. Der Name der Felder ist mit Zusatz [inkrementelle Nummer von 1 bis 5] so generisch wie möglich gehalten und kann deshalb für sämtliche Fachbereiche verwendet werden. Die Felder sind Zeichenketteneigenschaften. Bei der Adressateninitialisierung werden die hinterlegten Werte dann ebenfalls berücksichtigt.

<!-- PDF page 351 -->

# 6.12 Person

## 6.12.1 Registerkarte „Person“

![img-8.jpeg](img-8.jpeg)

Auf der Registerkarte „Person“ stehen folgende Metadaten zur Verfügung:

- Amts-/Dienstbezeichnung: Die Eigenschaft Amts-/Dienstbezeichnung ermöglicht die Auswahl einer Amts-/Dienstbezeichnung aus einer standardisiert zur Verfügung stehenden Auswahlliste. Die für diese Eigenschaft zur Verfügung stehenden Werte werden zentral administriert.
- Titel: In diesem Feld kann der Titel der Person gespeichert werden.
- Vorname: In diesem Feld kann der Vorname des Benutzers gespeichert werden.
- Nachname: In dieses Feld muss der Nachname des Benutzers gespeichert werden.
- Funktionsbezeichnung: Die Eigenschaft Funktionsbezeichnung dient zur Hinterlegung einer Funktionsbezeichnung beispielsweise zur Verwendung in Erledigungen (Serienbriefen).
- Geschlecht: In diesem Feld kann das Geschlecht der Person angegeben werden.
- Geboren am: In diesem Feld kann das Geburtsdatum der Person angegeben werden.
- Geboren in: Der Geburtsort der Person.
- Organisation: In diesem Feld können Organisationen der Person zugeordnet werden. Wenn eine Organisation eingetragen wird, wird die Person automatisch in die Eigenschaft Personen der ausgewählten Organisation eingetragen.

Benutzerhilfe

<!-- PDF page 352 -->

# 6.12.2 Registerkarte „Kontakt“

![img-9.jpeg](img-9.jpeg)

Auf der Registerkarte „Kontakt“ stehen folgende Metadaten zur Verfügung:

- Adresse: In diesem Feld können Adressen des Kontakts (Person oder Organisation) angegeben werden.
- E-Mail-Adressen: In diesem Feld können E-Mail-Adressen angegeben werden.
- Telefonnummern: In diesem Feld können die Telefonnummern eines Kontakts (Person oder Organisation) angegeben werden. Jeder Telefonnummer kann ein Typ und eine Beschreibung zugeordnet werden. Bei Verwendung von Adressatenlisten dient dieser Typ zum Filtern der Telefonnummern.
- Websites: In diesem Feld können Adressen zu einer oder mehreren Websites angegeben werden.
- Zimmernummer: Dieses Feld dient zur Hinterlegung einer Zimmernummer der Person (bzw. auch des zugehörigen Benutzers).
- Dienstgebäude: Dieses Feld dient zur Hinterlegung von Informationen zum Dienstgebäude der Organisation/Person (bzw. auch der zugehörigen Organisationseinheit/des zugehörigen Benutzers)

Benutzerhilfe

<!-- PDF page 353 -->

Benutzerhilfe
353

# 6.12.3 Registerkarte „Erweitert“

[tbl-1.md](tbl-1.md)

Auf der Registerkarte „Erweitert“ stehen folgende Metadaten zur Verfügung:

- Optionale Adressangaben: In diesem Feld werden dokumentbezogene Hinweise für einen Adressaten erfasst.
- Zusatz 1-5: Es gibt Anwendungsfälle, bei denen die vordefinierten Serienbrieffelder bei Erledigungen nicht ausreichen. Je nach Fachbereich gibt es da unterschiedliche Anforderungen. Damit nicht extra für die einzelnen Fälle spezifische Serienbrieffelder definiert werden müssen, wurde das Adressatenaggregat der Geschäftsobjekte bzw. die Formulare der Objektklassen Person und Organisation um 5 zusätzliche Felder erweitert. Der Name der Felder ist mit Zusatz [inkrementelle Nummer von 1 bis 5] so generisch wie möglich gehalten und kann deshalb für sämtliche Fachbereiche verwendet werden. Die Felder sind Zeichenketteneigenschaften. Bei der Adressateninitialisierung werden die hinterlegten Werte dann ebenfalls berücksichtigt.

<!-- PDF page 354 -->

# 6.13 Verteiler

![img-10.jpeg](img-10.jpeg)

Auf der Registerkarte „Verteiler“ stehen folgende Metadaten zur Verfügung:

- Kontaktraum: Zugeordneter Kontaktraum des Adressaten.
- Name: In diesem Feld werden der Name bzw. die Bezeichnung für das Objekt angegeben. Beim Erzeugen eines Objekts wird dieses Feld mit dem Text "Neufassung von Objektklasse" befüllt.
- Kurzbezeichnung: In diesem Feld können Anmerkungen, Stichworte und sonstige Aussagen über das Objekt gemacht werden.
- Adressaten: In diesem Feld werden die Adressaten (Organisationen, Verteiler und Personen) für die Reinschrift des Dokuments angegeben.

Benutzerhilfe

<!-- PDF page 355 -->

# 6.14 Schlagwort

![img-11.jpeg](img-11.jpeg)

Auf der Registerkarte „Schlagwort“ stehen folgende Metadaten zur Verfügung:

- Name: In diesem Feld wird der Name des Objekts definiert.
- Unterbegriffe: Beinhaltet die zu diesem Schlagwort gehörenden Unterbegriffe.
- Hinweis: Das aktuell geöffnete Schlagwort ist automatisch bei den eingetragenen Unterbegriffen als Oberbegriff eingetragen.
- Oberbegriffe: Beinhaltet die zu diesem Vorgang definierten Oberbegriffe.
- Hinweis: Das aktuell geöffnete Schlagwort ist automatisch bei den eingetragenen Oberbegriffen als Unterbegriff eingetragen.
- Synonyme: Hier können Synonyme zu dem Schlagwort eingetragen werden.
- Hinweis: Das aktuell geöffnete Schlagwort ist automatisch bei den eingetragenen Synonymen als Synonym eingetragen.
- Bevorzugtes Synonym: In diesem Feld kann das bevorzugte Synonym eingetragen werden
- Zusammenhang zu: Dieses Schlagwort besitzt zusätzliche Verknüpfungen zu Schlagworten, ohne gegenseitige Referenzierung.
- Ergänzende Hinweise: Hier können ergänzende Informationen zu dem Schlagwort eingetragen werden.

Benutzerhilfe

<!-- PDF page 356 -->

# 6.15 Dokumenttyp

## 6.15.1 Registerkarte „Dokumenttyp“

![img-12.jpeg](img-12.jpeg)

Auf der Registerkarte „Dokumenttyp“ stehen Ihnen folgende Metadaten zur Verfügung:

- Kurzbzeichnung: Die Kurzbezeichnung definiert den Namen des Dokumenttyps.
- Organisationseinheit: In diesem Feld wird die zuständige Organisationseinheit eingetragen.
- Musterdokumente: In diesem Feld werden alle diesem Dokumenttyp zugeordneten Musterdokumente angegeben. Diese Musterdokumente stehen für Dokumente dieses Dokumenttyps als Vorlagen zur Verfügung.
- Textbausteine: Bei der Bearbeitung eines Dokuments in Microsoft Office Word können vordefinierte Textbausteine eingefügt werden.
- Hinweis: Zum Einfügen von Textbausteinen müssen zuvor die entsprechenden Microsoft Office Word-Schaltflächen installiert werden.
- Beschreibung: Text, der den Dokumenttyp beschreibt bzw. erläutert.
- Sub-Dokumenttyp: In diesem Feld können Dokumenttypen angegeben werden, die dem Dokumenttyp untergeordnet werden. Dadurch kann eine Dokumenttyp-Hierarchie gebildet werden.

Benutzerhilfe

<!-- PDF page 357 -->

Benutzerhilfe
357

# 6.15.2 Registerkarte „Regeln"

[tbl-2.md](tbl-2.md)

Auf der Registerkarte „Regeln“ stehen Ihnen folgende Metadaten zur Verfügung:

- Prozesse kopieren: Dieses Feld bestimmt, ob beim Kopieren von Geschäftsobjekten, die diesem Aktenplaneintrag/Dokumenttyp zugeordnet sind, auch die Prozesse mitkopiert werden.

# 6.15.3 Registerkarte „Versandoptionen“

[tbl-3.md](tbl-3.md)

Auf der Registerkarte „Versandoptionen“ stehen Ihnen folgende Metadaten zur Verfügung:

- Konvertieren in das finale Format während der Finalisierung: Das Setzen dieser Eigenschaft bewirkt, dass bereits beim Erzeugen der Reinschrift Schriftstücke in das finale Format konvertiert werden.
- Finalisieren als: Format welches beim Erzeugen der Reinschrift verwendet werden soll.

<!-- PDF page 358 -->

Benutzerhilfe
358

# 6.16 Benutzer

## 6.16.1 Registerkarte „Benutzer"

[tbl-4.md](tbl-4.md)

<!-- PDF page 359 -->

Folgende wichtige Metadaten stehen Ihnen auf der Registerkarte „Benutzer“ zur Verfügung:

- Aktiv: Legt fest, ob sich der Benutzer anmelden kann.
- Log-in-Name: Muss den Login-Pfad des Benutzers in der Windows-Umgebung beinhalten. Mit dem hier festgelegten Log-In-Namen meldet sich der Benutzer künftig in der Fabasoft eGov-Suite Bayern an.
- Titel/Vorname/Nachname: Persönliche Daten des Benutzers. Der Objektname des Benutzers setzt sich aus Nachnamen, Vornamen und Titel zusammen.
- Nachgestellter Titel: Definiert den Titel der Person, der nachgestellt angeführt wird (z. B. "Bakk.").
- Mitglied von: Die Organisationseinheit, welcher der Benutzer angehört. Über die Such-Möglichkeit bei dieser Eigenschaft kann man nach bereits bestehenden Organisationseinheiten suchen und anschließend zur Liste hinzufügen.
- Rollen: In dieser Tabelle werden sämtliche für den Benutzer verfügbare Rollen definiert.
Hinweis: Wenn ein Mandant ausgewählt wird, so wird diese Rolle nur in diesem Mandanten berücksichtigt.
Wenn mehrere Standardrollen definiert sind, so wird die erste passende Rolle verwendet.
- Mandanten: Die Mandanten, in denen der Benutzer arbeitet bzw. zwischen denen er wechseln kann. Es ist die Angabe eines Standard-Mandanten möglich. Werden mehrere Mandanten hinterlegt, so wird der als Standard verwendet, der mit Standard-Mandant gekennzeichnet ist.
- Stellvertretungen: In dieser Eigenschaft ist das Benutzerstellvertretungsobjekt des Benutzers hinterlegt.
- Stellenzeichen: In dieser Eigenschaft kann ein Stellenzeichen für den Benutzer definiert werden, welches auch in den Objektnamen mit übernommen wird. Dadurch kann bei der Schnellsuche nach einem Benutzer auch nach dem Stellenzeichen gesucht werden.
- Person: In dieser Eigenschaft können Sie durch Auswahl aus dem Drop-down-Menü oder durch Suche das Personen-Objekt eintragen, welches die persönlichen Daten des Benutzers (z. B. Adresse, E-Mail Adresse, etc.) beinhaltet.
Hinweis: Der Benutzername und der Name des Personenobjekts werden gegenseitig aktualisiert. Sollte es notwendig sein, dass ein Benutzer als Adressat verwendet werden kann, dann ist die Angabe eines Personen-Objektes beim Benutzer notwendig (z. B. wenn ein Versand mit der Versandart „Intern“ an einen anderen Fabasoft eGov-Suite Bayern Benutzer verschickt wird).
- Autorisierte Arbeitsplätze: In dieser Liste können Arbeitsplatzobjekte festgelegt werden, an denen der Benutzer arbeiten darf. Ein Login über einen anderen Arbeitsplatz wäre somit nicht möglich.
- Vorlagensammlungen: Vorher am Schreibtisch erstellte Vorlagensammlungen oder durch Klick auf „Neu“ erzeugte Vorlagensammlungen können hier für diesen Benutzer hinterlegt werden. Dabei ist darauf zu achten, dass die Vorlagensammlung mindestens einer Kategorie zugeordnet ist.
- Führt Aktivitäten im Hintergrund aus: Um Benutzern (welche für ein Fabasoft Components/AT Service verwendet werden) das Ausführen von Hintergrundaktivitäten zu ermöglichen, muss dieses Feld auf „Ja“ gesetzt werden.

Benutzerhilfe
359

<!-- PDF page 360 -->

- Darf Versionen löschen: Um Benutzern das Löschen von Versionen zu ermöglichen, muss dieses Häkchen gesetzt werden.

## 6.16.2 Registerkarte „Umgebungen“

![img-13.jpeg](img-13.jpeg)

Auf der Registerkarte „Umgebungen“ stehen Ihnen folgende Metadaten zur Verfügung:

- Umgebungen: Liste der Umgebungen, die für den Benutzer erzeugt und diesem zugeordnet wurden.
Hinweis: Jeder Benutzer benötigt mindestens eine Arbeitsumgebung. Ist eine Vorlage für eine Umgebung definiert, wird automatisch eine Arbeitsumgebung initialisiert, sollte keine eingetragen sein.

- Standardvorlage für Umgebungen: Hier kann eine der Standard-Vorlagen ausgewählt werden. Beim ersten Anmelden wird automatisch anhand dieser Vorlage eine individuelle Arbeitsumgebung für Benutzer erzeugt.

- Vorlage für Umgebung pro Mandant: Wenn der Benutzer in mehreren Mandanten mit verschiedenen Arbeitsumgebungen arbeiten soll, kann hier pro Mandant jeweils eine eigene Vorlage angegeben werden.

- Automatisch lokale Umgebung erzeugen: Dieses Kennzeichen muss auf „Ja“ gesetzt sein, damit die Arbeitsumgebung automatisch erzeugt wird. Dabei wird die Arbeitsumgebung jedoch in dem Mandanten erzeugt, in dem auch das Benutzerobjekt angelegt wurde.

- Automatisch Umgebung in Mandant erzeugen: Dieses Kennzeichen muss auf „Ja“ gesetzt sein, damit die Arbeitsumgebung für den Benutzer im jeweiligen Mandanten erzeugt wird, dem der Benutzer zugeordnet wurde. Andernfalls muss dies manuell nachgeholt werden.

Benutzerhilfe
360

<!-- PDF page 361 -->

# 6.17 Benutzerstellvertretung

Benutzerstellvertretung - Regina Kainz (Benutzerstellvertretung) Bearbeiten

![img-14.jpeg](img-14.jpeg)

Auf der Registerkarte „Benutzerstellvertretung“ stehen folgende Metadaten zur Verfügung:

- Benutzer: Legt fest, welcher Benutzer vertreten wird.
- Rollen mit Stellvertreter: Legt fest, welche Stelle in welcher Organisationseinheit von welchem Benutzer vertreten werden soll.

**Hinweis:** Im Feld Rollen mit Stellvertreter können pro Eintrag weitere Eigenschaften definiert werden. Für die erweiterte Sicht klicken Sie bitte auf „Details anzeigen“ in Feld „Rollen mit Stellvertreter“.

Benutzerhilfe

<!-- PDF page 362 -->

Benutzerstellvertretung - Regina Kainz (Benutzerstellvertretung) Bearbeiten

Rolle

A

Rollen mit Stellvertreter (1 von 1)
![img-0.jpeg](img-0.jpeg)
- Stelle: Definiert die Stelle der Rolle des Benutzers, in welcher er vertreten werden soll.
- Organisationeinheit: Definiert die Gruppe der Rolle des Benutzers, in welcher er vertreten werden soll.
- Stellvertreter: Definiert den Benutzer, welcher die Stellvertreter durchführt.
- Start: Legt fest, ab wann die Vertretung beginnt.
- Ende: Legt fest, bis wann die Vertretung endet.
- Vertretungshinweis: Legt eine Bemerkung zur Stellvertretung fest. Diese wird dem Stellvertreter bei der Auswahl der Stellvertreterrolle angezeigt.
- Benutzerbezogene Vertretung: Legt fest, ob der Stellvertreter bereits begonnene Aktivitäten mit übernehmen soll. Wenn dies der Fall sein soll, so muss hierfür „Ja“ ausgewählt werden. Sollen nur neue Aktivitäten von der Stellvertretung betroffen sein, so muss „Nein“ ausgewählt werden.
- Für den Stellvertreter nicht gestattet: Legt fest, welcher Benutzer welchen Restriktionen in der Rolle des Stellvertreters unterliegt.
- Symbol: Definiert das Symbol, das bei der Rollenauswahl angezeigt wird.

Benutzerhilfe

<!-- PDF page 363 -->

# 6.18 Arbeitsumgebung (Administrative Sicht)

[tbl-0.md](tbl-0.md)

Auf der Registerkarte „Benutzereinstellungen“ stehen dem Administrator (der Endbenutzer sieht nur einen Bruchteil davon) folgende Metadaten zur Verfügung:

Benutzerhilfe

<!-- PDF page 364 -->

- Menüleiste anzeigen: Legt fest, ob die Menüleiste angezeigt wird.
- Ausstiegsbestätigung anzeigen: Wird dieses Feld auf "Ja" gesetzt, erfolgt eine Sicherheitsabfrage beim Beenden des Clients durch Schließen des Webbrowsers. Siehe auch Kapitel 1.2 „Beenden des Fabasoft eGov-Suite Bayern Webbrowser-Clients".
- Verfügbare Elemente auf Home: Definiert welche Widgets am Homescreen angezeigt werden
- Auswahl der Objektklasse beim Erfassen: Ist das Feld auf „Ja“ gesetzt, erscheint beim Erfassen ein Objektklassenauswahl Dialog (Eingangsdokument, Erledigung und internes Dokument stehen zur Auswahl). Ist das Feld auf „Nein“ gesetzt, wird ein Objekt jener Objektklasse automatisch angelegt, die in der Domäne eingestellt ist.
- Erzeugen Formular sichtbar beim direkten Import in einen Vorgang: Mit dieser Eigenschaft kann bestimmt werden, ob beim direkten Import eines Schriftstücks in einen Vorgang ein Formular zum Erzeugen des Dokuments angezeigt werden soll.
- Erfassungsmodus: Legt fest, ob immer eine Einzelerfassung oder eine Sammelerfassung durchgeführt werden soll, oder ob bei jedem Erfassung gefragt werden soll.
- Suchmuster: In diesem Feld können vordefinierte Suchmuster hinterlegt werden.
- Voreinstellungen im Workflow: Mit diesem hinterlegten Objekt können verschiedene Auswahllisten im Workflow beeinflusst werden, wie etwa Benutzer, Organisationseinheiten und Verteilerlisten beim Weiterleiten und Verfügen. Ebenso können die bereits gespeicherten Verfügungen eingesehen und bearbeitet werden.
- Nur Aktivitäten für aktuelle Rolle: Standardmäßig erhält ein Benutzer im Arbeitsvorrat alle Aktivitäten, die entweder persönlich (d.h. mit Benutzerinformation) an ihn gerichtet sind oder die eine zu einer beliebigen Rolle des Benutzers passende Teilnehmerinformation (d.h. nur Rollenangabe ohne Benutzerinformation) beinhalten. Wird dieses Feld auf „Ja“ gesetzt, werden zusätzlich zu den persönlichen Aktivitäten nur mehr Aktivitäten angezeigt, deren Teilnehmerinformation mit der aktuellen Rolle des Benutzers übereinstimmen.
- Benachrichtigungen im Workflow: Mithilfe dieses Feldes kann die automatische Benachrichtigung über diverse Ereignisse im Workflow beeinflusst werden.
- Vorlagensammlungen: In dieser Liste können Vorlagensammlungen hinterlegt werden, welche beim Erzeugen von neuen Objekten zur Verfügung stehen sollen.
- Benutzerliste für Verfügungen: In diesem Feld können Benutzer vordefiniert werden, die im Aktivitäten-Kontextmenüeintrag „Verfügen an“ erscheinen sollen.
- Hinweise zu Objekten anzeigen: Dieses Feld bestimmt, ob Hinweise zu Objekten in Form von Tooltips angezeigt werden.
- Annotationssoftware: In diesem Feld kann eingestellt werden, welche Software zum Annotieren verwendet werden soll. Wenn der Wert „Browser“ hinterlegt ist, wird die Annotation Software der Fabasoft eGov-Suite verwendet.
- Standardfarbe für Annotationen: Standardfarbe für die Annotationen bei Verwendung der eGov-Suite Annotation Software.
- Stempel: Hier können neue Stempel erzeugt werden, welche dem Benutzer dann in der eGov-Suite Annotation Software zur Verfügung stehen.
- Absenderzeile bei Eingangsdokumenten vorinitialisieren: Wenn das Feld aktiviert ist, wird beim Erzeugen eines Eingangsdokuments, das Absenderaggregat mit einer leeren Zeile

Benutzerhilfe
364

<!-- PDF page 365 -->

vorinitialisiert. Beim Erfassen von E-Mails hat die Eigenschaft keine Auswirkung auf die Initialisierung der Absender.

- Aktivitäten auf Objekten ohne Zugriff ausblenden: Wenn das Feld aktiviert ist, werden alle Aktivitäten im Arbeitsvorrat auf der Registerkarte "Zuletzt beendet" ausgeblendet, auf deren Prozessobjekte kein Lesezugriff besteht.
- Vorgänge mit aktiven Umlaufmappen ausblenden: Wenn das Feld aktiviert ist, werden alle Aktivitäten im Arbeitsvorrat auf der Registerkarte "Zu tun" ausgeblendet, die als Prozessobjekt einen Vorgang mit aktiven Umlaufmappen (=der Status der Umlaufmappe ist "In Bearbeitung") besitzen.
- Kontakträume: Beinhaltet die Kontakträume, welche in der Adressatenverwaltung angezeigt werden sollen.
- Standard Kontakträum: Kontakträum, welcher bei der Adressaten Erstellung voreingestellt wird. Hinweis: Der Kontakträum wird nur dann voreingestellt, wenn der Benutzer Änderungsrechte auf den Kontakträum besitzt.

## 6.19 Organisationseinheit

![img-1.jpeg](img-1.jpeg)

Auf der Registerkarte „Aufbauorganisation“ stehen folgende Metadaten zur Verfügung:

- Aktiv: In diesem Feld wird festgelegt, ob die Organisationseinheit aktiv ist.
- Organisationskennzeichen: In diesem Feld kann die Kurzbezeichnung der Organisationseinheit definiert werden.

Benutzerhilfe

<!-- PDF page 366 -->

- Bezeichnung: In diesem Feld wird die (vollständige) Bezeichnung der Organisationseinheit definiert.
- Behörde: In diesem Feld ist die zugehörige Behörde (Mandant) hinterlegt.
- Organisationskennzeichen zur GZ-Bildung: Wenn dieses Feld der Organisationseinheit der aktuellen Rolle befüllt ist, wird dieser Wert als Initialisierungswert bei neu erzeugten Erledigungen in der Eigenschaft "Zuständige OE" verwendet. Ansonsten wird die Organisationseinheit der aktuellen Rolle selbst als Initialisierungswert verwendet.
- Struktureinheit: In diesem Feld können der Gruppe Struktureinheiten zugewiesen werden, um eine Beziehung zwischen abstrakter und konkreter Organisation herstellen zu können.
- Übergeordnete Organisationseinheiten: In diesem Feld können übergeordnete Organisationseinheiten hinterlegt werden, um Hierarchien von Organisationseinheiten abbilden zu können.
- Untergeordnete Organisationseinheiten: In diesem Feld können untergeordnete Organisationseinheiten hinterlegt werden, um Hierarchien von Organisationseinheiten abbilden zu können.

Hinweis: Eine untergeordnete Organisationseinheit enthält gleichzeitig die aktuelle Organisationseinheit als übergeordnete Organisationseinheit.

Hinweis: Eine übergeordnete Organisationseinheit enthält gleichzeitig die aktuelle Organisationseinheit als untergeordnete Organisationseinheit.

## 6.20 Globaler Papierkorb

![img-2.jpeg](img-2.jpeg)

Auf der Registerkarte „Globaler Papierkorb“ stehen folgende Metadaten zur Verfügung:

- Aktiv: In diesem Feld kann eingestellt werden, ob der globale Papierkorb verwendet werden soll.

Benutzerhilfe

<!-- PDF page 367 -->

- Bestätigungsdialog anzeigen: In diesem Feld kann angegeben werden, ob eine Bestätigung für das Löschen eines Objekts erforderlich ist.
- Aufbewahrungszeitraum: In diesem Feld wird der Aufbewahrungszeitraum für gelöschte Objekte angegeben.
- ACL für Objekte im Globalen Papierkorb: In diesem Feld wird das ACL-Objekt (ACL) angegeben, mit dem die Objekte im globalen Papierkorb geschützt sind.
- ACL für Objekte, die aus dem globalen Papierkorb wiederhergestellt werden: In diesem Feld wird das ACL-Objekt (ACL) angegeben, mit dem die Objekte geschützt sind, die aus dem globalen Papierkorb wiederhergestellt wurden.
- Benutzerordner: In diesem Feld werden benutzerspezifische Ordner für gelöschte Objekte angezeigt.

Benutzerhilfe
367

<!-- PDF page 368 -->

# 6.21 Feiertagstabelle

![img-3.jpeg](img-3.jpeg)

Auf der Registerkarte „Feiertagstabelle“ stehen folgende Metadaten zur Verfügung:

- Keine Werktage: Jene Wochentage, welche nicht zur Arbeitswoche gehören, werden hier festgelegt.
- Feiertage: In dieser Liste können alle zu berücksichtigenden Feiertage erzeugt und hinterlegt werden.
- Zeitspannen: Alle verwendbaren Zeitspannen können in dieser Liste erzeugt und hinterlegt werden.

Benutzerhilfe

<!-- PDF page 369 -->

Benutzerhilfe
369

# 6.22 Feiertage

[tbl-1.md](tbl-1.md)

Auf der Registerkarte „Feiertag“ stehen folgende Metadaten zur Verfügung:

- Datum: Dieses Feld muss das Datum des Feiertags enthalten.
- Beschreibung: In dieser Eigenschaft kann eine (sprachabhängige) Bezeichnung des Feiertags (z.B. "Neujahr 2008") definiert werden.

# 6.23 Zeitspanne

[tbl-2.md](tbl-2.md)

Auf der Registerkarte „Zeitspanne“ stehen folgende Metadaten zur Verfügung:

<!-- PDF page 370 -->

- Mehrsprachiger Name: In diesem Feld wird der sprachabhängige Name des Objekts definiert.
- Zeitspanne: Dieses Feld erwartet eine natürliche Zahl als Eingabe. Zusammen mit der Eigenschaft Einheit wird damit die grundsätzliche Länge der Zeitspanne definiert.
- Einheit: In diesem Feld stehen die Einheiten "Sekunde", "Minute", "Stunde", "Tag", "Woche", "Monat" und "Jahr" zur Auswahl. Zusammen mit der Eigenschaft Zeitspanne wird damit die grundsätzliche Länge der Zeitspanne definiert.
- Auf Einheit runden: Um zu erreichen, dass aus dieser Zeitspanne berechnete Zeitpunkte weiter gerundet werden, kann in diesem Feld die gewünschte Einheit ("Sekunde", "Minute", "Stunde", "Tag", "Woche", "Monat" und "Jahr") definiert werden. Zusammen mit Eigenschaft Rundung wird die Berechnung des gerundeten Zeitpunkts definiert.
- Rundung: Um zu erreichen, dass aus dieser Zeitspanne berechnete Zeitpunkte weiter gerundet werden, kann in diesem Feld die Art der Rundung ("Normal", "Immer abrunden" und "Immer aufrunden") definiert werden. Zusammen mit Eigenschaft Auf Einheit runden wird die Berechnung des gerundeten Zeitpunkts definiert.
- Nächsten Werktag verwenden: Standardmäßig werden arbeitsfreie Tage und Feiertage bei der Berechnung eines Zeitpunkts aus einer Zeitspanne nicht berücksichtigt. Soll an Stelle eines berechneten arbeitsfreien Tags automatisch der nächste folgende Werktag verwendet werden, kann dieses Feld auf "Ja" gesetzt werden.

## 6.24 Amts-/Dienstbezeichnung

![img-4.jpeg](img-4.jpeg)

Auf der Registerkarte „Amts-/Dienstbezeichnung“ stehen folgende Metadaten zur Verfügung:

- Mehrsprachiger Name: In diesem Feld wird der (sprachabhängige) Name definiert.
- Kurzform: In diesem Feld kann eine Kurzform der Amts-/Dienstbezeichnung eingegeben werden.

Benutzerhilfe

<!-- PDF page 371 -->

# 6.25 Softwarekomponente

[tbl-3.md](tbl-3.md)

Auf der Registerkarte „Softwarekomponente“ stehen folgende Metadaten zur Verfügung:

- **Referenz**: In diesem Feld muss eine (im Mandanten) eindeutige Referenz für die Softwarekomponente vergeben werden. In der Regel besteht diese ausschließlich aus Großbuchstaben.
- **Versionsnummer**: In diesem Feld muss eine Versionsnummer für die Softwarekomponente definiert werden.
- **Name**: In diesem Feld muss der Objektname für die Softwarekomponente definiert werden.

Benutzerhilfe

<!-- PDF page 372 -->

- Zustand: Neu erzeugte Softwarekomponenten befinden sich standardmäßig im Zustand „In Entwicklung“. Nur in diesem Zustand kann die Softwarekomponente zum Erzeugen neuer Komponentenobjekte verwendet werden. Installierte Softwarekomponenten besitzen den Zustand „Installiert“ oder (falls sie gelöscht wurden) „Gelöscht“.
- Copyright: Dieses Feld erfordert die Eingabe von Copyright-Informationen.
- Vorausgesetzte Komponenten: Werden Komponentenobjekte mit dieser lokalen Softwarekomponente erzeugt, die Verweise auf andere Softwarekomponenten benötigen, sind diese anderen Softwarekomponenten in die Liste Vorausgesetzte Komponenten einzutragen. Wird dies nicht gemacht oder vergessen, können zwar die Komponentenobjekte angelegt werden, beim nächsten Update der Domäne gehen aber alle diese Objekte verloren bzw. werden beim Extrahieren aus der Domäne ignoriert.

Beispiel: Um eine Amts-/Dienstbezeichnung korrekt zu erzeugen, muss die Softwarekomponente COOELAK@1.1001 als vorausgesetzt definiert werden, da die Objektklasse „Amts-/Dienstbezeichnung“ zu dieser Softwarekomponente gehört. Man kann mit Softwarekomponenten nicht nur neue (eigene) Komponentenobjekte erzeugen, sondern auch andere Komponentenobjekte verändern, d.h. erweitern. Analog gilt, dass Erweiterungen nur dann ein Update der Domäne überstehen, wenn die entsprechende Softwarekomponente des erweiterten Komponentenobjektes als vorausgesetzt definiert ist.

Beispiel: Um in der MAPI-Konfiguration die „Konfiguration für das Versenden“ Update sicher zu definieren, muss die verwendete Softwarekomponente COOMAPI@1.1 voraussetzen.

Benutzerhilfe
372

<!-- PDF page 373 -->

Benutzerhilfe
373

# 6.26 Zugriffsdefinition

Aktengebunden (Zugriffsdefinition): Lesen

Name ☐ X

Zugriffsdefinition

Komponentenobjekt

Objekt

Versionen

Sicherheit

Archiv

Workflow

Unterschriften

Komponentenobjekt (Erweitert)

Mehrsprachiger Name
Aktengebunden

[tbl-4.md](tbl-4.md)
[tbl-5.md](tbl-5.md)
[tbl-6.md](tbl-6.md)

Auf der Registerkarte „Zugriffsdefinition“ stehen folgende Metadaten zur Verfügung:

- Mehrsprachiger Name: Name der Zugriffsdefinition.
- ACL Konfiguration: In dieser zusammengesetzten Eigenschaft wird die ACL für den jeweiligen Dokumentstatus definiert. Zusätzlich wird die ACL des jeweiligen Status des verbindlich gesetzten Objekts definiert.
- Detaillierte ACL Konfiguration für „In Bearbeitung“: In diesem Feld kann eine spezielle Definition für den Status In Bearbeitung eingetragen werden.
- Erlaubte Klassen: In diesem Feld werden die Objektklassen eingetragen, für die die Zugriffsdefinition verwendet werden kann.

<!-- PDF page 374 -->

Benutzerhilfe
374

# 7 Aktivitäten

## 7.1 Die Aktivität Eingang

Die Aktivität Eingang wird automatisch an die Person verfügt, die in den Metadaten eines neu erzeugten Eingangsdokuments im Feld Federführung eingetragen wurde.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

[tbl-7.md](tbl-7.md)

## 7.2 Die Aktivität Intern

Die Aktivität Intern wird automatisch an die Person verfügt, die in den Metadaten eines neu erzeugten internen Dokuments im Feld Federführung eingetragen wurde.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

[tbl-8.md](tbl-8.md)

## 7.3 Die Aktivität Ausgang

Die Aktivität Ausgang wird automatisch an die Person verfügt, die in den Metadaten einer neu erzeugten Erledigung im Feld Federführung eingetragen wurde.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

[tbl-9.md](tbl-9.md)

<!-- PDF page 375 -->

Benutzerhilfe
375

# 7.4 Die Aktivität Bearbeitung

Die Aktivität Bearbeitung wird automatisch an die Person verfügt, die in den Metadaten eines neu erzeugten Vorgangs im Feld Federführung eingetragen wurde.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

Abschließen
| Beendet die Aktivität

# 7.5 Die Aktivität Starten

Die Aktivität Starten wird automatisch an die Person verfügt, welche eine Umlaufmappe erstellt hat. (Federführender der Umlaufmappe ist)

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

Abschließen
| Beendet die Aktivität.

# 7.6 Die Aktivität Prüfen

Die Aktivität Prüfen wird automatisch an den Prozessverantwortlichen verfügt, wenn eine Umlaufmappen Aktivität abgeschlossen wurde. Ausgenommen sind die Aktivitäten Prüfen, Überarbeiten und Abschließen. Weiteres wird die Aktivität nicht verfügt, wenn der Prozessverantwortliche die Aktivität abgeschlossen hat. Der Geschäftsgangvermerk lautet „Laufweg prüfen (Automatische Aktivität)“ bzw. bei erfolgten Zeichnungen „Zeichnungen prüfen (Automatische Aktivität)“.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

Abschließen
| Beendet die Aktivität.

# 7.7 Die Aktivität Überarbeiten

Die Aktivität Überarbeiten wird automatisch an den Prozessverantwortlichen verfügt, wenn eine Zeichnung (Schlusszeichnung) abgelehnt wurde. Der Geschäftsgangvermerk lautet „Zeichnung abgelehnt (Automatische Aktivität)“.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

[tbl-10.md](tbl-10.md)

# 7.8 Die Aktivität Abschließen

Die Aktivität Abschließen kann zum Beenden eines Umlaufmappen Prozesses verwendet werden. Es wird keine automatische Folgeaktivität verfügt.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

Abschließen
| Beendet die Aktivität.

<!-- PDF page 376 -->

Benutzerhilfe
376

# 7.9 Die Aktivität Aufgabe

Die Aktivität Aufgabe kann z.B. verwendet werden, um einen Benutzer die Umlaufmappe zur Kontrolle oder Weiterverarbeitung zuzuteilen.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

Abschließen
Beendet die Aktivität.

# 7.10 Die Aktivität Versenden

Die Aktivität Versenden wird verfügt, um die in einer Umlaufmappe enthaltenen Erledigungen an die jeweils angegebenen Adressaten zu senden.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

Versand durchführen
Führt den Versand einer Erledigung innerhalb der betroffenen Umlaufmappe aus. Wenn mehrere Erledigungen existieren, erscheint ein Auswahldialog.

Versand zeichnen
Wenn finalisierte Dokumente vorhanden sind, kann hier der Versand gezeichnet werden.

# 7.11 Die Aktivität Medienübergang

Die Aktivität Medienübergang wird verfügt, wenn zwischen verschiedenen Medien (z.B. Elektronisch, Papier) gewechselt werden muss.

Folgende Arbeitsschritte stehen innerhalb dieser Aktivität zur Verfügung:

[tbl-11.md](tbl-11.md)

# 7.12 Die Aktivität Reinschrift erstellen

Die Aktivität Reinschrift erstellen wird verfügt, wenn eine Reinschrift einer Erledigung erstellt werden soll.

Diese Aktivität enthält folgende Arbeitsschritte:

<!-- PDF page 377 -->

Benutzerhilfe
377

Reinschrift erstellen | Erzeugt die Reinschrift für eine Erledigung, die ausgewählt werden kann.
Hinweis: Es kann nur eine Erledigung ausgewählt werden. Weitere Informationen im Kapitel 3.3.10.4.1 „Eine Reinschrift erzeugen“.

Erzeugte Reinschriften anzeigen | Durch einen Klick auf diesen Arbeitsschritt können alle erzeugten Reinschriften dieses Vorgangs eingesehen und bearbeitet werden. Weitere Informationen im Kapitel 3.3.10.4.2 „Erzeugte Reinschriften anzeigen“.

Abschließen | Beendet die Aktivität

## 7.13 Die Aktivität Weglegen

Die Aktivität Weglegen wird verfügt, wenn ein Vorgang weggelegt werden soll und mit einer dementsprechenden Zeichnung versehen werden muss.

Diese Aktivität enthält folgende Arbeitsschritte:

Weglegen | Bietet die Möglichkeit, den betroffenen Vorgang wegzulegen und mit einer Zeichnung sowie einer zeichnungsbezogenen Bemerkung zu versehen.

## 7.14 Die Aktivität Zum Akt

Die Aktivität Zum Akt enthält folgende Arbeitsschritte:

Zum Akt | Legt den betroffenen Vorgang Zum Akt.

## 7.15 Die Aktivität Kenntnisnahme (Vorgang)

Die Aktivität Kenntnisnahme enthält folgende Arbeitsschritte:

Kenntnisnahme zeichnen | Zeichnet beim Klick auf den Arbeitsschritt eine oder mehrere Dokumente zur Kenntnisnahme. Nach der Auswahl kann noch eine zeichnungsbezogene Bemerkung angebracht werden.

## 7.16 Die Aktivität Kenntnisnahme (hemmend) (Vorgang)

Die Aktivität Kenntnisnahme (hemmend) enthält folgende Arbeitsschritte:

Kenntnisnahme zeichnen | Zeichnet beim Klick auf den Arbeitsschritt eine oder mehrere Dokumente zur Kenntnisnahme. Nach der Auswahl kann noch eine zeichnungsbezogene Bemerkung angebracht werden.

## 7.17 Die Aktivität Kenntnisnahme (Umlaufmappe)

Die Aktivität Kenntnisnahme enthält folgende Arbeitsschritte:

<!-- PDF page 378 -->

Kenntnisnahme
zeichnen
Zeichnet beim Klick auf den Arbeitsschritt eine oder mehrere Dokumente zur Kenntnisnahme. Nach der Auswahl kann noch eine zeichnungsbezogene Bemerkung angebracht werden.

## 7.18 Die Aktivität Kenntnisnahme (hemmend) (Umlaufmappe)

Die Aktivität Kenntnisnahme (hemmend) enthält folgende Arbeitsschritte:

Kenntnisnahme
zeichnen
Zeichnet beim Klick auf den Arbeitsschritt eine oder mehrere Dokumente zur Kenntnisnahme. Nach der Auswahl kann noch eine zeichnungsbezogene Bemerkung angebracht werden.

## 7.19 Die Aktivität Kenntnisnahme (Dokumente)

Die Aktivität Zur Kenntnisnahme enthält folgende Arbeitsschritte:

Kenntnisnahme
zeichnen
Zeichnet beim Klick auf den Arbeitsschritt das Dokument zur Kenntnisnahme. Nach der Auswahl kann noch eine zeichnungsbezogene Bemerkung angebracht werden.

## 7.20 Die Aktivität Kenntnisnahme (hemmend) (Dokumente)

Die Aktivität Kenntnisnahme (hemmend) enthält folgende Arbeitsschritte:

Kenntnisnahme
zeichnen
Zeichnet beim Klick auf den Arbeitsschritt das Dokument zur Kenntnisnahme. Nach der Auswahl kann noch eine zeichnungsbezogene Bemerkung angebracht werden.

## 7.21 Die Aktivität Billigung

Wenn eine Umlaufmappe bzw. eine Erledigung darin gebilligt werden muss, wird die Aktivität Zur Billigung verfügt.

Diese Aktivität enthält folgende Arbeitsschritte:

[tbl-12.md](tbl-12.md)

## 7.22 Die Aktivität Mitzeichnung

Wenn eine Umlaufmappe bzw. eine Erledigung darin mitgezeichnet werden muss, wird die Aktivität Zur Mitzeichnung verfügt.

Benutzerhilfe
378

<!-- PDF page 379 -->

Diese Aktivität enthält folgende Arbeitsschritte:

[tbl-13.md](tbl-13.md)

## 7.23 Die Aktivität Schlusszeichnung

Wenn gewünscht wird, dass eine Person eine Umlaufmappe bzw. eine oder mehrere Erledigungen schlusszeichnet, wird die Aktivität Zur Schlusszeichnung verfügt.

Diese Aktivität enthält folgende Arbeitsschritte:

[tbl-14.md](tbl-14.md)

## 7.24 Die Aktivität Abgabe

Wenn über das Bewertungsverzeichnis, welches im Rahmen der Aussonderung vom Archiv übermittelt wurde, die Abgabe initiiert wird, wird dem aktuellen Benutzer die Aktivität Abgabe verfügt.

[tbl-15.md](tbl-15.md)

## 7.25 Die Aktivität Interner Eingang

Wenn bei einem Empfänger als Versandart „Intern“ eingetragen ist, wird eine Aktivität Interner Eingang auf einem Versandkuvert erzeugt, welche Kopien der versendeten Schriftstücke

Benutzerhilfe

<!-- PDF page 380 -->

enthält. Als Empfänger sind nur Personen und Organisationen möglich, für welche in der Fabasoft eGov-Suite Bayern ein Benutzer-Objekt existiert und die sich zumindest einmal in der Fabasoft eGov-Suite Bayern angemeldet haben.

[tbl-16.md](tbl-16.md)

# 8 Glossar

Um Ihnen das Arbeiten mit der Fabasoft eGov-Suite Bayern zu erleichtern, ist es notwendig, einige der in dieser Hilfe verwendeten Begriffe zu erläutern.

# A

[tbl-17.md](tbl-17.md)

Benutzerhilfe
380

<!-- PDF page 381 -->

[tbl-18.md](tbl-18.md)

Benutzerhilfe

<!-- PDF page 382 -->

Möchte ein Benutzer auf ein Objekt zugreifen, wird geprüft, welcher Eintrag in der ACL für ihn zutrifft. Ist dieser festgestellt, wird der Zugriff aufgrund der Zugriffsklassen gewährt oder verweigert.

Jedes Objekt ist in einer bestimmten Domäne angelegt worden (Eigenschaft Domäne). Es hat einen Eigentümer und kann auch einer Organisationseinheit zugeordnet werden (Eigenschaften Eigentümer und Organisationseinheit). Diese Eigenschaften können zur Bestimmung des Benutzers eines ACL-Eintrags herangezogen werden.

Die Fabasoft eGov-Suite Bayern unterstützt dafür die folgenden abstrakten Einträge in ACLs:

- Domäne des Eigentümers: trifft zu, wenn der Benutzer der gleichen Domäne angehört wie der Eigentümer des Objekts (bzw. im Mandantenbetrieb, wenn der aktuelle Mandant des Benutzers mit der Domäne des Eigentümerobjekts übereinstimmt).
- Domäne des Objekts: trifft zu, wenn der Benutzer der gleichen Domäne angehört wie das aktuelle Objekt (bzw. im Mandantenbetrieb, wenn der aktuelle Mandant des Benutzers mit der Domäne des Objekts übereinstimmt).
- Organisationseinheit des Objekts: trifft zu, wenn der Benutzer im Kontext der Organisationseinheit arbeitet, die in der Eigenschaft Organisationseinheit referenziert wird.
- Eigentümer des Objekts: trifft zu, wenn der Benutzer auch der Eigentümer des Objekts ist.

Falls mehrere ACL Einträge für einen Benutzer zutreffen (da er z.B. mehreren Organisationseinheiten angehört), wird jener ACL Eintrag herangezogen, der die höchste Bewertung erzielt. Falls mehrere Einträge mit der gleichen Bewertung existieren, werden die Zugriffsklassen der ACL Einträge vereinigt.

Mithilfe aller ACLs für Vorgangsdaten ist ein behördenübergreifender Workflow möglich. Für die Stelle Support ist in allen ACLs bearbeitender Zugriff auf die Objekte einer Behörde möglich.

[tbl-0.md](tbl-0.md)

Benutzerhilfe
382

<!-- PDF page 383 -->

Benutzerhilfe
383

[tbl-1.md](tbl-1.md)

<!-- PDF page 384 -->

Benutzerhilfe
384

[tbl-2.md](tbl-2.md)

<!-- PDF page 385 -->

Benutzerhilfe
385

[tbl-3.md](tbl-3.md)

# B

[tbl-4.md](tbl-4.md)

<!-- PDF page 386 -->

Benutzerhilfe
386

[tbl-5.md](tbl-5.md)
[tbl-6.md](tbl-6.md)
[tbl-7.md](tbl-7.md)

<!-- PDF page 387 -->

Benutzerhilfe
387

[tbl-8.md](tbl-8.md)

<!-- PDF page 388 -->

[tbl-9.md](tbl-9.md)

E

[tbl-10.md](tbl-10.md)

F

[tbl-11.md](tbl-11.md)

Benutzerhilfe

<!-- PDF page 389 -->

Benutzerhilfe
389

oder „Schlagwort“ sein. Der Unterschied ist, dass Fachdaten auf einen bestimmten Datentyp eingeschränkt werden können. Bei Schlagwörtern erfolgt keine Einschränkung.

[tbl-12.md](tbl-12.md)

G

[tbl-13.md](tbl-13.md)

K

[tbl-14.md](tbl-14.md)

<!-- PDF page 390 -->

können somit häufig benötigte Funktionen angewählt werden. Dadurch ist es möglich Aktionen rascher auszuführen.

Das Öffnen eines Kontextmenüs erfolgt durch Betätigung der rechten Maustaste. Die darin enthaltenen Menüpunkte können mit der linken Maustaste angewählt werden. Auch Kontextmenüs können wieder in Untermenüs strukturiert sein.

Der Vorteil von Kontextmenüs liegt an der besseren Übersicht und schnelleren Auffindbarkeit von Funktionen.

Benutzerhilfe
390

L

[tbl-15.md](tbl-15.md)

M

[tbl-16.md](tbl-16.md)

<!-- PDF page 391 -->

Benutzerhilfe
391

[tbl-17.md](tbl-17.md)

O

Objekt
Beispiele für Objekte sind ein Dokument, eine Person, ein Stellvertreter oder ein Ordner. Jedes Objekt besitzt verschiedene Eigenschaften (Metadaten), die mit Informationen, welche das Objekt beschreiben sollen, befüllt werden können. So kann beispielsweise bei einem Eingangsdokument ein Zustelldatum oder bei einem Absender die Wohnadresse erfasst werden.

<!-- PDF page 392 -->

Benutzerhilfe
392

[tbl-18.md](tbl-18.md)

<!-- PDF page 393 -->

Benutzerhilfe
393

[tbl-19.md](tbl-19.md)

S

[tbl-20.md](tbl-20.md)

<!-- PDF page 394 -->

[tbl-21.md](tbl-21.md)

Benutzerhilfe
394

<!-- PDF page 395 -->

Dokumenttyp, Textbaustein, Statischer Testbaustein (Word), Textbaustein-Kategorie, Vorlagensammlung, Vorlagenkategorie und Schlagworte.

- Registrar/-in: Wird in Vorgang-ACLs durch die Vergabe von mehr Rechten berücksichtigt und hat die Möglichkeit, Nicht-Standard-Dateiformate als Objekte der Klasse "Inhalt" zu importieren.
- Schriftgutverwalter: Wird in Vorgang-ACLs speziell berücksichtigt, hat die Möglichkeit, Nicht-Standard-Dateiformate als Objekte der Klasse "Inhalt" zu importieren und kann Schlagworte erzeugen und bearbeiten.
- Fachadministrator: Vereinigt alle Rechte der bisher genannten Stellen (mit Ausnahme des Datenschutzbeauftragten) und wird in sämtlichen ACLs speziell berücksichtigt. Zusätzlich können (am Schreibtisch) folgende Objekte erzeugt und verwaltet werden: Benutzer, Organisationseinheit, Feiertagstabelle, Feiertag, Zeitspanne, Suchmuster, Suchordner, Prozessdefinition, Frist und Verwaltungswerkzeug. Des Weiteren kann der Fachadministrator den Globalen Papierkorb des Mandanten zu verwalten.
- OE-Administrator: Hat die gleichen Rechte wie der Fachadministrator, jedoch muss die Organisationseinheit des zu bearbeitenden Objekts der Organisationseinheit des Benutzers untergeordnet sein. Das Suchen nach Globalen Papierkörben ist dem OE-Administrator jedoch untersagt.
- Support: Verfügt über die gleichen Berechtigungen wie der Fachadministrator. Zusätzlich ist es ihm möglich, Mandanten zu suchen und abzulegen sowie den Globalen Papierkorb des Mandanten zu verwalten.
- Domänenadministrator: Verfügt domänenweit über Berechtigungen auf sämtliche Objekte.

Hinweis: Unter dem allgemeinen Begriff „Administratoren“ sind generell die Stellen „Fachadministrator“, „Support“ und „Domänenadministrator“ zu verstehen.

[tbl-22.md](tbl-22.md)

Benutzerhilfe
395

<!-- PDF page 396 -->

Benutzerhilfe
396

oder Personen. Als Suchkriterien dienen dabei Metadaten des gesuchten Objekts, z.B. Eigentümer. Es ist ebenfalls möglich, mittels Volltextsuche in Inhalten zu suchen, z.B. von Microsoft Word-Objekten.

Die Suchmöglichkeiten und Suchergebnisse unterliegen den jeweiligen Zugriffsrechten des betreffenden Benutzers. Objekte, die den Suchkriterien entsprechen, werden nur dann im Suchergebnis angezeigt, wenn die betreffende Person über das entsprechende Suchrecht verfügt.

Das Suchergebnis wird in einer eingeschränkten Objektliste, auch Trefferliste genannt, angezeigt. Objekte in der Trefferliste können je nach Zugriffsrechten direkt geöffnet und bearbeitet werden. Eine Trefferliste kann in eine Ablage z.B. in einen Ordner übernommen werden.

Basierend auf einer Trefferliste kann die durchgeführte Suche mithilfe der Schaltfläche „Suche ändern“ geändert werden. Die maximale Trefferanzahl ist konfigurierbar.

[tbl-23.md](tbl-23.md)

T

Tastenkombination

Eine Tastenkombination ist eine Alternative zur Maus. Sie ermöglichen das schnellere Ausführen von Funktionen.

Falls es für eine Aktion eine Tastenkombination gibt, wird diese in der Regel beim zugehörigen Menüeintrag mit der Tastenkombination Strg + Umschalttaste + ? angezeigt (z.B. „Weiter“ Alt+W). Der Befehl „Weiter“ kann also auch aufgerufen werden, indem die Alt-Taste gedrückt bleibt, während die W-Taste betätigt wird. Tastenkombinationen mit der Strg-Taste funktionieren äquivalent. Eine Typische Tastenkombination, welche auch außerhalb der Fabasoft eGov-Suite Bayern häufig verwendet wird, ist Strg+C (kopieren).

Es empfiehlt sich, Tastenkombinationen für einige, häufig benötigte Aktionen zu verwenden. Das Arbeiten kann somit wesentlich effizienter gestaltet werden.

<!-- PDF page 397 -->

Benutzerhilfe
397

[tbl-24.md](tbl-24.md)

U

# Umlaufmappe

Eine Umlaufmappe kann in einem Vorgang, am Schreibtisch und in Ordnern erzeugt werden. Sie sind immer einem Vorgang zugeordnet.

- Arbeitsdokumente:
Die Arbeitsdokumente einer Umlaufmappe sind die Hauptdokumente der Umlaufmappe. Sie werden bei den Zeichnungsverfahren bzw. Aktivitäten (z.B. Versenden) verwendet. Erlaubt sind darin ausschließlich registrierte Dokumente. Die Dokumente können aber auch aus fremden Vorgängen stammen. Das Hinzufügen/Entfernen von Objekten ist bis zum Abschluss der Umlaufmappe möglich, mit der Einschränkung, dass sich immer mindestens ein Dokument in den Arbeitsdokumenten einer aktiven Umlaufmappe befinden muss. Der direkte Import von Schriftstücken wird auch unterstützt. Dabei wird ein Schriftstück automatisch (ohne Erzeugen Dialog) als

<!-- PDF page 398 -->

registrierte Erledigung erfasst. Bereits erfasste Schriftstücke bzw. Teamroom Schriftstücke können nicht eingefügt werden.

**Hinweis:** In den Arbeitsdokumenten können nur dann Dokumente direkt erzeugt werden (bzw. auch per direktem Import von Schriftstücken), wenn der Benutzer ausreichend Rechte auf den übergeordneten Vorgang der Umlaufmappe hat. Der Benutzer erhält bei unzureichenden Rechten eine entsprechende Hinweismeldung.

- „Ergänzende Dokumente“:
Die Liste „Ergänzenden Dokumente“ bietet die Möglichkeit, zur Umlaufmappe Dokumente/Schriftstücke beizufügen, welche zwar für die Umlaufmappe relevant sind, aber nicht gezeichnet werden. Im Gegensatz zu den Arbeitsdokumenten können auch nicht registrierte Dokumente eingefügt werden. Schriftstücke sind nur dann in der Liste erlaubt, wenn sie noch nicht erfasst wurden bzw. noch nicht einem Teamroom zugeordnet sind. Beim direkten Import eines Schriftstücks erfolgt keine Erfassung. Die Schriftstücke lassen sich aber wie gewohnt über die Menüaktion „Als Dokument erfassen“ registrieren.

**Hinweis:** Wenn die Umlaufmappe gesperrt ist, wird die Menüaktion „Als Dokument erfassen“ ausgeblendet. Dies verhindert, dass es beim Abschluss der Aktion zu einer Sperrmeldung kommt, wenn der Benutzer die Aktion über das Bearbeiten Formular ausführt.

V

**Verfügungen**

Verfügungen werden verwendet, um die nächste Aktivität im Zuge der formalen Erledigung eines Vorgangs festzulegen. Mithilfe von Verfügungen können Laufwege in der Fabasoft eGov-Suite ad hoc angepasst werden, die Prozessverantwortung bleibt dabei unverändert.

Bei einer Verfügung wird die verfügte Aktivität zwischen der aktuellen und der nächsten Aktivität im Laufweg eingefügt. Eine ausführliche Beschreibung der Aktivitäten, die in der Fabasoft eGov-Suite Bayern verfügt werden können, finden Sie in Kapitel 7 „Aktivitäten“.

Sie haben die Möglichkeit, in einem Laufweg mehrere Aktivitäten für die jeweils betroffene Person mit einem Termin für die betreffende Aktivität festzulegen.

Benutzerhilfe
398

<!-- PDF page 399 -->

Benutzerhilfe
399

Versandarten
Folgende Versandarten stehen bei der Versendung u.a. zur Verfügung:

- „Papier“
Für alle Empfänger, bei denen als Versandart „Papier“ ausgewählt ist, wird ein Fenster geöffnet, in dem die Reinschriften und die dazugehörigen Anlagen für den Papierversand angezeigt werden. Sie können im Zuge der Endkontrolle die elektronischen Schriftstücke öffnen und für den Versand ausdrucken.

- „Fax“
Wenn bei einem Empfänger als Versandart „Fax“ ausgewählt ist, wird eine E-Mail geöffnet, in der die Fax-Adressinformation des Empfängers eingetragen ist. Der weitere Ablauf entspricht dem Vorgehen bei einer E-Mail-Versendung.
**Hinweis:** Diese Vorgangsweise funktioniert nur, wenn ein E-Mail-Programm (z.B. Microsoft Outlook) mit Ihrem E-Mail Postfach verknüpft ist.

- „E-Mail“
Wenn bei einem Empfänger als Versandart „E-Mail“ eingetragen ist, wird eine E-Mail geöffnet, in der die E-Mail-Adressinformation des Empfängers eingetragen ist und als Anhang die für diesen Empfänger generierte Reinschrift und die dazugehörigen Anlagen eingefügt sind. Sie können im Sinne einer Endkontrolle die E-Mail und die Anlagen prüfen und die E-Mail versenden. Die versendeten E-Mails können als Dokumente beim Vorgang hinterlegt werden. Falls Lese- und Empfangsbestätigungen angefordert werden, können diese bei den E-Mails eingesehen werden.

- „E-Mail: Signiert (qualifiziert)“, „E-Mail: Signiert (fortgeschritten)“
Funktionsweise entspricht „E-Mail“.

- „Elektronische Zustellung (XML)“
Wenn bei einem Empfänger als Versandart „Elektronische Zustellung (XML)“ eingetragen ist, wird ein XDOMEA XML-Dokument erstellt welches anschließend exportiert werden kann.

- „Intern“
Wenn bei einem Empfänger als Versandart „Intern“ eingetragen ist, wird eine Aktivität *Interner Eingang* auf einem Versandkuvert erzeugt, welche Kopien der versendeten Schriftstücke enthält. Als Empfänger sind nur Personen und Organisationen möglich, für die in der Fabasoft eGov-Suite Bayern ein Benutzer bzw. eine Organisationseinheit referenziert ist.

Version
Die Fabasoft eGov-Suite Bayern ermöglicht das Speichern eines Objekts als Version. Dabei werden die Metadaten und die Inhalte des Objekts als Version gesichert. Dadurch ist es möglich, das Objekt

<!-- PDF page 400 -->

auf einen Zeitpunkt in der Vergangenheit zurückzusetzen, um den damaligen Zustand des Objekts einzusehen.

Generell werden Versionen von Objekten entweder automatisch durch das System oder durch explizite Benutzerinteraktion erstellt.

Ein Beispiel für das Sichern einer Version ist das Anbringen einer elektronischen Unterschrift. Dadurch wird eine Bearbeitungsphase nachvollziehbar abgeschlossen und durch Sichern einer revisionssicheren Version dokumentiert (z.B. Verfasserversion, Versandversion).

Die folgenden Regeln gelten sowohl bei der automatischen, als auch bei der benutzerdefinierten Versionierung:

- Beim Sichern einer Version werden die folgenden Informationen gespeichert:
- Versionsnummer
- Beschreibung
- Ersteller der Version
- Erstelldatum der Version
- Automatische oder explizite Version
- Vorher gesicherte Versionen sind nicht änderbar.

In den folgenden Fällen wird eine automatische Version erstellt:

- Bei einem Benutzerwechsel
Automatische Versionen von Objekten werden erstellt, wenn ein Benutzerwechsel erfolgt. Eine Version wird also gesichert, wenn eine Person ein Objekt bearbeitet, die ungleich jener Person ist, die die letzte Änderung an dem betroffenen Objekt vorgenommen hat.
- Bei der Ausführung von Unterschriften
Automatische Versionen von Geschäftsobjekten werden erstellt, wenn eine Unterschrift an dem Geschäftsobjekt angebracht wird. Ob eine Version erstellt wird, sowie die Art der Versionierung wird durch die Unterschriftenart bestimmt.

Die Anzahl der Versionen bei einem Objekt ist nicht begrenzt, kann aber administrativ gesteuert werden (Vorgabe der maximalen Anzahl von Versionen bei einem Objekt bzw. der ältesten Version, die erhalten bleiben soll).

## Verteilerlisten

Mithilfe von Verteilerlisten können Verfügungen an mehrere Teilnehmer gleichzeitig definiert werden. Die definierten Teilnehmer erhalten die verfügte Aktivität parallel in ihren Arbeitsvorrat. Im Gegensatz zu Verfügungsmustern werden dabei nur die Teilnehmerinformationen definiert, die gewünschte Aktivität wird bei der Verfügung selbst angegeben.

Benutzerhilfe
400

<!-- PDF page 401 -->

Benutzerhilfe
401

Vorgang
Ein Vorgang ist eine Untereinheit der Akten und fasst Schriftstücke und Dokumente zusammen. Die Erzeugung eines solchen ist sowohl im „Aktenplan“ als auch am „Schreibtisch“ möglich.

Abhängig von den Medien der Schriftstücke, die einem Vorgang zugeordnet werden, können in der Fabasoft eGov-Suite drei Arten von Vorgängen unterschieden werden:
- Elektronischer Vorgang/Akte
- Papiervorgang/-akte
**Hinweis:** Wenn in der Benutzereinstellung die Ansicht „e-Registratur“ eingestellt ist, wird automatisch beim Erzeugen eines Vorgangs dieser Eintrag gesetzt.
- Hybridvorgang/-akte

Zur Unterscheidung dieser drei Arten steht in den Metadaten des Vorgangs die Eigenschaft *Original* zur Verfügung. Für nähere Informationen siehe Kapitel 6.9.1 „Registerkarte „Vorgang““.

Vorlagensammlung
In einer Vorlagensammlung werden Objekte hinterlegt, die als Vorlagen verfügbar sein sollen, wenn neue Objekte erzeugt werden. Vorlagensammlungen können z.B. in der Arbeitsumgebung von Benutzern eingetragen werden. In diesem Fall stehen Vorlagen nur für den jeweiligen Benutzer zur Verfügung. Um allen Benutzern die Vorlagen zur Verfügung zu stellen, muss dies von Benutzern mit der Stelle „Fachadministrator“ oder „OE-Administrator“ entsprechend konfiguriert werden.

W

Wiedervorlage
In der Fabasoft eGov-Suite Bayern besteht die Möglichkeit einer Wiedervorlage von Schriftstücken (soweit zur Information verfügt), Dokumenten und Vorgängen, d.h. die Bearbeitung eines Schriftstücks, Dokuments oder Vorgangs kann verschoben und nach einem bestimmten Zeitraum wiederaufgenommen werden.

Windows-Explorer
Der Windows-Explorer ist Bestandteil des Betriebssystems Microsoft Windows. Mit diesem Explorer können unter anderem Dateien gesucht, ausgeführt, kopiert, gelöscht und umbenannt werden. Der Aufruf des Microsoft Windows-Explorers kann z.B. mittels der Tastenkombination Windows+E erfolgen.

<!-- PDF page 402 -->

Benutzerhilfe
402

# X

[tbl-0.md](tbl-0.md)

# Z

[tbl-1.md](tbl-1.md)

<!-- PDF page 403 -->

Benutzerhilfe
403

Mit dieser Tabelle kann genau festgelegt werden, wer welche Rechte auf ein Objekt besitzt. Da aber nicht für jeden einzelnen Benutzer ein eigener Eintrag in dieser Tabelle erzeugt werden soll, können Benutzer in Organisationseinheiten und Stellen zusammengefasst werden. Beispielsweise gewährt man allen Mitarbeitern der Abteilung X Leserechte auf bestimmte Objekte, alle Abteilungsleiter erhalten Änderungsrechte und dürfen diese Objekte demnach auch verändern. Diese Rechte können für einzelne Objekte (z.B. ein bestimmtes Dokument) oder auch für einen Typ (z.B. alle Dokumente oder Vorgänge) zur Anwendung kommen.

Zwischenablage
Die Zwischenablage ist ein temporärer Speicher, in den Daten gelegt werden können. Die Daten sind solange vorhanden, bis sie entweder durch einen neuen Speichervorgang in die Zwischenablage überschrieben werden, oder der Computer abgeschaltet bzw. neu gestartet wird.

Wird ein Objekt mithilfe des Kontextmenüeintrages „Kopieren“ in die Zwischenablage gelegt, kann diese meist auf mehrere Arten wieder eingefügt werden:
- Das „Duplikat einfügen“: dabei wird eine Kopie der Datei an der gewünschten Stelle eingefügt.
- Das „Verknüpfung einfügen“ dabei wird lediglich ein neuer Zeiger auf das alte Objekt eingefügt.
- Die Tastenkombination Strg+V (verhält sich wie „Verknüpfung einfügen“).